# Qt5 CMake 工程

一个使用 CMake 构建的简单 Qt5 应用程序。

## 前置条件

- CMake 3.10+
- Qt5
- 支持 C++11 的编译器

## 构建步骤

### Windows (Visual Studio)

```bash
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022"
cmake --build . --config Release
```

### Linux/macOS

```bash
mkdir build
cd build
cmake ..
make
```

## 运行

构建完成后，在 `build` 目录下运行：

```bash
./Qt5Demo
```

## 项目结构

```
.
├── CMakeLists.txt      # CMake 配置文件
├── main.cpp            # 主程序入口
├── mainwindow.h        # 主窗口头文件
├── mainwindow.cpp      # 主窗口实现
└── README.md           # 本文件
```
