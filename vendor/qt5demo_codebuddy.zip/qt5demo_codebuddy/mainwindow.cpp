#include "mainwindow.h"
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QWidget>
#include <QMenuBar>
#include <QStatusBar>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUI();
}

MainWindow::~MainWindow()
{
}

void MainWindow::setupUI()
{
    // 创建中心部件
    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    // 创建布局
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);

    // 添加标签
    QLabel *label = new QLabel("Hello, Qt5!", this);
    label->setAlignment(Qt::AlignCenter);
    layout->addWidget(label);

    // 添加按钮
    QPushButton *button = new QPushButton("Click Me", this);
    layout->addWidget(button);

    // 信号槽连接
    connect(button, &QPushButton::clicked, [label]() {
        static int count = 0;
        label->setText(QString("Hello, Qt5! (Clicked %1 times)").arg(++count));
    });

    // 创建菜单
    QMenuBar *menuBar = this->menuBar();
    QMenu *fileMenu = menuBar->addMenu("File");

    QAction *exitAction = fileMenu->addAction("Exit");
    connect(exitAction, &QAction::triggered, this, &QMainWindow::close);

    // 状态栏
    statusBar()->showMessage("Ready");
}
