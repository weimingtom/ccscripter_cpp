#pragma once

#include <string>

class NSNumber {
public:
	std::string *stringValue() {
		return NULL;
	}
	static NSNumber *numberWithInt(int x) {
		return NULL;	
	}
};

class NSString {
public:
	bool isEqualToString(const char *x) {
		return false;	
	}
};

class NSArray {
public:

};

class NSMutableArray {
public:
	void insertObject(void *obj, int index)
	{
		
	}
	void *objectAtIndex(int index)
	{
		return NULL;
	}
};

