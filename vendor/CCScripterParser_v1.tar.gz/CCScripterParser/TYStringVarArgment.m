//
//  TYStringVarArgment.m
//  Tukuyomi
//
//  Created by toveta on Wed Apr 09 2003.
//  Copyright (c) 2003 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#import "TYStringVarArgment.h"
#import "TYScriptEngine.h"

@implementation TYStringVarArgment
+(id)argmentWithVarID:(id)aObj
{
    return [ [ [ self alloc ] initWithVarID:aObj ] autorelease ];
}

-(id)initWithVarID:(id)aObj
{
    self = [ super init ];
    
    varID = [ aObj retain ];
    
    return self;
}

// override
-(id)varID
{
    return [ varID intNumber ];
}

-(TYVarType)varType
{
    return TYStringVarType;
}

-(TYArgType)argType
{
    return TYStringVarArgType;
}

-(NSString*)stringObj
{
    return [ [ TYScriptEngine sharedEngine ] stringValueWithVarID:[ self varID ] ]; 
}

- (void)dealloc
{
	[varID release];
	[super dealloc];
}

@end
