#pragma once

#include "Foundation/Foundation.h"

class TYScriptEngine {
public:
	static TYScriptEngine *sharedEngine() 
	{
		return NULL;	
	}

	void eval(void *x)
	{

	}
	void incRunColumn()
	{
	}

	void registLoopTargetID(void *x1, void *x2, void *x3, void *x4)
	{
		
	}
	void resetRunColumn() {
	}
	void *judgefchk(void *) {
		return NULL;	
	}
	void *judgelchk(void *) {
		return NULL;	
	}
	void addLabelLog(NSString *)
	{
		
	}
	void moveRunLine(int fix)
	{
	}
	char *nextLine()
	{
		return NULL;
	}
};

