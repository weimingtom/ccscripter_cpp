//
//  TYArgment.h
//  YLLinkTest
//
//  Created by toveta on Sun Apr 06 2003.
//  Copyright (c) 2003 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#pragma once
#include "Foundation/Foundation.h"

typedef enum {
    TYNotVarType=0,
    TYStringVarType=1,
    TYIntVarType=2,
    TYArrayVarType=3,
    TYDigitVarTypeMask=2
} TYVarType;

typedef enum {
    TYDigitArgType,
    TYConstStringArgType,
    TYIntVarArgType,
    TYStringVarArgType,
    TYAliasArgType,
    TYFchkArgType
} TYArgType;

// Nスクの引数のベースクラス
class TYArgment {
// 下記メソッドのうち、必要なものをオーバーライドすること
public:
	void *varID() {
		return NULL;	
	}
//-(TYVarType)varType;
//-(TYArgType)argType;
	NSNumber *intNumber() {
		return NULL;	
	}
//-(NSString*)stringObj;
//-(NSString*)rawString;
// ここまで
	int intValue() {
		return 0;	
	}
};

// 下位3ビットが真となる比較結果のフラグを表す
typedef enum { 
    TYEqualOpType=2,
    TYNotEqualOpType=1|4,
    TYGreatThanOpTYpe=4,
    TYGreatOrEqualOpType=2|4,
    TYLessThanOpType=1,
    TYLessOrEqualOpType=1|2
} TYOpType;

// 引数比較用の関数
bool TYCompareArgment(void *,void *,TYOpType);

