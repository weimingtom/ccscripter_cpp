/*
 *  TYBitOperator.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYBitOperator_qt.h"
#include <QDebug>
#include <unistd.h>  // for read()

TYBitOperator::TYBitOperator(QFile* f, size_t s, QObject* parent)
    : QObject(parent)
    , fh(f)
    , size(s)
    , mask(0x100)
    , tmp(0)
{
    // Replaces: fh = [ f retain ];
    // Note: QFile is implicit shared, no need to retain
    
    // Replaces: tmp = *(unsigned char*)[ [ fh readDataOfLength:1 ] bytes ];
    QByteArray byte = fh->read(1);
    if (!byte.isEmpty()) {
        tmp = static_cast<unsigned char>(byte[0]);
    }
}

TYBitOperator::~TYBitOperator()
{
    // Replaces: [ fh release ]; (automatic in Qt)
}

// Replaces: -(int)get
int TYBitOperator::get()
{
    mask >>= 1;
    if (mask == 0x00) {
        Q_ASSERT_X(size != 0, "TYBitOperator::get", "Over Limit Size");
        size--;
        QByteArray byte = fh->read(1);
        if (!byte.isEmpty()) {
            tmp = static_cast<unsigned char>(byte[0]);
        }
        mask = 0x80;
    }
    return (tmp & mask) ? 1 : 0;
}

// Replaces: -(unsigned int)getWithLength:(int)n
unsigned int TYBitOperator::getWithLength(int n)
{
    unsigned int v = 0;

    Q_ASSERT_X(n > 0 && n <= 32, "TYBitOperator::getWithLength", "invalid bit length");

    for (v = 0; n > 0; n--) {
        v <<= 1;
        if (get())
            v |= 1;
    }
    return v;
}

// C-style struct functions

// Replaces: TYCoreBitOperater TYCreateCoreBitOperater(NSFileHandle* f, unsigned int s)
TYCoreBitOperator* TYCreateCoreBitOperator(QFile* f, unsigned int s)
{
    TYCoreBitOperator* mySelf = new TYCoreBitOperator;
    if (mySelf == nullptr)
        return nullptr;
    
    // Replaces: mySelf->fd = [ f fileDescriptor ]
    mySelf->fd = f->handle();
    mySelf->mask = 0x100;
    
    // Replaces: result = read(mySelf->fd, &mySelf->tmp, 1);
    ssize_t result = ::read(mySelf->fd, &mySelf->tmp, 1);
    if (!result) {
        TYReleaseCoreBitOperator(mySelf);
        return nullptr;
    }
    
    return mySelf;
}

// Replaces: __inline__ int TYGetCoreBitOperater(TYCoreBitOperater)
inline int TYGetCoreBitOperator(TYCoreBitOperator* mySelf)
{
    mySelf->mask >>= 1;
    if (mySelf->mask == 0x00) {
        ::read(mySelf->fd, &mySelf->tmp, 1);
        mySelf->mask = 0x80;
    }
    return (mySelf->tmp & mySelf->mask) ? 1 : 0;
}

// Replaces: __inline__ unsigned int TYGetBitsCoreBitOperater(TYCoreBitOperater, int)
inline unsigned int TYGetBitsCoreBitOperator(TYCoreBitOperator* mySelf, int n)
{
    unsigned int v = 0;

    for (int i = 0; i < n; i++) {
        v <<= 1;
        
        mySelf->mask >>= 1;
        if (mySelf->mask == 0x00) {
            ::read(mySelf->fd, &mySelf->tmp, 1);
            mySelf->mask = 0x80;
        }
        if (mySelf->tmp & mySelf->mask)
            v |= 1;
    }
    return v;
}

// Replaces: void TYReleaseCoreBitOperater(TYCoreBitOperater)
void TYReleaseCoreBitOperator(TYCoreBitOperator* mySelf)
{
    delete mySelf;
}