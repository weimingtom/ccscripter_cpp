/*
 *  TYCartainEffectGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYCartainEffectGenerater_qt.h"
#include <QPainter>

const int PIXEL_OF_COLUMN_CARTAIN = 24;

TYCartainEffectGenerater::TYCartainEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                                                 TYEffectDefinitionValue* effect, QObject* parent)
    : QObject(parent)
    , m_beforeImage(beforeImage)
    , m_afterImage(afterImage)
    , m_beforePhase(0)
    , m_isComplete(false)
{
    TYEffectDefinition effdef = effect->definition();
    
    switch (effdef.type) {
    case TYEffectTopCartain:
        m_reverse = true;
        m_horizontal = false;
        break;
    case TYEffectRightCartain:
        m_reverse = true;
        m_horizontal = true;
        break;
    case TYEffectLeftCartain:
        m_reverse = false;
        m_horizontal = true;
        break;
    default:
        m_reverse = false;
        m_horizontal = false;
        break;
    }
    
    m_pixelOfColumn = PIXEL_OF_COLUMN_CARTAIN;
    
    if (m_horizontal) {
        m_numberOfColumn = m_beforeImage.width() / PIXEL_OF_COLUMN_CARTAIN;
        m_phaseMax = PIXEL_OF_COLUMN_CARTAIN + m_numberOfColumn - 1;
        m_pointMax = m_beforeImage.width();
        m_remainder = m_beforeImage.width() % PIXEL_OF_COLUMN_CARTAIN;
    } else {
        m_numberOfColumn = m_beforeImage.height() / PIXEL_OF_COLUMN_CARTAIN;
        m_phaseMax = PIXEL_OF_COLUMN_CARTAIN + m_numberOfColumn - 1;
        m_pointMax = m_beforeImage.height();
        m_remainder = 0;
    }
    
    m_effectTime = effdef.time;
    m_phaseInterval = effdef.time / 1000.0 / m_phaseMax;
    m_startDate = QDateTime::currentDateTime();
    m_currentImage = m_beforeImage;
    
    QTimer::singleShot(0, this, SLOT(drawEffect()));
}

TYCartainEffectGenerater::~TYCartainEffectGenerater()
{
}

void TYCartainEffectGenerater::drawEffect()
{
    qint64 elapsed = m_startDate.msecsTo(QDateTime::currentDateTime());
    int phase = (elapsed * m_phaseMax) / m_effectTime;
    
    if (phase >= m_phaseMax) {
        m_currentImage = m_afterImage;
        m_isComplete = true;
        emit effectImageChanged(m_currentImage);
        emit effectFinished();
        return;
    }
    
    int movePhase = phase - m_beforePhase;
    if (movePhase == 0) {
        QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
        return;
    }
    
    m_currentImage = m_beforeImage.copy();
    QPainter painter(&m_currentImage);
    
    int w, h, x, y;
    int* mp;
    
    if (m_horizontal) {
        w = 1;
        h = m_beforeImage.height();
        y = 0;
        mp = &x;
    } else {
        w = m_beforeImage.width();
        h = 1;
        x = 0;
        mp = &y;
    }
    
    for (int currentPhase = m_beforePhase + 1; currentPhase <= phase; currentPhase++) {
        for (int i = 0, loc = currentPhase - 1; i < m_numberOfColumn; i++, loc--) {
            if (loc >= 0 && loc < PIXEL_OF_COLUMN_CARTAIN) {
                *mp = m_reverse ? (m_pointMax - PIXEL_OF_COLUMN_CARTAIN * i - loc - 1) 
                                 : (PIXEL_OF_COLUMN_CARTAIN * i + loc);
                painter.drawImage(x, y, m_afterImage, x, y, w, h);
            }
        }
        // Handle remainder
        if (m_remainder) {
            int loc = currentPhase - 1 - m_numberOfColumn;
            if (loc >= 0 && loc < m_remainder) {
                *mp = m_reverse ? (m_pointMax - m_pixelOfColumn * m_numberOfColumn - loc - 1)
                                 : (m_pixelOfColumn * m_numberOfColumn + loc);
                painter.drawImage(x, y, m_afterImage, x, y, w, h);
            }
        }
    }
    
    painter.end();
    m_beforePhase = phase;
    
    emit effectImageChanged(m_currentImage);
    
    QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
}