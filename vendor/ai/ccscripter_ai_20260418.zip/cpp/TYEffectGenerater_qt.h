/*
 *  TYEffectGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Base class for effect generators that create transition effects.
 */

#ifndef TYEFFECTGENERATER_QT_H
#define TYEFFECTGENERATER_QT_H

#include <QObject>
#include <QImage>

class TYEffectDefinitionValue;

class TYEffectGenerater : public QObject
{
    Q_OBJECT
    
public:
    // Constructor for image transition effects
    TYEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                     TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    
    // Constructor for quake/shake effects
    TYEffectGenerater(const QImage& image, int quakeType, int times, int second,
                     QObject* parent = nullptr);
    
    virtual ~TYEffectGenerater();
    
    // Set delegate
    void setDelegate(QObject* delegate) { m_delegate = delegate; }
    
    // Get current effect image
    QImage currentImage() const { return m_nowImage; }
    
    // Check if effect is complete
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
protected:
    // Draw effect - to be overridden by subclasses
    virtual void drawEffect();
    
    QImage m_beforeImage;
    QImage m_afterImage;
    QImage m_nowImage;
    QObject* m_delegate;
    bool m_isComplete;
};

#endif // TYEFFECTGENERATER_QT_H