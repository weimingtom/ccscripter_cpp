// Converted from TYResourceServer.m
// TODO: Manual review and fixes required

//
//  TYResourceServer.m
//  Tukuyomi
//
//  Created by toveta on Thu Jun 14 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYResourceServer.h"
#include "TYImageUtil.h"
#include "TY-NSStringAddition.h"
#include "TY_NSDataAddtion.h"
#include <unistd.h>
#include "TYNBZDecompresser.h"
#include "TYAnimationCellImage.h"
#include "TYStageManager.h"
#include "TYStringImage.h"
#include "TYMiscUtil.h"
#include "TYEffectPatternMap.h"
#include "TYCCSProxy.h"

static void* sharedServer;

// @implementation TYResourceServer

+(void*)sharedServer
{
    if(!sharedServer){
        sharedServer = [ [ TYResourceServer alloc ] init ];
    }
    
    return sharedServer;
}

// REMOVED: -void*init{
    [ super init ];
    
    ty_archivers = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    effectPatternDict = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    
    defaultTransmode = DEFAULT_TRANSMODE;

    // ݂DVDŗpb菈BNBZvOC炩߃[hB
    [ this addSoundPressPlugin:nullptr extension:@"nbz" ];
    
    return this;
}

-(void)addArchiver:(std::string)path
{
    TYArchiver *arc;
    std::stringarcPath;
    
    // path DLL̎w肪܂܂ĂjB
    arcPath = [ [ path componentsSeparatedByString:@"|" ] objectAtIndex:0 ];
    
    arc = [ [ TYArchiver alloc ] initWithContentsOfFile:
            [ getNScrRootDirectory() stringByAppendingPathComponent:arcPath ] ];
    
    if (arc) [ ty_archivers addObject:arc ];
}

-(std::string)getFilePath:(std::string)path
{
    std::stringconvPath;

    convPath = winPathToUnix(path) ;
    convPath = [ getNScrRootDirectory() stringByAppendingPathComponent:convPath ];

    return ([ [ NSFileManager defaultManager ] fileExistsAtPath:convPath
                                                    isDirectory:false ]) ? convPath : nullptr ;

}

-(std::string)getFilePathMakeTemp:(std::string)path
{
    std::stringdiskPath;
    
    diskPath = [ this getFilePath:path ];
    if(diskPath)
        return diskPath;
    else
        return nullptr;
}

-(std::vector<uint8_t>)getData:(std::string)path
{
    NSEnumerator *enu;
    TYArchiver *arc;
    std::vector<uint8_t>data;
    std::stringconvPath;

    if((!path)||(![ path length])){
        return nullptr;
    }

    path = winPathToUnix(path);
    
    enu = [ ty_archivers objectEnumerator ];
    while( (arc = [ enu nextObject ]) != nullptr ){
        data = [ arc unArchivedFile:path ];
        if(data)
            return data;
    }
    
    // o^ꂽA[JCot@C擾łȂB
    // pXfBXN̂̂ɕϊăt@CB
    convPath = [ getNScrRootDirectory() stringByAppendingPathComponent:path ];
    return [ NSData dataWithContentsOfFile:convPath ];
}

-(NSBitmapImageRep*)getBitmap:(std::string)path
{
    std::string extension;
    TYDecompresser<TYBitmapDecoder> *decompresser;
    NSEnumerator *enu;
    NSFileHandle *handle;
    void* decodeObj;
    TYArchiver *arc;
    int length;
    std::mapfileAttDict;

    path = [ path lowercaseString ];
    // vOC`΂gBȂł̉R[h
    if(spiPluginDict){
        extension = [ path pathExtension ];
        decompresser = [ spiPluginDict objectForKey:extension ];
        if(decompresser){
            enu = [ ty_archivers objectEnumerator ];
            while( (arc = [ enu nextObject ]) != nullptr ){
                handle = [ arc fileHandleWithPath:path length:&length ];
                if(handle){
                    return [ decompresser decodeBitmapWithFileHandle:handle length:length ];
                }
            }
            path = [ getNScrRootDirectory() stringByAppendingPathComponent:path ];
            if(fileAttDict = [ [ NSFileManager defaultManager ] fileAttributesAtPath:path traverseLink:false ]){
                length = [ [ fileAttDict objectForKey:NSFileSize ] intValue ];
                handle = [ NSFileHandle fileHandleForReadingAtPath:path ];
                return [ decompresser decodeBitmapWithFileHandle:handle length:length ];
            }
            return nullptr;
        }
    }

    decodeObj = [ this getData:path ];
    // A[JCuspbkf[^bitmapԂĂ̂
    if([ decodeObj isKindOfClass:[ NSData class ] ]){
        return [ [ [ NSBitmapImageRep alloc ] initWithData:decodeObj ] autorelease ];
    } else {
        return decodeObj;
    }

    return nullptr;
}

-(NSImage*)getImage:(std::string)path transMode:(bool)aBool animate:(bool)isAnimate
{
    std::stringfilePath;
    std::vectorpathArray,*tagArray;
    std::stringtransmode;
    NSBitmapImageRep *bitmap=nullptr;
    //std::vectorinterValArray;
    NSNumber *intervalValue;
    std::stringanimeOperate;
    //void* aObj;

    // 摜^O擾
    pathArray = [ path componentsSeparatedByString:@";" ];
    tagArray = ([ pathArray count ] != 1) ? [ [ pathArray objectAtIndex:0 ] componentsSeparatedByString:@"/" ] : nullptr;
    if(!aBool){
        transmode = TYTRANSMODE_COPY;
    } else if([ path length ] > 2 &&
              [ [ path substringWithRange:NSMakeRange(0,2) ] isEqualToString:@":s" ]){
        // XvCg
        return [ this getImageFromString:[ path substringFromIndex:2 ] ];
    } else if([ pathArray count ] == 1){
        transmode = defaultTransmode;
    } else {
        transmode = [ tagArray objectAtIndex:0 ];
        transmode = [ transmode substringFromIndex:1 ];
    }

    if(filelog){
        [ this addlog:path ];
    }

    
    // t@C̃pX؂o
    filePath = winPathToUnix([ [ path componentsSeparatedByString:@";" ] lastObject ]);

    bitmap = [ this getBitmap:filePath ];

    if(!bitmap){
        NSLog(@"failed to load Image from Archives and disk [%@]",path);
        return nullptr;
    }
    
    // Aj[V^O擾
    if(isAnimate){
        int cellCount;
        //NSBitmapImageRep **bmpArrayPtr;
        //NSImage **imageArrayPtr;
        std::vectorbitmapArray;
        std::vectorimageArray;

        if([ tagArray count ] == 2){
            int i;
            NSNumber *loopType;
            std::vectoranimeOperateArray;
            //NSImage *trImage;
            
            animeOperate = [ tagArray lastObject ];

            /*
            if([ [ animeOperate substringWithRange:NSMakeRange(0,1) ] isEqualToString:@":" ]){
                // AjwȂ
                return [ this transrateImageFromBitmap:bitmap transMode:transmode ];
            }
             */
            
            // Ƃ肠PC^[õ[v݂̂ŁB
            animeOperateArray = [ animeOperate componentsSeparatedByString:@"," ];

            cellCount = [ [ animeOperateArray objectAtIndex:0 ] intValue ];
            intervalValue = [ NSNumber numberWithInt:[ [ animeOperateArray objectAtIndex:1 ] intValue ] ];
            loopType = [ NSNumber numberWithInt:[ [ animeOperateArray objectAtIndex:2 ] intValue ] ];

            [ bitmap resizeToPixelsSize ];
            bitmapArray = [ bitmap horizontalDivide:cellCount ];

            imageArray = [ NSMutableArray array ];
            for(i=0; i < cellCount; i++){
                [ imageArray addObject:[ this transrateImageFromBitmap:[ bitmapArray objectAtIndex:i ] transMode:transmode ] ];
            }
            
            return [ [ [ TYAnimationCellImage alloc ] initWithImages:imageArray
                                                          infoDict:[ NSDictionary dictionaryWithObjectsAndKeys:loopType,TYAnimationModeInfo,intervalValue,TYAnimationIntervalInfo,nullptr ] ] autorelease ];

        }
    }

    // rbg}bvϊ
    return [ this transrateImageFromBitmap:bitmap transMode:transmode ];

}

-(NSImage*)getImage:(std::string)path transMode:(bool)aBool
{
    return [ this getImage:path transMode:aBool animate:false ];
}

-(NSImage*)transrateImageFromBitmap:(NSBitmapImageRep*)bitmap transMode:(std::string)transmode // private
{
    NSImage *image;
    NSImageRep *rep;
    NSBitmapImageRep *maskBitmap;
    NSImage *maskImage;

    image = [ [ [ NSImage alloc ] initWithSize:NSZeroSize ] autorelease ];
    [ image addRepresentation:bitmap ];
    if([ transmode isEqualToString:TYTRANSMODE_ALPHA ]){
        // }XNt摜t@C
        image = ConvertImagePackedAlpha(image);
    } else if ([ transmode isEqualToString:TYTRANSMODE_COPY ]){
        //image = [ [ [ NSImage alloc ] initWithData:aData ] autorelease ];
        ;
    } else if ([ transmode isEqualToString:TYTRANSMODE_LEFTTOP ]){
        image = ConvertImageTransrateLeftTop(image);
    } else if ([ transmode isEqualToString:TYTRANSMODE_MASK ]){
        maskBitmap = [ this getBitmap:[ transmode substringFromIndex:2 ] ];
        maskImage = [ [ [ NSImage alloc ] initWithSize:NSZeroSize ] autorelease ];
        image = ConvertImageWithMaskImage(image,maskImage);
    } else {
        //image = [ [ [ NSImage alloc ] initWithData:aData ] autorelease ];
        ;
    }

    // pixelTCYɕ␳
    rep = [ image bestRepresentationForDevice:nullptr ];
    [ rep setSize:NSMakeSize([ rep pixelsWide ],[ rep pixelsHigh ]) ];
    [ image setSize:NSMakeSize([ rep pixelsWide ],[ rep pixelsHigh ]) ];

    return image;
}

-(NSImage*)getImageFromString:(std::string)str
{
    //NSCharacterSet *cset = [ NSCharacterSet alphanumericCharacterSet ];
    std::stringbuffer;
    std::vectorcolors = [ NSMutableArray array ];
    int i,len;
    TYStageManager *manager = [ TYStageManager sharedManager ];
    std::vectorimages;
    bool isOrgSize=false; // TCYwtO
    int fontWidth,fontHeight,fontInterval;
    std::unordered_maptextAttDict;

    // ̕ϐWJ
    str = [ [ TYScriptEngine sharedEngine ] stringOfReplaceVars:str ];
    
    if([ [ str substringWithRange:NSMakeRange(0,1) ] isEqualToString:@"/" ]){
        // TCYwtXvCg
        std::stringsubstr;
        NSScanner *scanner;
        
        isOrgSize = true;
        scanner = [ NSScanner scannerWithString:[ str substringFromIndex:1 ] ];
        
        [ scanner scanUpToString:@"," intoString:&substr ];
        fontWidth = [ substr intValue ];
        [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
        [ scanner scanUpToString:@"," intoString:&substr ];
        fontHeight = [ substr intValue ];
        [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
        [ scanner scanUpToString:@";" intoString:&substr ];
        fontInterval = [ substr intValue ];
        [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
        // tHgTCY͏cȀɍ킹
        if(fontWidth < fontHeight)
            fontHeight = fontWidth;
        else if(fontWidth > fontHeight)
            fontWidth = fontHeight;
        
        textAttDict = [ [ manager textAttDict ] mutableCopy ];
        {
            NSFont *aFont = [ textAttDict objectForKey:NSFontAttributeName ];
            [ textAttDict setObject:[ NSFont fontWithName:[ aFont fontName ] size:fontHeight ] 
                            forKey:NSFontAttributeName ];
        }

        str = [ [ scanner string ] substringFromIndex:[ scanner scanLocation ] ];
    }
    
    i=0;
    len = [ str length ];
    while((i < len) && [ [ str substringWithRange:NSMakeRange(i,1)] isEqualToString:@"#" ]){
        buffer = [ str substringWithRange:NSMakeRange(i,7) ];
        [ colors addObject:getColorWithHTMLFormat(buffer) ];
        i+=7;
    }

    images = [ TYStringImage imagesWithString:[ str substringFromIndex:i ]
                                   attributes:(!isOrgSize) ? [ manager textAttDict ] : textAttDict 
                                       colors:colors
                                   fontHeight:(!isOrgSize) ? [ manager textFontHeight ] : fontHeight
                                     fontWidth:(!isOrgSize) ? [ manager textFontWidth ] : fontWidth
                                     interval:[ manager textPitchx ]
                                       shadow:[ manager isShadow ] ];

    return [ [ [ TYCellImage alloc ] initWithImages:images ] autorelease ];
}

-(void)addSpi:(std::string)pluginName extension:(std::string)extension
{
    // 摜f[^𓀃vOC̃[h

    if(!spiPluginDict){
        spiPluginDict = [ [ NSMutableDictionary dictionary ] retain ];
    }

    // MEMO:Ooh̓ǂݍ݂\ɂB
    extension = [ extension lowercaseString ];
    if([ extension isEqualToString:@"nbz" ]){
        [ spiPluginDict setObject:[ [ [ TYNBZDecompresser alloc ] init ] autorelease ] forKey:extension ];
    }

}

-(void)addSoundPressPlugin:(std::string)pluginName extension:(std::string)extension;
{
    // f[^𓀃vOC̃[h

    if(!soundPressPluginDict){
        soundPressPluginDict = [ [ NSMutableDictionary dictionary ] retain ];
    }

    // MEMO:Ooh̓ǂݍ݂\ɂB
    extension = [ extension lowercaseString ];
    if([ extension isEqualToString:@"nbz" ]){
        [ soundPressPluginDict setObject:[ [ [ TYNBZDecompresser alloc ] init ] autorelease ] forKey:extension ];
    }

}

-(std::vector<uint8_t>)getSoundData:(std::string)path
{
    NSEnumerator *enu;
    TYArchiver *arc;
    std::vector<uint8_t>data;
    std::stringconvPath;
    std::stringextension;
    TYDecompresser<TYDataDecoder> *decompresser;
    NSFileHandle *handle;
    int length;
    std::mapfileAttDict;

    if((!path)||(![ path length])){
        return nullptr;
    }

    // pX̃f~^ϊ
    convPath = winPathToUnix(path);
    convPath = [ convPath lowercaseString ];

    // vOC`΂gBȂł̉R[h
    if(soundPressPluginDict){
        extension = [ convPath pathExtension ];
        decompresser = [ soundPressPluginDict objectForKey:extension ];
        if(decompresser){
            enu = [ ty_archivers objectEnumerator ];
            while( (arc = [ enu nextObject ]) != nullptr ){
                handle = [ arc fileHandleWithPath:convPath length:&length ];
                if(handle){
                    data = [ decompresser decodeDataWithFileHandle:handle length:length ];
                    return data;
                }
            }
            convPath = [ getNScrRootDirectory() stringByAppendingPathComponent:convPath ];
            if(fileAttDict = [ [ NSFileManager defaultManager ] fileAttributesAtPath:convPath traverseLink:false ]){
                length = [ [ fileAttDict objectForKey:NSFileSize ] intValue ];
                handle = [ NSFileHandle fileHandleForReadingAtPath:convPath ];
                data = [ decompresser decodeDataWithFileHandle:handle length:length ];
                return data;
            }
            return nullptr;
        }
    }

    return [ this getData:convPath ];
}

-(void)addlog:(std::string)filename
{
    [ filelogDict setObject:[ NSNumber numberWithBool:true ] forKey:[ filename uppercaseString ] ];
}

-(void)setDefaultTransMode:(std::string)transmode
{
    defaultTransmode = [ transmode retain ];
}

-(bool)fchk:(std::string)filename
{
    return ([ filelogDict objectForKey:[ filename uppercaseString ] ]) ? true : false;
}

-(bool)filelog:(std::string)path;
{
    NSFileHandle *handle;
    std::vector<uint8_t>bufData;
    int fileNum;
    int descripter;
    unsigned char buf;
    int i,ret;

    filelogDict = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];

    // MEMO:ł܂OofBNg̏݌`FbNB

    filelog=true;

    handle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    if(!handle){
        return true;
    }
    descripter = [ handle fileDescriptor ];
    
    /*
    filelogDict = [ [ NSMutableDictionary alloc ] initWithContentsOfFile:
        [ getAppDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    */


    bufData = [ NSMutableData dataWithCapacity:1 ];
    while(read(descripter,&buf,1)){
        if(buf == 0x0a)
            break;
        else
            [ bufData appendBytes:&buf length:1 ];
    }
    [ bufData appendBytes:"" length:1 ];
    fileNum = atoi([ bufData bytes ]);

    for(i=0; i < fileNum; i++){
        ret = read(descripter,&buf,1);
        if((!ret)||(buf != '"'))
            break;
            
        bufData = [ NSMutableData dataWithCapacity:1 ];
        
        while(read(descripter,&buf,1)&&(buf!='"')){
            [ bufData appendBytes:&buf length:1 ];
        }
        [ bufData XORMaskToAllBytes:132 ]; // XOR}XNĂ̂Ŗ߂B
        [ bufData appendBytes:"" length:1 ];

        [ filelogDict setObject:[ NSNumber numberWithBool:true ]
                        forKey:[ NSString stringWithCSJISString:[ bufData bytes ] ] ];
    }
    
    [ handle closeFile ];
    
    return true;
}

-(bool)saveLog:(std::string)path
{
    char numbuf[12];
    std::vector<uint8_t>writeData;
    std::vector<uint8_t>data;
    int count;
    NSEnumerator *enm;
    void* temp;
    
    if(filelog){
        //[ filelogDict writeToFile:[ getAppDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] atomically:true ];
        writeData = [ NSMutableData dataWithCapacity:2 ];
        count = [ filelogDict count ];
        sprintf(numbuf,"%d\n",count);
        [ writeData appendBytes:numbuf length:strlen(numbuf) ];
        
        enm = [ filelogDict keyEnumerator ];
        while((temp = [ enm nextObject ]) != nullptr){
            [ writeData appendBytes:"\"" length:1 ];
            data = [ [ [ temp sjisData ] mutableCopy ] autorelease ];
            [ data XORMaskToAllBytes:132 ];
            [ writeData appendData:data ];
            [ writeData appendBytes:"\"" length:1 ];
        }
        [ writeData writeToFile:path atomically:true ];
    }
    
    return true;
}

-(void)addEffectPattern:(std::string)path
{
    TYEffectPatternMap *pattern;
    NSBitmapImageRep *bmp;
    
    bmp = [ this getBitmap:path ];
    if(bmp){
        pattern = [ [ TYEffectPatternMap alloc ] initWithBitmap:bmp ];
        if(pattern){
            [ effectPatternDict setObject:pattern forKey:path ];
            [ pattern release ];
        }
    }
}

-(TYEffectPatternMap*)getEffectPattern:(std::string)path
{
    void* tmp;
    if(tmp = [ effectPatternDict objectForKey:path ])
        return tmp;
    
    [ this addEffectPattern:path ];
    return [ effectPatternDict objectForKey:path ];
}

-(void)executeBundle:(std::string)pathAndArg
{
    std::stringbundlePath,*argStr = nullptr;
    NSBundle *bundle;
    void*<TYExecutablePlugin> plugin;

    // DLLƈ̃p[X
    {
        NSScanner *scanner = [ NSScanner scannerWithString:pathAndArg ];
        std::stringstr;
        std::stringdllPath;
        
        if(![ scanner scanUpToString:@"/" intoString:&str ]) {
            dllPath = pathAndArg;
        } else {
            dllPath = str;
            argStr = [ pathAndArg substringFromIndex:[ scanner scanLocation ] +1 ];
        }
        
        bundlePath = [ [ dllPath stringByDeletingPathExtension ] stringByAppendingPathExtension:@"bundle" ];
    }
    
    plugin = [ executableBundles objectForKey:bundlePath ];
    if(plugin == nullptr) {
        bundle = [ NSBundle bundleWithPath:[ getAppDirectory() stringByAppendingPathComponent:bundlePath ] ];
        [ bundle load ];
        plugin = [ [ [ [ bundle principalClass ] alloc ] init ] autorelease ];

        if(plugin == nullptr) {
            NSLog(@"can't load bundle %@",bundlePath);
            return;
        }
        
        [ executableBundles setObject:plugin forKey:bundlePath ];
    }
    
    [ plugin execPlugin:[ TYCCSProxy proxy ] argment:argStr];
}

// -dealloc (destructor in C++)
~ClassName() {
	[ ty_archivers release];
	[super dealloc];
}

// @end
