/*
 *  TYCrossFadeGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYCrossFadeGenerater_qt.h"
#include <QPainter>
#include <QDebug>

TYCrossFadeGenerater::TYCrossFadeGenerater(const QImage& beforeImage, const QImage& afterImage,
                                          TYEffectDefinitionValue* effect, QObject* parent)
    : QObject(parent)
    , m_beforeImage(beforeImage)
    , m_afterImage(afterImage)
    , m_isComplete(false)
{
    TYEffectDefinition effdef = effect->definition();
    m_effectTime = effdef.time;
    m_phaseInterval = effdef.time / 1000.0 / 256.0;
    m_startDate = QDateTime::currentDateTime();
    
    // Use Qtimer for progressive updates
    QTimer::singleShot(0, this, SLOT(drawEffect()));
}

TYCrossFadeGenerater::~TYCrossFadeGenerater()
{
}

void TYCrossFadeGenerater::drawEffect()
{
    // Calculate phase (0-256)
    qint64 elapsed = m_startDate.msecsTo(QDateTime::currentDateTime());
    int phase = (elapsed * 256) / m_effectTime;
    
    if (phase >= 256) {
        // Effect complete
        m_currentImage = m_afterImage;
        m_isComplete = true;
        emit effectImageChanged(m_currentImage);
        emit effectFinished();
        return;
    }
    
    // Blend images
    m_currentImage = QImage(m_beforeImage.size(), QImage::Format_ARGB32);
    QPainter painter(&m_currentImage);
    
    // Draw before image with decreasing opacity
    painter.setOpacity(1.0 - (phase / 256.0));
    painter.drawImage(0, 0, m_beforeImage);
    
    // Draw after image with increasing opacity
    painter.setOpacity(phase / 256.0);
    painter.drawImage(0, 0, m_afterImage);
    
    painter.end();
    
    emit effectImageChanged(m_currentImage);
    
    // Schedule next frame
    QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
}