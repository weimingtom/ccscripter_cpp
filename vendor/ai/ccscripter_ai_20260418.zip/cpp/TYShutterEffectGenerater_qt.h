/*
 *  TYShutterEffectGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Shutter transition effect generator.
 */

#ifndef TYSHUTTEREFFECTGENERATER_QT_H
#define TYSHUTTEREFFECTGENERATER_QT_H

#include <QObject>
#include <QImage>
#include <QTimer>
#include <QDateTime>
#include "TYEffecter_qt.h"

class TYShutterEffectGenerater : public QObject
{
    Q_OBJECT
    
public:
    TYShutterEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                             TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    ~TYShutterEffectGenerater();
    
    QImage currentImage() const { return m_currentImage; }
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
public slots:
    void drawEffect();
    
private:
    QImage m_beforeImage;
    QImage m_afterImage;
    QImage m_currentImage;
    QDateTime m_startDate;
    bool m_horizontal;
    bool m_reverse;
    int m_effectTime;
    int m_pixelOfColumn;
    int m_numberOfColumn;
    int m_beforePhase;
    double m_phaseInterval;
    bool m_isComplete;
};

#endif // TYSHUTTEREFFECTGENERATER_QT_H