/*
 *  FLogMarge_Main.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Utility to merge file access logs.
 *  Usage: FLogMarge file1 file2 margeFile
 */

#include <QCoreApplication>
#include <QString>
#include "TYFileLog_qt.h"

int main(int argc, const char* argv[])
{
    QCoreApplication app(argc, const_cast<char**>(argv));
    
    if (argc < 4) {
        qWarning() << "usage: FLogMarge file1 file2 margeFile";
        return -1;
    }
    
    QString path1 = QString::fromLocal8Bit(argv[1]);
    QString path2 = QString::fromLocal8Bit(argv[2]);
    QString path3 = QString::fromLocal8Bit(argv[3]);
    
    TYFileLog* log1 = new TYFileLog(path1);
    TYFileLog* log2 = new TYFileLog(path2);
    
    log1->addFileLog(log2);
    log1->writeToFile(path3);
    
    delete log1;
    delete log2;
    
    return 0;
}