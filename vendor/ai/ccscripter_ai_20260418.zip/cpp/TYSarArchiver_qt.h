/*
 *  TYSarArchiver.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  SAR archive file management.
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSString*         -> QString
 *  NSDictionary*      -> QMap
 *  NSFileHandle*      -> QFile
 *  NSData*           -> QByteArray
 */

#ifndef TYSARARCHIVER_QT_H
#define TYSARARCHIVER_QT_H

#include <QObject>
#include <QString>
#include <QMap>
#include <QFile>
#include <QByteArray>
#include <cstdint>

// Forward declaration
class TYSarArchivedFile;

// SAR archive handler class
class TYSarArchiver : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)archiverWithContentsOfFile:(NSString*)path
    static TYSarArchiver* archiverWithContentsOfFile(const QString& path);
    
    // Replaces: -(id)initWithContentsOfFile:(NSString*)path
    explicit TYSarArchiver(const QString& path, QObject* parent = nullptr);
    ~TYSarArchiver();
    
    // Replaces: -(NSFileHandle*)fileHandleWithPath:(NSString*)aPath length:(int*)length
    QFile* fileHandleWithPath(const QString& aPath, qint64* length);
    
    // Replaces: -(NSData*)unArchivedFile:(NSString*)address
    QByteArray unArchivedFile(const QString& address);
    
    // Read raw data at offset
    QByteArray readDataOffset(unsigned offset, unsigned length);
    
private:
    void loadArchive();
    QString m_arcPath;                                      // Replaces: NSString *arcPath
    QMap<QString, TYSarArchivedFile*> m_filesDict;         // Replaces: NSDictionary *filesDict
    unsigned m_baseOffset;                                  // Replaces: unsigned baseOffset
};

// Archived file info struct
struct TYSarArchivedFileInfo {
    unsigned fileOffset;
    unsigned fileLength;
};

// Inline factory (replaces static __inline__)
inline TYSarArchivedFileInfo TYMakeSarArchivedFileInfo(unsigned offset, unsigned length) {
    TYSarArchivedFileInfo info;
    info.fileOffset = offset;
    info.fileLength = length;
    return info;
}

#endif // TYSARARCHIVER_QT_H