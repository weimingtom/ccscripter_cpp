/*
 *  TYAnimationCellImage.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYAnimationCellImage_qt.h"
#include <QTimer>

// Animation info dictionary keys
const QString TYAnimationModeInfo = QStringLiteral("TYAnimationModeInfo");
const QString TYAnimationIntervalInfo = QStringLiteral("TYAnimationIntervalInfo");

TYAnimationCellImage::TYAnimationCellImage(const QVariantList& images, 
                                          const QVariantMap& infoDict, QObject* parent)
    : QObject(parent)
    , m_images(images)
    , m_delegate(nullptr)
    , m_isPlaying(false)
    , m_intervalIsArray(false)
    , m_back(false)
    , m_currentCell(0)
    , m_timer(nullptr)
{
    // Get animation mode
    if (infoDict.contains(TYAnimationModeInfo)) {
        m_mode = static_cast<TYAnimationMode>(infoDict[TYAnimationModeInfo].toInt());
    } else {
        m_mode = TYAnimationNoPlay;
    }
    
    // Get interval
    if (m_mode != TYAnimationNoPlay && infoDict.contains(TYAnimationIntervalInfo)) {
        m_interval = infoDict[TYAnimationIntervalInfo];
        m_intervalIsArray = (m_interval.type() == QVariant::List);
    }
}

TYAnimationCellImage::~TYAnimationCellImage()
{
    if (m_timer) {
        m_timer->stop();
        delete m_timer;
    }
}

void TYAnimationCellImage::changeCell(int index)
{
    if (index >= 0 && index < m_images.size()) {
        m_currentCell = index;
        emit cellChanged(m_currentCell);
    }
}

void TYAnimationCellImage::play()
{
    if (m_mode == TYAnimationNoPlay) {
        return;
    }
    
    m_back = false;
    changeCell(0);
    resume();
}

void TYAnimationCellImage::stop()
{
    m_isPlaying = false;
    if (m_timer) {
        m_timer->stop();
    }
}

void TYAnimationCellImage::resume()
{
    if (m_mode == TYAnimationNoPlay) {
        return;
    }
    
    m_isPlaying = true;
    setNextTimer();
}

void TYAnimationCellImage::setNextTimer()
{
    int delay;
    
    // Determine delay based on interval type
    if (m_intervalIsArray) {
        QVariantList intervals = m_interval.toList();
        if (m_currentCell < intervals.size()) {
            delay = intervals[m_currentCell].toInt();
        } else {
            delay = 100;  // Default
        }
    } else {
        delay = m_interval.toInt();
    }
    
    if (!m_timer) {
        m_timer = new QTimer(this);
        connect(m_timer, &QTimer::timeout, this, &TYAnimationCellImage::changingCell);
    }
    
    m_timer->setSingleShot(true);
    m_timer->start(delay);
}

void TYAnimationCellImage::changingCell()
{
    if (!m_isPlaying) {
        return;
    }
    
    switch (m_mode) {
    case TYAnimationLoopingPlayback:
        advanceCell();
        if (m_currentCell >= m_images.size()) {
            changeCell(0);
        }
        setNextTimer();
        break;
        
    case TYAnimationNormalPlayback:
        if (m_currentCell + 1 >= m_images.size()) {
            stop();
        } else {
            advanceCell();
            setNextTimer();
        }
        break;
        
    case TYAnimationLoopingBackAndForthPlayback:
        if (!m_back) {
            if (m_currentCell + 1 >= m_images.size() - 1) {
                m_back = true;
            }
            advanceCell();
        } else {
            if (m_currentCell <= 1) {
                m_back = false;
            }
            changeCell(m_currentCell - 1);
        }
        setNextTimer();
        break;
        
    case TYAnimationNoPlay:
        break;
    }
    
    emit cellChanged(m_currentCell);
}

void TYAnimationCellImage::advanceCell()
{
    changeCell(m_currentCell + 1);
}