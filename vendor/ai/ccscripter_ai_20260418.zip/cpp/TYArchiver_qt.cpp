/*
 *  TYArchiver.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYArchiver_qt.h"
//#include "TYSarArchiver.h"  // Would need to convert these too
//#include "TYNsaArchiver.h"

TYArchiver::TYArchiver(const QString& path, QObject* parent)
    : QObject(parent)
    , m_path(path)
{
}

TYArchiver::~TYArchiver()
{
}

// Replaces: +(id)archiverWithContentsOfFile:(NSString*)path
// Note: Returns owned pointer - caller responsible for deletion
TYArchiver* TYArchiver::archiverWithContentsOfFile(const QString& path)
{
    // Replaces: return [ [ [ [ self class ] alloc ] initWithContentsOfFile:path ] autorelease ];
    // In Qt, we use parent = nullptr and caller deletes
    TYArchiver* archiver = new TYArchiver(path);
    return archiver;
}

// Replaces: -(id)initWithContentsOfFile:(NSString*)path
// Note: This is a factory that creates the appropriate subclass
// In Qt, this would typically be handled differently
TYArchiver::TYArchiver(const QString& path, QObject* parent)
    : QObject(parent)
    , m_path(path)
{
    // Replaces: self = [ [ super init ] autorelease ]
    // Note: In Qt, we don't use autorelease - memory management is explicit
    
    /* Get file extension */
    // Replaces: excstr = [ path pathExtension ];
    QString ext = getFileExtension();
    
    // Replaces: if([ excstr compare:@"sar" options:NSCaseInsensitiveSearch ] == NSOrderedSame)
    if (ext.toLower() == QStringLiteral("sar")) {
        // sar format
        qDebug() << "SAR archive format detected - would create TYSarArchiver";
        // temp = [ [ TYSarArchiver alloc ] initWithContentsOfFile:path ];
        // return temp;
    } 
    // Replaces: else if([ excstr compare:@"nsa" options:NSCaseInsensitiveSearch ] == NSOrderedSame)
    else if (ext.toLower() == QStringLiteral("nsa")) {
        qDebug() << "NSA archive format detected - would create TYNsaArchiver";
        // temp = [ [ TYNsaArchiver alloc ] initWithContentsOfFile:path ];
        // return temp;
    }
    else {
        qWarning() << "Tukuyomi is not supporting this type of archive:" << path;
    }
}

// Replaces: -(NSFileHandle*)fileHandleWithPath:(NSString*)aPath length:(int*)length
QFile* TYArchiver::fileHandleWithPath(const QString& aPath, qint64* length)
{
    QFile* file = new QFile(aPath);
    if (file->exists()) {
        *length = file->size();
        return file;
    }
    delete file;
    return nullptr;
}

// Replaces: -(NSData*)unArchivedFile:(NSString*)address
QByteArray TYArchiver::unArchivedFile(const QString& address)
{
    Q_UNUSED(address);
    // Would implement archive extraction here
    return QByteArray();
}