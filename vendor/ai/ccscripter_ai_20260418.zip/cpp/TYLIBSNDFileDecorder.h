// Converted from TYLIBSNDFileDecorder.h
// TODO: Manual review and fixes required

//
//  TYLIBSNDFileDecorder.h
//  Tukuyomi
//
//  Created by toveta on Sat Sep 28 2002.
//  Copyright (c) 2002 toveta All rights reserved.
//




class TYLIBSNDFileDecorder : public NSObject {
private:TYWaveDecorder

};
