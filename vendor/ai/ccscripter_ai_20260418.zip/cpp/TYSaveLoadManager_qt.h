/*
 *  TYSaveLoadManager.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Manages save/load game state functionality.
 */

#ifndef TYSAVELOADMANAGER_QT_H
#define TYSAVELOADMANAGER_QT_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QList>
#include <QDateTime>

// Constants
#define SAVEDATA_NAME "save%d.dat"

// Notifications
extern const QString TYDataSaveNotification;
extern const QString TYSaveNumberKey;
extern const QString TYSaveDateStringKey;

class TYSaveLoadManager : public QObject
{
    Q_OBJECT
    
public:
    TYSaveLoadManager(QObject* parent = nullptr);
    ~TYSaveLoadManager();
    
    // Names management
    void setNames(const QStringList& names);
    QStringList names() const { return m_names; }
    
    // Number of save slots
    void setNumber(int number);
    int number() const { return m_dataNum; }
    
    // Reset date for specific slot
    void resetDateWithNumber(int number);
    
    // Load save data info
    void dataLoad();
    
    // Get date strings for UI
    QStringList dateStrings(bool isLoad);
    
    // Check which slots have data
    QList<bool> existsArray() const { return m_existsList; }
    
signals:
    void dataSaveNotification(int number, const QString& dateString);
    
private:
    QString generateBookmarkString(int number) const;
    
    QStringList m_names;           // Replaces: NSArray *names
    QList<QString> m_bookmarkList; // Replaces: NSMutableArray *bookmarkArray
    QList<bool> m_existsList;      // Replaces: NSMutableArray *existsArray
    int m_dataNum;                 // Replaces: int dataNum
    bool m_loaded;                 // Replaces: BOOL loaded
};

#endif // TYSAVELOADMANAGER_QT_H