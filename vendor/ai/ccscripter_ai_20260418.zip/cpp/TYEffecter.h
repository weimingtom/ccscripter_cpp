// Converted from TYEffecter.h
// TODO: Manual review and fixes required

//
//  TYEffecter.h
//  Tukuyomi
//
//  Created by toveta on Mon Jun 18 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */




// GtFNg̊ǗAGtFNg摜̐ǗAXV^C}Cxg̎ssNXłBgĂȂǁB
class TYEffecter : public NSObject {
    NSMutableDictionary *ty_effectDict; // [U[`GtFNgԍi[
    NSDate *startDate; // GtFNgJn
    NSTimeInterval beforeParsentage;
    TYEffectRegister *nowEffect;
    NSImage *beforeImage;
    NSImage *afterImage;
    NSImage *nowImage;
}

+(id)effecter;
id init();
void setEffectNo(int effectNo); type:(int)effectType time:(int)time path:(NSString*)path;
//NSImage * playEffectNo(int effectNo); fromImage:(NSImage*)fromImage toImage:(NSImage*)toImage;
void setBeforeImage(NSImage* aImage);;
NSImage* beforeImage();
//TYEffectRegister* getEffect(int effectNo);;

// GtFNgʊJn
BOOL startEffect(NSImage* newImage); effectNo:(int)effectNo;
// GtFNĝC[W擾
BOOL getEffectionImage(NSImage** drawImage);;


typedef enum  {
TYEffectCached=0,// ύXȂBLbVÔ
TYEffectInstant, // uŕ\
TYEffectLeftShutter,//@Q@Vb^[
TYEffectRightShutter,//@R@EVb^[
TYEffectTopShutter,//@S@Vb^[
TYEffectBottomShutter,//@T@Vb^[
TYEffectLeftCartain,//@U@J[e
TYEffectRightCartain,//@V@EJ[e
TYEffectTopCartain,//@W@J[e
TYEffectBottomCartain,//@X@J[e
TYEffectCrossFadeWithPixel,//PO@sNZPʂ̃NXtF[h
TYEffectLeftScroll,//PP@XN[
TYEffectRightScroll,//PQ@EXN[
TYEffectTopScroll,//PR@ォXN[
TYEffectBottomScroll,//PS@XN[
TYEffectFadeWithMask,//PT@}XNp^[ɂtF[hB
TYEffectMosaicOut,//16 UCNAEg
TYEffectMosaicIn,//17 UCNC
TYEffectCrossFadeWithMask,//18 }XNp^[ɂNXtF[h
} TYEffectType ;
};

// GtFNg̕
typedef enum {
    TYTopDirection=1,
    TYBottomDirection=2,
    TYLeftDirection=4,
    TYRightDirection=8
} TYEffectDirection;

// ȃGtFNgԍ
enum {
TYEffectNoWindow=-2,
TYEffectNoLocal=-1,
TYEffectNoChached=0,
TYEffectNoInstant=1
};

// ɓo^GtFNgIuWFNg
class TYEffectRegister : public NSObject {
    int ty_effectType;
    int ty_time; 
    NSString* ty_path;
}
+(id)effectRegisterType:(int)type time:(int)time path:(NSString*)path;
id initWithType(int type); time:(int)time path:(NSString*)path;
int getType();
int getTime();
NSString* getPath();

};

typedef struct tyEffectDefinition {
    TYEffectType type;
    int time;
    NSString *path;
} TYEffectDefinition;

static __inline__ TYEffectDefinition TYMakeEffectDefinition(TYEffectType aType,int aTime,NSString* aPath) {
    TYEffectDefinition effdef;
    effdef.type = aType;
    effdef.time = aTime;
    effdef.path = aPath;
    return effdef;
}

// NSValue̓NXNX^Ȃ̂ŃIuWFNg܂ލ\̂Ǘɂ̓bp邵Ȃ킯ŁB
class TYEffectDefinitionValue : public NSObject {
    NSValue *value;
}
+(id)valueWithEffectDefinition:(TYEffectDefinition)aDefinition;
id initWithEffectDefinition(TYEffectDefinition aDefinition);;
void getValue(void * buffer);;
};