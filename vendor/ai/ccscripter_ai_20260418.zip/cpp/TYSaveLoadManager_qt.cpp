/*
 *  TYSaveLoadManager.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYSaveLoadManager_qt.h"
#include "TYMiscUtil_qt.h"
#include <QDir>
#include <QFileInfo>

// Notification constants
const QString TYDataSaveNotification = QStringLiteral("TYDataSaveNotification");
const QString TYSaveNumberKey = QStringLiteral("TYSaveNumberKey");
const QString TYSaveDateStringKey = QStringLiteral("TYSaveDateStringKey");

TYSaveLoadManager::TYSaveLoadManager(QObject* parent)
    : QObject(parent)
    , m_dataNum(0)
    , m_loaded(false)
{
    // Default names
    m_names << QStringLiteral("<SAVE>")
            << QStringLiteral("<LOAD>")
            << QStringLiteral("bookmark");
}

TYSaveLoadManager::~TYSaveLoadManager()
{
}

void TYSaveLoadManager::setNames(const QStringList& names)
{
    m_names = names;
}

void TYSaveLoadManager::setNumber(int number)
{
    m_dataNum = number;
    
    // Clear and resize arrays
    m_bookmarkList.clear();
    m_existsList.clear();
    
    for (int i = 0; i < number; i++) {
        m_bookmarkList.append(QString());
        m_existsList.append(false);
    }
}

int TYSaveLoadManager::number() const
{
    return m_dataNum;
}

void TYSaveLoadManager::resetDateWithNumber(int number)
{
    if (number <= 0 || number > m_dataNum) {
        return;
    }
    
    QString filename = QString(SAVEDATA_NAME).arg(number);
    QString path = getNScrRootDirectory() + "/" + filename;
    
    QFileInfo fileInfo(path);
    bool exists = fileInfo.exists();
    
    // Generate bookmark string
    QString bookmark = m_names.value(2);  // "bookmark"
    bookmark += TYWideCharDecimalString(number);
    
    if (number < 10) {
        bookmark += QStringLiteral(" ");  // WSPACE
    }
    bookmark += QStringLiteral(" ");
    
    if (!exists) {
        bookmark += QStringLiteral("No Save Data");
    } else {
        // Get modification date
        QDateTime modDate = fileInfo.lastModified();
        bookmark += modDate.toString(QStringLiteral("MMddHHmm"));
    }
    
    m_bookmarkList[number - 1] = bookmark;
    m_existsList[number - 1] = exists;
}

void TYSaveLoadManager::dataLoad()
{
    if (m_loaded) {
        return;
    }
    
    m_loaded = true;
    
    // Scan save data files
    for (int i = 1; i <= m_dataNum; i++) {
        resetDateWithNumber(i);
    }
}

QStringList TYSaveLoadManager::dateStrings(bool isLoad)
{
    QStringList result;
    
    // Title
    result.append(m_names.value(isLoad ? 1 : 0));
    
    // Load save data info if not already loaded
    dataLoad();
    
    // Add bookmark strings
    result += m_bookmarkList;
    
    return result;
}