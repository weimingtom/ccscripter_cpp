// Converted from TYMenuModeView.m
// TODO: Manual review and fixes required

//
//  TYMenuModeView.m
//  Tukuyomi
//
//  Created by toveta on Thu Feb 06 2003.
//  Copyright (c) 2003 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYMenuModeView.h"
#include "TYControllButton.h"
#include "TYKeyBind.h"
#include "TYMainController.h"
#include "TYVisualNovelView.h"

// @implementation TYMenuModeView

-(void*)initWithFrame:(NSRect)aFrame
{
    // 初期化
    this = super->initWithFrame(aFrame);
    if (!this)
        return nullptr;
	
	return this;
}

-(void) setController:(void*)aObj
        buttonArray:(void*)bArray
        actionArray:(void*)aArray
        bgColor:(NSColor*)aColor
{
    controller = aObj;
    
    selectedButton = nullptr;

    btnArray = [ bArray retain ];
    
    actArray = [ aArray retain ];

    menuWindowColor = [ aColor retain ];        
}

-(IBAction)execButton:(void*)sender
{
    [ this select_action ];
}

- (void)drawRect:(NSRect)rect {
    // Drawing code here.
    [ menuWindowColor set ];
    NSRectFillUsingOperation(rect,NSCompositeSourceOver);
}

// REMOVED: -voidupdatesTrackingRect{
    NSEnumerator *enu;
    TYControllButton *temp;
    NSTrackingRectTag tag;

    if(btnDict)
        [ this removeAllTrackingRect ];

    btnDict = [ [ NSMutableDictionary dictionary ] retain ];
    enu = [ btnArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
        tag = [ this addTrackingRect:[ temp frame ] owner:this userData:nullptr assumeInside:false ];
        [ btnDict setObject:temp forKey:[ NSNumber numberWithInt:tag ] ];
    }
}

// REMOVED: -voidremoveAllTrackingRect{
    NSEnumerator *enu;
    NSNumber *temp;
    
    if(!btnDict)
        return;

    if(selectedButton != nullptr) {
        [ selectedButton changeCell:0 ];
        [ selectedButton setNeedsDisplay:true ];
    }
        
    selectedButton = nullptr;

    enu = [ btnDict keyEnumerator ];
    while(temp = [ enu nextObject ]){
        [ this removeTrackingRect:[ temp intValue ] ];
    }
    
    [ btnDict release ];
    btnDict = nullptr;
}

-(void)setButtonArray:(std::vector)aArray
{
    if(btnArray)
        [ btnArray autorelease ];
    btnArray = [ aArray retain ];
}

-(void)setActionArray:(std::vector)aArray
{
    if(actArray)
        [ actArray autorelease ];
    actArray = [ aArray retain ];
}

// REMOVED: -boolacceptsFirstResponder{
    return true;
}

-(void)mouseEntered:(NSEvent*)theEvent
{
    TYControllButton *btn;
    int no;

    no = [ theEvent trackingNumber ];
    btn = [ btnDict objectForKey:[ NSNumber numberWithInt:no ] ];
    [ btn changeCell:1 ];
    [ btn setNeedsDisplay:true ];
        
    if(selectedButton && (btn != selectedButton)){
        [ selectedButton changeCell:0 ];
    }
    
    selectedButton = btn;
}

-(void)mouseExited:(NSEvent*)theEvent
{
    TYControllButton *btn;
    int no;
    
    no = [ theEvent trackingNumber ];
    btn = [ btnDict objectForKey:[ NSNumber numberWithInt:no ] ];
    [ btn changeCell:0 ];
    [ btn setNeedsDisplay:true ];
    
    if(selectedButton == btn)
        selectedButton = nullptr;
}

-(void)mouseMoved:(NSEvent*)theEvent
{
    ;
}

-(void)mouseDown:(NSEvent*)theEvent
{
    ;
}

-(void)keyDown:(NSEvent*)theEvent
{
    [ this performSelector:TYSelectorForKeycode([ theEvent keyCode ]) withObject:nullptr ];
}

- (void)scrollWheel:(NSEvent *)theEvent
{
    if([ theEvent deltaY ] > 0.0){
        [ this up_action ];
    } else {
        [ this down_action ];
    }
}


// REMOVED: -voiddown_action{
    TYControllButton *btn;
    int idx;
    
    idx = (selectedButton == nullptr) ? -1 : [ btnArray indexOfObject:selectedButton ];

    if((idx == [ btnArray count ] -1) || idx == -1){
        btn = [ btnArray objectAtIndex:0 ];
    } else {
        btn = [ btnArray objectAtIndex:idx +1 ];
    }
    
    if(selectedButton != btn){
        [ selectedButton changeCell:0 ];
        [ selectedButton setNeedsDisplay:true ];
        [ btn changeCell:1 ];
        [ btn setNeedsDisplay:true ];
        selectedButton = btn;
    }    
}

-(void)rightMouseDown:(NSEvent*)theEvent
{
    [ this cancel_action:nullptr ];
}

// REMOVED: -voidselect_action{
    int idx;
    
    if(!selectedButton)
        return;
    
    idx = [ btnArray indexOfObject:selectedButton ];
    [ this endMode ];
    [ controller ty_systemcall:[ NSMutableArray arrayWithObjects:@"systemcall",[ actArray objectAtIndex:idx ] ,nullptr ] ];
}

-(void)cancel_action:(void*)sender
{
    /*
    [ controller exitSystemModeResumeStatus:true ];
    [ this removeFromSuperview ];    
     */
    [ this endMode ];
}

// REMOVED: -voidup_action{
    TYControllButton *btn;
    int idx;
    
    idx = (selectedButton == nullptr) ? -1 : [ btnArray indexOfObject:selectedButton ];

    if(idx == 0 || idx == -1){
        btn = [ btnArray lastObject ];
    } else {
        btn = [ btnArray objectAtIndex:idx -1 ];
    }
    
    if(selectedButton != btn){
        [ selectedButton changeCell:0 ];
        [ selectedButton setNeedsDisplay:true ];
        [ btn changeCell:1 ];
        [ btn setNeedsDisplay:true ];
        selectedButton = btn;
    }
}

// REMOVED: -voidendMode{
    [ [ this window ] makeFirstResponder:[ this superview ] ];
    [ this removeAllTrackingRect ];
    [ controller exitSystemModeResumeStatus:true ];
    [ [ this retain ] autorelease ];
    [ this removeFromSuperview ];    
}

// -dealloc (destructor in C++)
~ClassName() {
	[menuWindowColor release];
        [btnDict release];
        [btnArray release];
        [actArray release];
	[super dealloc];
}

// @end
