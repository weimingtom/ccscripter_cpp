QT += core
QT -= gui

CONFIG += c++11

TARGET = lzss_test
TEMPLATE = app

SOURCES += lzss_qt.cpp main_qt.cpp

HEADERS += lzss_qt.h