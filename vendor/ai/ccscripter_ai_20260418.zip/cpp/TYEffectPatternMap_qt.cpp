/*
 *  TYEffectPatternMap.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYEffectPatternMap_qt.h"
#include <QImage>
#include <QDebug>

TYEffectPatternMap::TYEffectPatternMap(const QImage& bitmap, QObject* parent)
    : QObject(parent)
    , m_mapData()
    , m_pixelsWide(0)
    , m_pixelsHigh(0)
{
    if (bitmap.isNull()) {
        return;
    }
    
    m_pixelsWide = bitmap.width();
    m_pixelsHigh = bitmap.height();
    int pixelSize = m_pixelsWide * m_pixelsHigh;
    
    m_mapData.resize(pixelSize);
    uint8_t* dp = reinterpret_cast<uint8_t*>(m_mapData.data());
    
    // Convert image to 32-bit if needed
    QImage img = bitmap.convertToFormat(QImage::Format_ARGB32);
    
    int bytesPerPixel = 4;  // 32-bit = 4 bytes
    const uint8_t* bp = img.constBits();
    
    int depth = img.depth();
    if (depth != 24 && depth != 32) {
        qWarning() << "Unsupported bitmap depth:" << depth << "- converting";
        img = img.convertToFormat(QImage::Format_RGB32);
        bp = img.constBits();
        depth = 32;
    }
    
    if (depth == 24) {
        bytesPerPixel = 3;
    }
    
    // Extract first channel (red) as pattern map
    for (int i = 0; i < pixelSize; i++) {
        *dp = *bp;  // Copy red channel
        dp++;
        bp += bytesPerPixel;
    }
}

TYEffectPatternMap::~TYEffectPatternMap()
{
    // m_mapData auto-cleans up
}

// Replaces: -(const unsigned char*)patternMapData
const uint8_t* TYEffectPatternMap::patternMapData() const
{
    return reinterpret_cast<const uint8_t*>(m_mapData.constData());
}