/*
 *  TYArrayValue.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Manages array variables for NScripter.
 */

#ifndef TYARRAYVALUE_QT_H
#define TYARRAYVALUE_QT_H

#include <QObject>
#include <QVariant>
#include <QVariantList>

class TYArrayValue : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithID:(int)idNo limits:(NSArray*)limits
    TYArrayValue(int idNo, const QVariantList& limits, QObject* parent = nullptr);
    ~TYArrayValue();
    
    // Get/set numeric value at address
    // Replaces: -(NSNumber*)getNumOfAddress:(NSArray*)address
    QVariant getNumOfAddress(const QVariantList& address) const;
    
    // Replaces: -(void)setNum:(NSNumber*)number address:(NSArray*)address
    void setNum(const QVariant& number, const QVariantList& address);
    
    // Replaces: -(void)setNumbers:(NSArray*)numbers address:(NSArray*)address
    void setNumbers(const QVariantList& numbers, const QVariantList& address);
    
    // Get dimensions
    int idNo() const { return m_idNo; }
    QVariantList limits() const { return m_limits; }
    
private:
    int m_idNo;                    // Replaces: int idNo
    QVariantList m_limits;        // Replaces: NSArray *limits
    QVariantList m_data;          // Actual array data
    
    int calculateIndex(const QVariantList& address) const;
};

#endif // TYARRAYVALUE_QT_H