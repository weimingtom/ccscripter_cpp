/*
 *  TYEffectGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYEffectGenerater_qt.h"

TYEffectGenerater::TYEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                                    TYEffectDefinitionValue* effect, QObject* parent)
    : QObject(parent)
    , m_beforeImage(beforeImage)
    , m_afterImage(afterImage)
    , m_delegate(nullptr)
    , m_isComplete(false)
{
    Q_UNUSED(effect);
}

TYEffectGenerater::TYEffectGenerater(const QImage& image, int quakeType, int times, int second,
                                    QObject* parent)
    : QObject(parent)
    , m_nowImage(image)
    , m_delegate(nullptr)
    , m_isComplete(false)
{
    Q_UNUSED(quakeType);
    Q_UNUSED(times);
    Q_UNUSED(second);
}

TYEffectGenerater::~TYEffectGenerater()
{
}

void TYEffectGenerater::drawEffect()
{
    // Base implementation - should be overridden by subclasses
    m_nowImage = m_afterImage.isNull() ? m_beforeImage : m_afterImage;
}