/*
 *  TYPreferencePanelController.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYPreferencePanelController_qt.h"
#include "TYEnviroment_qt.h"

TYPreferencePanelController::TYPreferencePanelController(QObject* parent)
    : QObject(parent)
    , m_bufferPage(5)
    , m_enableAutoReplay(true)
    , m_enableBold(false)
    , m_enableMovie(true)
    , m_hideOtherFullScreen(true)
    , m_scaleInFullScreen(true)
{
}

TYPreferencePanelController::~TYPreferencePanelController()
{
}

void TYPreferencePanelController::loadEnvironment()
{
    m_bufferPage = TYEnviroment::objectForKey(TYEnvKeys::LookbackBufferPage).toInt();
    m_enableAutoReplay = TYEnviroment::objectForKey(TYEnvKeys::LookbackVoiceReplay).toBool();
    m_enableBold = TYEnviroment::objectForKey(TYEnvKeys::EnableBoldFont).toBool();
    m_enableMovie = TYEnviroment::objectForKey(TYEnvKeys::EnablePlayMovie).toBool();
    m_hideOtherFullScreen = TYEnviroment::objectForKey(TYEnvKeys::HideOtherFullScreen).toBool();
    m_scaleInFullScreen = TYEnviroment::objectForKey(TYEnvKeys::ScaleInFullScreenMode).toBool();
}

int TYPreferencePanelController::showDialog()
{
    // In QtWidgets integration, would show a dialog
    // For now, just load and return
    TYPreferencePanelController controller;
    controller.loadEnvironment();
    return 0;
}