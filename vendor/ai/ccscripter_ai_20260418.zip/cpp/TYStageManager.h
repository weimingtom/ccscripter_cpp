// Converted from TYStageManager.h
// TODO: Manual review and fixes required

//
//  TYStageManager.h
//  Tukuyomi
//
//  Created by toveta on Sun Aug 19 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */













typedef enum tySkipStatusMask {
    TYNoSkip = 0,
    TYOnetimeSkipMask = 1,
    TYSelectionSkipMask = 1 << 1,
    TYKidokuSkipMask = 1 << 2,
    TYAutoModeSkipMask = 1 << 3,
    TYEffectCancelSkipMask = TYSelectionSkipMask | TYKidokuSkipMask ,
    TYNoTimeWaitSkipMask = TYOnetimeSkipMask | TYSelectionSkipMask | TYKidokuSkipMask,
} TYSkipStatusMask;

#define BAR_NUMBER_MAX 99

// ItXN[obt@̕ύXsNXBeLXg\̐˂Ă
@interface TYStageManager : NSObject < TYController,TYSaveDataCoding > {
    TYMainController *controller; // C[WnRg[[B
    id engine; // XNvgGW
    NSImage *compositeLayer; // 摜C[ƃeLXgC[𓝍C[
    NSMutableDictionary *effectDefDict; // GtFNg`o^
    TYEffectGenerater *effectGenerater; // GtFNgʍ쐬NX
    id afterEffectTarget; // GtFNgIɒ@IuWFNg
    SEL afterEffectSelector; // ZN^
    id afterEffectObject; // IuWFNg
    //TYEffecter *effecter; // GtFNg鉺IuWFNgB
    
    NSImage *visualLayer; // wiƂLƂXvCgƂB
    
    // wi
    NSImage *bgImage;
    NSString *bgPath;
    NSRect bgRect; // wi̕`̈
    
    // L
    float underline;
    TYStandingChar *leftCharImage;
    TYStandingChar *centerCharImage;
    TYStandingChar *rightCharImage;
    
    // XvCg
    NSMutableArray *spriteArray;
    int humanz; // G̔ԍ܂ł̃XvCg̏ɕ\B
    BOOL isUseHumanz; // XNvghumanz߂gꂽƂtOB
    BOOL isWindowback; // XvCgeLXgEChȄɕ`悷B
    NSMutableArray *hideSpriteArray; // allsphide ߂ňꎞIvisible:NO ɂXvCg
    
    // tB^
    NSData *monocroSample;
    int nega;
    
    //NSMutableArray *textQueue;
    NSImage *novelLayer; // ƃeLXgEChẼC[
    NSLayoutManager *layoutManager;
    NSString *textQueue;
    
    NSImage *overNovelLayer;
    
    NSMutableDictionary *textAttDict;
    NSMutableDictionary *textShadowAttDict;
    NSString *textFontName;
    NSFont *textFont;
    NSSize displayFontSize; // ۂɕ\tHg̃TCY
    
    BOOL novelLayerOn; // eLXgEChE\tO
    BOOL eraseTextWindow;
    
    int textLeftOffset;
    int textTopOffset;
    int textColumn;
    int textRow;
    int textFontWidth;
    int textFontHeight;
    NSColor *textFontColor;
    int textPitchx;
    int textPitchy;
    int *textSpeed;
    int userTextSpeed;
    int scriptTextSpeed;
    NSArray *defaultSpeed;
    int selectedSpeedTag;
    BOOL textBold;
    BOOL textShadowed;
    
    int locateX;
    
    id textWindow;
    NSString *textWindowPath;
    NSRect textWindowRect;
    //NSPoint textWindowPoint;
    //NSSize textWindowSize;
    
    enum TYTPStatus { // eLXg\Ԏ̃Xe[^X
        TYTPOff,
        TYTPPrinting,
        TYTPClickWait,
        TYTPTimeWait,
    } tpStatus;
    BOOL waitNewPage; // ő҂tO
    BOOL forceClickWait; // NbN҂tO
    BOOL forceWaitNewPage; // y[W҂tO
    BOOL invalidNewLine; // stO
    NSCharacterSet *clickStrSet;
    int clickStrUnderLimit;
    NSCharacterSet *hyphenationSet; // ֑pZbg

    int nowColumn;
    int nowRow;
    int nowStorageLength;
    int nowStorageOffset;
    
    //NSString *textQueue;

    // GtFNgIɋN郁\bhƃV[o[
    /*
    id nextTarget;
    id nextObject;
    SEL nextSelector;
    */
    
    // {^֘A
    TYExtraButtonManager *buttonManager;
    int beforeSelectButtonID;
    NSString *buttonTargetValue;
    BOOL releaseButtonAfterSelect;
    BOOL isDrawButton;
    NSNumber *btnTime;
    NSDate *btnStartDate;
    
    // I
    TYSelectionManager *selectionManager;
    int beforeSelectIndex;
    NSArray *selectAction;
    NSColor *selectColor;
    NSColor *unSelectColor;
    
    // XLbv
    int skipStatus;
    int automodeWait;
    int automodeWaitType;
    int waitCountOfChar;
    BOOL playingSoundFlg;
    BOOL waitFinishSound;
    BOOL waitFinishSoundOnBtnTime2;

    // NbN҂J[\
    TYWaitCursor *clickWaitCursor;
    TYWaitCursor *pageWaitCursor;
    TYWaitCursor *currentCursor;
    
    BOOL linepage,linepageWait;
    
    // VXeJX^}CY
    NSString *textgosubLabel;
    BOOL isPage;
    NSMutableArray *cselInfo; // AR}h̏Ɋi[B
    NSMutableArray *cselImage;
    
    // zobt@
    NSMutableArray *lookbackQueue;
    
    // o[
    NSMutableDictionary *barDict;
}
+(id)sharedManager;

+(void)setModeSVGA;

void setController(id aController); engine:(id)aEngine;

void enterSystemMode();
void exitSystemModeResumeStatus(BOOL aBool);;
BOOL isPossibleEnterSystemMode();

void loadTextWindow(NSString* path);;
void loadBGImage(NSString* aPath);;
void addSprite(NSMutableArray * argments); visible:(BOOL)aBool; // XvCgǉ

void startSelect(NSArray* messages); responds:(NSArray*)respondArray;
 
void updateStage(); // 摜̍č\z
void updateStageOnlyButton();
NSImage* visualLayer();
NSImage* compositeLayer();
void changeVisualLayer(NSNumber* effectNum);; // wiɕύXƂɌĂ΂
void flushNovelLayer(); // novelLayeȑcompositeLayer̍ĕ`B
void startEraseTextWindow(NSNumber* effectNum);;
//void setNextPerformSelector(SEL aSelector); target:(id)target withObject:(id)object;
NSArray* lookbackQueue();

//void addTextQueue(NSString* aString);; // eLXgL[ɒǉ
void textPrint(NSString* aString);; // eLXg̕\Jn
void drawTextWindow();
NSRect textWindowRect();
void drawChar(NSString* charStr); color:(NSColor*)color atColumn:(int)column atRow:(int)row;
void drawAttStr(NSAttributedString* str); atColumn:(int)column atRow:(int)row;
NSPoint drawPoint();
void setSkipStatus(int aStatus);;
int skipStatus();
void setClickWait(BOOL pageWait);;
//void rectOfColumnRange(NSRange columnRange); rowRange:(NSRange)rowRange;
//void ty_bg(NSString* path); effectNo:(int)effectNo; // wi摜ύX

void resetGame();

int status();
void setStatus(int status);;

void printing();
void resumePrinting();
void automode_select_action(); // AutomodetOێ܂܂ɂȂB

// Jnh
void ty_select(NSMutableArray * argments);;
void ty_spstr(NSMutableArray * argments);;
void ty_textclear(NSMutableArray* argments);;
void ty_lookbackflush(NSMutableArray* argments);;

//void setTextWindow(NSArray argments);;
void makeAttributeDict(); // tHg̏C̍č\z
NSDictionary* textAttDict();
int textFontWidth();
int textFontHeight();
int textPitchx();
BOOL isShadow();

void changeFont(id fontManager);;
void changeTextSpeed(int index);;
void setAutoMode(int speed);
           waitType:(int)type
               wait:(int)wait;
int userTextSpeed();

void startButtonWait(NSMutableArray* argments); releaseAfterSelect:(BOOL)aBool;
void changeSelectedButton(unsigned int btnIndex);;
void responseButton(int result);;
void changeSelection(int index);;
void responseSelection();
void makeCselImage();

// sprite operation
NSRect rectOfSprite(int idNo);;
void setSprite(int idNo); visible:(BOOL)aBool;
void setSprite(int idNo); cell:(int)cellNo;

/* delegate methods of EffectGeneraters*/
void changeEffectionImage(NSImage* drawImage);;
void effectFinished();

// notification
void updateSprites(NSNotification* aNotification);; // from TYNScrSprite
void startWaveSound(NSNotification* aNotification);; // from TYWaveController
void stopWaveSound(NSNotification* aNotification);;

//#define VSCREEN_WIDTH 640
//#define VSCREEN_HEIGHT 480

extern int VSCREEN_WIDTH;
extern int VSCREEN_HEIGHT;
#define LD_LOCATE_LEFT @"l"
#define LD_LOCATE_CENTER @"c"
#define LD_LOCATE_RIGHT @"r"
#define CL_LOCATE_ALL @"a"
#define WINDOW_EFFECT_NO -2
#define SHADOW_TICKNESS 1
#define SPRITE_MAX 255
#define DEFAULT_TEXTWINDOW @"#999999"
extern NSString* const CSEL_LABEL;
#define CSEL_SPRITE_NO 500

extern NSSize TYVirtualScreenSize();
extern NSRect TYVirtualScreenRect();
extern NSRect TYFromRect(NSPoint*,NSSize*,NSSize*);

};
