/*
 *  TYDecompresser.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  @protocol          -> abstract class / interface
 *  NSData*            -> QByteArray
 *  NSBitmapImageRep*  -> QImage (or QPixmap)
 *  NSFileHandle*      -> QFile*
 *  + (id)sharedObject -> static instance() pattern
 */

#ifndef TYDECOMPRESSER_QT_H
#define TYDECOMPRESSER_QT_H

#include <QObject>
#include <QByteArray>
#include <QImage>
#include <QFile>
#include <cstdint>

class TYDecompresser : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)sharedObject
    static TYDecompresser* sharedInstance();
    
    // Constructor
    explicit TYDecompresser(QObject* parent = nullptr);
    ~TYDecompresser();
};

// Abstract interface for data decoders
// Replaces: @protocol TYDataDecoder
class TYDataDecoder
{
public:
    virtual ~TYDataDecoder() = default;
    // Replaces: -(NSData*)decodeDataWithFileHandle:(NSFileHandle*)handle length:(int)encode_size
    virtual QByteArray decodeData(QFile& handle, int encodeSize) = 0;
};

// Abstract interface for bitmap decoders
// Replaces: @protocol TYBitmapDecoder  
class TYBitmapDecoder
{
public:
    virtual ~TYBitmapDecoder() = default;
    // Replaces: -(NSBitmapImageRep*)decodeBitmapWithFileHandle:(NSFileHandle*)handle length:(int)encode_size
    virtual QImage decodeBitmap(QFile& handle, int encodeSize) = 0;
};

#endif // TYDECOMPRESSER_QT_H