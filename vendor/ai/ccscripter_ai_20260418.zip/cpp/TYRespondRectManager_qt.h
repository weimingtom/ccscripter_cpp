/*
 *  TYRespondRectManager.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Manages button selection, menus, and clickable regions.
 */

#ifndef TYRESPONDRECTMANAGER_QT_H
#define TYRESPONDRECTMANAGER_QT_H

#include <QObject>
#include <QRect>
#include <QImage>
#include <QList>

class TYStageManager;

class TYRespondRectManager : public QObject
{
    Q_OBJECT
    
public:
    // Constructor
    TYRespondRectManager(TYStageManager* manager, QObject* parent = nullptr);
    ~TYRespondRectManager();
    
    // Add selection with rect
    void addSelection(int buttonId, const QRect& rect);
    
    // Initialize button images
    void initialButtonImage();
    
    // Selection
    int selectedButtonId() const { return m_selectedButtonId; }
    int selectedIndex() const { return m_selectedIndex; }
    int incrementToIndex();
    int decrementToIndex();
    
    // Rect map data
    QByteArray rectMapData() const { return m_rectMapData; }
    
    // Check if selection changed
    bool changeSelection(int index);
    
    // Drawing
    void draw();
    
    // Clear
    void clear();
    
signals:
    void selectionChanged(int index);
    
private:
    TYStageManager* m_stageManager;
    QList<QRect> m_btnArray;
    QImage m_drawBuffer;
    int m_beforeSelection;
    QByteArray m_rectMapData;
    int m_selectedButtonId;
    int m_selectedIndex;
};

#endif // TYRESPONDRECTMANAGER_QT_H