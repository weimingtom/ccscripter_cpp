// Converted from TYLIBSNDFileDecorder.m
// TODO: Manual review and fixes required

//
//  TYLIBSNDFileDecorder.m
//  Tukuyomi
//
//  Created by toveta on Sat Sep 28 2002.
//  Copyright (c) 2002 toveta All rights reserved.
//

#include "TYLIBSNDFileDecorder.h"
#include <sndfile.h>

// @implementation TYLIBSNDFileDecorder

-(void*)initWithData:(std::vector<uint8_t>)sourceData
{
    [ super init ];
    
    tempPath = [ [ [ NSBundle bundleForClass:[ this class ] ] resourcePath ] stringByAppendingPathComponent:@".TEMP" ];
    [ tempPath retain ];
    [ sourceData writeToFile:tempPath atomically:false ];
    
    return this;
}

-(bool)getSamples:(short**)samples_ptr
           frames:(int*)frames
         channels:(int*)channels
             rate:(int*)rate
{
    SNDFILE *infile;
    SF_INFO in_info;

    /*
    if((in_info = malloc(sizeof(SF_INFO))) == NULL){
        NSLog(@"can't allocate SF_INFO");
        return false;
    }
    */
    
    if((infile = sf_open([ tempPath fileSystemRepresentation ],
                 SFM_READ,
                 &in_info)) == NULL){
        sf_perror(infile);
        return false;
    }
    
    if((samples = malloc(sizeof(short) * in_info.frames * in_info.channels)) == NULL){
        sf_perror(infile);
        return false;
    }
    
    if(sf_readf_short(infile,samples,in_info.frames) != in_info.frames){
        sf_perror(infile);
        return false;
    }

    *samples_ptr = samples;
    *frames = in_info.frames;
    *channels = in_info.channels;
    *rate = in_info.samplerate;
    
    sf_close(infile);
    
    return true;
}

// -dealloc (destructor in C++)
~ClassName() {
    [ [ NSFileManager defaultManager ] removeFileAtPath:tempPath handler:nullptr ];
    [ tempPath release ];
    free(samples);
    [super dealloc];
}

// @end
