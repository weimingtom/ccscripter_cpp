// Converted from TYFullScreenContentView.h
// TODO: Manual review and fixes required

//
//  TYFullScreenContentView.h
//  Tukuyomi
//
//  Created by toveta on Sat Feb 16 2002.
//  Copyright (c) 2001 toveta All rights reserved.
//



class TYFullScreenContentView : public NSView {

}
void drawRect(NSRect rect);;

};
