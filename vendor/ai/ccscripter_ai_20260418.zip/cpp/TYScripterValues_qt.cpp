/*
 *  TYScripterValues.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYScripterValues_qt.h"
#include "TYArrayValue_qt.h"
#include <QFile>
#include <QDataStream>
#include <QDebug>
#include <cstring>

// Static member initialization
int TYScripterValues::s_minGlobalIdNo = MIN_GLOBAL_IDNO;
TYScripterValues* TYScripterValues::s_instance = nullptr;

// Replaces: +(id)ScripterValues
TYScripterValues* TYScripterValues::scripterValues()
{
    if (!s_instance) {
        s_instance = new TYScripterValues();
    }
    return s_instance;
}

// Replaces: +(void)setMinGlobalNo:(int)aInt
void TYScripterValues::setMinGlobalNo(int aInt)
{
    s_minGlobalIdNo = aInt;
}

// Constructor
TYScripterValues::TYScripterValues(QObject* parent)
    : QObject(parent)
{
    initialize();
}

void TYScripterValues::initialize()
{
    // Initialize string values with empty strings
    for (int i = 0; i < NUM_OF_VALUES; i++) {
        m_strValues[i] = QString();
    }
}

TYScripterValues::~TYScripterValues()
{
    qDeleteAll(m_arrayValues);
    m_arrayValues.clear();
}

// Replaces: -(NSString*)getStringValue:(id)idno
QString TYScripterValues::getStringValue(const QVariant& idno)
{
    int intId = idno.toInt();
    if (intId >= 0 && intId < NUM_OF_VALUES) {
        return m_strValues[intId];
    }
    return QString();
}

// Replaces: -(NSNumber*)getIntValue:(id)idno
QVariant TYScripterValues::getIntValue(const QVariant& idno)
{
    if (idno.canConvert<int>()) {
        int intId = idno.toInt();
        Q_ASSERT_X((intId >= 0) && (intId < NUM_OF_VALUES), 
                    "TYScripterValues::getIntValue", 
                    "int value reference overflow");
        return QVariant(m_values[intId]);
    } else {
        // Array variable case
        // TODO: Implement array value lookup
        return QVariant();
    }
}

// Replaces: -(void)setStringValue:(id)idno object:(NSString*)setString
void TYScripterValues::setStringValue(const QVariant& idno, const QString& setString)
{
    int intId = idno.toInt();
    Q_ASSERT_X((intId >= 0) && (intId < NUM_OF_VALUES),
               "TYScripterValues::setStringValue",
               "string value reference overflow");
    m_strValues[intId] = setString;
}

// Replaces: -(void)setIntValue:(id)idno object:(NSNumber*)setNumber
void TYScripterValues::setIntValue(const QVariant& idno, const QVariant& setNumber)
{
    if (idno.canConvert<int>()) {
        int intId = idno.toInt();
        Q_ASSERT_X((intId >= 0) && (intId < NUM_OF_VALUES),
                   "TYScripterValues::setIntValue",
                   "int value reference overflow");
        
        m_values[intId] = setNumber.toInt();
        
        // Apply limits if set
        QString key = QString::number(intId);
        if (m_limitDict.contains(key)) {
            QVariantList limitArray = m_limitDict.value(key);
            if (m_values[intId] < limitArray[0].toInt()) {
                m_values[intId] = limitArray[0].toInt();
            } else if (m_values[intId] > limitArray[1].toInt()) {
                m_values[intId] = limitArray[1].toInt();
            }
        }
    } else {
        // Array variable case
        // TODO: Implement array value setting
    }
}

// Replaces: -(void)setArrayLine:(id)idno values:(NSArray*)aArray
void TYScripterValues::setArrayLine(const QVariant& idno, const QVariantList& aArray)
{
    Q_UNUSED(idno);
    Q_UNUSED(aArray);
    // TODO: Implement array line setting
}

// Replaces: -(void)setIntLimitID:(id)idno low:(id)aLow high:(id)aHigh
void TYScripterValues::setIntLimitId(const QVariant& idno, const QVariant& aLow, const QVariant& aHigh)
{
    QString key = idno.toString();
    QVariantList limitArray;
    limitArray.append(aLow);
    limitArray.append(aHigh);
    m_limitDict.insert(key, limitArray);
}

// Replaces: -(void)defineArrayValue:(NSArray*)aArray
void TYScripterValues::defineArrayValue(const QVariantList& aArray)
{
    if (aArray.isEmpty()) {
        return;
    }
    
    int idNo = aArray[0].toInt();
    
    // Build increment array (+1 for each element except first)
    QVariantList incArray;
    for (int i = 1; i < aArray.size(); i++) {
        incArray.append(aArray[i].toInt() + 1);
    }
    
    TYArrayValue* arrayValue = new TYArrayValue(idNo, incArray);
    m_arrayValues.insert(QString::number(idNo), arrayValue);
}

// Replaces: -(BOOL)loadGlobalValues:(NSString*)path
bool TYScripterValues::loadGlobalValues(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QDataStream in(&file);
    in.setByteOrder(QDataStream::LittleEndian);
    
    for (int i = s_minGlobalIdNo; i < MAX_GLOBAL_IDNO; i++) {
        // Read integer value
        in >> m_values[i];
        
        // Read string value (as QByteArray for CS-JIS encoding)
        QByteArray strData;
        in >> strData;
        if (!strData.isEmpty()) {
            m_strValues[i] = QString::fromLatin1(strData);
        }
    }
    
    file.close();
    return true;
}

// Replaces: -(BOOL)saveGlobalValues:(NSString*)path
bool TYScripterValues::saveGlobalValues(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }
    
    QDataStream out(&file);
    out.setByteOrder(QDataStream::LittleEndian);
    
    for (int i = s_minGlobalIdNo; i < MAX_GLOBAL_IDNO; i++) {
        // Write integer value
        out << m_values[i];
        
        // Write string value (as CS-JIS encoded bytes)
        QByteArray strData = m_strValues[i].toLatin1();
        out << strData;
    }
    
    file.close();
    return true;
}

// Replaces: -(void)margeGlobalValues:(TYScripterValues*)margeValues
void TYScripterValues::mergeGlobalValues(TYScripterValues* margeValues)
{
    if (!margeValues) {
        return;
    }
    
    for (int i = s_minGlobalIdNo; i < MAX_GLOBAL_IDNO; i++) {
        if (m_values[i] == 0) {
            m_values[i] = margeValues->m_values[i];
        }
        if (m_strValues[i].isEmpty()) {
            m_strValues[i] = margeValues->m_strValues[i];
        }
    }
}

// Replaces: -(void)resetGame
void TYScripterValues::resetGame()
{
    for (int i = 0; i < s_minGlobalIdNo; i++) {
        m_values[i] = 0;
        m_strValues[i].clear();
    }
}

// Serialization methods

// Replaces: -(id)encodeWithSaveData
QVariantList TYScripterValues::encodeWithSaveData() const
{
    QVariantList saveData;
    
    // Encode global variables
    QByteArray globalData;
    globalData.reserve(s_minGlobalIdNo * 5);
    
    for (int i = 0; i < s_minGlobalIdNo; i++) {
        // Store integer value (4 bytes)
        quint32 val = static_cast<quint32>(m_values[i]);
        globalData.append(reinterpret_cast<const char*>(&val), 4);
        
        // Store string value (CS-JIS encoded)
        QByteArray strData = m_strValues[i].toLatin1();
        globalData.append(strData);
        globalData.append('\0');  // Null terminator
    }
    
    saveData.append(globalData);
    
    // For array values, would need to serialize separately
    // TODO: Encode arrayValues
    
    return saveData;
}

// Replaces: -(void)decodeWithSaveData:(id)aObject
void TYScripterValues::decodeWithSaveData(const QVariantList& data)
{
    if (data.isEmpty()) {
        return;
    }
    
    QByteArray globalData = data[0].toByteArray();
    const char* ptr = globalData.constData();
    int len = globalData.size();
    int pos = 0;
    
    for (int i = 0; i < s_minGlobalIdNo && pos < len; i++) {
        // Read integer value (4 bytes)
        if (pos + 4 <= len) {
            quint32 val;
            std::memcpy(&val, ptr + pos, 4);
            m_values[i] = static_cast<int>(val);
            pos += 4;
        }
        
        // Read string value (null-terminated)
        if (pos < len) {
            QString str = QString::fromLatin1(ptr + pos);
            m_strValues[i] = str;
            pos += str.length() + 1;
        }
    }
}