/*
 *  TYQuakeEffectGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Quake/shake transition effect generator.
 */

#ifndef TYQUAKEEFFECTGENERATER_QT_H
#define TYQUAKEEFFECTGENERATER_QT_H

#include <QObject>
#include <QImage>
#include <QTimer>
#include <QDateTime>
#include "TYEffecter_qt.h"

// Quake type enum
enum TYQuakeType {
    TYQuakeTypeHorizontal,
    TYQuakeTypeVertical
};

class TYQuakeEffectGenerater : public QObject
{
    Q_OBJECT
    
public:
    TYQuakeEffectGenerater(const QImage& image, int type, int times, int second,
                          QObject* parent = nullptr);
    ~TYQuakeEffectGenerater();
    
    QImage currentImage() const { return m_currentImage; }
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
public slots:
    void drawEffect();
    
private:
    QImage m_sourceImage;
    QImage m_currentImage;
    TYQuakeType m_quakeType;
    int m_quakeTimes;
    int m_quakeSecond;
    int m_timeOfShake;
    int m_timeOfQuarter;
    QDateTime m_startDate;
    bool m_isComplete;
};

#endif // TYQUAKEEFFECTGENERATER_QT_H