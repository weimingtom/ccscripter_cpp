// Converted from TYExtVolumeController.h
// TODO: Manual review and fixes required

/* TYExtVolumeController */




class TYExtVolumeController : public TYBGMVolumeController {
    IBOutlet NSSlider *SESlider;
    IBOutlet NSSlider *VoiceSlider;

    float defaultBGMVolume;
    float defaultVoiceVolume;
    float defaultSEVolume;
}
IBAction setDefault(id sender);;

id initWithDefaultBGMVolume(float defBGMVol);
                    bgmVolume:(float)bgmVol
           defaultVoiceVolume:(float)defVoiceVol
                  voiceVolume:(float)voiceVol
              defaultSEVolume:(float)defSEVol
                     seVolume:(float)seVol;

float voiceVolume();
float seVolume();

};
