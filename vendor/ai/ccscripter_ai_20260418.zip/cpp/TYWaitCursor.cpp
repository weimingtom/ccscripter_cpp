// Converted from TYWaitCursor.m
// TODO: Manual review and fixes required

//
//  TYWaitCursor.m
//  Tukuyomi
//
//  Created by toveta on Sat Mar 09 2002.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYWaitCursor.h"
#include "TYStageManager.h"

// @implementation TYWaitCursor

-(void*)initWithResource:(std::string)aPath offset:(NSPoint)point absolute:(bool)aBool
{
    this = [ super init ];
    if(![ aPath length ]){
        [ this autorelease ];
        return nullptr;
    }

    resourcePath = [ aPath retain ];
    offset = point;
    isAbsolute = aBool;
    
    return this;
}

// REMOVED: -voidloadImage{
    if(isLoad)
        return;
    isLoad = true;

    cursorImage = [ [ TYResourceServer sharedServer ] getImage:resourcePath transMode:true animate:true ];
    if(!cursorImage)
        return ;
    [ cursorImage retain ];
    if([ cursorImage isAnimate ]){
        [ (TYAnimationCellImage*)cursorImage setDelegate:this ];
    }
    cursorSize = (cursorImage) ? [ cursorImage size ] : NSZeroSize ;

    bufferImage = [ [ NSImage alloc ] initWithSize:cursorSize ];
}

-(void)setDelegate:(void*)aObject
{
    delegate = aObject;
}

// REMOVED: -void*compositeLayer{
    return [ delegate compositeLayer ];
}

-(void)drawToView:(void*)aView point:(NSPoint)point
{
    targetView = aView;

    [ this loadImage ];
    if(!cursorImage)
        return;

    if(isAbsolute){
        targetPoint = NSMakePoint(offset.x,VSCREEN_HEIGHT-offset.y-[ cursorImage size ].height);
    } else {
        targetPoint = point;
        targetPoint.x += offset.x;
        targetPoint.y += -offset.y;
        targetPoint.y += -[ cursorImage size ].height;
    }


    if([ (TYAnimationCellImage*)cursorImage isAnimate ]&&(![ (TYAnimationCellImage*)cursorImage isPlaying ])){
        [ (TYAnimationCellImage*)cursorImage play ];
    }

    [ this drawImage:true ];
}


-(void)didChangeCell:(void*)sender
{
    [ this drawImage:true ];
}

-(void)drawImage:(bool)aBool
{
    NSImage *offscreen;
    NSRect inRect = NSMakeRect(targetPoint.x,
                               (isAbsolute) ? VSCREEN_HEIGHT -offset.y -cursorSize.height : targetPoint.y ,
                               cursorSize.width,
                               cursorSize.height);
    
    // ItXN[擾
    offscreen = [ delegate compositeLayer ];

    // obt@ɃRs[
    [ bufferImage lockFocus ];
    NSEraseRect(NSMakeRect(0,0,inRect.size.width,inRect.size.height));
    [ offscreen compositeToPoint:NSZeroPoint
                        fromRect:inRect
                       operation:NSCompositeCopy ];
     
    if(aBool){
        //[ offscreen lockFocus ];
        [ cursorImage compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
        //[ offscreen unlockFocus ];
    }
    [ bufferImage unlockFocus ];

    // EChEɕ`
     [ targetView directDrawImage:bufferImage
                          inRect:inRect
                        fromRect:NSMakeRect(0,0,cursorSize.width,cursorSize.height) ];
    //[ targetView setImage:offscreen ];

}

// REMOVED: -voidclear{
    if(!cursorImage)
        return;

    [ this stop ];
    
    [ targetView setImage:[ delegate compositeLayer ] ];
    //[ this drawImage:false ];
}

// REMOVED: -voidstop{
    if(cursorImage && [ (TYAnimationCellImage*)cursorImage isAnimate ]&&[ (TYAnimationCellImage*)cursorImage isPlaying ]){
        [ (TYAnimationCellImage*)cursorImage stop ];
    }    
}

// REMOVED: -voidresume{
    if(cursorImage && [ (TYAnimationCellImage*)cursorImage isAnimate ])
        [ (TYAnimationCellImage*)cursorImage resume ];
}

// -dealloc (destructor in C++)
~ClassName() {
    [ cursorImage release ];
    [resourcePath release];
    [ bufferImage release ];
    [super dealloc];
}

// REMOVED: -std::stringdescription{
    return [ NSString stringWithFormat:@"path=%@ point=%@ absolute=%d",resourcePath,NSStringFromPoint(offset),isAbsolute ];
}

// ----------------------------------------------------------------------------------------
// NSCoding
// ----------------------------------------------------------------------------------------

- (void*)initWithCoder:(NSCoder *)aDecoder
{
    // [super init] - needs manual fix;
    resourcePath = [ [ aDecoder decodeObject ] retain ];
    offset = [ aDecoder decodePoint ];
    [ aDecoder decodeValueOfObjCType:@encode(bool) at:&isAbsolute ];

    return this;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [ aCoder encodeObject:resourcePath ];
    [ aCoder encodePoint:offset ];
    [ aCoder encodeValueOfObjCType:@encode(bool) at:&isAbsolute ];

}

// @end
