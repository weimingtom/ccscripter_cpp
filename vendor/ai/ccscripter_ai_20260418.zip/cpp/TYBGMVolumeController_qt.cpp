/*
 *  TYBGMVolumeController.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYBGMVolumeController_qt.h"

TYBGMVolumeController::TYBGMVolumeController(float volume, QObject* parent)
    : QObject(parent)
    , m_delegate(nullptr)
    , m_volume(volume)
{
}

TYBGMVolumeController::~TYBGMVolumeController()
{
}

void TYBGMVolumeController::showDialog()
{
    // Would show Qt dialog
}

void TYBGMVolumeController::setBGMVolume(float volume)
{
    m_volume = volume;
    emit volumeChanged(volume);
}