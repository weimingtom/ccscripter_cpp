// Converted from TYBGLZSSDecorder.m
// TODO: Manual review and fixes required

//
//  TYBGLZSSDecorder.m
//  Tukuyomi
//
//  Created by toveta on Sat Nov 02 2002.
//  Copyright (c) 2002 toveta All rights reserved.
//

#include "TYBGLZSSDecorder.h"
#include "lzss.h"

// @implementation TYBGLZSSDecorder

static std::vector<uint8_t>decodeData;
static int encode_size,original_size;
static bool is_end;

+(std::vector<uint8_t>)decodeWithFileHandle:(NSFileHandle*)fh encode_size:(int)e original_size:(int)o
{

    is_end = false;
    encode_size = e;
    original_size = o;
    
    [ NSThread detachNewThreadSelector:@selector(decode:)
                              toTarget:this
                            withObject:fh ];
    
    while(!is_end)
        [ [ NSRunLoop currentRunLoop ] runUntilDate:[ NSDate dateWithTimeIntervalSinceNow:0.01 ] ];
        
    [ decodeData autorelease ];
    return decodeData;
}

// private
+(void)decode:(NSFileHandle*)fh
{
    NSAutoreleasePool *ap = [ [ NSAutoreleasePool alloc ] init ];
    decodeData = TYDataWithLzssDecodeFromFile(fh,encode_size,original_size);
    [ decodeData retain ];
    is_end = true;
    [ ap release ];
}
// @end
