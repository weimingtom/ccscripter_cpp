/*
 *  TYArrayValue.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYArrayValue_qt.h"
#include <QDebug>

TYArrayValue::TYArrayValue(int idNo, const QVariantList& limits, QObject* parent)
    : QObject(parent)
    , m_idNo(idNo)
    , m_limits(limits)
{
    // Calculate total size and initialize
    int totalSize = 1;
    for (const QVariant& limit : limits) {
        totalSize *= (limit.toInt() + 1);  // +1 because NScripter arrays are 1-indexed
    }
    m_data.resize(totalSize);
}

TYArrayValue::~TYArrayValue()
{
}

// Replaces: -(NSNumber*)getNumOfAddress:(NSArray*)address
QVariant TYArrayValue::getNumOfAddress(const QVariantList& address) const
{
    int index = calculateIndex(address);
    if (index >= 0 && index < m_data.size()) {
        return m_data[index];
    }
    return QVariant(0);
}

// Replaces: -(void)setNum:(NSNumber*)number address:(NSArray*)address
void TYArrayValue::setNum(const QVariant& number, const QVariantList& address)
{
    int index = calculateIndex(address);
    if (index >= 0 && index < m_data.size()) {
        m_data[index] = number;
    }
}

// Replaces: -(void)setNumbers:(NSArray*)numbers address:(NSArray*)address
void TYArrayValue::setNumbers(const QVariantList& numbers, const QVariantList& address)
{
    int baseIndex = calculateIndex(address);
    for (int i = 0; i < numbers.size() && (baseIndex + i) < m_data.size(); i++) {
        m_data[baseIndex + i] = numbers[i];
    }
}

// Calculate linear index from multi-dimensional address
int TYArrayValue::calculateIndex(const QVariantList& address) const
{
    if (address.isEmpty()) {
        return 0;
    }
    
    int index = 0;
    int multiplier = 1;
    
    for (int i = 0; i < address.size() && i < m_limits.size(); i++) {
        int dimIndex = address[i].toInt() - 1;  // Convert to 0-based index
        if (dimIndex < 0 || dimIndex > m_limits[i].toInt()) {
            return -1;  // Out of bounds
        }
        index += dimIndex * multiplier;
        multiplier *= (m_limits[i].toInt() + 1);
    }
    
    return index;
}