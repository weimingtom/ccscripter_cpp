/*
 *  TYRespondRectManager.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYRespondRectManager_qt.h"
#include "TYStageManager_qt.h"

TYRespondRectManager::TYRespondRectManager(TYStageManager* manager, QObject* parent)
    : QObject(parent)
    , m_stageManager(manager)
    , m_beforeSelection(-1)
    , m_selectedButtonId(-1)
    , m_selectedIndex(-1)
{
}

TYRespondRectManager::~TYRespondRectManager()
{
}

void TYRespondRectManager::addSelection(int buttonId, const QRect& rect)
{
    m_btnArray.append(rect);
    Q_UNUSED(buttonId);
}

void TYRespondRectManager::initialButtonImage()
{
    // Would initialize button images
}

int TYRespondRectManager::incrementToIndex()
{
    if (m_btnArray.isEmpty()) {
        return -1;
    }
    m_selectedIndex = (m_selectedIndex + 1) % m_btnArray.size();
    return m_selectedIndex;
}

int TYRespondRectManager::decrementToIndex()
{
    if (m_btnArray.isEmpty()) {
        return -1;
    }
    m_selectedIndex--;
    if (m_selectedIndex < 0) {
        m_selectedIndex = m_btnArray.size() - 1;
    }
    return m_selectedIndex;
}

bool TYRespondRectManager::changeSelection(int index)
{
    bool changed = (index != m_beforeSelection);
    m_beforeSelection = index;
    m_selectedIndex = index;
    
    if (changed) {
        emit selectionChanged(index);
    }
    
    return changed;
}

void TYRespondRectManager::draw()
{
    // Would render to draw buffer
}

void TYRespondRectManager::clear()
{
    m_btnArray.clear();
    m_selectedIndex = -1;
    m_selectedButtonId = -1;
}