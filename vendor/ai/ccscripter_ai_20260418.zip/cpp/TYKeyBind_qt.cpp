/*
 *  TYKeyBind.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYKeyBind_qt.h"
#include "TYMiscUtil_qt.h"
#include <QCoreApplication>
#include <QDir>
#include <QSettings>

static QMap<unsigned short, QString> s_keyBindDict;
static bool s_initialized = false;

static void init()
{
    if (s_initialized) {
        return;
    }
    
    QString path = getNScrRootDirectory() + "/" + KEYBIND_FILENAME;
    
    // Try to load from file
    QSettings settings(path, QSettings::IniFormat);
    if (!settings.status()) {
        for (const QString& key : settings.allKeys()) {
            s_keyBindDict.insert(key.toUShort(), settings.value(key).toString());
        }
    }
    
    // Fallback to bundle resource
    if (s_keyBindDict.isEmpty()) {
        // In Qt, would look for resource file
        // For now, use common defaults
    }
    
    s_initialized = true;
}

// Replaces: SEL TYSelectorForKeycode(unsigned short aCode)
QString TYSelectorForKeycode(unsigned short aCode)
{
    if (!s_initialized) {
        init();
    }
    
    return s_keyBindDict.value(aCode, QString());
}