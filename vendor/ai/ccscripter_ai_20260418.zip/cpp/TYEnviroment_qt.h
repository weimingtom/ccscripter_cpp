/*
 *  TYEnviroment.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Environment/configuration manager for Tukuyomi
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSMutableDictionary -> QSettings / QMap
 *  + (id)objectForKey: -> static QVariant get(const QString& key)
 */

#ifndef TYENVIRONMENT_QT_H
#define TYENVIRONMENT_QT_H

#include <QObject>
#include <QString>
#include <QVariant>
#include <QMap>

class TYEnviroment : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)objectForKey:(id)aObj
    static QVariant objectForKey(const QString& key);
    
    // Replaces: +(id)defaultObjectForKey:(id)aObj
    static QVariant defaultObjectForKey(const QString& key);
    
    // Replaces: +(void)setObject:(id)aObj forKey:(id)aKey
    static void setObject(const QVariant& value, const QString& key);
    
    // Replaces: +(void)save
    static void save();
    
    // Replaces: +(float)floatForKey:(id)aObj
    static float floatForKey(const QString& key);
    
    // Replaces: +(BOOL)boolForKey:(id)aKey
    static bool boolForKey(const QString& key);
    
    // Replaces: +(void)reload
    static void reload();
    
    // Get singleton instance
    static TYEnviroment* instance();
    
private:
    explicit TYEnviroment(QObject* parent = nullptr);
    
    void load();
    void saveToFile();
    
    QMap<QString, QVariant> m_defaults;
    QMap<QString, QVariant> m_data;
    
    static TYEnviroment* s_instance;
};

// Constants for dictionary keys
// Replaces: extern NSString* const TYXXXEnviroment;
namespace TYEnvKeys {
    extern const QString FontName;
    extern const QString AudioFilePath;
    extern const QString WindowPointX;
    extern const QString WindowPointY;
    extern const QString BGMVolume;
    extern const QString VoiceVolume;
    extern const QString SEVolume;
    extern const QString ScaleInFullScreenMode;
    extern const QString EnableBoldFont;
    extern const QString FullScreenMode;
    extern const QString WaveExtraName;
    extern const QString DisableSelectScript;
    extern const QString LookbackBufferPage;
    extern const QString LookbackVoiceReplay;
    extern const QString DisplayResizeAtFullScreen;
    extern const QString AutomodeWaitType;
    extern const QString AutomodeWaitTime;
    extern const QString Kidokumode;
    extern const QString EnablePlayMovie;
    extern const QString HideOtherFullScreen;
    extern const QString LastSelectedFolderPref;
}

// Config file name
// Replaces: #define ENVDATA_FILENAME @"envdata.plist"
const QString ENV_FILENAME = QStringLiteral("envdata.plist");

#endif // TYENVIRONMENT_QT_H