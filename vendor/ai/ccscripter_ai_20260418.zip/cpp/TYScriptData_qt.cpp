/*
 *  TYScriptData.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYScriptData_qt.h"
#include "TY_NSStringAddition_qt.h"
#include <QDir>
#include <QFile>
#include <QTextStream>

TYScriptData::TYScriptData(const QString& path, QObject* parent)
    : QObject(parent)
{
    initWithDirectory(path);
}

TYScriptData::TYScriptData(const QStringList& pathArray, QObject* parent)
    : QObject(parent)
{
    initWithTextFiles(pathArray);
}

TYScriptData::TYScriptData(const QString& encodingFile, bool, QObject* parent)
    : QObject(parent)
{
    Q_UNUSED(encodingFile);
    // Would initialize from encoding file
}

TYScriptData::~TYScriptData()
{
}

void TYScriptData::initWithDirectory(const QString& path)
{
    QDir dir(path);
    if (!dir.exists()) {
        return;
    }
    
    // Get all .txt files sorted
    QStringList filters;
    filters << "*.txt";
    QStringList files = dir.entryList(filters, QDir::Files | QDir::Readable, QDir::Name);
    
    initWithTextFiles(files);
}

void TYScriptData::initWithTextFiles(const QStringList& pathArray)
{
    m_data.clear();
    m_labels.clear();
    m_labelDict.clear();
    
    int lineNum = 0;
    
    for (const QString& filePath : pathArray) {
        QFile file(filePath);
        if (!file.open(QIODevice::ReadOnly)) {
            continue;
        }
        
        QTextStream in(&file);
        in.setCodec("Shift-JIS");
        
        while (!in.atEnd()) {
            QString line = in.readLine();
            m_data.append(line);
            
            // Check for labels (lines ending with :)
            QString trimmed = line.trimmed();
            if (trimmed.endsWith(':')) {
                QString label = trimmed.left(trimmed.length() - 1);
                m_labels.append(label);
                m_labelDict.insert(label, lineNum);
            }
            
            lineNum++;
        }
        
        file.close();
    }
}

int TYScriptData::lineOfLabel() const
{
    return m_labels.size();
}

int TYScriptData::lineOfInstantLabelWithNowLine(int nowLine, bool reverse) const
{
    if (m_labels.isEmpty()) {
        return -1;
    }
    
    if (reverse) {
        // Find previous label
        for (int i = m_labels.size() - 1; i >= 0; i--) {
            if (m_labelDict.value(m_labels[i]) < nowLine) {
                return m_labelDict.value(m_labels[i]);
            }
        }
    } else {
        // Find next label
        for (int i = 0; i < m_labels.size(); i++) {
            if (m_labelDict.value(m_labels[i]) > nowLine) {
                return m_labelDict.value(m_labels[i]);
            }
        }
    }
    
    return -1;
}

QString TYScriptData::stringAtIndex(int index) const
{
    if (index >= 0 && index < m_data.size()) {
        return m_data[index];
    }
    return QString();
}

QByteArray TYScriptData::dataAtIndex(int index) const
{
    // Return as Shift-JIS encoded bytes
    QString str = stringAtIndex(index);
    return str.toLatin1();
}