/*
 *  TYPatternFadeGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Pattern-based fade transition effect generator.
 */

#ifndef TYPATTERNFADEGENERATER_QT_H
#define TYPATTERNFADEGENERATER_QT_H

#include <QObject>
#include <QImage>
#include <QTimer>
#include <QDateTime>
#include "TYEffecter_qt.h"
#include "TYEffectPatternMap_qt.h"

class TYPatternFadeGenerater : public QObject
{
    Q_OBJECT
    
public:
    TYPatternFadeGenerater(const QImage& beforeImage, const QImage& afterImage,
                          TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    ~TYPatternFadeGenerater();
    
    QImage currentImage() const { return m_currentImage; }
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
public slots:
    void drawEffect();
    
private:
    QImage m_beforeImage;
    QImage m_afterImage;
    QImage m_currentImage;
    TYEffectPatternMap* m_patternMap;
    const uint8_t* m_patternPtr;
    int m_patternWide;
    int m_patternHigh;
    QDateTime m_startDate;
    int m_effectTime;
    double m_phaseInterval;
    bool m_isComplete;
};

#endif // TYPATTERNFADEGENERATER_QT_H