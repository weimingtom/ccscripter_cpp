/*
 *  TYSarArchiver.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYSarArchiver_qt.h"
#include "TYSarArchivedFile_qt.h"
#include <QFile>
#include <QDebug>
#include <cstring>

// Replaces: +(id)archiverWithContentsOfFile:(NSString*)path
TYSarArchiver* TYSarArchiver::archiverWithContentsOfFile(const QString& path)
{
    return new TYSarArchiver(path);
}

// Replaces: -(id)initWithContentsOfFile:(NSString*)path
TYSarArchiver::TYSarArchiver(const QString& path, QObject* parent)
    : QObject(parent)
    , m_baseOffset(0)
{
    m_arcPath = path;
    loadArchive();
}

void TYSarArchiver::loadArchive()
{
    QFile file(m_arcPath);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Cannot open SAR archive:" << m_arcPath;
        return;
    }
    
    // Read number of files (2 bytes, big-endian)
    QByteArray header = file.read(2);
    if (header.size() < 2) {
        qWarning() << "Invalid SAR archive header";
        return;
    }
    
    const uint8_t* ptr = reinterpret_cast<const uint8_t*>(header.constData());
    unsigned filenum = (ptr[0] << 8) | ptr[1];
    
    // Read base offset (4 bytes, big-endian)
    QByteArray offsetData = file.read(4);
    if (offsetData.size() < 4) {
        qWarning() << "Invalid SAR archive offset";
        return;
    }
    
    ptr = reinterpret_cast<const uint8_t*>(offsetData.constData());
    m_baseOffset = (ptr[0] << 24) | (ptr[1] << 16) | (ptr[2] << 8) | ptr[3];
    
    // Read file entries
    for (unsigned i = 0; i < filenum; ++i) {
        // Read filename (null-terminated, max 256 chars)
        QByteArray filenameData;
        char c;
        while (file.getChar(&c)) {
            if (c == '\0') {
                break;
            }
            // Convert backslash to forward slash
            filenameData.append(c == '\\' ? '/' : c);
        }
        
        if (filenameData.isEmpty()) {
            continue;
        }
        
        QString filename = QString::fromLatin1(filenameData.constData());
        
        // Read file offset (4 bytes, big-endian)
        QByteArray offsetBuf = file.read(4);
        if (offsetBuf.size() < 4) {
            break;
        }
        ptr = reinterpret_cast<const uint8_t*>(offsetBuf.constData());
        unsigned fileOffset = (ptr[0] << 24) | (ptr[1] << 16) | (ptr[2] << 8) | ptr[3];
        
        // Read file length (4 bytes, big-endian)
        QByteArray lengthBuf = file.read(4);
        if (lengthBuf.size() < 4) {
            break;
        }
        ptr = reinterpret_cast<const uint8_t*>(lengthBuf.constData());
        unsigned fileLength = (ptr[0] << 24) | (ptr[1] << 16) | (ptr[2] << 8) | ptr[3];
        
        // Create archived file object
        TYSarArchivedFile* archivedFile = new TYSarArchivedFile(fileOffset, fileLength);
        m_filesDict.insert(filename.toLower(), archivedFile);
    }
    
    file.close();
}

TYSarArchiver::~TYSarArchiver()
{
    qDeleteAll(m_filesDict);
}

// Replaces: -(NSFileHandle*)fileHandleWithPath:(NSString*)aPath length:(int*)length
QFile* TYSarArchiver::fileHandleWithPath(const QString& aPath, qint64* length)
{
    TYSarArchivedFile* tmp = m_filesDict.value(aPath.toLower());
    if (!tmp) {
        return nullptr;
    }
    
    QFile* handle = new QFile(m_arcPath);
    if (!handle->open(QIODevice::ReadOnly)) {
        delete handle;
        return nullptr;
    }
    
    unsigned fileOffset;
    tmp->getFileDataOffset(&fileOffset, reinterpret_cast<unsigned*>(length));
    
    handle->seek(fileOffset + m_baseOffset);
    return handle;
}

// Replaces: -(NSData*)unArchivedFile:(NSString*)address
QByteArray TYSarArchiver::unArchivedFile(const QString& address)
{
    TYSarArchivedFile* tmp = m_filesDict.value(address.toLower());
    if (!tmp) {
        return QByteArray();
    }
    
    unsigned fileOffset, fileLength;
    tmp->getFileDataOffset(&fileOffset, &fileLength);
    
    return readDataOffset(fileOffset, fileLength);
}

// Replaces: -(NSData*)readDataOffset:(unsigned)offset length:(unsigned)length
QByteArray TYSarArchiver::readDataOffset(unsigned offset, unsigned length)
{
    QFile file(m_arcPath);
    if (!file.open(QIODevice::ReadOnly)) {
        return QByteArray();
    }
    
    file.seek(offset + m_baseOffset);
    QByteArray data = file.read(length);
    file.close();
    
    return data;
}