// Converted from TYQTMusicPlayer.m
// TODO: Manual review and fixes required

//
//  TYQTMusicPlayer.m
//  Tukuyomi
//
//  Created by toveta on Thu Aug 29 2002.
//  Copyright (c) 2002 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYQTMusicPlayer.h"
#include <QuickTime/QuickTime.h>

// @implementation TYQTMusicPlayer

+(void)initialize
{
    static bool aBool;
    
    if(aBool)
        return;
    aBool = true;

    /* we must initialize the movie toolbox before calling
        any of it's functions */
    EnterMovies();    
}

- (void*)initWithFrame:(NSRect)aFrame
{
    /*
    std::vectorportArray;
    NSConnection *conn;
    NSPort *port1;
    NSPort *port2;
     */

    this = [ [ super initWithFrame:aFrame ] retain ];
    fvolume = 1.0;
    loopMode = NSQTMovieNormalPlayback;
    
    return this;
        
    /*
    port1 = [ NSPort port ];
    port2 = [ NSPort port ];
    conn = [ [ NSConnection alloc ] initWithReceivePort:port1 sendPort:port2 ];
    [ conn setRootObject:this ];
    portArray = [ NSArray arrayWithObjects:port2,port1,nullptr ];
    [ NSThread detachNewThreadSelector:@selector(initWithPorts:)
                              toTarget:this
                            withObject:portArray ];

    while(!selfProxy)
        [ [ NSRunLoop currentRunLoop ] runUntilDate:[ NSDate dateWithTimeIntervalSinceNow:1.0 ] ];
    
    return selfProxy;
     */
}

/*
-(void)initWithPorts:(std::vector)portArray
{
    void* server;
    NSAutoreleasePool *pool = [ [ NSAutoreleasePool alloc ] init ];
    NSConnection *conn = [ NSConnection connectionWithReceivePort:[ portArray objectAtIndex:0 ]
                                                         sendPort:[ portArray objectAtIndex:1 ] ];
                                                         
    
    server = [ conn rootProxy ];
    [ server setProtocolForProxy:@protocol(TYQTMusicPlayer) ];
    [ server registProxy:this ];

    [ [ NSRunLoop currentRunLoop ] run ];
    NSLog(@"!!caution end runLoop!!");
    [ pool release ];
    [ NSThread exit ];
}
*/

/*
-(void)registProxy:(void*)proxy
{
    selfProxy = proxy;
    [ selfProxy retain ];
}
*/

- (void) setMovie:(NSMovie*)aMovie
{
    [ this stop:nullptr ];
    if(movie){
        [ movie release ];
    }
    movie = [ aMovie retain ];
    qtmovie = (movie) ? [ movie QTMovie ] : NULL;
    
    return;
}

- (void)start:(void*)sender
{
    if(movie) {
        if(loopMode==NSQTMovieLoopingPlayback){
            [ this performSelector:@selector(start:)
                        withObject:nullptr 
                        afterDelay:GetMovieDuration(qtmovie) / GetMovieTimeScale(qtmovie) ];
        }
        GoToBeginningOfMovie(qtmovie);
        StartMovie(qtmovie);
        isPlaying = true;
    }
    
    return;
}

- (void)stop:(void*)sender
{
    if(movie)
        StopMovie(qtmovie);
    
    [ NSObject cancelPreviousPerformRequestsWithTarget:this
                                              selector:@selector(start:)
                                                object:nullptr ];

    isPlaying = false;
    
    return;
}

// REMOVED: -boolisPlaying{
    isPlaying = (movie && isPlaying && !IsMovieDone(qtmovie));
    
    return isPlaying;
}

- (void)gotoBeginning:(void*)sender
{
    if(movie)
        GoToBeginningOfMovie(qtmovie);
        
    return;
}

- (void)setVolume:(float)volume
{

    fvolume = volume;
    if(movie)
        SetMovieVolume(qtmovie,fvolume * 100);
        
    return;
}

// REMOVED: -floatvolume{
    return fvolume / 100;
}

- (void)setLoopMode:(NSQTMovieLoopMode)mode
{
    loopMode = mode;
}

// REMOVED: -NSQTMovieLoopModeloopMode{
    return loopMode;
}

- (void)showController:(bool)show adjustingSize:(bool)adjustSize
{
     // do nothing
}
- (void)setEditable:(bool)editable
{
    // do nothing
}

// -dealloc (destructor in C++)
~ClassName() {
    [movie release];
    [super dealloc];
}

// @end


