/*
 *  TYInstantGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYInstantGenerater_qt.h"

TYInstantGenerater::TYInstantGenerater(const QImage& beforeImage, const QImage& afterImage,
                                       TYEffectDefinitionValue* effect, QObject* parent)
    : TYEffectGenerater(parent)
{
    // Store images for effect
    Q_UNUSED(beforeImage);
    Q_UNUSED(afterImage);
    Q_UNUSED(effect);
}

void TYInstantGenerater::drawEffect()
{
    // Instant effect - just emit finished signal
    // The afterImage is already set
    emit effectFinished();
}