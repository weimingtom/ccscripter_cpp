/*
 *  TYMosaicEffectGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Mosaic transition effect generator.
 */

#ifndef TYMOSAICEFFECTGENERATER_QT_H
#define TYMOSAICEFFECTGENERATER_QT_H

#include <QObject>
#include <QImage>
#include <QTimer>
#include "TYEffecter_qt.h"

class TYMosaicEffectGenerater : public QObject
{
    Q_OBJECT
    
public:
    TYMosaicEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                           TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    ~TYMosaicEffectGenerater();
    
    QImage currentImage() const { return m_currentImage; }
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
public slots:
    void drawEffect();
    
private:
    QImage m_sourceImage;
    QImage m_afterImage;
    QImage m_currentImage;
    bool m_inToward;
    int m_phase;
    int m_phaseNum;
    double m_phaseInterval;
    bool m_isComplete;
};

#endif // TYMOSAICEFFECTGENERATER_QT_H