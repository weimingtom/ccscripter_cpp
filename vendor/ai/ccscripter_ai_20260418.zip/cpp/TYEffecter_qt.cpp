/*
 *  TYEffecter.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYEffecter_qt.h"
#include <QDebug>

// Static instance
TYEffecter* TYEffecter::s_instance = nullptr;

// TYEffectDefinitionValue implementation

// Replaces: +(id)valueWithEffectDefinition:(TYEffectDefinition)aDefinition
TYEffectDefinitionValue* TYEffectDefinitionValue::create(const TYEffectDefinition& definition)
{
    return new TYEffectDefinitionValue(definition);
}

// Replaces: -(id)initWithEffectDefinition:(TYEffectDefinition)aDefinition
TYEffectDefinitionValue::TYEffectDefinitionValue(const TYEffectDefinition& definition, QObject* parent)
    : QObject(parent)
    , m_definition(definition)
{
}

// Replaces: -(void)getValue:(void *)buffer
void TYEffectDefinitionValue::getValue(TYEffectDefinition* buffer) const
{
    *buffer = m_definition;
}

// TYEffectRegister implementation

// Replaces: +(id)effectRegisterType:(int)type time:(int)time path:(NSString*)path
TYEffectRegister* TYEffectRegister::create(int type, int time, const QString& path)
{
    return new TYEffectRegister(type, time, path);
}

// Replaces: -(id)initWithType:(int)type time:(int)time path:(NSString*)path
TYEffectRegister::TYEffectRegister(int type, int time, const QString& path, QObject* parent)
    : QObject(parent)
    , m_type(type)
    , m_time(time)
    , m_path(path)
{
}

// TYEffecter implementation

// Replaces: +(id)effecter
TYEffecter* TYEffecter::effecter()
{
    if (!s_instance) {
        s_instance = new TYEffecter();
    }
    return s_instance;
}

// Replaces: -(id)init
TYEffecter::TYEffecter(QObject* parent)
    : QObject(parent)
    , m_beforePercentage(0.0)
    , m_nowEffect(nullptr)
{
}

// Replaces: -(id)init
TYEffecter::~TYEffecter()
{
    qDeleteAll(m_effectDict);
    m_effectDict.clear();
}

// Replaces: -(void)setEffectNo:(int)effectNo type:(int)effectType time:(int)time path:(NSString*)path
void TYEffecter::setEffectNo(int effectNo, int effectType, int time, const QString& path)
{
    TYEffectRegister* reg = TYEffectRegister::create(effectType, time, path);
    m_effectDict.insert(effectNo, reg);
}

// Replaces: -(void)setBeforeImage:(NSImage*)aImage
void TYEffecter::setBeforeImage(const QImage& image)
{
    m_beforeImage = image;
}

// Replaces: -(BOOL)startEffect:(NSImage*)newImage effectNo:(int)effectNo
bool TYEffecter::startEffect(const QImage& newImage, int effectNo)
{
    if (!m_effectDict.contains(effectNo)) {
        qWarning() << "Effect not found:" << effectNo;
        return false;
    }
    
    TYEffectRegister* reg = m_effectDict.value(effectNo);
    m_afterImage = newImage;
    m_startDate = QDateTime::currentDateTime();
    m_beforePercentage = 0.0;
    m_nowEffect = reg;
    
    return true;
}

// Replaces: -(BOOL)getEffectionImage:(NSImage**)drawImage
bool TYEffecter::getEffectionImage(QImage* drawImage)
{
    if (m_nowEffect == nullptr) {
        return false;
    }
    
    // Calculate progress
    int elapsed = m_startDate.msecsTo(QDateTime::currentDateTime());
    int totalTime = m_nowEffect->getTime();
    
    if (totalTime <= 0) {
        *drawImage = m_afterImage;
        return true;
    }
    
    double progress = qMin(1.0, static_cast<double>(elapsed) / totalTime);
    
    TYEffectType type = static_cast<TYEffectType>(m_nowEffect->getType());
    
    // Generate effect based on type
    switch (type) {
    case TYEffectInstant:
        *drawImage = m_afterImage;
        break;
        
    case TYEffectCached:
        *drawImage = m_beforeImage;
        break;
        
    case TYEffectCrossFade:
    case TYEffectCrossFadeWithPixel:
        // Simple cross-fade interpolation
        if (m_beforeImage.isNull() || m_afterImage.isNull()) {
            *drawImage = m_afterImage.isNull() ? m_beforeImage : m_afterImage;
        } else {
            // Blend images
            *drawImage = m_beforeImage;
            // In a full implementation, would blend here
        }
        break;
        
    default:
        // For other effects, would call specific effect generators
        *drawImage = m_afterImage;
        break;
    }
    
    // Emit signal for image changes
    emit effectImageChanged(*drawImage);
    
    // Check if effect is complete
    if (progress >= 1.0) {
        emit effectFinished();
        m_nowEffect = nullptr;
    }
    
    return true;
}

// TYEffectGenerater implementation placeholder
// (Full implementation would require all the specific effect generators)