/*
 *  TYResourceServer.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYResourceServer_qt.h"
#include "TYArchiver_qt.h"
#include <QFile>
#include <QDir>
#include <QCoreApplication>
#include <QProcess>
#include <QDebug>

// Static member initialization
TYResourceServer* TYResourceServer::s_instance = nullptr;

const QString TYResourceServer::FILELOG_FILENAME = QStringLiteral("NScrflog.dat");
const QString TYResourceServer::WIN_PATH_DELIMITER = QStringLiteral("\\");

TYResourceServer::TYResourceServer(QObject* parent)
    : QObject(parent)
    , m_filelog(false)
{
}

TYResourceServer::~TYResourceServer()
{
    // Clean up archivers
    qDeleteAll(m_archivers);
    m_archivers.clear();
    
    // Clean up effect patterns
    qDeleteAll(m_effectPatternDict.values());
    m_effectPatternDict.clear();
}

// Replaces: +(id)sharedServer
TYResourceServer* TYResourceServer::sharedServer()
{
    if (!s_instance) {
        s_instance = new TYResourceServer();
    }
    return s_instance;
}

// Replaces: -(void)addArchiver:(NSString*)path
void TYResourceServer::addArchiver(const QString& path)
{
    TYArchiver* archiver = TYArchiver::archiverWithContentsOfFile(path);
    if (archiver) {
        m_archivers.append(archiver);
    }
}

// Replaces: -(NSString*)getFilePath:(NSString*)path
QString TYResourceServer::getFilePath(const QString& path)
{
    // Check if file exists directly
    if (QFile::exists(path)) {
        return path;
    }
    
    // Check in archives
    // TODO: Implement archive lookup
    foreach (TYArchiver* archiver, m_archivers) {
        Q_UNUSED(archiver);
        // Would look up in archive
    }
    
    return QString();
}

// Replaces: -(NSData*)getData:(NSString*)path
QByteArray TYResourceServer::getData(const QString& path)
{
    // Try direct file first
    QFile file(path);
    if (file.open(QIODevice::ReadOnly)) {
        return file.readAll();
    }
    
    // Try archives
    return findInArchives(path);
}

// Helper to find file in archives
QByteArray TYResourceServer::findInArchives(const QString& path)
{
    Q_UNUSED(path);
    // TODO: Implement archive lookup
    return QByteArray();
}

// Replaces: -(NSImage*)getImage:(NSString*)path transMode:(BOOL)aBool animate:(BOOL)isAnimate
QImage TYResourceServer::getImage(const QString& path, bool transMode, bool animate)
{
    Q_UNUSED(animate);
    return getImage(path, transMode);
}

// Replaces: -(NSImage*)getImage:(NSString*)path transMode:(BOOL)aBool
QImage TYResourceServer::getImage(const QString& path, bool transMode)
{
    QImage image;
    QString filePath = getFilePath(path);
    
    if (filePath.isEmpty()) {
        // Try archives
        QByteArray data = findInArchives(path);
        if (!data.isEmpty()) {
            image.loadFromData(data);
        }
    } else {
        image.load(filePath);
    }
    
    if (image.isNull()) {
        return QImage();
    }
    
    if (transMode) {
        return transrateImageFromBitmap(image, m_defaultTransmode);
    }
    
    return image;
}

// Replaces: -(NSImage*)getImageFromString:(NSString*)str
QImage TYResourceServer::getImageFromString(const QString& str)
{
    Q_UNUSED(str);
    // Would render string to image
    return QImage();
}

// Replaces: -(NSBitmapImageRep*)getBitmap:(NSString*)path
QImage TYResourceServer::getBitmap(const QString& path)
{
    return getImage(path, false);
}

// Internal image transformation
// Replaces: -(NSImage*)transrateImageFromBitmap:(NSBitmapImageRep*)bitmap transMode:(NSString*)transmode
QImage TYResourceServer::transrateImageFromBitmap(const QImage& bitmap, const QString& transmode)
{
    if (transmode == QStringLiteral("l") || transmode == TYTRANSMODE_LEFTTOP) {
        // Left-top transparent
        // Would call ConvertImageTransrateLeftTop
        return bitmap;
    }
    // Add other modes as needed
    return bitmap;
}

// Replaces: -(NSData*)getSoundData:(NSString*)path
QByteArray TYResourceServer::getSoundData(const QString& path)
{
    return getData(path);
}

// Replaces: -(TYEffectPatternMap*)getEffectPattern:(NSString*)path
TYEffectPatternMap* TYResourceServer::getEffectPattern(const QString& path)
{
    if (m_effectPatternDict.contains(path)) {
        return m_effectPatternDict.value(path);
    }
    // TODO: Load and create effect pattern
    return nullptr;
}

// Replaces: -(NSString*)getFilePathMakeTemp:(NSString*)path
QString TYResourceServer::getFilePathMakeTemp(const QString& path)
{
    QString filePath = getFilePath(path);
    if (!filePath.isEmpty()) {
        return filePath;
    }
    
    // Create temp file
    QString tempPath = QDir::temp().absoluteFilePath(QFileInfo(path).fileName());
    QFile::copy(path, tempPath);
    return tempPath;
}

// Replaces: -(void)addSpi:(NSString*)pluginName extension:(NSString*)extension
void TYResourceServer::addSpi(const QString& pluginName, const QString& extension)
{
    m_spiPluginDict.insert(extension, pluginName);
}

// Replaces: -(void)addSoundPressPlugin:(NSString*)pluginName extension:(NSString*)extension
void TYResourceServer::addSoundPressPlugin(const QString& pluginName, const QString& extension)
{
    m_soundPressPluginDict.insert(extension, pluginName);
}

// Replaces: -(void)setDefaultTransMode:(NSString*)transmode
void TYResourceServer::setDefaultTransMode(const QString& transmode)
{
    m_defaultTransmode = transmode;
}

// Replaces: -(void)addEffectPattern:(NSString*)path
void TYResourceServer::addEffectPattern(const QString& path)
{
    Q_UNUSED(path);
    // TODO: Load effect pattern from file
}

// Replaces: -(void)executeBundle:(NSString*)pathAndArg
void TYResourceServer::executeBundle(const QString& pathAndArg)
{
    QString program = pathAndArg;
    QStringList args;
    
    // Simple parsing - would need more sophisticated parsing in real code
    int spaceIndex = pathAndArg.indexOf(' ');
    if (spaceIndex > 0) {
        program = pathAndArg.left(spaceIndex);
        args = pathAndArg.mid(spaceIndex + 1).split(' ');
    }
    
    QProcess::startDetached(program, args);
}

// Replaces: -(BOOL)filelog:(NSString*)path
bool TYResourceServer::filelog(const QString& path)
{
    if (m_filelogDict.contains(path)) {
        return true;
    }
    m_filelog = true;
    m_filelogDict.insert(path, path);
    return false;
}

// Replaces: -(void)addlog:(NSString*)filename
void TYResourceServer::addlog(const QString& filename)
{
    m_filelogDict.insert(filename, filename);
}

// Replaces: -(BOOL)fchk:(NSString*)filename
bool TYResourceServer::fchk(const QString& filename)
{
    return m_filelogDict.contains(filename) || QFile::exists(filename);
}

// Replaces: -(BOOL)saveLog:(NSString*)path
bool TYResourceServer::saveLog(const QString& path)
{
    Q_UNUSED(path);
    // Would serialize filelogDict to file
    return true;
}