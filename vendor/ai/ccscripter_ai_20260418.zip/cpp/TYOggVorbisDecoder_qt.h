/*
 *  TYOggVorbisDecoder.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Ogg/Vorbis audio decoder.
 */

#ifndef TYOggVorbisDecoder_QT_H
#define TYOggVorbisDecoder_QT_H

#include "TYWaveDecorder_qt.h"
#include <QByteArray>
#include <cstdint>

class TYOggVorbisDecoder : public TYWaveDecoder
{
    Q_OBJECT
    
public:
    explicit TYOggVorbisDecoder(const QByteArray& sourceData, QObject* parent = nullptr);
    ~TYOggVorbisDecoder();
    
    // TYWaveDecoder implementation
    bool initWithData(const QByteArray& sourceData) override;
    bool getSamples(int16_t** samples, int* frames, int* channels, int* rate) override;
    
private:
    QByteArray m_ovData;
    const char* m_ovPtr;
    QByteArray m_sampleData;
    
    // OggVorbis file data structure
    struct TYOVFileData {
        const char* stPtr;
        int cursor;
        int length;
    };
    
    static size_t ovRead(void* ptr, size_t size, size_t nmemb, void* datasource);
    static int ovSeek(void* datasource, int64_t offset, int whence);
    static int ovClose(void* datasource);
    static long ovTell(void* datasource);
};

#endif // TYOggVorbisDecoder_QT_H