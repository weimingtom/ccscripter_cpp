/*
 *  TY_NSDataAddtion.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  NSData category extensions for bit access and XOR operations.
 */

#ifndef TY_NSDATAADDITION_QT_H
#define TY_NSDATAADDITION_QT_H

#include <QByteArray>
#include <cstdint>

// Bit access for immutable data
namespace TYDataUtils {
    // Replaces: -(int)getBitAtIndex:(unsigned int)aIndex
    inline int getBitAtIndex(const QByteArray& data, unsigned int index) {
        if (data.size() < static_cast<int>(index >> 3)) {
            return 0;
        }
        return data.at(index >> 3) & (1 << (index & 0x7));
    }
}

// Bit access for mutable data
namespace TYMutableDataUtils {
    // Replaces: -(void)setBit:(int)aBit atIndex:(unsigned int)aIndex
    inline void setBit(QByteArray& data, int bit, unsigned int index) {
        unsigned int byteIndex = index >> 3;
        
        if (data.size() < static_cast<int>(byteIndex)) {
            data.resize(byteIndex);
            if (!bit) {
                return;
            }
        }
        
        char* ptr = data.data() + byteIndex;
        if (bit) {
            *ptr |= (1 << (index & 0x7));
        } else {
            *ptr &= ~(1 << (index & 0x7));
        }
    }
    
    // Replaces: -(void)XORMaskToAllBytes:(unsigned char)code
    inline void xorMask(QByteArray& data, unsigned char code) {
        for (int i = 0; i < data.size(); i++) {
            data[i] = data[i] ^ code;
        }
    }
}

#endif // TY_NSDATAADDITION_QT_H