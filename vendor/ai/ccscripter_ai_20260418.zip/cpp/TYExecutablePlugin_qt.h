/*
 *  TYExecutablePlugin.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Protocol for executable plugins.
 */

#ifndef TYEXECUTABLEPLUGIN_QT_H
#define TYEXECUTABLEPLUGIN_QT_H

#include <QString>

class TYCCScripterProxy;

// Interface for executable plugins
class TYExecutablePlugin
{
public:
    virtual ~TYExecutablePlugin() = default;
    
    // Replaces: -(void)execPlugin:(id<TYCCScripterProxy>)ccsProxy argment:(NSString*)aStr
    virtual void execPlugin(TYCCScripterProxy* ccsProxy, const QString& argStr) = 0;
};

#endif // TYEXECUTABLEPLUGIN_QT_H