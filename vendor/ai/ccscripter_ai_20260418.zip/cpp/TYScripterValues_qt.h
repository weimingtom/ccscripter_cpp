/*
 *  TYScripterValues.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Manages NScripter script variables (integer and string values).
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSString*         -> QString
 *  NSNumber*         -> QVariant
 *  NSArray*          -> QVariantList
 *  NSMutableDictionary -> QMap
 */

#ifndef TYSCRIPTERVALUES_QT_H
#define TYSCRIPTERVALUES_QT_H

#include <QObject>
#include <QString>
#include <QVariant>
#include <QMap>
#include <QStringList>
#include <cstdint>

// Constants
#define NUM_OF_VALUES 10000
#define MIN_GLOBAL_IDNO 200
#define MAX_GLOBAL_IDNO 4095

// Forward declaration
class TYArrayValue;

// Script variable manager class
class TYScripterValues : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)ScripterValues
    static TYScripterValues* scripterValues();
    
    // Replaces: +(void)setMinGlobalNo:(int)aInt
    static void setMinGlobalNo(int aInt);
    
    // Constructor
    TYScripterValues(QObject* parent = nullptr);
    ~TYScripterValues();
    
    // Value accessors
    // Replaces: -(id)getStringValue:(id)idno
    QString getStringValue(const QVariant& idno);
    
    // Replaces: -(id)getIntValue:(id)idno
    QVariant getIntValue(const QVariant& idno);
    
    // Value setters
    // Replaces: -(void)setStringValue:(id)idno object:(NSString*)setString
    void setStringValue(const QVariant& idno, const QString& setString);
    
    // Replaces: -(void)setIntValue:(id)idno object:(NSNumber*)setNumber
    void setIntValue(const QVariant& idno, const QVariant& setNumber);
    
    // Replaces: -(void)setArrayLine:(id)idno values:(NSArray*)aArray
    void setArrayLine(const QVariant& idno, const QVariantList& aArray);
    
    // Replaces: -(void)setIntLimitID:(id)idno low:(id)aLow high:(id)aHigh
    void setIntLimitId(const QVariant& idno, const QVariant& aLow, const QVariant& aHigh);
    
    // Replaces: -(void)defineArrayValue:(NSArray*)aArray
    void defineArrayValue(const QVariantList& aArray);
    
    // Save/Load
    // Replaces: -(BOOL)loadGlobalValues:(NSString*)path
    bool loadGlobalValues(const QString& path);
    
    // Replaces: -(BOOL)saveGlobalValues:(NSString*)path
    bool saveGlobalValues(const QString& path);
    
    // Merge values from another instance
    // Replaces: -(void)margeGlobalValues:(TYScripterValues*)margeValues
    void mergeGlobalValues(TYScripterValues* margeValues);
    
    // Reset game state
    // Replaces: -(void)resetGame
    void resetGame();
    
    // Serialization (implements TYSaveDataCoding)
    QVariantList encodeWithSaveData() const;
    void decodeWithSaveData(const QVariantList& data);
    
private:
    void initialize();
    
    int m_values[NUM_OF_VALUES];                    // Replaces: int values[NUM_OF_VALUES]
    QString m_strValues[NUM_OF_VALUES];            // Replaces: NSString *strValues[NUM_OF_VALUES]
    QMap<QString, TYArrayValue*> m_arrayValues;  // Replaces: NSMutableDictionary *arrayValues
    QMap<QString, QVariantList> m_limitDict;      // Replaces: NSMutableDictionary *limitDict
    
    static int s_minGlobalIdNo;  // Replaces: static int MIN_GLOBAL_IDNO
    static TYScripterValues* s_instance;
};

#endif // TYSCRIPTERVALUES_QT_H