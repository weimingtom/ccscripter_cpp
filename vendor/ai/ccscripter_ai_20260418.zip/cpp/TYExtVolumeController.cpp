// Converted from TYExtVolumeController.m
// TODO: Manual review and fixes required

#include "TYExtVolumeController.h"

// @implementation TYExtVolumeController

- (IBAction)setDefault:(void*)sender
{
    [ BGMSlider setFloatValue:defaultBGMVolume ];
    [ VoiceSlider setFloatValue:defaultVoiceVolume ];
    [ SESlider setFloatValue:defaultSEVolume ];    
}

-(void*)initWithDefaultBGMVolume:(float)defBGMVol
                    bgmVolume:(float)bgmVol
           defaultVoiceVolume:(float)defVoiceVol
                  voiceVolume:(float)voiceVol
              defaultSEVolume:(float)defSEVol
                     seVolume:(float)seVol
{
    this = [ super init ];
    
    defaultBGMVolume=defBGMVol;
    defaultVoiceVolume=defVoiceVol;
    defaultSEVolume=defSEVol;

    [ NSBundle loadNibNamed:@"ExtVolume" owner:this ];
    
    [ BGMSlider setFloatValue:bgmVol ];
    [ VoiceSlider setFloatValue:voiceVol ];
    [ SESlider setFloatValue:seVol ];

    return this;
}

// REMOVED: -floatvoiceVolume{
    return [ VoiceSlider floatValue ];
}

// REMOVED: -floatseVolume{
    return [ SESlider floatValue ];
}

// @end
