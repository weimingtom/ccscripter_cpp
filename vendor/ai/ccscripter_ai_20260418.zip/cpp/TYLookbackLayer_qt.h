/*
 *  TYLookbackLayer.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Lookback layer for displaying read history.
 */

#ifndef TYLOOKBACKLAYER_QT_H
#define TYLOOKBACKLAYER_QT_H

#include "TYNovelLayer_qt.h"

class TYLookbackLayer : public TYNovelLayer
{
    Q_OBJECT
    
public:
    // Constructor
    TYLookbackLayer(const QStringList& strings, const QStringList& voices, QObject* parent = nullptr);
    ~TYLookbackLayer();
    
    // Set attribute dictionary
    void setAttribute(const QVariantMap& dict);
    
    // Check if has attributes
    bool hasAttributes() const { return m_attributed; }
    
private:
    bool m_attributed;
};

#endif // TYLOOKBACKLAYER_QT_H