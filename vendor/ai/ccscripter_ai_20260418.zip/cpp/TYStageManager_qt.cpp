/*
 *  TYStageManager.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYStageManager_qt.h"
#include <QDebug>

TYStageManager* TYStageManager::s_instance = nullptr;

TYStageManager::TYStageManager(QObject* parent)
    : QObject(parent)
    , m_controller(nullptr)
    , m_engine(nullptr)
    , m_effectGenerater(nullptr)
    , m_selectionManager(nullptr)
    , m_buttonManager(nullptr)
    , m_clickWaitCursor(nullptr)
    , m_pageWaitCursor(nullptr)
    , m_tpStatus(TYTPOff)
    , m_skipStatus(TYNoSkip)
    , m_humanZ(0)
    , m_isUseHumanZ(false)
    , m_isWindowback(false)
    , m_novelLayerOn(false)
    , m_eraseTextWindow(false)
    , m_textLeftOffset(0)
    , m_textTopOffset(0)
    , m_textColumn(0)
    , m_textRow(0)
    , m_textFontWidth(0)
    , m_textFontHeight(0)
    , m_textPitchX(0)
    , m_textPitchY(0)
    , m_userTextSpeed(0)
    , m_scriptTextSpeed(0)
    , m_selectedSpeedTag(0)
    , m_textBold(false)
    , m_textShadowed(false)
    , m_locateX(0)
    , m_nowColumn(0)
    , m_nowRow(0)
    , m_nowStorageLength(0)
    , m_nowStorageOffset(0)
    , m_waitNewPage(false)
    , m_forceClickWait(false)
    , m_forceWaitNewPage(false)
    , m_invalidNewLine(false)
    , m_clickStrUnderLimit(0)
    , m_beforeSelectButtonID(0)
    , m_releaseButtonAfterSelect(false)
    , m_isDrawButton(false)
    , m_beforeSelectIndex(0)
    , m_isPage(false)
    , m_automodeWait(0)
    , m_automodeWaitType(0)
    , m_waitCountOfChar(0)
    , m_playingSoundFlg(false)
    , m_waitFinishSound(false)
    , m_textFontSize(0)
{
}

TYStageManager* TYStageManager::sharedManager()
{
    if (!s_instance) {
        s_instance = new TYStageManager();
    }
    return s_instance;
}

void TYStageManager::setModeSVGA()
{
    // Would set screen mode
}

void TYStageManager::setController(QObject* controller, QObject* engine)
{
    m_controller = controller;
    m_engine = engine;
}

void TYStageManager::enterSystemMode()
{
}

void TYStageManager::exitSystemModeResumeStatus(bool resume)
{
    Q_UNUSED(resume);
}

bool TYStageManager::isPossibleEnterSystemMode()
{
    return true;
}

void TYStageManager::loadTextWindow(const QString& path)
{
    m_textWindowPath = path;
}

void TYStageManager::loadBGImage(const QString& path)
{
    m_bgPath = path;
    m_bgImage.load(path);
}

void TYStageManager::addSprite(const QStringList& arguments, bool visible)
{
    Q_UNUSED(arguments);
    Q_UNUSED(visible);
}

void TYStageManager::startSelect(const QStringList& messages, const QStringList& respondArray)
{
    Q_UNUSED(messages);
    Q_UNUSED(respondArray);
}

void TYStageManager::updateStage()
{
    emit stageUpdated();
}

void TYStageManager::updateStageOnlyButton()
{
}

void TYStageManager::changeVisualLayer(int effectNum)
{
    Q_UNUSED(effectNum);
}

void TYStageManager::flushNovelLayer()
{
}

void TYStageManager::startEraseTextWindow(int effectNum)
{
    Q_UNUSED(effectNum);
}

QStringList TYStageManager::lookbackQueue()
{
    return m_lookbackQueue;
}

void TYStageManager::textPrint(const QString& str)
{
    Q_UNUSED(str);
}

void TYStageManager::drawTextWindow()
{
}

void TYStageManager::setClickWait(bool pageWait)
{
    m_waitNewPage = pageWait;
}

void TYStageManager::resetGame()
{
    m_nowColumn = 0;
    m_nowRow = 0;
    m_lookbackQueue.clear();
}

int TYStageManager::status() const
{
    return m_status;
}

void TYStageManager::setStatus(int status)
{
    m_status = status;
}

void TYStageManager::printing()
{
    m_tpStatus = TYTPPrinting;
}

void TYStageManager::resumePrinting()
{
}

void TYStageManager::automode_select_action()
{
}

void TYStageManager::ty_select(const QStringList& arguments)
{
    Q_UNUSED(arguments);
}

void TYStageManager::ty_spstr(const QStringList& arguments)
{
    Q_UNUSED(arguments);
}

void TYStageManager::ty_textclear(const QStringList& arguments)
{
    Q_UNUSED(arguments);
}

void TYStageManager::ty_lookbackflush(const QStringList& arguments)
{
    Q_UNUSED(arguments);
}

void TYStageManager::makeAttributeDict()
{
}

void TYStageManager::changeFont(QObject* fontManager)
{
    Q_UNUSED(fontManager);
}

void TYStageManager::changeTextSpeed(int index)
{
    Q_UNUSED(index);
}

void TYStageManager::setAutoMode(int speed, int type, int wait)
{
    m_automodeWait = wait;
    m_automodeWaitType = type;
}

void TYStageManager::startButtonWait(const QStringList& arguments, bool releaseAfterSelect)
{
    Q_UNUSED(arguments);
    Q_UNUSED(releaseAfterSelect);
}

void TYStageManager::changeSelectedButton(unsigned int btnIndex)
{
    Q_UNUSED(btnIndex);
}

void TYStageManager::responseButton(int result)
{
    Q_UNUSED(result);
}

void TYStageManager::changeSelection(int index)
{
    m_beforeSelectIndex = index;
    emit selectionChanged(index);
}

void TYStageManager::responseSelection()
{
}

void TYStageManager::makeCselImage()
{
}

QRect TYStageManager::rectOfSprite(int idNo) const
{
    return m_spriteRects.value(idNo);
}

void TYStageManager::setSprite(int idNo, bool visible)
{
    m_spriteVisibility[idNo] = visible;
}

void TYStageManager::setSprite(int idNo, int cellNo)
{
    m_spriteCells[idNo] = cellNo;
}

void TYStageManager::changeEffectionImage(const QImage& image)
{
    Q_UNUSED(image);
}

void TYStageManager::effectFinished()
{
    emit this->effectFinished();
}

void TYStageManager::updateSprites()
{
}

void TYStageManager::startWaveSound()
{
}

void TYStageManager::stopWaveSound()
{
}

QSize TYVirtualScreenSize()
{
    return QSize(VSCREEN_WIDTH, VSCREEN_HEIGHT);
}

QRect TYVirtualScreenRect()
{
    return QRect(0, 0, VSCREEN_WIDTH, VSCREEN_HEIGHT);
}