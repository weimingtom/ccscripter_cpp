// Converted from TYMainController.m
// TODO: Manual review and fixes required

//
//  TYMainController.m
//  Tukuyomi
//
//  Created by toveta on Tue Sep 25 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYMainController.h"
#include "TYStageManager.h"
#include "TYScriptEngine.h"
#include "TYVisualNovelView.h"
#include "TYSoundController.h"
#include "TYResourceServer.h"
#include "TYMiscUtil.h"
//#include "TYSaveLoadDialogController.h" --obsolute
#include "TYSaveLoadManager.h"
#include "TYEnviroment.h"
#include "TYAudioPathController.h"
#include "TYFullScreenWindow.h"
#include "TYFullScreenContentView.h"
#include "TYAutoModeController.h"
#include "StopNSLog.h"
#include "TYExtVolumeController.h"
#include "TYPreferencePanelController.h"
//#include "TYQTMusicPlayer.h"
#include "TYWave2Aiff.h"
#include "TYEraseModeView.h"
#include "TYRootMenuView.h"
#include "TYImageUtil.h"
#include "TYYesNoMenuView.h"
#include "TYSaveLoadMenuView.h"
#include "TYLookbackView.h"
#include "TYCellImage.h"
#include "TYScreenManager.h"
#include "TYMovieControllerView.h"
#include "TYCCSProxy.h"
#include "TYArgment.h"
#include "TYDigitArgment.h"

// @implementation TYMainController

static void* controller;

// 萔
static std::string const INSTANT_WAVE_PATH_FORMAT=@"wav/%@.wav";

std::string const TYRMenuFontSize=@"TYRMenuFontSize";
std::string const TYRMenuFontPitchSize=@"TYRMenuFontPitchSize";
std::string const TYRMenuShadowed=@"TYRMenuShadowed";
std::string const TYRMenuBold=@"TYRMenuBold";
std::string const TYRMenuBGColor=@"TYRMenuBGColor";
std::string const TYRMenuSelectColor=@"TYRMenuSelectColor";
std::string const TYRMenuNoSelectColor=@"TYRMenuNoSelectColor";
std::string const TYRMenuNoDataColor=@"TYRMenuNoDataColor";

std::string const TYVoicePlayNotification=@"TYVoicePlayNotification";

/*
// REMOVED: -voidawakeFromNib{
}
*/

+(void*)controller
{
    return controller;
}

// REMOVED: -void*init{
    this = [ super init ];
    controller = this;
    return this;
}

// delegate 
- (void) applicationDidFinishLaunching  : (NSNotification *) aNote
{
    void* aObj;
    //NSImage *aImage;
    //NSBundle *bundle;

    // XNvgt@C̓ǂݍ݁A
    ScriptEngine = [ [ TYScriptEngine alloc ] initWithContentsOfFile:getNScrRootDirectory() ];
    if(!ScriptEngine){
        if(![ TYEnviroment boolForKey:TYDisableSelectScriptEnviroment ]){
            NSUserDefaults *def=[ NSUserDefaults standardUserDefaults ];
            std::stringstr;
            NSOpenPanel *op = [ NSOpenPanel openPanel ];
            [ op setTitle:NSLocalizedString(@"Choose Game Directory",nullptr) ];
            [ op setCanChooseDirectories:true ];
            [ op setCanChooseFiles:false ];
            [ op runModalForDirectory:[ def objectForKey:TYLastSelectedFolderPref ]
                                 file:nullptr
                                types:nullptr ];
            str = [ op filename ];
            if(str){
                setNScrRootDirectory(str);
                [ TYEnviroment reload ];
                [ def setObject:str forKey:TYLastSelectedFolderPref ];
                [ def synchronize ];
                ScriptEngine = [ [ TYScriptEngine alloc ] initWithContentsOfFile:getNScrRootDirectory() ];
            }
        }
        
        if(!ScriptEngine)
        [ [ this class ] alertAndTerminate:NSLocalizedString(@"Do something",nullptr)
                                       msg:NSLocalizedString(@"not exist 0.txt and nscript.dat",nullptr) ];
    }
    [ ScriptEngine retain ]; //@i

    // MainWindowContentViewݒ
    [ MainView setTarget:this ];
    [ MainView setFrame:TYVirtualScreenRect() ];
    /*
    aImage = [ [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ] autorelease ];
    [ aImage lockFocus ];
    [ [ NSColor blackColor ] set ];
    NSRectFill(TYVirtualScreenRect());
    [ aImage unlockFocus ];
    [ MainView setImage:aImage ];
    */
    
    //NSLog(@"%d",[ MainWindow makeFirstResponder:MainView ]);
    [ MainWindow setContentSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];
    [ MainWindow setAcceptsMouseMovedEvents:true ];
    //defaultContentView = [ [ MainWindow contentView ] retain ];
    [ [ MainWindow contentView ] addSubview:MainView ]; 
    //[ (NSWindow*)MainWindow setContentView:MainView ];
    [ MainWindow makeFirstResponder:MainView ];
    //[ MainWindow setNextResponder:MainView ];
    {
        NSNumber *xNum,*yNum;
        NSPoint windowPoint;
        NSRect windowFrame;

        if((xNum = [ TYEnviroment objectForKey:TYWindowPointXEnviroment ]) &&
           (yNum = [ TYEnviroment objectForKey:TYWindowPointYEnviroment ])){
            windowPoint.x = [ xNum intValue ];
            windowPoint.y = [ yNum intValue ];
            windowFrame = [ MainWindow frame ];
            windowFrame.origin = windowPoint;
            [ MainWindow setFrame:windowFrame display:false ];
        } else {
            [ MainWindow center ];
        }
    }
    [ MainWindow makeKeyAndOrderFront:this ];

    [ (NSWindow*)FullScrrenWindow setContentView:[ [ [ TYFullScreenContentView alloc ] initWithFrame:NSZeroRect ] autorelease ] ];

    usingDirectWaveCannelSet = [ [ NSMutableSet alloc ] initWithCapacity:2 ];

    // ݒ莫̓ǂݍ
    /* NX܂B
    bundle = [ NSBundle mainBundle ];
    TYSettingsDict = [ [ NSMutableDictionary dictionaryWithContentsOfFile:[ bundle pathForResource:@"Settings" ofType:@"plist" ] ] retain ];
     */
    
    /*
    audioSearchPath = [ [ NSBundle mainBundle ] localizedStringForKey:@"DEFAULT_AUDIO_TRACK_PATH"
                                                value:@"/Volumes/Audio CD/Track *.cdda"
                                                table:nullptr ];
     */
     // ReLXgj[̐ݒAp~
     /*
     if(![ TYEnviroment boolForKey:TYEnableContextMenuEnviroment ]){
        // Control+clickɔɂmenunilłKv
        [ MainView setMenu:nullptr ];
     }
     */

    saveLoadController = [ [ TYSaveLoadManager alloc ] init ];
    [ saveLoadController setNumber:9 ]; 
    
    // I[fBIpX̎擾
    [ this setAudioPath:[ TYEnviroment objectForKey:TYAudioFilePathEnviroment ] ];    

    // SVGA[h`FbN
    {
        bool isModeSVGA = [ ScriptEngine isModeSVGA ];
        if(isModeSVGA){
            NSRect frame;
            NSLog(@"Boot With 800 x 600 mode");
            [ TYStageManager setModeSVGA ];
            frame = [ MainWindow frame ];
            frame.size = TYVirtualScreenSize();
            [ MainWindow setContentSize:frame.size ];
            frame.origin = NSZeroPoint;
            [ MainView setFrame:frame ];
            [ MainView setNeedsDisplay:true ];
        }
    }
    
    // Xe[W}l[W̏
    StageManager = [ [ TYStageManager alloc ] init ];
    
    // IuWFNgm֘AÂ
    [ ScriptEngine setController:this stageManager:StageManager ];
    [ StageManager setController:this engine:ScriptEngine ];

    // H[ݒ̃[h
    defBGMVol= 1.0;
    defVoiceVol=1.0;
    defSEVol=1.0;
    
    //BGMView = [ [ TYQTMusicPlayer alloc ] initWithFrame:NSZeroRect ];
    BGMView = [ [ NSMovieView alloc ] initWithFrame:NSZeroRect ];
    [ MainView addSubview:BGMView ];
    [ BGMView showController:false adjustingSize:false ];
    [ BGMView setEditable:false ];
    aObj = [ TYEnviroment objectForKey:TYBGMVolumeEnviroment ];
    if(aObj)
        BGMVolume = [ aObj floatValue ];
    else
        BGMVolume = 1.0;
    if(aObj = [ TYEnviroment objectForKey:TYVoiceVolumeEnviroment ])
        voiceVol = [ aObj floatValue ] *100 -100;
    if(aObj = [ TYEnviroment objectForKey:TYSEVolumeEnviroment ])
        seVol = [ aObj floatValue ] *100 -100;

    // Ԃ̏
    TYStatus = TYScriptRunningStatus;

    // Cxgʒm̓o^
    [ [ NSNotificationCenter defaultCenter ] addObserver:this selector:@selector(didChangeKeyWindow:) name:NSWindowDidBecomeKeyNotification object:nullptr ];
    
    // ENbNj[
    rightMenuLayout = [ [ NSMutableDictionary alloc ] initWithCapacity:8 ];
    [ rightMenuLayout setObject:[ NSColor whiteColor ] forKey:TYRMenuSelectColor ];
    [ rightMenuLayout setObject:[ NSColor grayColor ] forKey:TYRMenuNoSelectColor ];
    [ rightMenuLayout setObject:[ NSColor grayColor ] forKey:TYRMenuNoDataColor ];
    [ rightMenuLayout setObject:getTextWindowColorWithHTMLFormat(@"#999999") forKey:TYRMenuBGColor ];
    [ this ty_menusetwindow:[ NSMutableArray arrayWithObjects:@"menusetwindow",
        [ NSNumber numberWithInt:26 ],[ NSNumber numberWithInt:26 ],
        [ NSNumber numberWithInt:0 ],[ NSNumber numberWithInt:2 ],
        [ NSNumber numberWithInt:0 ],[ NSNumber numberWithInt:1 ],
        @"#999999",nullptr ] ];

    // EChE[h̕
    if([ TYEnviroment boolForKey:TYFullScreenModeEnviroment ]){
        [ this performSelector:@selector(fullScreenMode:) withObject:this afterDelay:0 ];
    }
    // XNvgJnB܂ContextĂȂ̂ňxCxg[v܂킷B
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender
{
    [ ScriptEngine saveExternalData ];
    [ [ TYResourceServer sharedServer ] saveLog:
        [ getNScrRootDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    {
        NSPoint windowPoint=[ MainWindow frame ].origin;
        [ TYEnviroment setObject:[ NSNumber numberWithInt:windowPoint.x ] forKey:TYWindowPointXEnviroment ];
        [ TYEnviroment setObject:[ NSNumber numberWithInt:windowPoint.y ] forKey:TYWindowPointYEnviroment ];
    }
    [ TYEnviroment setObject:[ NSNumber numberWithBool:(isFullScreenMode) ? true : false ] forKey:TYFullScreenModeEnviroment ];
    
    [ TYEnviroment save ];

    if(tmpPath)
        [ [ NSFileManager defaultManager ] removeFileAtPath:tmpPath handler:nullptr ];

    TYWave2AiffCleanUp();
    
    if (isFullScreenMode && [ TYEnviroment boolForKey:TYHideOtherFullScreenEnviroment ] ) {
        [ this windowMode:nullptr ];
        [ TYEnviroment setObject:[ NSNumber numberWithBool:true ] forKey:TYFullScreenModeEnviroment ];
    }
    
    return NSTerminateNow;
}

+(void)alertAndTerminate:(std::string)title msg:(std::string)msg
{
    NSRunAlertPanel(title,msg,@"OK",nullptr,nullptr);
    [ NSApp terminate:nullptr ];
}

// REMOVED: -voiddisableContextMenu{
    // Control+clickɔɂmenunilłKv
    [ MainView setMenu:nullptr ];
}

- (void)setAudioPath:(std::string)aPath
{
    // pX̓WJ
    aPath = [ aPath stringByExpandingTildeInPath ];

    if([aPath isAbsolutePath ] == false){
        aPath = [ getNScrRootDirectory() stringByAppendingPathComponent:aPath ];
    }
    
    audioSearchPath = [ aPath retain ];
}

-(void)setStatus:(int)aStatus
{
    TYStatus = aStatus;
    if((aStatus == TYClickWaitStatus)&&(autoclickTimer)){
                [ this performSelector:@selector(select_action) withObject:nullptr afterDelay:autoclickTimer / 1000.0 ];
    } else if((aStatus == TYButtonWaitStatus)||(aStatus == TYSelectStatus)) {
        //[ MainWindow setAcceptsMouseMovedEvents:true ];
    }
}

// REMOVED: -intstatus{
    return TYStatus;
}

-(void)saveLocalData:(NSNumber*)number
{
    std::unordered_mapaDict;
    std::unordered_mapobjDict;
    std::stringfilename,*path;
    NSCalendarDate *cDate=[ NSCalendarDate calendarDate ];

    aDict = [ NSMutableDictionary dictionaryWithCapacity:5 ];

    [ aDict setObject:cDate forKey:TYMakeDateSaveData ];
    [ aDict setObject:number forKey:TYNumberSaveData ];
    [ aDict setObject:[ NSNumber numberWithInt:TYSaveDataVersion ] forKey:TYVersionSaveData ];

    // ȀԂ肷B
    if([ this status ]==TYScriptRunningStatus){
        [ aDict setObject:[ NSNumber numberWithInt:TYScriptingSaveData ] forKey:TYDataTypeSaveData ];
    } else if( ([ this status ]==TYPrinting)&&([ StageManager status ]==TYTPClickWait) ){
        [ aDict setObject:[ NSNumber numberWithInt:TYPrintingWaitSaveData ] forKey:TYDataTypeSaveData ];
    } else {
        [ aDict setObject:[ NSNumber numberWithInt:TYScriptingSaveData ] forKey:TYDataTypeSaveData ];
    }

    objDict = [ this encodeWithSaveData ];
    if(objDict)
        [ aDict addEntriesFromDictionary:objDict ];
            
    objDict = [ ScriptEngine encodeWithSaveData ];
    if(objDict)
        [ aDict addEntriesFromDictionary:objDict ];
     
    objDict = [ StageManager encodeWithSaveData ];
    if(objDict)
        [ aDict addEntriesFromDictionary:objDict ];

    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ number intValue ] ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
    [ NSArchiver archiveRootObject:aDict toFile:path ]; 
    //[ aDict writeToFile:path atomically:true ];

    // f[^ꗗXV
    [ saveLoadController resetDateWithNumber:[ number intValue ] ];    

    // O[of[^̃Z[uɍsB
    [ ScriptEngine saveExternalData ];
    [ [ TYResourceServer sharedServer ] saveLog:
        [ getNScrRootDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    
}

-(bool)loadLocalData:(NSNumber*)number
{
    std::stringfilename,*path;
    std::mapaDict;
    int scriptStatus;

    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ number intValue ] ];    
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];

    aDict = [ NSUnarchiver unarchiveObjectWithFile:path ];
    //aDict = [ NSDictionary dictionaryWithContentsOfFile:path ];
    if(!aDict)
        return false;

    [ this decodeWithSaveData:aDict ];
    [ ScriptEngine decodeWithSaveData:aDict ];
    [ StageManager decodeWithSaveData:aDict ];

    if([ this status ] == TYScriptRunningStatus){
        [ ScriptEngine setBreakRun:true ];
    }

    scriptStatus = [ [ aDict objectForKey:TYDataTypeSaveData ] intValue ];
    if(scriptStatus==TYScriptingSaveData){
        [ this setStatus:TYScriptRunningStatus ];
        [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    } else {
        [ this setStatus:TYPrinting ];
        [ StageManager setStatus:TYTPClickWait];
    }
    
    return true;
}

// REMOVED: -void*encodeWithSaveData{
    std::unordered_mapdict = [ NSMutableDictionary dictionary ];
    
    std::stringwavePath;

    if(waveController){
        wavePath = [ waveController soundPathIfNeedPlayingAtLoad ];
        if(wavePath)
            [ dict setObject:wavePath forKey:TYWavePathSaveData ];
    }

    if(bgmPath){
        if([ BGMView loopMode ]==NSQTMovieLoopingPlayback){
            [ dict setObject:bgmPath forKey:TYBGMPathSaveData ];
        } else if(bgmForceSave){
            [ dict setObject:bgmPath forKey:TYBGMPathSaveData ];
            [ dict setObject:[ NSNumber numberWithBool:true ] forKey:TYBGMNoLoopSaveData ];
        }
    }

    [ dict setObject:[ NSNumber numberWithInt:autoclickTimer ] forKey:TYAutoClickTimerSaveData ];
    
    return dict;
}

-(void)decodeWithSaveData:(void*)aObject
{
    void* temp;
    
    if([ BGMView isPlaying ])
        [ BGMView stop:this ];
    if(bgmPath){
        [ bgmPath release ];
        bgmPath = nullptr;
    }
    temp = [ aObject objectForKey:TYBGMPathSaveData ];
    if(temp){
        void* temp2;
        temp2 = [ aObject objectForKey:TYBGMNoLoopSaveData ];
        [ this playSound:temp loop:(temp2) ? false : true forceSave:(temp2) ? true : false ];
    }

    if(waveController){
        [ waveController release ];
        waveController = nullptr;
    }
    temp = [ aObject objectForKey:TYWavePathSaveData ];
    if(temp){
        waveController = [ [ TYSoundController alloc ] initWithResource:temp loop:true ];
        [ waveController play ];
    }

    temp = [ aObject objectForKey:TYAutoClickTimerSaveData ];
    if(temp){
        autoclickTimer = [ temp intValue ];
    } else {
        autoclickTimer = 0;
    }
    
}

// REMOVED: -intautoclickTimer{
    return autoclickTimer;
}

-(void)setImage:(NSImage*)aImage
{
    [ MainView setImage:aImage ];
    [ MainView setNeedsDisplay:true ];
}

-(void)setImage:(NSImage*)aImage inRect:(NSRect)inRect
{
    [ MainView setImage:aImage ];
    if(isFullScreenMode){
        [ MainView setNeedsDisplayScalingRect:inRect ];
    } else {
        [ MainView setNeedsDisplayInRect:inRect ];
    }
}

// REMOVED: -NSImage*image{
    return [ MainView image ];
}

-(void)directDrawImage:(NSImage*)sourceImage inRect:(NSRect)inRect fromRect:(NSRect)fromRect
{
    [ MainView directDrawImage:sourceImage inRect:inRect fromRect:fromRect ];
}

// REMOVED: -NSImage*makeImageFromMainView{
    NSImage *image;
    NSBitmapImageRep *rep;

    [ MainView lockFocus ];
    rep = [ [ NSBitmapImageRep alloc ] initWithFocusedViewRect:[ MainView frame ] ];
    [ MainView unlockFocus ];
    if(!rep)
        return nullptr;
    [ rep setSize:TYVirtualScreenSize() ];

    image = [ [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ] autorelease ];
    [ image addRepresentation:rep ];
    return image;
}

-(void)setNeedsDisplayMainView:(bool)needs
{
    [ MainView setNeedsDisplay:true ];
}

-(void)setAcceptsMouseMovedEvents:(bool)flag
{
    //[ MainWindow setAcceptsMouseMovedEvents:flag ];
}

// REMOVED: -NSWindow*mainWindow{ return MainWindow; }

-(void)ty_savenumber:(std::vector)argments
{
    [ saveLoadController setNumber:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] ];
}

-(void)ty_savefileexist:(std::vector)argments
{
    std::stringpath,*filename;
    bool exist;
    
    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ] ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];

    exist = [ [ NSFileManager defaultManager ] fileExistsAtPath:path ];
    
    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:@"mov",[ argments objectAtIndex:1 ],[ NSNumber numberWithInt:(exist) ? 1 : 0 ],nullptr ] ];
}

-(void)ty_savetime:(std::vector)argments
{
    std::mapaDict;
    std::stringpath,*filename;
    int dateValue[4];
    std::vectorevalArg;
    NSCalendarDate *date;
    int i;

    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];

    aDict = [ NSUnarchiver unarchiveObjectWithFile:path ];
    if(!aDict){
        evalArg = [ NSMutableArray arrayWithObjects:@"",[ argments objectAtIndex:2 ],[ NSNumber numberWithInt:0 ],nullptr
            ];
        [ ScriptEngine ty_mov:evalArg ];
    } else {
        date = [ aDict objectForKey:TYMakeDateSaveData ];
        dateValue[0] = [ date monthOfYear ];
        dateValue[1] = [ date dayOfMonth ];
        dateValue[2] = [ date hourOfDay ];
        dateValue[3] = [ date minuteOfHour ];
        for(i=0;i < 4; i++){
            evalArg = [ NSMutableArray arrayWithObjects:@"",[ argments objectAtIndex:2+i ],
                [ NSNumber numberWithInt:dateValue[i] ],nullptr ];
            [ ScriptEngine ty_mov:evalArg ];
        }
    }
}

-(void)ty_filelog:(std::vector)argments
{
    [ [ TYResourceServer sharedServer ] filelog:
        [ getNScrRootDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
}

-(void)ty_mp3:(std::vector)argments
{
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:false ];
}

-(void)ty_mp3save:(std::vector)argments
{
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:true ];
}

-(void)ty_mp3loop:(std::vector)argments
{
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true forceSave:false ];
}

-(void)ty_mp3stop:(std::vector)argments
{
    [ this ty_playstop:argments ];
}

-(void)ty_play:(std::vector)argments
{
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true forceSave:false ];
}

-(void)ty_playonce:(std::vector)argments
{
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:false ];
}

-(void)ty_bgm:(std::vector)argments
{
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true forceSave:false ];
}

-(void)ty_bgmonce:(std::vector)argments
{
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:false ];
}

-(void)playSound:(std::string)argment loop:(bool)aBool forceSave:(bool)save
{
    std::vectorcomponents;
    NSMovie *movie;
    int trackNo;
    std::stringpath;

    if(![ argment length ]){
        [ this ty_playstop:nullptr ];
        return;
    }
    
    if(bgmPath)
        [ bgmPath autorelease ];
    bgmPath = [ argment retain ];
    bgmForceSave = save;
    
    if([ [ argment substringWithRange:NSMakeRange(0,1) ] isEqualToString:@"*" ]){
        // I[fBIgbN̉t
        trackNo = [ [ argment substringFromIndex:1 ] intValue ];
        components = [ audioSearchPath componentsSeparatedByString:@"*" ];
        path = [ NSString stringWithFormat:@"%@%02d%@",[ components objectAtIndex:0 ],trackNo,[ components objectAtIndex:1 ] ];
        movie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:path ] byReference:true ];
    } else {
        std::vector<uint8_t>data;
        std::stringfilePath;
        //std::stringtempPath;

        if(filePath = [ [ TYResourceServer sharedServer ] getFilePath:bgmPath ]){
            movie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:filePath ] byReference:true ];
        } else {
            std::stringnewTmpPath;
            newTmpPath = [ getNScrRootDirectory() stringByAppendingPathComponent:[ NSString stringWithFormat:@".%@",[ winPathToUnix(bgmPath) lastPathComponent ] ] ];
            if([ tmpPath isEqualToString:newTmpPath ]){
                [ BGMView gotoBeginning:nullptr ];
                [ BGMView start:nullptr ];
                return;
            }
            [ [ NSFileManager defaultManager ] removeFileAtPath:tmpPath handler:nullptr ];
            [ tmpPath release ];
            tmpPath = newTmpPath;
            
            // ォNSMovie@ς蕪Ȃ̂ŁAfBXNɈxނƂɂB
            data = [ [ TYResourceServer sharedServer ] getData:winPathToUnix(bgmPath) ];
            if(data){
                [ tmpPath retain ];
                [ data writeToFile:tmpPath atomically:false ];
                movie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:tmpPath ] byReference:true ];
                // MP3t@CbyReferenace:NOȂ̂
                //[ [ NSFileManager defaultManager ] removeFileAtPath:tempPath handler:nullptr ];
            } else {
                tmpPath = nullptr;
                movie = nullptr;
            }
        }
        path = bgmPath;
    }

    if(!movie){
        qtMovie = NULL;
        if(gMyTimer)
            [ gMyTimer invalidate ];
        gMyTimer = nullptr;
        [ BGMView stop:nullptr ];
        NSLog(@"can't play audio file = %@",path);
        return;
    }
    [ BGMView setMovie:movie ];
    if(aBool)
        [ BGMView setLoopMode:NSQTMovieLoopingPlayback ];
    else
        [ BGMView setLoopMode:NSQTMovieNormalPlayback ];
    [ BGMView setVolume:BGMVolume ];
    
    if (floor(NSAppKitVersionNumber) < NSAppKitVersionNumber10_2) {
        qtMovie = [ movie QTMovie ];
        gMyTimer = [NSTimer scheduledTimerWithTimeInterval:0.1		// interval, 0.1 seconds
                            target:this
                            selector:@selector(idleTimer:)		// call this method
                            userInfo:nullptr
                            repeats:true];
    }
    [ BGMView start:nullptr ];
    NSLog2(@"playing=%d",[ BGMView isPlaying ]);
    [ movie release ];
}

-(void)ty_playstop:(std::vector)argments
{
    if([ BGMView isPlaying ])
        [ BGMView stop:this ];

    if(bgmPath)
        [ bgmPath release ];

    bgmPath=nullptr;
}

-(void) idleTimer:(void*)sender
{
    MoviesTask(qtMovie,0);
}

// ̌Quick Time API𒼐ڌĂяoƕsN̂ŕB
// Apple͂ƂƂNSMovieView̃oOB 
-(void)ty_avi:(std::vector)argments
{
    [ this playMovie:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ]
            cancel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ] ];
}

-(void)ty_mpegplay:(std::vector)argments
{
    [ this playMovie:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ]
            cancel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ] ];
}

-(void)playMovie:(std::string)aPath cancel:(bool)aBool
{
    std::stringfilePath;
    Movie movie;

    if([ TYEnviroment boolForKey:TYEnablePlayMovieEnviroment ] == false)
        return;
        
    filePath = [ [ TYResourceServer sharedServer ] getFilePathMakeTemp:aPath ];
    if(!filePath)
        return;
        
    movieView = [ [ NSMovieView alloc ] initWithFrame:TYVirtualScreenRect() ];
    [ movieView setMovie:
        [ [ [ NSMovie alloc ] initWithURL:
            [ [ [ NSURL alloc ] initFileURLWithPath:filePath ] autorelease ] 
                              byReference:true ] autorelease ] ];
    [ movieView showController:false adjustingSize:false ];
    [ movieView setEditable:false ];
    [ movieView setVolume:[ BGMView volume ] ];
    [ movieView setFrame:TYVirtualScreenRect() ];
    movie = [ [ movieView movie ] QTMovie ];
    [ movieView setLoopMode:NSQTMovieNormalPlayback ];

    ctrlView = [ [ TYMovieControllerView alloc ] initWithFrame:TYVirtualScreenRect() ];
    [ ctrlView setController:this ];
    [ MainView addSubview:movieView ];
    [ movieView addSubview:ctrlView ];
    [ MainWindow makeFirstResponder:ctrlView ];

    [ movieView start:this ];
    [ this performSelector:@selector(endCheckMovie)
                        withObject:nullptr 
                        afterDelay:GetMovieDuration(movie) / GetMovieTimeScale(movie) ];
    
    [ ScriptEngine setBreakRun:true ];
}

// REMOVED: -voidendCheckMovie{
    if([ movieView isPlaying ]) {
        [ this performSelector:@selector(endCheckMovie)
                            withObject:nullptr 
                            afterDelay:0.1 ];        
    } else {
        [ this endPlayMovie ];
    }
}

// REMOVED: -voidendPlayMovie{
    if(!movieView) return;
    
    [ NSObject cancelPreviousPerformRequestsWithTarget:this
                                          selector:@selector(endCheckMovie) object:nullptr ];
    
    [ movieView stop:nullptr ];
    [ ctrlView removeFromSuperview ];
    [ movieView removeFromSuperview ];
    [ ctrlView autorelease ];
    [ movieView autorelease ];
    ctrlView = nullptr;
    movieView = nullptr;
    
    [ MainWindow makeFirstResponder:MainView ];
    if(isFullScreenMode==true)
        [ [ FullScrrenWindow contentView ] setNeedsDisplay:true ];
    [ ScriptEngine performSelector:@selector(runScript)  withObject:nullptr afterDelay:0 ];
}

-(void)ty_v:(std::vector)argments
{
    [ this playWaveSound:[ NSString stringWithFormat:INSTANT_WAVE_PATH_FORMAT,[ argments objectAtIndex:1 ] ] loop:false ];
}

-(void)ty_wave:(std::vector)argments
{
    [ this playWaveSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false ];
}

-(void)ty_waveloop:(std::vector)argments
{
    [ this playWaveSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true ];
}

-(void)playWaveSound:(std::string)argment loop:(bool)aBool
{    
    if(waveController) {
        [ waveController stop ];
        // 10.3NSSoundThread Safeł͖oO悤Ȃ̂ŁAx点ĂB
        [ waveController performSelector:@selector(autorelease) withObject:nullptr afterDelay:15.0 ];
    }
    waveController = [ [ TYSoundController alloc ] initWithResource:argment loop:aBool ];

    if(enable_automode && !aBool)
        [ waveController setPostingNotification:true ];
    [ waveController play ];
}

-(void)ty_wavestop:(std::vector)argments
{
    [ waveController stop ];
}

-(void)ty_dv:(std::vector)argments
{
    [ this playWaveChannel:0
                      path:[ NSString stringWithFormat:INSTANT_WAVE_PATH_FORMAT,[ argments objectAtIndex:1 ] ]
                      loop:false ];
}

-(void)ty_dwave:(std::vector)argments
{
    [ this playWaveChannel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]
                      path:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ]
                      loop:false ];
}

-(void)ty_dwaveloop:(std::vector)argments
{
    [ this playWaveChannel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]
                      path:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ]
                      loop:true ];
}

-(void)playWaveChannel:(int)ch path:(std::string)aPath loop:(bool)aBool
{
    int volume;
    
    NSAssert(((0 <= ch) && (ch < DIRECT_WAVE_MAX)),@"Direct Sound Channel Error");

    switch(ch){
        case 0:
        case DIRECT_WAVE_REPLAY:
            volume = (100 +voiceVol) *TYSOUND_VOLUME_MAX /100;
            break;
        default:
            volume = (100 +seVol) *TYSOUND_VOLUME_MAX /100;
    }

    
    if(*(directWaveController + ch)) {
        [ *(directWaveController + ch)stop ];
        // 10.3NSSoundThread Safeł͖oO悤Ȃ̂ŁAxꂹĂB
        [ *(directWaveController + ch) performSelector:@selector(release) withObject:nullptr afterDelay:15.0 ];
    }
    
    *(directWaveController + ch) = [ [ TYSoundController alloc ] initWithResource:aPath
                                                                        loop:aBool
                                                                       volume:volume ];
    if((ch==0) && !aBool)
        [ *(directWaveController +ch) setPostingNotification:true ];

    if(ch==0) 
        [ [ NSNotificationCenter defaultCenter ] 
            postNotificationName:TYVoicePlayNotification
                          object:aPath ]; 
    
    [ usingDirectWaveCannelSet addObject:[ NSNumber numberWithInt:ch ] ];

    [ *(directWaveController + ch) play ];
    
}

-(void)ty_dwavestop:(std::vector)argments
{
    int ch = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    NSAssert(((0 <= ch) && (ch < DIRECT_WAVE_MAX)),@"Direct Sound Channel Error");

    [ *(directWaveController + ch)stop ];
}

-(void)ty_stop:(std::vector)argments
{
    NSEnumerator *enu;
    void* temp;
    
    if([ BGMView isPlaying ])
        [ BGMView stop:this ];

    if(bgmPath)
        [ bgmPath release ];

    bgmPath=nullptr;

    [ waveController stop ];

    enu = [ usingDirectWaveCannelSet objectEnumerator ];
    while( temp = [ enu nextObject ]){
        [ directWaveController[ [ temp intValue ] ] stop ];
    }
}

// EChE^CgύX
-(void)ty_caption:(std::vector)argments
{
    [ MainWindow setTitle:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

// o[WύX
-(void)ty_versionstr:(std::vector)argments
{
    scriptVersionStr = [ NSString stringWithFormat:@"%@\n%@",[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ],[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ] ];
    [ scriptVersionStr retain ];
}

-(void)ty_click:(std::vector)argments
{
    [ ScriptEngine setBreakRun:true ];
    [ this setStatus:TYClickWaitStatus ];
}

-(void)ty_autoclick:(std::vector)argments
{
    autoclickTimer = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    //[ StageManager setAutoclickTimer:autoclickTimer ];
}

-(void)ty_wait:(std::vector)argments
{
    [ ScriptEngine setBreakRun:true ];
    [ this setStatus:TYTimeWaitStatus ];
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:
        [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] / 1000.0 ];
}

-(void)ty_delay:(std::vector)argments 
{
    [ ScriptEngine setBreakRun:true ];
    [ this setStatus:TYClickWaitStatus ];
    [ this performSelector:@selector(select_action) withObject:nullptr afterDelay:
        [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] / 1000.0 ];
}

-(void)ty_spi:(std::vector)argments
{
    std::vectorargArray;
    std::stringarg;

    arg = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    argArray = [ arg componentsSeparatedByString:@"|" ];

    [ [ TYResourceServer sharedServer ] addSpi:[ argArray objectAtIndex:0 ] extension:[ argArray objectAtIndex:1 ] ];
}

-(void)ty_soundpressplgin:(std::vector)argments
{
    std::vectorargArray;
    std::stringarg;

    arg = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    argArray = [ arg componentsSeparatedByString:@"|" ];

    [ [ TYResourceServer sharedServer ] addSoundPressPlugin:[ argArray objectAtIndex:0 ] extension:[ argArray objectAtIndex:1 ] ];
}

-(void)ty_mode_ext:(std::vector)argments
{
    mode_ext=true;
    [ this setEnableAutomode:true ];
}

-(void)setEnableAutomode:(bool)aBool
{
    int i,n;
    NSMenu *menu;
    NSMenuItem *mItem=[ [ NSMenuItem alloc ] initWithTitle:NSLocalizedString(@"AutoMode...",nullptr)
                                                    action:NULL
                                             keyEquivalent:@"A" ];

    enable_automode=aBool;

    //[ TYSoundController setPostingNotification:true ];

    [ mItem setEnabled:true ];
    [ mItem setAction:@selector(openAutoMode:) ];
    [ mItem setTarget:this ];
    menu = [ NScrMenu submenu ];
    n = [ menu numberOfItems ];
    i = 0;
    while(1){
        if([ menu itemAtIndex:i ] == SkipMenu){
            [ menu insertItem:mItem atIndex:i ];
            break;
        }
        i++;
        if(i>=n){
            [ menu insertItem:mItem atIndex:i ];
            break;
        }
    }
    /*
     [ ScriptEngine setBreakRun:true ];
     [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
     */

    
}

-(void)ty_automode_time:(std::vector)argments
{
    NSNumber *temp;
    
    if(!enable_automode)
        [ this setEnableAutomode:true ];
    
    if(!(temp = [ TYEnviroment objectForKey:TYAutomodeWaitTimeEnviroment ])) {
        temp = [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ];
        [ TYEnviroment setObject:[ NSNumber numberWithInt:[ temp intValue ] ] forKey:TYAutomodeWaitTimeEnviroment ];
    }
}

-(void)ty_defmp3vol:(std::vector)argments
{
    defBGMVol=[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] /100.0;
}

-(void)ty_voicevol:(std::vector)argments
{
    // Ȃ100񂾂? łB
    voiceVol = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] -100;
}

-(void)ty_defvoicevol:(std::vector)argments
{
    defVoiceVol=[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] /100.0;
}

-(void)ty_sevol:(std::vector)argments
{
    seVol = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] -100;
}

-(void)ty_defsevol:(std::vector)argments
{
    defSEVol=[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] /100.0;
}

-(void)ty_mp3vol:(std::vector)argments
{
    int volume;
    
    volume = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    
    BGMVolume = volume / 100.0;
    [ BGMView setVolume:volume / 100.0 ];
}

-(void)ty_kidokuskip:(std::vector)argments
{
    if(![ TYEnviroment objectForKey:TYKidokumodeEnviroment ]) {
        [ TYEnviroment setObject:[ NSNumber numberWithBool:true ] forKey:TYKidokumodeEnviroment ];
    }
    [ SkipMenu setTitle:NSLocalizedString(@"KidokuSkip",nullptr) ];
    [ SkipMenu setAction:@selector(skipWhileKidoku:) ];
    [ ScriptEngine enableKidoku ];
}

-(void)ty_kidokumode:(std::vector)argments
{
    [ TYEnviroment setObject:
        [ NSNumber numberWithBool:(([ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]) ? true : false) ]
                      forKey:TYKidokumodeEnviroment ];
}

-(void)ty_reset:(std::vector)argments
{
    [ this resetGame:nullptr ];
}

-(void)ty_menu_window:(std::vector)argments
{
    [ this windowMode:nullptr ];
}

-(void)ty_menu_full:(std::vector)argments
{
    [ this fullScreenMode:nullptr ];
}

-(void)ty_savename:(std::vector)argments
{
    [ saveLoadController setNames:[ NSArray arrayWithObjects:
        [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ],
        [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ],
        [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:3 ] ],nullptr ] ];
}

-(void)ty_systemcall:(std::vector)argments
{
    std::stringarg=[ [ argments objectAtIndex:1 ] lowercaseString ];

    if([ arg isEqualToString:@"load" ]){
        [ this enterSaveLoadMenu:1 ];
    } else if([ arg isEqualToString:@"save" ]){
        [ this enterSaveLoadMenu:0 ];
    } else if([ arg isEqualToString:@"skip" ]){
        void* envObj;
        envObj = [ TYEnviroment objectForKey:TYKidokumodeEnviroment ];
        if(envObj && [ envObj boolValue ]) 
            [ this skipWhileKidoku:nullptr ];
        else
            [ this skipToSelection:nullptr ];
    } else if([ arg isEqualToString:@"windowerase" ]){
        [ this eraseTextWindowMode:nullptr ];
    } else if([ arg isEqualToString:@"lookback" ]){
        [ this enterLookback:nullptr ];
    } else if([ arg isEqualToString:@"rmenu" ]){
        [ this openRightclickMenu:nullptr ];
    } else if([ arg isEqualToString:@"reset" ]){
        [ this enterYesNoModeTitle:NSLocalizedString(@"May I reset?",nullptr)
                         yesAction:@"_reset" 
                          noAction:@"" ];
    } else if([ arg isEqualToString:@"resetdlg" ]){
        [ this resetGame:[ NSNull null ] ];
    } else if([ arg isEqualToString:@"_reset" ]){
        [ this resetGame:nullptr ];
    } else if([ arg length ] >= 7) {
        std::stringcmd = [ arg substringWithRange:NSMakeRange(0,6) ];
        std::stringnostr = [ arg substringFromIndex:6 ];
        std::vectornames = [ saveLoadController names ];
        std::stringbookmark;
        std::stringtitle;
        
        if([ cmd isEqualToString:@"_qload" ]){
            bookmark = [ [ names objectAtIndex:2 ] stringByAppendingString:
                            TYWideCharDecimalStringWithString(nostr) ];
            title = [ NSString stringWithFormat:NSLocalizedString(@"May I Load?",nullptr),bookmark ];
            [ this enterYesNoModeTitle:title
                             yesAction:[ @"_eload" stringByAppendingString:nostr ]
                              noAction:@"" ];
        } else if([ cmd isEqualToString:@"_qsave" ]){
            bookmark = [ [ names objectAtIndex:2 ] stringByAppendingString:
                            TYWideCharDecimalStringWithString(nostr) ];
            title = [ NSString stringWithFormat:NSLocalizedString(@"May I Save?",nullptr),bookmark ];
            [ this enterYesNoModeTitle:title
                             yesAction:[ @"_esave" stringByAppendingString:nostr ]
                              noAction:@"" ];
        } else if([ cmd isEqualToString:@"_eload" ]) {
            [ NSObject cancelPreviousPerformRequestsWithTarget:ScriptEngine
                                                      selector:@selector(runScript)
                                                        object:nullptr ];
            [ this loadLocalData:[ NSNumber numberWithInt:[ nostr intValue ] ] ];
        } else if([ cmd isEqualToString:@"_esave" ]) {
            [ NSObject cancelPreviousPerformRequestsWithTarget:ScriptEngine
                                                      selector:@selector(runScript)
                                                        object:nullptr ];
            [ this saveLocalData:[ NSNumber numberWithInt:[ nostr intValue ] ] ];
        }
    }
}

-(void)enterYesNoModeTitle:(std::string)title 
                 yesAction:(std::string)yAction 
                  noAction:(std::string)nAction
{
        TYMenuModeView *aView;
        aView = [ [ TYYesNoMenuView alloc ] initWithFrame:TYVirtualScreenRect()
                                            controller:this
                                            attributes:[ StageManager textAttDict ]
                                            titleAndAction:
                                                [ NSMutableArray arrayWithObjects:
                                                    title,
                                                    yAction,
                                                    nAction,nullptr ]
                                                layout:rightMenuLayout ];
        [ MainView addSubview:aView ];
        [ [ aView window ] makeFirstResponder:aView ];
        [ aView updatesTrackingRect ];
        [ this enterSystemMode ];
}

-(void)ty_rmenu:(std::vector)argments
{
    void* temp;
    NSEnumerator *enu;
    
    if(rightMenuItemArray)
        [ rightMenuItemArray release ];
    
    rightMenuItemArray = [ [ NSMutableArray alloc ] initWithCapacity:[ argments count ] -1 ];
    
    enu = [ argments objectEnumerator ];
    [ enu nextObject ];
    while(temp = [ enu nextObject ]){
        [ rightMenuItemArray addObject:[ ScriptEngine getStringOfArgment:temp ] ];
        temp = [ enu nextObject ];
        [ rightMenuItemArray addObject:temp ];
    }
}

-(void)ty_menusetwindow:(std::vector)argments
{
    NSSize fontSize,pitchSize;
    int shadow,bold;
    NSColor *color;
    
    fontSize.width = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    fontSize.height = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    pitchSize.width = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    pitchSize.height = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    bold = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ];
    shadow = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:6 ] ] intValue ];
    color = getTextWindowColorWithHTMLFormat([ ScriptEngine getStringOfArgment:[ argments objectAtIndex:7 ] ]);
    
    [ rightMenuLayout setObject:[ NSValue valueWithSize:fontSize ] forKey:TYRMenuFontSize ];
    [ rightMenuLayout setObject:[ NSValue valueWithSize:pitchSize ] forKey:TYRMenuFontPitchSize ];
    [ rightMenuLayout setObject:[ NSNumber numberWithBool:shadow ] forKey:TYRMenuShadowed ];
    [ rightMenuLayout setObject:[ NSNumber numberWithBool:bold ] forKey:TYRMenuBold ];
    [ rightMenuLayout setObject:color forKey:TYRMenuBGColor ];
}

-(void)ty_menuselectcolor:(std::vector)argments
{
    NSColor *color;
    std::string str;

    if(!rightMenuLayout)
        rightMenuLayout = [ [ NSMutableDictionary alloc ] initWithCapacity:8 ];

    str = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    color = getColorWithHTMLFormat(str);
    [ rightMenuLayout setObject:color forKey:TYRMenuSelectColor ];
    
    str = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ];
    color = getColorWithHTMLFormat(str);
    [ rightMenuLayout setObject:color forKey:TYRMenuNoSelectColor ];
    
    str = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:3 ] ];
    color = getColorWithHTMLFormat(str);
    [ rightMenuLayout setObject:color forKey:TYRMenuNoDataColor ];
}

-(void)ty_lookbackcolor:(std::vector)argments
{
    lookbackColor = [ getColorWithHTMLFormat([ argments objectAtIndex:1 ]) retain ];
}

-(void)ty_lookbackbutton:(std::vector)argments
{
    lookbackBtn = [ NSArray arrayWithObjects:
                    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ],
                    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ],
                    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:3 ] ],
                    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:4 ] ],nullptr ];
    [ lookbackBtn retain ];
}

-(void)ty_getmousepos:(std::vector)argments
{
    NSPoint btnClickPoint;
    NSPoint screenPoint;
    NSPoint windowPoint;
    NSPoint viewPoint;

    // 10.2.5AconvetPoint: fromView:niloOĂ(
    screenPoint = [ NSEvent mouseLocation ];
    windowPoint = [ [ MainView window ] frame ].origin;
    viewPoint = [ MainView frame ].origin;
    
    btnClickPoint = NSMakePoint(screenPoint.x -windowPoint.x -viewPoint.x,
                                screenPoint.y -windowPoint.y -viewPoint.y);
    if(btnClickPoint.x < 0)
        btnClickPoint.x = 0;
    else if(btnClickPoint.x > VSCREEN_WIDTH)
        btnClickPoint.x = VSCREEN_WIDTH;
    
    if(btnClickPoint.y < 0)
        btnClickPoint.y = 0;
    else if(btnClickPoint.y > VSCREEN_HEIGHT)
        btnClickPoint.y = VSCREEN_HEIGHT;
    btnClickPoint.y = VSCREEN_HEIGHT -btnClickPoint.y;

    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:@"mov",[ argments objectAtIndex:1 ],[ NSNumber numberWithInt:btnClickPoint.x ],nullptr ] ];
    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:@"mov",[ argments objectAtIndex:2 ],[ NSNumber numberWithInt:btnClickPoint.y ],nullptr ] ];
}

-(void)ty_exec_dll:(std::vector)argments
{
    [ [ TYResourceServer sharedServer ] executeBundle:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    [ ScriptEngine setBreakRun:true ];
}

-(void)ty_getret:(std::vector)argments
{
    TYArgment *arg = [ argments objectAtIndex:1 ];
    
    if([ arg varType ] & TYDigitVarTypeMask) {
        [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:@"mov",arg,
            [ NSNumber argmentWithInt:[ [ TYCCSProxy proxy ] returnCode ] ],nullptr ] ];
    } else if([ arg varType ] ==  TYStringVarType) {
        [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:@"mov",arg,
            [ [ TYCCSProxy proxy ] returnString ],nullptr ] ];
    }
}

-(void)setTrap:(bool)aBool
{
    trapSelectAction = aBool;
}

- (void)changeFont:(void*)fontManager
{
    [ StageManager changeFont:fontManager ];
}

- (IBAction)changeTextSpeed:(void*)sender
{
    NSEnumerator *enu=[ [ SpeedMenu itemArray ] objectEnumerator ];
    void* tmp;

    while((tmp = [ enu nextObject ])!=nullptr){
        [ tmp setState:NSOffState ];
    }
    [ sender setState:NSOnState ];
    
    [ StageManager changeTextSpeed:[ sender tag ] ];
}

// REMOVED: -intselectedSpeedTag{
    NSEnumerator *enu=[ [ SpeedMenu itemArray ] objectEnumerator ];
    void* tmp;

    while((tmp = [ enu nextObject ])!=nullptr){
        if([tmp state ]==NSOnState){
            return [ tmp tag ];
        }
    }
    return -1;
}

- (IBAction)skipToSelection:(void*)sender
{
    [ StageManager setSkipStatus:TYSelectionSkipMask ];
}

- (IBAction)skipWhileKidoku:(void*)sender
{
    [ ScriptEngine setWatchKidoku:true ];
    [ StageManager setSkipStatus:TYKidokuSkipMask ];
}

- (IBAction)versionDisp:(void*)sender
{
    std::stringtitle;
    title = NSLocalizedString(@"SCRIPT_VERSION",nullptr);
    NSRunInformationalAlertPanel(title,scriptVersionStr,@"OK",nullptr,nullptr);
}
- (IBAction)openSaveDialog:(void*)sender
{
    if([ this isPossibleEnterSystemMode ]){
        [ this enterSaveLoadMenu:0 ];
    } else {
        NSBeep();
    }

}

- (IBAction)openLoadDialog:(void*)sender
{
    if([ this isPossibleEnterSystemMode ]){
        [ this enterSaveLoadMenu:1 ];
    } else {
        NSBeep();
    }
}

- (void)enterSaveLoadMenu:(int)loadmode
{
    std::vectordArray;
    std::vectoreArray;
    TYSaveLoadMenuView *aView;
    
    dArray = [ saveLoadController dateStrings:loadmode ];
    eArray = [ saveLoadController existsArray ];
    
    aView = [ [ TYSaveLoadMenuView alloc ] initWithFrame:TYVirtualScreenRect()
                                              controller:this
                                                 layout:rightMenuLayout
                                                 attributes:[ StageManager textAttDict ]
        dateStrArray:[ saveLoadController dateStrings:loadmode ]
        existsArray:[ saveLoadController existsArray ]
        doLoad:loadmode ];
    [ MainView addSubview:aView ];
    [ [ aView window ] makeFirstResponder:aView ];
    [ aView updatesTrackingRect ];
    [ this enterSystemMode ];
}

/* obsolute
- (void)openSaveLoadDialog:(int)loadmode
{
    NSAutoreleasePool *aPool;
    std::map aDict;
    std::stringpath,*filename;
    void* aObj;
    int result;
    int i,num;
    
    if([ saveLoadController isLoaded ] == false){
        // LoadĂȂ΃Z[uf[^t@C
        num = [ saveLoadController number ];
        aPool = [ [ NSAutoreleasePool alloc ] init ];
        for(i=1; i <= num; i++){
            filename = [ NSString stringWithFormat:SAVEDATA_NAME,i ];
            path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
            aDict = [ NSUnarchiver unarchiveObjectWithFile:path ];
            if(aDict){
                aObj = [ aDict objectForKey:TYMakeDateSaveData ];
                if(aObj)
                    [ saveLoadController setDate:aObj number:i ];
            }
        }
        [ aPool release ];

        [ saveLoadController setLoaded:true ];
    }

    [ saveLoadController setLoadMode:loadmode ];
    [ NSBundle loadNibNamed:@"SaveLoadDialog" owner:saveLoadController ];

    if(loadmode){
        [ saveLoadController setTitle:@"LOAD" ];
    } else {
        [ saveLoadController setTitle:@"SAVE" ];
    }
    
    result = [[NSApplication sharedApplication]
            runModalForWindow:[ saveLoadController window ] ];
    [ [ saveLoadController window ] close ];

    if(result==DIALOG_OK){
        if(loadmode){
            // load
            [ this loadLocalData:[ NSNumber numberWithInt:[ saveLoadController selectedRow ] +1 ] ];
        } else {
            [ this saveLocalData:[ NSNumber numberWithInt:[ saveLoadController selectedRow ] +1 ] ];
        }
    }    
}
*/

- (IBAction)openAudioPathWindow:(void*)sender
{
    if(!audioPathController){
        audioPathController = [ [ TYAudioPathController alloc ] init ];
        [ NSBundle loadNibNamed:@"AudioPath" owner:audioPathController ];
        [ audioPathController setDelegate:this ];
    } 

    [ audioPathController openWithPath:audioSearchPath defaultPath:[ TYEnviroment defaultObjectForKey:TYAudioFilePathEnviroment ] ];
}

- (IBAction)showDebugInfo:(void*)sender
{
    TYGetDisplayInfo();
    NSRunInformationalAlertPanel(@"Debug Infomation",[ NSString stringWithFormat:@"Line:%d",[ ScriptEngine runLine ]+1 ], @"OK", nullptr, nullptr);

}

-(void)changeAudioPath:(std::string)aPath
{
    if(audioSearchPath)
        [ audioSearchPath release ];

    audioSearchPath = [ aPath retain ];
    [ TYEnviroment setObject:audioSearchPath forKey:TYAudioFilePathEnviroment ];

    [ audioPathController autorelease ];
    audioPathController = nullptr;

    // BGMtȂ瑦ɍĉt`FbN
    if(bgmPath){
        bool loop = ([ BGMView loopMode ]==NSQTMovieLoopingPlayback) ? true : false;
        if(loop || bgmForceSave){
            [ this playSound:bgmPath loop:loop forceSave:bgmForceSave ];
        }
    }
}

- (IBAction)windowMode:(void*)sender
{
    NSRect mainFrame=[ MainView frame ];

    if(!isFullScreenMode)
        return;

    // VXe[h̕ύX͓ŝ
    if(isSystemMode){
        NSBeep();
        return;
    }

    isFullScreenMode=false;

    TYEndFullScreen();
    
    [ [ MainView retain ] autorelease ];
    [ MainView removeFromSuperview ];
    [ [ MainWindow contentView ] addSubview:MainView ];
    mainFrame.origin.x = 0;
    mainFrame.origin.y = 0;
    mainFrame.size.width = VSCREEN_WIDTH;
    mainFrame.size.height = VSCREEN_HEIGHT;
    [ MainView setScaling:1.0 ];
    [ MainView setFrame:mainFrame ];

    [ MainWindow makeFirstResponder:MainView ];
    [ FullScrrenWindow setAcceptsMouseMovedEvents:false ];
    [ MainWindow setAcceptsMouseMovedEvents:true ];
    [ FullScrrenWindow orderOut:this ];
    [ MainWindow makeKeyAndOrderFront:this ];

    if([ TYEnviroment boolForKey:TYHideOtherFullScreenEnviroment ]) {
        [ NSApp unhideAllApplications:nullptr ];
    }
}

- (IBAction)fullScreenMode:(void*)sender
{
#ifndef DEBUG
    NSRect screenRect;
    NSRect mainFrame=[ MainView frame ];
    NSSize fullScreenSize;

    if(isFullScreenMode)
        return;
    
    // VXe[h̕ύX͓ŝ
    if(isSystemMode){
        NSBeep();
        return;
    }

    if([ TYEnviroment boolForKey:TYDisplayResizeAtFullScreenEnviroment ]) {
        if([ TYEnviroment boolForKey:TYHideOtherFullScreenEnviroment ]) {
            [ NSApp hideOtherApplications:nullptr ];
        }
        fullScreenSize = TYStartFullScreen(VSCREEN_WIDTH,VSCREEN_HEIGHT);
    } else
        fullScreenSize = NSZeroSize;
    
    screenRect = [ [ FullScrrenWindow screen ] frame ];
    if(!NSEqualSizes(fullScreenSize,NSZeroSize)) {
        screenRect = NSMakeRect(0,
                                NSHeight(screenRect) -fullScreenSize.height,
                                fullScreenSize.width,
                                fullScreenSize.height);
    }
    
    [ [ MainView retain ] autorelease ];
    [ MainView removeFromSuperview ];
    [ [ FullScrrenWindow contentView ] addSubview:MainView ];
    {
        mainFrame.origin.x = (screenRect.size.width -mainFrame.size.width) /2;
        mainFrame.origin.y = (screenRect.size.height -mainFrame.size.height) /2;
    }
    [ MainView setFrame:mainFrame ];

    /*
     [ [ BGMView retain ] autorelease ];
     [ BGMView removeFromSuperview ];
     [ [ MainWindow contentView ] addSubview:BGMView ];
     */

    [ FullScrrenWindow setFrame:screenRect display:true ];

    //[ MainWindow orderOut:this ];
    //[ MainView removeFromSuperview ];
    [ FullScrrenWindow makeFirstResponder:MainView ];
    [ FullScrrenWindow setLevelToFront ];
    [ FullScrrenWindow makeKeyAndOrderFront:this ];
    [ MainWindow setAcceptsMouseMovedEvents:false ];
    [ FullScrrenWindow setAcceptsMouseMovedEvents:true ];
    
    isFullScreenMode = true;
#endif
}

-(void)didChangeKeyWindow:(NSNotification*)notification
{
    if(isFullScreenMode){
        if([ notification object ] != FullScrrenWindow){
            [ FullScrrenWindow setLevelToNormal ];
        } else {
            [ FullScrrenWindow setLevelToFront ];
        }
    }
}

- (IBAction)openBGMVolumeDialog:(void*)sender
{
    if(!volumeController){
        float bV;
        void* temp;
        bV = (temp = [ TYEnviroment objectForKey:TYBGMVolumeEnviroment ]) ? [ temp floatValue ] : defBGMVol;
        
        if(!mode_ext) {
            volumeController = [ [ TYBGMVolumeController alloc ] initWithBGMVolume:bV ];
        } else {
            float vV,sV;
            vV = (temp = [ TYEnviroment objectForKey:TYVoiceVolumeEnviroment ]) ? [ temp floatValue ] : defVoiceVol;
            sV = (temp = [ TYEnviroment objectForKey:TYSEVolumeEnviroment ]) ? [ temp floatValue ] : defSEVol;
            
            volumeController = [ [ TYExtVolumeController alloc ]initWithDefaultBGMVolume:defBGMVol
                                                                              bgmVolume:bV
                                                                           defaultVoiceVolume:defVoiceVol
                                                                                  voiceVolume:vV
                                                                              defaultSEVolume:defSEVol
                                                                                     seVolume:sV ];
        }
        
                 //[ [ (mode_ext) ? TYBGMVolumeController : TYExtVolumeContoller alloc ] init ];
        //[ NSBundle loadNibNamed:@"BGMVolume" owner:this ];
    }
    [ volumeController setDelegate:this ];
    [ volumeController showDialog ];
    [ this closeBGMVolumeDialog:volumeController ];
    
    //[ VolumeSlider setFloatValue:[ BGMView volume ] ];

    //[[NSApplication sharedApplication] runModalForWindow:[ VolumeSlider window ] ];
}

- (IBAction)preference:(void*)sender
{
    [ TYPreferencePanelController showDialog ];
}

- (void)changeBGMVolume:(void*)sender
{
    float volume = [ sender floatValue ];

    BGMVolume = volume;
    [ BGMView setVolume:volume ];
}

- (void)closeBGMVolumeDialog:(void*)sender
{
    [ TYEnviroment setObject:[ NSNumber numberWithFloat:BGMVolume ]
                      forKey:TYBGMVolumeEnviroment ];
    if(mode_ext){
        [ TYEnviroment setObject:[ NSNumber numberWithFloat:[ volumeController voiceVolume ] ]
                          forKey:TYVoiceVolumeEnviroment ];
        voiceVol = [ volumeController voiceVolume ] *100 -100;

        [ TYEnviroment setObject:[ NSNumber numberWithFloat:[ volumeController seVolume ] ]
                          forKey:TYSEVolumeEnviroment ];
        seVol = [ volumeController seVolume ] *100 -100;        
    }
}

- (IBAction)openAutoMode:(void*)sender
{
    static TYAutoModeController *autoDialog;
    if(!autoDialog)
        autoDialog=[ [ TYAutoModeController dialog ] retain ];

    if([ TYEnviroment objectForKey:TYAutomodeWaitTimeEnviroment ] == nullptr) {
        [ TYEnviroment setObject:[ NSNumber numberWithInt:0 ] forKey:TYAutomodeWaitTimeEnviroment ];
    }

    if([ autoDialog runModalTextSpeed:[ StageManager userTextSpeed ]
            waitValue:[ [ TYEnviroment objectForKey:TYAutomodeWaitTimeEnviroment ] intValue ]
            waitType:[ [ TYEnviroment objectForKey:TYAutomodeWaitTypeEnviroment ] intValue ] ] 
              == NSOKButton){
        [ TYEnviroment setObject:[ NSNumber numberWithInt:[ autoDialog waitNum ] ] forKey:TYAutomodeWaitTimeEnviroment ];
        [ TYEnviroment setObject:[ NSNumber numberWithInt:[ autoDialog waitType ] ] forKey:TYAutomodeWaitTypeEnviroment ];
        [ StageManager setAutoMode:[ autoDialog textSpeed ]
                          waitType:[ autoDialog waitType ]
                              wait:[ autoDialog waitNum ] ];
    }
}

- (IBAction)eraseTextWindowMode:(void*)sender
{
    TYEraseModeView *aView;
    
    if(sender && ![ this isPossibleEnterSystemMode ]){
        NSBeep();
        return;
    }
    
    aView = [ [ TYEraseModeView alloc ] initWithFrame:TYVirtualScreenRect() controller:this ];
    [ aView autorelease ];
    [ MainView addSubview:aView ];
    [ [ aView window ] makeFirstResponder:aView ];
    [ this enterSystemMode ];
}

- (IBAction)openRightclickMenu:(void*)sender
{
    if(sender && ![ this isPossibleEnterSystemMode ]){
        NSBeep();
        return;
    }
    
    if(!menuModeView){
        menuModeView = [ [ TYRootMenuView alloc ] initWithFrame:TYVirtualScreenRect()
                                            controller:this
                                            attributes:[ StageManager textAttDict ]
                                            menuItems:rightMenuItemArray
                                                layout:rightMenuLayout ];
    }
    
    [ MainView addSubview:menuModeView ];
    [ [ menuModeView window ] makeFirstResponder:menuModeView ];
    [ menuModeView updatesTrackingRect ];
    
    [ this enterSystemMode ];
}

- (IBAction)enterLookback:(void*)sender
{
    TYLookbackView *aView;
    std::unordered_mapaDict;
    std::vectorqueue;
    TYCellImage *img1,*img2;
    
    if(sender && ![ this isPossibleEnterSystemMode ]){
        NSBeep();
        return;
    }
    queue = [ StageManager lookbackQueue ];
    if(![ queue count ])
        return;
    
    // {^摜
    {
        TYResourceServer *server = [ TYResourceServer sharedServer ];
        NSImage *uoncur,*uoffcur,*doncur,*doffcur;
        
        if(!lookbackBtn) {
            lookbackBtn = [ NSArray arrayWithObjects:@"uoncur.bmp",
                                                     @"uoffcur.bmp",
                                                     @"doncur.bmp",
                                                     @"doffcur.bmp",nullptr ];
            [ lookbackBtn retain ];
        }
        
        uoncur = [ server getImage:[ lookbackBtn objectAtIndex:1 ] transMode:true ];
        uoffcur = [ server getImage:[ lookbackBtn objectAtIndex:0 ] transMode:true ];
        
        doncur = [ server getImage:[ lookbackBtn objectAtIndex:3 ] transMode:true ];
        doffcur = [ server getImage:[ lookbackBtn objectAtIndex:2 ] transMode:true ];
        
        if(uoncur && uoffcur)
            img1 = [ [ TYCellImage alloc ] initWithImages:
                        [ NSArray arrayWithObjects:uoncur,uoffcur,nullptr ] ];
        else
            img1 = nullptr;
            
        if(doncur && doffcur)
            img2 = [ [ TYCellImage alloc ] initWithImages:
                        [ NSArray arrayWithObjects:doncur,doffcur,nullptr ] ];
        else
            img2 = nullptr;
    }
    
    aDict = [ [ [ StageManager textAttDict ] mutableCopy ] autorelease ];
    if(lookbackColor)
        [ aDict setObject:lookbackColor forKey:NSForegroundColorAttributeName ];
    aView = [ [ TYLookbackView alloc ] initWithFrame:TYVirtualScreenRect()
                                          controller:this
                                          attributes:aDict
                                              layout:rightMenuLayout
                                              buffer:queue
                                             ubutton:img1
                                             dbutton:img2 ];
    [ aView autorelease ];
    
    [ MainView addSubview:aView ];
    [ aView updatesTrackingRect ];
    [ [ aView window ] makeFirstResponder:aView ];
    
    [ this enterSystemMode ];

}

- (IBAction)resetGame:(void*)sender
{
    if(sender){
        if(![ sender respondsToSelector:@selector(tag:) ]) {
            if(NSRunAlertPanel(NSLocalizedString(@"Reset Game",nullptr),
                                  NSLocalizedString(@"May I reset?",nullptr),
                                  @"OK",
                                  nullptr,
                                 @"Cancel") == NSAlertOtherReturn){
                return ;
            }
        } else if(![ this isPossibleEnterSystemMode ]){
            // j[Ă΂ꂽꍇŁAJڂłȂB
            NSBeep();
            return;
        } else {
            [ this ty_systemcall:[ NSArray arrayWithObjects:@"systemcall",@"reset",nullptr ] ];
            return ;
        }            
    }
    
    if([ this status ] == TYScriptRunningStatus){
        [ ScriptEngine setBreakRun:true ];
    }
    
    [ this setStatus:TYScriptRunningStatus ];
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];

    
    [ BGMView stop:this ];
    [ bgmPath release ];
    bgmPath=nullptr;

    [ waveController release ];
    waveController=nullptr;

    autoclickTimer=0;

    [ StageManager resetGame ];
    [ ScriptEngine resetGame ];
}

- (IBAction)forceResume:(void*)sender
{
    [ ScriptEngine runScript ];
}

// REMOVED: -voidselect_action{
    if(trapSelectAction && TYStatus != TYPrinting)
        [ ScriptEngine fireOfTrap ];
    
    switch (TYStatus) {
    case TYClickWaitStatus:
        [ NSObject cancelPreviousPerformRequestsWithTarget:this selector:@selector(select_action) object:nullptr ];
        [ ScriptEngine runScript ];
        break;
    case TYPrinting:
        [ StageManager select_action ];
        break;
    case TYButtonWaitStatus:
        //[ MainWindow setAcceptsMouseMovedEvents:false ];
            
        [ StageManager select_action ];
        break;
    case TYSelectStatus:
        [ StageManager select_action ];
    default : break;
    }
}

-(IBAction)cancel_action:(void*)sender
{
    switch (TYStatus) {
        case TYButtonWaitStatus:
            [ StageManager cancel_action:sender ];
            break;
        case TYSelectStatus:
            [ this openRightclickMenu:nullptr ];
            break;
        case TYScriptRunningStatus:
        case TYClickWaitStatus:
            break;
        default:
            [ StageManager cancel_action:sender ];
    }
}

// REMOVED: -voidup_action{
    switch (TYStatus) {
    case TYButtonWaitStatus:
    case TYSelectStatus:
    case TYPrinting:
        [ StageManager up_action ];
        break;
    default : break;
    }
}
 
// REMOVED: -voiddown_action{
    switch (TYStatus) {
    case TYButtonWaitStatus:
    case TYSelectStatus:
        [ StageManager down_action ];
        break;
    default : break;
    }
}

-(void)move_mouse:(NSPoint)point
{
    switch (TYStatus){
    case TYButtonWaitStatus:
    case TYSelectStatus:
        [ StageManager move_mouse:point ];
        break;
    default:break;
    }
}

-(void)other_action:(void*)code
{
    switch (TYStatus){
    case TYButtonWaitStatus:
        [ StageManager other_action:code ];
        break;
    default:break;
    }
}

// REMOVED: -voidenterSystemMode{        
    isSystemMode = true;
        
    switch (TYStatus){
    case TYPrinting:
        [ StageManager enterSystemMode ];
        break;
    case TYScriptRunningStatus:
        [ ScriptEngine setBreakRun:true ];
        [ NSObject cancelPreviousPerformRequestsWithTarget:ScriptEngine
                                                  selector:@selector(runScript)
                                                    object:nullptr ];
        break;
    default:break;
    }
    [ MainView setImage:[ StageManager visualLayer ] ];
}

-(void)exitSystemModeResumeStatus:(bool)aBool
{
    switch (TYStatus & (TYRmodeStatusMask -1)){
    case TYPrinting:
    case TYSelectStatus:
        [ StageManager exitSystemModeResumeStatus:aBool ];
        break;
    case TYScriptRunningStatus:
        [ ScriptEngine performSelector:@selector(runScript)
                            withObject:nullptr
                            afterDelay:0.1 ];
        break;
    default:break;
    }

    isSystemMode = false;
}

// REMOVED: -boolisPossibleEnterSystemMode{
    // [U̗vɂăVXe[hֈڍs\ȏԂԂB
    if(isSystemMode)
        return false;
    
    switch (TYStatus){
    case TYPrinting:
        return [ StageManager isPossibleEnterSystemMode ];
    case TYSelectStatus:
        return true;
    default:
        return false;
    }
}


// @end
