// Converted from TYCCSProxy.m
// TODO: Manual review and fixes required

//
//  TYCCSProxy.m
//  Tukuyomi
//
//  Created by toveta on Sun Aug 03 2003.
//  Copyright (c) 2003 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYCCSProxy.h"
#include "TYMainController.h"

// @implementation TYCCSProxy

static void* proxy;

+(void*)proxy
{
    if(!proxy) {
        proxy = [ [ this alloc ] init ];
    }
    
    return proxy;
}

// REMOVED: -NSWindow*mainWindow{
    return [ [ TYMainController controller ] mainWindow ];
}

-(void)setRetunCode:(int)aInt string:(std::string)aStr
{
    returnCode = aInt;
    [ returnString release ];
    returnString = [ aStr retain ];
    
    [ [ TYScriptEngine sharedEngine ] performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
}

// REMOVED: -intreturnCode{ return returnCode; }
// REMOVED: -std::stringreturnString{ return returnString; }

// @end
