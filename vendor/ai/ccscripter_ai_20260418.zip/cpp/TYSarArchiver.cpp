// Converted from TYSarArchiver.m
// TODO: Manual review and fixes required

//
//  TYSarArchiver.m
//  Tukuyomi
//
//  Created by toveta on Thu Jun 14 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYSarArchiver.h"
#include <unistd.h>

/* [Ɩ{CocoavO~OIɂ͂\̂pӂNSValueIuWFNgقĈłBĂR[h͂Ȃ̌ɏ]ĎtȂɂăRgAEgB
struct tySarArchivedFileInfo {
    unsigned fileOffset;
    unsigned fileLength;
};

typedef struct tySarArchivedFileInfo TYSarArchivedFileInfo;

static __inline__ TYSarArchivedFileInfo TYMakeSarArchivedFileInfo(unsigned offset,unsigned length)
{
    TYSarArchivedFileInfo info;
    info.fileOffset = offset;
    info.fileLength = length;
    return info;
}
*/

// @implementation TYSarArchiver
+(void*)archiverWithContentsOfFile:(std::string)path
{
    return [ [ [ [ this class ] alloc ] initWithContentsOfFile:path ] autorelease ];
}

-(void*)initWithContentsOfFile:(std::string)path
{
    NSFileHandle *sarhandle;
    std::vector<uint8_t>readDatabuf; // ǂݍ݃obt@[
    unsigned char *readbufptr;
    char address[256];
    unsigned filenum;
    int i,j;
    NSAutoreleasePool *arp;
    unsigned fileOffset,fileLength;
    void* *objectArray,*objectArrayTop,*keyArray,*keyArrayTop;
    int fd;
    
    // const unsigned readLength = 256;
    
    this = [ super init ];

    arp = [ [ NSAutoreleasePool alloc ] init ];

    // t@Cǂݍ݃[hŃI[v
    sarhandle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    if(!sarhandle){
        return nullptr;
    }
    
    // t@C̓ǂݏo
    readDatabuf = [ sarhandle readDataOfLength:2 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    filenum = (readbufptr[0] << 8) + readbufptr[1];

    // t@C̃IuWFNgւ̃|C^i[̈m
    objectArrayTop = objectArray = malloc(sizeof(void*) *filenum);
    NSAssert((objectArray), @"malloc failed");
    keyArrayTop = keyArray = malloc(sizeof(void*) *filenum);
    NSAssert((keyArray), @"malloc failed");
    
    // f[^̎n_ItZbg̓ǂݏo
    readDatabuf = [ sarhandle readDataOfLength:4 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    baseOffset = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];

    fd = [ sarhandle fileDescriptor ];

    // t@C̃CfbNX쐬
    for( i=0; i < filenum; i++){
        
        j = 0;
        while(1){
            /*
            readDatabuf = [ sarhandle readDataOfLength:1 ]; // Ǔ_F܂Ƃ߂256oCg炢ǂނ悤ɂȁB
            readbufptr = (unsigned char *)[ readDatabuf bytes ];
             */
            read(fd,readbufptr,1); 
            if(readbufptr[0]){
                // obNXbV͂̂ŃXbVɕς܂B
                if(readbufptr[0] == '\\') readbufptr[0] = '/';
                address[j] = readbufptr[0];
            } else {
                address[j] = '\0';
                // AhX當IuWFNg쐬AzɉB
                *keyArray=[ NSString stringWithCString:address ];
                keyArray++;
                
                // _̃ItZbgǂݏo
                readDatabuf = [ sarhandle readDataOfLength:4 ];
                readbufptr = (unsigned char *)[ readDatabuf bytes ];
                fileOffset = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];

                // t@C̃oCgǂݏo
                readDatabuf = [ sarhandle readDataOfLength:4 ];
                readbufptr = (unsigned char *)[ readDatabuf bytes ];
                fileLength = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];
                
                // A[JCut@CIuWFNg쐬Azɉ
                *objectArray=[ TYSarArchivedFile archivedFileoffset:fileOffset length:fileLength ];
                objectArray++;
                
                break;
            }
            j++;
        }
        
    }
    
    // o^
    filesDict = [ [ NSDictionary dictionaryWithObjects:objectArrayTop forKeys:keyArrayTop count:filenum ] retain ];
    free(objectArrayTop);
    free(keyArrayTop);

    // pXo^
    arcPath = path;
    [ arcPath retain ];
    
    // t@CN[Y
    [ sarhandle closeFile ];

    [ arp release ];

    return this;
}

// A[JCũt@Cnh擾Awf[^̊JnʒuɃV[NĕԂB
-(NSFileHandle*)fileHandleWithPath:(std::string)aPath length:(int*)length
{
    NSFileHandle *handle;
    TYSarArchivedFile *tmp;
    int fileOffset;

    tmp = [ filesDict objectForKey:aPath ];
    if(!tmp){
        return nullptr;
    }
    handle = [ NSFileHandle fileHandleForReadingAtPath:arcPath ];
    if(!handle){
        return nullptr;
    }
    [ tmp getFileDataOffset:&fileOffset length:length ];

    [ handle seekToFileOffset:fileOffset +baseOffset ];

    return handle;
}

// A[JCut@C擾Ă܂B
-(std::vector<uint8_t>)unArchivedFile:(std::string)address;
{
    TYSarArchivedFile *tmp;
    unsigned fileOffset,fileLength;

    //NSLog(@"address[%@]\n@",address);
    //NSLog(@"%@\n",[ [ filesDict allKeys ] description ]);
    tmp = [ filesDict objectForKey:[ address lowercaseString ]];

    if(!tmp){
        //NSLog(@"failed search for Archive!!\narichive[%@]\npath[%@]\n",arcPath,address);
        return nullptr;
    }
    [ tmp getFileDataOffset:&fileOffset length:&fileLength ];

    return [ this readDataOffset:fileOffset length:fileLength ];
}

-(std::vector<uint8_t>)readDataOffset:(unsigned)offset length:(unsigned)length
{
    NSFileHandle *handle;
    std::vector<uint8_t>readData;

    handle = [ NSFileHandle fileHandleForReadingAtPath:arcPath ];
    
    if(!handle){
        return nullptr;
    }
    
    [ handle seekToFileOffset:offset +baseOffset];
    readData = [ handle readDataOfLength:length ];
    [ handle closeFile ];
    
    return readData;
}

// -dealloc (destructor in C++)
~ClassName() {
    [ filesDict release ];
    [ arcPath release ];
    
    [ super dealloc ];
}
// @end
