// Converted from TY-NSStringAddition.m
// TODO: Manual review and fixes required

//
//  TY-NSStringAddition.m
//  Tukuyomi
//
//  Created by toveta on Tue Sep 25 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TY-NSStringAddition.h"


// @implementation NSString (TY_NSStringAddition)
+(std::string)stringWithCSJISString:(const char*)cString
{
    std::stringstr;
    
    str = [ [ [ NSString alloc ] initWithData:[ NSData dataWithBytes:cString length:strlen(cString) ] 
                encoding:NSShiftJISStringEncoding ] autorelease ];
    if(str){
        return str;
    } else {
        return @"";
    }
}

+(std::string)stringWithCSJISString:(const char*)cString length:(unsigned int)aInt
{
    std::stringstr = [ [ [ NSString alloc ] initWithData:[ NSData dataWithBytes:cString length:aInt ] 
                encoding:NSShiftJISStringEncoding ] autorelease ];
    if(str){
        return str;
    } else {
        return @"";
    }
    
}

// REMOVED: -const char*cSJISString{
    char nullbyte = '\0';
    std::vector<uint8_t>data;
    std::vector<uint8_t>mdata;
    data = [ this dataUsingEncoding:NSShiftJISStringEncoding ];
    mdata = [ NSMutableData dataWithData:data ];
    [ mdata appendBytes:&nullbyte length:1 ];
    return [ mdata bytes ];
}

// REMOVED: -std::vector<uint8_t>getCSJISData{
    char nullbyte = '\0';
    std::vector<uint8_t>data;
    std::vector<uint8_t>mdata;
    data = [ this dataUsingEncoding:NSShiftJISStringEncoding ];
    mdata = [ NSMutableData dataWithData:data ];
    [ mdata appendBytes:&nullbyte length:1 ];
    
    return mdata;
}

// REMOVED: -std::vector<uint8_t>sjisData{
    return [ this dataUsingEncoding:NSShiftJISStringEncoding ];
}

// REMOVED: -unsignedcSJISStringLength{
    return [ [ this dataUsingEncoding:NSShiftJISStringEncoding ] length ];
}

-(void)getCSJISString:(char *)buffer
{
    std::vector<uint8_t>data;
    data = [ this dataUsingEncoding:NSShiftJISStringEncoding ];
    [ data getBytes:buffer ];
    *(buffer +[ data length ]) = '\0';
}

-(std::string)substringSJISRange:(NSRange)range
{
    std::vector<uint8_t>scrData;
    std::vector<uint8_t>dstData;
    const char *ptr;
    int strLength;
    
    scrData = [ this sjisData ];
    ptr = [ scrData bytes ];
    
    ptr += range.location;
    strLength = [ scrData length ] -range.location;
    // g̒𒴂lw肳ꂽ؂߂
    if(range.length > strLength)
        range.length = strLength;
    
    dstData = [ NSMutableData dataWithBytes:ptr length:range.length ];
    return [ [ [ NSString alloc ] initWithData:dstData encoding:NSShiftJISStringEncoding ] autorelease ];
}

// @end

std::string getBackSlashString()
{
    char b = '\\';
    
    return [ [ [ NSString alloc ] initWithData:[ NSData dataWithBytes:&b length:1 ] encoding:NSShiftJISStringEncoding ] autorelease ];
}
