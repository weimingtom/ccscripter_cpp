/*
 *  spb.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "spb_qt.h"
#include <QImage>
#include <QByteArray>
#include <cstring>
#include <cstdint>

#define BPP 3

// Helper macros converted to inline functions
inline uint16_t swapBigShortToHost(uint16_t val) {
    return ((val & 0x00ff) << 8) | ((val & 0xff00) >> 8);
}

// Replaces: NSBitmapImageRep* TYGetSpbWithData(NSData* d, size_t encode_size, size_t decode_size)
QImage TYGetSpbWithData(const QByteArray& d, size_t encode_size, size_t decode_size)
{
    Q_UNUSED(decode_size);
    
    if (d.isEmpty()) {
        return QImage();
    }
    
    const uint8_t* data = reinterpret_cast<const uint8_t*>(d.constData());
    
    // Read width and height (big-endian)
    uint16_t width = swapBigShortToHost(*reinterpret_cast<const uint16_t*>(&data[0]));
    uint16_t height = swapBigShortToHost(*reinterpret_cast<const uint16_t*>(&data[2]));
    
    if (width == 0 || height == 0) {
        return QImage();
    }
    
    size_t data_size = width * height * BPP;
    QByteArray dataBmp(static_cast<int>(data_size), 0);
    uint8_t* destBmp = reinterpret_cast<uint8_t*>(dataBmp.data());
    
    size_t tmp_data_size = width * height;
    QByteArray tmpData(static_cast<int>(tmp_data_size + 4), 0);
    uint8_t* tmp_data = reinterpret_cast<uint8_t*>(tmpData.data());
    
    const uint8_t* src = &data[4];
    uint8_t* dest = tmp_data;
    
    uint32_t bits = 0;
    int remain_bit = 0;
    
    // Process RGB channels (interleaved format)
    for (int rgb = 2; rgb >= 0; rgb--) {
        dest = tmp_data;
        
        // Get first byte
        if (remain_bit < 8) {
            if (src >= data + encode_size) {
                break;
            }
            bits = (bits << 8) | *src++;
            remain_bit += 8;
        }
        int ch = (bits >> remain_bit) & 0xFF;
        remain_bit -= 8;
        *dest++ = static_cast<uint8_t>(ch);
        
        while (dest < tmp_data + tmp_data_size) {
            // Get 3 bits
            if (remain_bit < 3) {
                if (src >= data + encode_size) {
                    break;
                }
                bits = (bits << 8) | *src++;
                remain_bit += 8;
            }
            int nbit = (bits >> remain_bit) & 0x07;
            remain_bit -= 3;
            
            if (nbit == 0) {
                *dest++ = static_cast<uint8_t>(ch);
                *dest++ = static_cast<uint8_t>(ch);
                *dest++ = static_cast<uint8_t>(ch);
                *dest++ = static_cast<uint8_t>(ch);
                continue;
            }
            
            int mask;
            if (nbit == 7) {
                // Get 1 more bit
                if (remain_bit < 1) {
                    if (src >= data + encode_size) {
                        break;
                    }
                    bits = (bits << 8) | *src++;
                    remain_bit += 8;
                }
                mask = ((bits >> remain_bit) & 0x01) + 1;
                remain_bit -= 1;
            } else {
                mask = nbit + 2;
            }
            
            for (int i = 0; i < 4; i++) {
                int t;
                if (mask == 8) {
                    // Get 8 bits directly
                    if (remain_bit < 8) {
                        if (src >= data + encode_size) {
                            break;
                        }
                        bits = (bits << 8) | *src++;
                        remain_bit += 8;
                    }
                    ch = (bits >> remain_bit) & 0xFF;
                    remain_bit -= 8;
                } else {
                    // Get N bits
                    if (remain_bit < mask) {
                        if (src >= data + encode_size) {
                            break;
                        }
                        bits = (bits << 8) | *src++;
                        remain_bit += 8;
                    }
                    t = (bits >> remain_bit) & ((1 << mask) - 1);
                    remain_bit -= mask;
                    
                    if (t & 1) {
                        ch += (t >> 1) + 1;
                    } else {
                        ch -= (t >> 1);
                    }
                }
                *dest++ = static_cast<uint8_t>(ch);
            }
        }
        
        // Deinterleave and copy to destination
        uint8_t* p = tmp_data;
        uint8_t* q = destBmp + rgb;
        
        for (int j = 0; j < height / 2; j++) {
            for (int i = 0; i < width; i++) {
                *q = *p++;
                q += 3;
            }
            q += width * 3;  // Skip every other line (weave to interlace conversion)
            for (int i = 0; i < width; i++) {
                q -= 3;
                *q = *p++;
            }
            q += width * 3;
        }
        
        if (height & 1) {
            for (int i = 0; i < width; i++) {
                *q = *p++;
                q += 3;
            }
        }
    }
    
    // Create QImage from RGB data
    QImage result(width, height, QImage::Format_RGB888);
    std::memcpy(result.bits(), destBmp, data_size);
    
    return result;
}