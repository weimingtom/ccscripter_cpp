/*
 *  TYEnviroment.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYEnviroment_qt.h"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QSettings>
#include <QDebug>

// Static member initialization
TYEnviroment* TYEnviroment::s_instance = nullptr;

// Environment key constants
namespace TYEnvKeys {
    const QString FontName = QStringLiteral("FontName");
    const QString AudioFilePath = QStringLiteral("AudioFilePath");
    const QString WindowPointX = QStringLiteral("WindowPointX");
    const QString WindowPointY = QStringLiteral("WindowPointY");
    const QString BGMVolume = QStringLiteral("BGMVolume");
    const QString VoiceVolume = QStringLiteral("VoiceVolume");
    const QString SEVolume = QStringLiteral("SEVolume");
    const QString ScaleInFullScreenMode = QStringLiteral("ScaleInFullScreenMode");
    const QString EnableBoldFont = QStringLiteral("EnableBoldFont");
    const QString FullScreenMode = QStringLiteral("FullScreenMode");
    const QString WaveExtraName = QStringLiteral("WaveExtraName");
    const QString DisableSelectScript = QStringLiteral("DisableSelectScript");
    const QString LookbackBufferPage = QStringLiteral("LookbackBufferPage");
    const QString LookbackVoiceReplay = QStringLiteral("LookbackVoiceReplay");
    const QString DisplayResizeAtFullScreen = QStringLiteral("DisplayResizeAtFullScreen");
    const QString AutomodeWaitType = QStringLiteral("AutomodeWaitType");
    const QString AutomodeWaitTime = QStringLiteral("AutomodeWaitTime");
    const QString Kidokumode = QStringLiteral("Kidokumode");
    const QString EnablePlayMovie = QStringLiteral("EnablePlayMovie");
    const QString HideOtherFullScreen = QStringLiteral("HideOtherFullScreen");
    const QString LastSelectedFolderPref = QStringLiteral("LastSelectedFolderPref");
}

TYEnviroment::TYEnviroment(QObject* parent)
    : QObject(parent)
{
    // Initialize defaults
    m_defaults.insert(TYEnvKeys::BGMVolume, QVariant(256));
    m_defaults.insert(TYEnvKeys::VoiceVolume, QVariant(256));
    m_defaults.insert(TYEnvKeys::SEVolume, QVariant(256));
    m_defaults.insert(TYEnvKeys::ScaleInFullScreenMode, QVariant(true));
    m_defaults.insert(TYEnvKeys::EnableBoldFont, QVariant(false));
    m_defaults.insert(TYEnvKeys::FullScreenMode, QVariant(false));
    m_defaults.insert(TYEnvKeys::LookbackBufferPage, QVariant(5));
    m_defaults.insert(TYEnvKeys::LookbackVoiceReplay, QVariant(true));
    m_defaults.insert(TYEnvKeys::DisplayResizeAtFullScreen, QVariant(false));
    m_defaults.insert(TYEnvKeys::AutomodeWaitType, QVariant(0));
    m_defaults.insert(TYEnvKeys::AutomodeWaitTime, QVariant(2000));
    m_defaults.insert(TYEnvKeys::Kidokumode, QVariant(false));
    m_defaults.insert(TYEnvKeys::EnablePlayMovie, QVariant(true));
    m_defaults.insert(TYEnvKeys::HideOtherFullScreen, QVariant(true));
    
    load();
}

TYEnviroment* TYEnviroment::instance()
{
    if (!s_instance) {
        s_instance = new TYEnviroment();
    }
    return s_instance;
}

void TYEnviroment::load()
{
    // Load from QSettings
    QSettings settings(QCoreApplication::organizationName(),
                      QCoreApplication::applicationName());
    
    m_data.clear();
    for (const QString& key : settings.allKeys()) {
        m_data.insert(key, settings.value(key));
    }
}

void TYEnviroment::reload()
{
    load();
}

// Replaces: +(id)objectForKey:(id)aObj
QVariant TYEnviroment::objectForKey(const QString& key)
{
    return instance()->m_data.value(key, 
        instance()->m_defaults.value(key, QVariant()));
}

// Replaces: +(id)defaultObjectForKey:(id)aObj
QVariant TYEnviroment::defaultObjectForKey(const QString& key)
{
    return instance()->m_defaults.value(key, QVariant());
}

// Replaces: +(void)setObject:(id)aObj forKey:(id)aKey
void TYEnviroment::setObject(const QVariant& value, const QString& key)
{
    instance()->m_data.insert(key, value);
}

// Replaces: +(void)save
void TYEnviroment::save()
{
    instance()->saveToFile();
}

void TYEnviroment::saveToFile()
{
    QSettings settings(QCoreApplication::organizationName(),
                      QCoreApplication::applicationName());
    
    for (auto it = m_data.constBegin(); it != m_data.constEnd(); ++it) {
        settings.setValue(it.key(), it.value());
    }
    settings.sync();
}

// Replaces: +(float)floatForKey:(id)aObj
float TYEnviroment::floatForKey(const QString& key)
{
    return objectForKey(key).toFloat();
}

// Replaces: +(BOOL)boolForKey:(id)aKey
bool TYEnviroment::boolForKey(const QString& key)
{
    return objectForKey(key).toBool();
}