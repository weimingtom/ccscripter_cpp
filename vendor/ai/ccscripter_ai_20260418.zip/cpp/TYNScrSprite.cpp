// Converted from TYNScrSprite.m
// TODO: Manual review and fixes required

//
//  TYNScrSprite.m
//  Tukuyomi
//
//  Created by toveta on Fri Oct 19 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYNScrSprite.h"
#include "TYStageManager.h"
#include "StopNSLog.h"

std::string const TYSpriteAnimationNotification=@"TYSpriteAnimationNotification";

// @implementation TYNScrSprite

/*
+(void*)dummySprite:(int)idNo // Arrayp̃_~[
{
    return [ [ [ [ this class ] alloc ] initWithID:idNo
                                        image:nullptr
                                        point:NSZeroPoint
                                        alpha:[ NSNumber numberWithInt:0 ]
                                        visible:false ] autorelease ];
}
*/

-(void*)initWithID:(int)idNo path:(std::string)aPath point:(NSPoint)point alpha:(NSNumber*)alphaNum visible:(bool)aBool;
{
    NSSize imageSize;

    this = [ super init ];

    spriteID = idNo;
    imagePath = [ aPath retain ];

    visible = aBool;
    [ this loadImageFromPath ];

    imageSize = (sourceImage) ? [ sourceImage size ] : NSZeroSize;

    drawPoint.x = point.x;
    drawPoint.y = VSCREEN_HEIGHT -imageSize.height -point.y;

    if(alphaNum)
        alpha = [ alphaNum intValue ];

    /*
    if(visible && sourceImage && [ (TYAnimationCellImage*)sourceImage isAnimate ]){
        [ (TYAnimationCellImage*)sourceImage play ];
        [ sourceImage setDelegate:this ];
    }
     */
    
    return this;
}
/*
-(void*)initWithID:(int)idNo image:(NSImage*)aImage point:(NSPoint)point alpha:(NSNumber*)alphaNum visible:(bool)aBool
{
    NSSize imageSize;
    NSSize vSize;

    this = [ super init ];
    
    spriteID = idNo;
    
    sourceImage = aImage;
    [ sourceImage retain ];
    
    // `n_Ä߂B
    imageSize = (aImage) ? [ aImage size ] : NSZeroSize;

    drawPoint.x = point.x;
    drawPoint.y = VSCREEN_HEIGHT -imageSize.height -point.y;
    
    alpha = [ alphaNum intValue ];
    
    visible = aBool;
    
    return this;
}
*/

-(void)moveX:(NSNumber*)x Y:(NSNumber*)y alpha:(NSNumber*)alphaNum
{
    //NSSize imageSize;
    
    drawPoint.x += [ x intValue ];
    drawPoint.y -= [ y intValue ]; // MacłYW]ĂB
    alpha += [ alphaNum intValue ];
    if(alpha < 0)
        alpha = 0;
    else if(alpha > SPRITE_ALPHA_MAX)
        alpha = SPRITE_ALPHA_MAX;
        
    //imageSize = [ sourceImage size ];
}

-(void)absoluteMoveX:(NSNumber*)x Y:(NSNumber*)y alpha:(NSNumber*)alphaNum
{
    drawPoint.x = [ x intValue ];
    drawPoint.y = VSCREEN_HEIGHT -[ sourceImage size ].height - [ y intValue ];
    if(alphaNum){
        alpha = [ alphaNum intValue ];
        if(alpha < 0)
            alpha = 0;
        else if(alpha > SPRITE_ALPHA_MAX)
            alpha = SPRITE_ALPHA_MAX;
    }
}

-(void)setVisible:(bool)aBool
{
    if(visible == aBool) {
        return;
    }
    
    visible = aBool;
    if(sourceImage && [ (TYAnimationCellImage*)sourceImage isAnimate ]){
        if(visible && ![ (TYAnimationCellImage*)sourceImage isPlaying ]){
            [ (TYAnimationCellImage*)sourceImage play ];
            [ sourceImage setDelegate:this ];
        } else if(!visible && [ (TYAnimationCellImage*)sourceImage isPlaying ]){
            [ (TYAnimationCellImage*)sourceImage stop ];
        }
    }    
}
// REMOVED: -boolvisible{ return visible; }

// REMOVED: -intspriteID{
    return spriteID;
}

-(void)draw // override
{    
    if(visible)
        [ super draw ];
}

// REMOVED: -voidloadImageFromPath{
    [ super loadImageFromPath ];

    // MEMO:G̃AjΉꍇ͂̃R[h̓X[p[NXɈڂB
    if(sourceImage && [ sourceImage isAnimate ] && visible){
        [ (TYAnimationCellImage*)sourceImage play ];
        [ sourceImage setDelegate:this ];
    }
}

/*
-(bool)isEqual:(void*)object // BASIC protocol
{
    if(![ [ this class ] isMemberOfClass:[ object class ] ]){
        return false;
    }
    
    return ([ this spriteID ] == [ object spriteID ]) ? true : false;
}
*/


// implementation of NSCoding
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [ super encodeWithCoder:aCoder ];
    
    [ aCoder encodeValueOfObjCType:"i" at:&spriteID ];
    [ aCoder encodeValueOfObjCType:@encode(bool) at:&visible ];
}

- (void*)initWithCoder:(NSCoder *)aDecoder
{
    [ super initWithCoder:aDecoder ];
    [ aDecoder decodeValueOfObjCType:"i" at:&spriteID ];
    [ aDecoder decodeValueOfObjCType:@encode(bool) at:&visible ];

    return this;
}

// REMOVED: -std::stringdescription{
    return [ NSString stringWithFormat:@"ID=%d,point=%@,alpha=%d",spriteID,NSStringFromPoint(drawPoint),alpha ];
}

-(void)didChangeCell:(void*)sender
{
    [ [ NSNotificationCenter defaultCenter ] postNotificationName:TYSpriteAnimationNotification object:this ];
}

// -dealloc (destructor in C++)
~ClassName() {
    // MEMO:G̃AjΉꍇ͂̃R[h̓X[p[NXɈڂB
    if(sourceImage && [ sourceImage isAnimate ] && [ (TYAnimationCellImage*)sourceImage isPlaying ]){
        [ (TYAnimationCellImage*)sourceImage stop ];
    }
    [super dealloc];
}

// @end
