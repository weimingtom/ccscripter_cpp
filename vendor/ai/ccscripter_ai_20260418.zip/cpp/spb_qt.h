/*
 *  spb.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  SPB image decompression (NScripter's proprietary image format).
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSData*           -> QByteArray
 *  NSBitmapImageRep* -> QImage
 */

#ifndef SPB_QT_H
#define SPB_QT_H

#include <QImage>
#include <QByteArray>
#include <cstddef>

// SPB decompression function
// Replaces: NSBitmapImageRep* TYGetSpbWithData(NSData* d, size_t encode_size, size_t decode_size)
QImage TYGetSpbWithData(const QByteArray& data, size_t encode_size, size_t decode_size);

#endif // SPB_QT_H