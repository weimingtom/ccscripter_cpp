/*
 *  TYArchiver.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSString*          -> QString
 *  NSFileHandle*      -> QFile*
 *  NSData*            -> QByteArray
 *  [path pathExtension] -> QFileInfo(path).suffix()
 *  [str compare:@"sar" options:NSCaseInsensitiveSearch] -> str.toLower() == "sar"
 *  [ [ super init ] autorelease ] -> constructor calling parent
 *  + (id)archiverWithContentsOfFile: -> static factory method
 */

#ifndef TYARCHIVER_QT_H
#define TYARCHIVER_QT_H

#include <QObject>
#include <QString>
#include <QFile>
#include <QByteArray>
#include <QFileInfo>
#include <QDebug>

// Forward declarations
class TYSarArchiver;
class TYNsaArchiver;

class TYArchiver : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)archiverWithContentsOfFile:(NSString*)path
    static TYArchiver* archiverWithContentsOfFile(const QString& path);
    
    // Replaces: -(id)initWithContentsOfFile:(NSString*)path
    explicit TYArchiver(const QString& path, QObject* parent = nullptr);
    ~TYArchiver();
    
    // Replaces: -(NSFileHandle*)fileHandleWithPath:(NSString*)aPath length:(int*)length
    QFile* fileHandleWithPath(const QString& aPath, qint64* length);
    
    // Replaces: -(NSData*)unArchivedFile:(NSString*)address
    QByteArray unArchivedFile(const QString& address);
    
protected:
    // Helper to get file extension
    QString getFileExtension() const { return QFileInfo(m_path).suffix().toLower(); }
    
private:
    QString m_path;  // Replaces: implicit ivar
};

#endif // TYARCHIVER_QT_H