/*
 *  TYScrollEffectGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Scroll transition effect generator.
 */

#ifndef TYSCROLLEFFECTGENERATER_QT_H
#define TYSCROLLEFFECTGENERATER_QT_H

#include <QObject>
#include <QImage>
#include <QTimer>
#include <QDateTime>
#include "TYEffecter_qt.h"

class TYScrollEffectGenerater : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithBeforeImage:afterImage:effect:
    TYScrollEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                            TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    ~TYScrollEffectGenerater();
    
    QImage currentImage() const { return m_currentImage; }
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
public slots:
    void drawEffect();
    
private:
    QImage m_beforeImage;
    QImage m_afterImage;
    QImage m_unionImage;
    QImage m_currentImage;
    QDateTime m_startDate;
    bool m_horizontal;
    bool m_reverse;
    int m_phaseMax;
    int m_effectTime;
    double m_phaseInterval;
    bool m_isComplete;
};

#endif // TYSCROLLEFFECTGENERATER_QT_H