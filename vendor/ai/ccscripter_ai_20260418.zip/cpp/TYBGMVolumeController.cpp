// Converted from TYBGMVolumeController.m
// TODO: Manual review and fixes required

#include "TYBGMVolumeController.h"

// @implementation TYBGMVolumeController

- (IBAction)changeBGMVolume:(void*)sender
{
    [ delegate changeBGMVolume:sender ];
}

- (IBAction)dialogOK:(void*)sender
{
    [ [ sender window ] orderOut:this ];
    [[NSApplication sharedApplication] stopModalWithCode:NSOKButton ];
}

-(void*)initWithBGMVolume:(float)volume
{
    [ super init ];
    [ NSBundle loadNibNamed:@"BGMVolume" owner:this ];
    [ BGMSlider setFloatValue:volume ];
    return this;
}

-(void)setDelegate:(void*)aObj
{
    delegate = aObj;
}

// REMOVED: -voidshowDialog{
    [[NSApplication sharedApplication] runModalForWindow:[ BGMSlider window ] ];
}

-(void)setBGMVolume:(float)volume
{
    [ BGMSlider setFloatValue:volume ];
}

// @end
