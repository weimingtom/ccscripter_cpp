/*
 *  main_qt.cpp
 *  Test Qt version of lzss decompression
 */

#include <QCoreApplication>
#include <QFile>
#include <QByteArray>
#include <QDebug>
#include "lzss_qt.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    
    // Example usage:
    // QFile file("compressed.dat");
    // if (file.open(QIODevice::ReadOnly)) {
    //     QByteArray decompressed = TYDataWithLzssDecodeFromFile(file, encodedSize, originalSize);
    //     file.close();
    // }
    
    qDebug() << "LZSS Qt version compiled successfully!";
    
    return 0;  // a.exec(); // For console app, return 0
}