// Converted from TYEffecter.m
// TODO: Manual review and fixes required

//
//  TYEffecter.m
//  Tukuyomi
//
//  Created by toveta on Mon Jun 18 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYEffecter.h"


// @implementation TYEffecter
+(void*)effecter
{
    return [ [ [ [ this class ] alloc ] init ] autorelease ];
}

// REMOVED: -void*init{
    this = [ super init ];
    
    // 0ԂLbV̂݁APԁA-2(windoweffect)uԕ\ŗ\񂵂Ă
    ty_effectDict = [ [ NSMutableDictionary alloc ] initWithObjectsAndKeys:
                        [ TYEffectRegister effectRegisterType:TYEffectInstant time:0 path:nullptr ],
                        [ NSNumber numberWithInt:-2 ],
                        [ TYEffectRegister effectRegisterType:TYEffectCached time:0 path:nullptr ],
                        [ NSNumber numberWithInt:0 ],
                        [ TYEffectRegister effectRegisterType:TYEffectInstant time:0 path:nullptr ],
                        [ NSNumber numberWithInt:1 ],
                        nullptr ];
        
    return this;
}

-(void)setBeforeImage:(NSImage*)aImage
{
    if(beforeImage)
        [ beforeImage autorelease ];
    beforeImage = [ aImage copy ];
}
// REMOVED: -NSImage*beforeImage{
    return beforeImage;
}

-(void)setEffectNo:(int)effectNo type:(int)effectType time:(int)time path:(std::string)path
{
    TYEffectRegister *tmp;
    
    // `FbN͂߂ǂ̂ŏȗ
    
    tmp = [ TYEffectRegister effectRegisterType:effectType time:time path:path ];

    if(!tmp){
        return ;
    }
    
    [ ty_effectDict setObject:tmp forKey:[ NSNumber numberWithInt:effectNo ] ];
    
    return ;
}

-(bool)startEffect:(NSImage*)newImage effectNo:(int)effectNo
{
    TYEffectRegister *reg;
    int type;
    bool endFlg;
    
    reg = [ ty_effectDict objectForKey:[ NSNumber numberWithInt:effectNo ] ];

    type = [ reg getType ];

    // ItXN[XV݂̂Ȃ疳ďI
    if(type == TYEffectCached){
        return true;
    }

    [ afterImage autorelease ];
    afterImage = [ newImage copyWithZone:NULL ];
    //[ afterImage retain ];

    
    switch(type){
    case TYEffectInstant:
        [ beforeImage autorelease ];
        beforeImage = afterImage;
        [ beforeImage retain ];
        if(nowImage)
            [ nowImage autorelease ];
        nowImage = beforeImage;
        [ nowImage retain ];
        endFlg = true;
        break;
    default:
        // obt@̈̊m
        if(nowImage)
            [ nowImage autorelease ];
        nowImage = [ beforeImage copyWithZone:[ beforeImage zone ] ];
        // ݎ擾
        if(startDate)
            [ startDate autorelease ];
        startDate =  [ [ NSDate date ] retain ];
        
        // is󋵂̏
        beforeParsentage = 0;
        
        nowEffect = reg;
        endFlg = false;
    }
    
    return endFlg;
}

-(bool)getEffectionImage:(NSImage**)drawImage
{
    NSTimeInterval parsentage;

    // ڂ̊擾
    parsentage = [ startDate timeIntervalSinceNow ] * -1 / ( [ nowEffect getTime ] / 1000.0 );
    
    if(parsentage >= 1 ){
        *drawImage = afterImage;
        [ beforeImage autorelease ];
        beforeImage = afterImage;
        [ beforeImage retain ];

        return true;
    }
    
    [ nowImage lockFocus ];
    
    // GtFNgʂ̍쐬
    switch([ nowEffect getType ]){
    case TYEffectCrossFadeWithPixel:
    default:
        //[ beforeImage compositeToPoint:NSZeroPoint operation:NSCompositeCopy ];
        [ afterImage dissolveToPoint:NSZeroPoint fraction:(parsentage -beforeParsentage)];
        break;
    }
    
    [ nowImage unlockFocus ];
    
    beforeParsentage = parsentage;
    *drawImage = nowImage;
    
    return false;
}


// REMOVED: -std::stringdescription{
    return [ ty_effectDict description ];
}

// -dealloc (destructor in C++)
~ClassName() {
    [ ty_effectDict release ];
    
    [ super dealloc ];
}
// @end

// ȉAGtFNgf[^IuWFNg̎
// @implementation TYEffectRegister
+(void*)effectRegisterType:(int)type time:(int)time path:(std::string)path
{
    return [ [ [ [ this class ] alloc ] initWithType:type time:time path:path ] autorelease ];
}

-(void*)initWithType:(int)type time:(int)time path:(std::string)path
{
    this = [ super init ];
    
    ty_effectType = type;
    ty_time = time;
    if(path)
        ty_path = [ [ NSString stringWithString:path ] retain ];
    
    return this;
}

// REMOVED: -intgetType{
    return ty_effectType;
}

// REMOVED: -intgetTime{
    return ty_time; 
}

// REMOVED: -std::stringgetPath{
    return ty_path;
}

// REMOVED: -std::stringdescription{
    return [ NSString stringWithFormat:@"type:%d time:%d path:%@",ty_effectType,ty_time,ty_path ];
}

// -dealloc (destructor in C++)
~ClassName() {
    [ ty_path release ];
    [ super dealloc ];
}
// @end

// @implementation TYEffectDefinitionValue
+(void*)valueWithEffectDefinition:(TYEffectDefinition)aDefinition
{
    return [ [ [ [ this class ] alloc ] initWithEffectDefinition:aDefinition ] autorelease ];
}

-(void*)initWithEffectDefinition:(TYEffectDefinition)aDefinition
{
    this = [ super init ];

    if(aDefinition.path)
        [ aDefinition.path retain ];
    
    value = [ [ NSValue alloc ] initWithBytes:&aDefinition objCType:@encode(TYEffectDefinition) ];

    return this;
}

- (void)getValue:(void *)buffer
{
    [ value getValue:buffer ];
}

// -dealloc (destructor in C++)
~ClassName() {
    TYEffectDefinition aDefinition;
    
    [ value getValue:&aDefinition ];
    
    if(aDefinition.path)
        [ aDefinition.path release];
        
    [ value release ];
    
    [super dealloc];
}

// @end