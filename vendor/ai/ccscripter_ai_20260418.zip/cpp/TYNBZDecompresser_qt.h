/*
 *  TYNBZDecompresser.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  NBZ (bzip2) decompression implementation.
 */

#ifndef TYNBZDECOMPRESSER_QT_H
#define TYNBZDECOMPRESSER_QT_H

#include "TYDecompresser_qt.h"
#include <QByteArray>

class TYNBZDecompresser : public TYDecompresser, public TYDataDecoder, public TYBitmapDecoder
{
    Q_OBJECT
    
public:
    // Replaces: +(id)sharedObject
    static TYNBZDecompresser* sharedInstance();
    
    // TYDataDecoder implementation
    QByteArray decodeData(QFile& handle, int encodeSize) override;
    
    // TYBitmapDecoder implementation
    QImage decodeBitmap(QFile& handle, int encodeSize) override;
};

#endif // TYNBZDECOMPRESSER_QT_H