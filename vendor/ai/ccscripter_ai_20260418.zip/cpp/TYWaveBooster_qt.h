/*
 *  TYWaveBooster.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Adjusts volume of WAV audio data.
 */

#ifndef TYWAVEBOOSTER_QT_H
#define TYWAVEBOOSTER_QT_H

#include <QByteArray>

// Adjust volume of WAV data (supports 8-bit and 16-bit PCM)
// Replaces: extern NSData* TYWaveBoost(NSData*, int)
QByteArray TYWaveBoost(const QByteArray& sourceData, int volume);

#endif // TYWAVEBOOSTER_QT_H