/*
 *  TYCCScripterProxy.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Proxy interface for communicating with executable plugins.
 */

#ifndef TYCCSCRIPTERPROXY_QT_H
#define TYCCSCRIPTERPROXY_QT_H

#include <QObject>
#include <QString>

// Forward declaration (avoid UI dependency)
class QWindow;

// Proxy interface for executable plugins
class TYCCScripterProxy
{
public:
    virtual ~TYCCScripterProxy() = default;
    
    // Replaces: -(NSWindow*)mainWindow
    virtual QWindow* mainWindow() = 0;
    
    // Replaces: -(void)setRetunCode:(int)aInt string:(NSString*)aStr
    virtual void setReturnCode(int code, const QString& str) = 0;
    
    // Replaces: -(int)returnCode
    virtual int returnCode() const = 0;
    
    // Replaces: -(NSString*)returnString
    virtual QString returnString() const = 0;
};

#endif // TYCCSCRIPTERPROXY_QT_H