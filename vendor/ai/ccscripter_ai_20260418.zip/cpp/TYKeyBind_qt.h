/*
 *  TYKeyBind.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Keyboard key binding utilities.
 */

#ifndef TYKEYBIND_QT_H
#define TYKEYBIND_QT_H

#include <QString>
#include <QMap>

// Constants
#define KEYBIND_FILENAME "keybind.plist"

// Get selector for keycode
// Replaces: extern SEL TYSelectorForKeycode(unsigned short aCode)
QString TYSelectorForKeycode(unsigned short aCode);

#endif // TYKEYBIND_QT_H