/*
 *  TYFileLog.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYFileLog_qt.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <cstdio>
#include <cstring>

TYFileLog::TYFileLog(const QString& path, QObject* parent)
    : QObject(parent)
{
    loadFromFile(path);
}

TYFileLog::~TYFileLog()
{
    // QSet auto-cleans up
}

// Replaces: -(id)initWithContentsOfFile:(NSString*)path
void TYFileLog::loadFromFile(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return;
    }
    
    QTextStream in(&file);
    in.setCodec("Shift-JIS");
    
    // Read file count
    bool ok;
    int fileNum = in.readLine().toInt(&ok);
    if (!ok) {
        file.close();
        return;
    }
    
    // Read file entries
    for (int i = 0; i < fileNum; ++i) {
        QString line = in.readLine();
        if (line.isEmpty()) {
            break;
        }
        
        // XOR decode with mask 132 (0x84)
        QByteArray data = line.toLatin1();
        for (int j = 0; j < data.size(); ++j) {
            data[j] = data[j] ^ 0x84;
        }
        
        QString filename = QString::fromLatin1(data);
        m_logSet.insert(filename.toUpper());
    }
    
    file.close();
}

// Replaces: -(BOOL)writeToFile:(NSString*)path
bool TYFileLog::writeToFile(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }
    
    QTextStream out(&file);
    out.setCodec("Shift-JIS");
    
    // Write file count
    out << QString::number(m_logSet.size()) << "\n";
    
    // Write each filename with XOR encoding
    for (const QString& filename : m_logSet) {
        QByteArray data = filename.toLatin1();
        for (int i = 0; i < data.size(); ++i) {
            data[i] = data[i] ^ 0x84;
        }
        out << QString::fromLatin1(data) << "\n";
    }
    
    file.close();
    return true;
}

// Replaces: -(void)addTYFileLog:(TYFileLog*)margeLog
void TYFileLog::addFileLog(TYFileLog* margeLog)
{
    if (margeLog) {
        m_logSet.unite(margeLog->logs());
    }
}

// Replaces: -(void)addLog:(NSString*)filename
void TYFileLog::addLog(const QString& filename)
{
    m_logSet.insert(filename.toUpper());
}

// Replaces: -(BOOL)isRead:(NSString*)filename
bool TYFileLog::isRead(const QString& filename) const
{
    return m_logSet.contains(filename.toUpper());
}