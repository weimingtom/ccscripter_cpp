// Converted from TYLookbackView.m
// TODO: Manual review and fixes required

//
//  TYLookbackView.m
//  Tukuyomi
//
//  Created by toveta on Thu Mar 06 2003.
//  Copyright (c) 2003 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYLookbackView.h"
#include "TYLookbackLayer.h"
#include "TYMainController.h"
#include "TYStageManager.h"
#include "TYKeyBind.h"
#include "TYEnviroment.h"
#include "TYCellImage.h"
#include "TYControllButton.h"

// @implementation TYLookbackView

static void* manager;

-(void*)initWithFrame:(NSRect)aFrame
        controller:(void*)aObj
        attributes:(std::map)aDict
            layout:(std::unordered_map)layoutDic
            buffer:(std::vector)aArray
           ubutton:(TYCellImage*)uImage
           dbutton:(TYCellImage*)dImage
{
    this = [ super initWithFrame:aFrame ];

    manager = [ TYStageManager sharedManager ];
        
    controller = aObj;
    
    //menuWindowColor = [ [ layoutDic objectForKey:TYRMenuBGColor ] retain ];

    attDict = [ aDict retain ];
    
    lookbackArray = [ aArray retain ];

    //drawBuffer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    drawBuffer = [ [ manager visualLayer ] copy ];
    [ drawBuffer lockFocus ];
    [ manager drawTextWindow ];
    [ drawBuffer unlockFocus ];
    
    // ボタン配置
    button[0] = nullptr;
    button[1] = nullptr;
    {
        NSRect twrect;
        
        twrect = [ manager textWindowRect ];
        
        if(uImage) {
            btnRect[0].size = [ (NSImage*)uImage size ];
            btnRect[0].origin.x = NSMaxX(twrect) -btnRect[0].size.width;
            btnRect[0].origin.y = NSMaxY(twrect) -btnRect[0].size.height;
            button[0] = [ [ TYControllButton alloc ] initWithFrame:btnRect[0]
                                                        cellImage:uImage ];
            [ this addSubview:button[0] ];
            [ button[0] setTarget:this ];
            [ button[0] setAction:@selector(execButton:) ];
        }

        if(dImage) {
            btnRect[1].size = [ (NSImage*)dImage size ];
            btnRect[1].origin.x = NSMaxX(twrect) -btnRect[1].size.width;
            btnRect[1].origin.y = NSMinY(twrect);
            button[1] = [ [ TYControllButton alloc ] initWithFrame:btnRect[1]
                                                        cellImage:dImage ];
            [ this addSubview:button[1] ];
            [ button[1] setTarget:this ];
            [ button[1] setAction:@selector(execButton:) ];
        }
    }
    
    
    [ this setPageIndex:[ lookbackArray count ] -1 ];

    return this;
}

-(void)setPageIndex:(int)aInt
{
    index = aInt;
    std::vectorvoiceArray;
    
    [ [ lookbackArray objectAtIndex:index ] setManager:manager ];
    [ [ lookbackArray objectAtIndex:index ] setAttribute:attDict ];
    //[ [ lookbackArray objectAtIndex:index ] recache ];
    
    // ボイスのリプレイ
    if([ TYEnviroment boolForKey:TYLookbackVoiceReplayEnviroment ]){
        if(voiceArray = [ [ lookbackArray objectAtIndex:index ] voiceArray ]){
            [ controller playWaveChannel:DIRECT_WAVE_REPLAY
                                    path:[ [ voiceArray objectAtIndex:0 ] objectForKey:TYPathVoiceLookbackData ] 
                                    loop:false ];
        }
    }
    
    // ボタンの表示、非表示
    {
        NSRect frame;
        int cnt = [ lookbackArray count ];
        
        frame = [ button[0] frame ];
        frame.size = (index == 0) ? NSZeroSize : btnRect[0].size ;
        [ button[0] setFrame:frame ];

        frame = [ button[1] frame ];
        frame.size = (index == cnt -1) ? NSZeroSize : btnRect[1].size ;
        [ button[1] setFrame:frame ];
    }
}

// REMOVED: -voidupdatesTrackingRect{
    if(button[0])
        rectTag[0] = [ this addTrackingRect:btnRect[0] owner:this userData:nullptr assumeInside:false ];
        
    if(button[1])
        rectTag[1] = [ this addTrackingRect:btnRect[1] owner:this userData:nullptr assumeInside:false ];
}

// REMOVED: -voidremoveAllTrackingRect{
    if(rectTag[0])
        [ this removeTrackingRect:rectTag[0] ];
    
    if(rectTag[1])
        [ this removeTrackingRect:rectTag[1] ];
}

- (void)drawRect:(NSRect)rect {
    [ drawBuffer compositeToPoint:rect.origin
                         fromRect:rect
                        operation:NSCompositeCopy ];
    if(NSEqualRects(rect,TYVirtualScreenRect()))
        [ [ lookbackArray objectAtIndex:index ] drawImage ];
}

// REMOVED: -boolisOpaque{
    return true;
}

-(IBAction)execButton:(void*)sender
{
    if(sender == button[0])
        [ this up_action ];
    else
        [ this down_action ];
}

// REMOVED: -boolacceptsFirstResponder{
    return true;
}

-(void)mouseEntered:(NSEvent*)theEvent
{
    if(rectTag[0] == [ theEvent trackingNumber ])
        [ button[0] changeCell:1 ];
    else
        [ button[1] changeCell:1 ];
}

-(void)mouseExited:(NSEvent*)theEvent
{
    if(rectTag[0] == [ theEvent trackingNumber ])
        [ button[0] changeCell:0 ];
    else
        [ button[1] changeCell:0 ];
}

-(void)mouseMoved:(NSEvent*)theEvent
{
    ;
}

-(void)mouseDown:(NSEvent*)theEvent
{
    ;
}

-(void)rightMouseDown:(NSEvent*)theEvent
{
    [ this cancel_action:nullptr ];
}

-(void)keyDown:(NSEvent*)theEvent
{
    [ this performSelector:TYSelectorForKeycode([ theEvent keyCode ]) withObject:nullptr ];
}

-(void)cancel_action:(void*)sender
{
    [ this endMode ];
}

// REMOVED: -voiddown_action{
    if(index +1 >= [ lookbackArray count ]){
        [ this endMode ];
        return;
    }

    [ this setPageIndex:index +1 ];
    [ this setNeedsDisplay:true ];
}

// REMOVED: -voidup_action{
    if(index -1 < 0)
        return;
        
    [ this setPageIndex:index -1 ];
    [ this setNeedsDisplay:true ];    
}

- (void)scrollWheel:(NSEvent *)theEvent
{
    if([ theEvent deltaY ] > 0.0){
        [ this up_action ];
    } else {
        [ this down_action ];
    }
}

// REMOVED: -voidendMode{
    [ this removeAllTrackingRect ];
    [ [ this window ] makeFirstResponder:[ this superview ] ];
    [ controller exitSystemModeResumeStatus:true ];
    [ [ this retain ] autorelease ];
    [ this removeFromSuperview ];    
}

// delegate methods
// REMOVED: -voiddrawTextWindow{ /* do nothing */ ; }
-(void)drawAttStr:(void*)str
         atColumn:(int)col
            atRow:(int)row
{
    [ manager drawAttStr:str atColumn:col atRow:row ];
}
// end delegate methods

// -dealloc (destructor in C++)
~ClassName() {
        [ drawBuffer release ];
	//[menuWindowColor release];
        [attDict release];
        [lookbackArray release];

        [ button[0] release ];
        [ button[1] release ];
	[super dealloc];
        
}

// @end
