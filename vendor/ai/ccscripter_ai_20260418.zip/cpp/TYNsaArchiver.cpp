// Converted from TYNsaArchiver.m
// TODO: Manual review and fixes required

//
//  TYNsaArchiver.m
//  Tukuyomi
//
//  Created by toveta on Sat Oct 13 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYNsaArchiver.h"
#include <unistd.h>
#include "lzss.h"
#include "spb.h"
//#include "TYBGLZSSDecorder.h"

static TYNsaFileMode NsaArchiverMode = TYNormalNsaFileMode;

// @implementation TYNsaArchiver

+(void)setMode:(TYNsaFileMode)aMode
{
    NsaArchiverMode = aMode;
}

-(void*)initWithContentsOfFile:(std::string)path
{
    NSFileHandle *handle;
    std::vector<uint8_t>readDatabuf; // ǂݍ݃obt@[
    unsigned char *readbufptr;
    char address[256];
    unsigned filenum;
    int i,j;
    NSAutoreleasePool *arp;
    unsigned fileCompress,fileOffset,fileLength,fileExLength;
    void* *objectArray,*objectArrayTop,*keyArray,*keyArrayTop;
    int fd;
    
    // const unsigned readLength = 256;
    
    this = [ super init ];

    arp = [ [ NSAutoreleasePool alloc ] init ];

    // t@Cǂݍ݃[hŃI[v
    handle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    if(!handle){
        return nullptr;
    }
    
    // t@C̓ǂݏo
    switch (NsaArchiverMode) {
    case TY2TypeNsaFileMode:
        [ handle readDataOfLength:1 ];
        break;
    case TY3TypeNsaFileMode:
        [ handle readDataOfLength:2 ];
        break;
    default:
        break;
    }
    readDatabuf = [ handle readDataOfLength:2 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    filenum = (readbufptr[0] << 8) + readbufptr[1];

    // t@C̃IuWFNgւ̃|C^i[̈m
    objectArrayTop = objectArray = malloc(sizeof(void*) *filenum);
    NSAssert((objectArray), @"malloc failed");
    keyArrayTop = keyArray = malloc(sizeof(void*) *filenum);
    NSAssert((keyArray), @"malloc failed");
    
    // f[^̎n_ItZbg̓ǂݏo
    readDatabuf = [ handle readDataOfLength:4 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    baseOffset = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];
    switch (NsaArchiverMode) {
    case TY2TypeNsaFileMode:
        baseOffset++;
        break;
    case TY3TypeNsaFileMode:
        baseOffset += 2;
        break;
    default:
        break;
    }
    fd = [ handle fileDescriptor ];
    
    // t@C̃CfbNX쐬
    for( i=0; i < filenum; i++){
        
        j = 0;
        while(1){
            /*
            readDatabuf = [ handle readDataOfLength:1 ]; // MEMO:[fBXNv^擾fgetc()RXgႢ悤ȁB
            readbufptr = (unsigned char *)[ readDatabuf bytes ];
             */
            read(fd,readbufptr,1);
            if(readbufptr[0]){
                // obNXbV͂̂ŃXbVɕς܂B
                if(readbufptr[0] == '\\') readbufptr[0] = '/';
                address[j] = readbufptr[0];
            } else {
                address[j] = '\0';
                // AhX當IuWFNg쐬AzɉB
                // MEMO:œ{̎gꂽA[JCuŎʉ\BNSDataŎׂB
                *keyArray=[ NSString stringWithCString:address ];
                keyArray++;
                
                // k^Cv̓ǂݏo
                readDatabuf = [ handle readDataOfLength:1 ];
                readbufptr = (unsigned char *)[ readDatabuf bytes ];
                fileCompress = *readbufptr;
                
                // _̃ItZbgǂݏo
                readDatabuf = [ handle readDataOfLength:4 ];
                readbufptr = (unsigned char *)[ readDatabuf bytes ];
                fileOffset = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];

                // t@C̃oCgǂݏo
                readDatabuf = [ handle readDataOfLength:4 ];
                readbufptr = (unsigned char *)[ readDatabuf bytes ];
                fileLength = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];
                
                // t@C̓WJoCgǂݏo
                readDatabuf = [ handle readDataOfLength:4 ];
                readbufptr = (unsigned char *)[ readDatabuf bytes ];
                fileExLength = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];
                
                
                // A[JCut@CIuWFNg쐬Azɉ
                *objectArray=[ TYNsaArchivedFile archivedFileoffset:fileOffset length:fileLength type:fileCompress exLength:fileExLength ];
                objectArray++;
                
                break;
            }
            j++;
        }
        
    }
    // o^
    filesDict = [ [ NSDictionary dictionaryWithObjects:objectArrayTop forKeys:keyArrayTop count:filenum ] retain ];
    free(objectArrayTop);
    free(keyArrayTop);

    // pXo^
    arcPath = path;
    [ arcPath retain ];
    
    // t@CN[Y
    [ handle closeFile ];

    [ arp release ];

    return this;
}

// A[JCut@C擾Ă܂B
-(void*)unArchivedFile:(std::string)address;
{
    TYNsaArchivedFile *tmp;
    unsigned fileOffset,fileLength;

    //NSLog(@"address[%@]\n@",address);
    //NSLog(@"%@\n",[ [ filesDict allKeys ] description ]);
    tmp = [ filesDict objectForKey:[ address lowercaseString ] ];

    if(!tmp){
        //NSLog(@"failed search for Archive!!\narichive[%@]\npath[%@]\n",arcPath,address);
        return nullptr;
    }
    [ tmp getFileDataOffset:&fileOffset length:&fileLength ];

    switch ([ tmp compressType ]){
        NSFileHandle *fh;
        case 0:
            // kĂȂf[^Ȃ炻̂܂ܕԂ
            return [ this readDataOffset:fileOffset length:fileLength ];
        case 1:
            return TYGetSpbWithData([ this readDataOffset:fileOffset length:fileLength ],
                                    fileLength,
                                    [ tmp expandedLength ]);
        case 2:
            fh=[ NSFileHandle fileHandleForReadingAtPath:arcPath ];
            [ fh seekToFileOffset:fileOffset +baseOffset];
            return TYDataWithLzssDecodeFromFile(fh,fileLength,[ tmp expandedLength ]);
            //return [ TYBGLZSSDecorder decodeWithFileHandle:fh encode_size:fileLength original_size:[ tmp expandedLength ] ];
    }

    /*
    if([ tmp compressType ] == 0){
        return [ this readDataOffset:fileOffset length:fileLength ]; // kĂȂf[^Ȃ炻̂܂ܕԂ
    }
    
    // compressType==2 lzss`
    if([ tmp compressType ] == 2){
        
    }
     */
    

    
    return nullptr;
}

// @end
