/*
 *  TYNsaArchivedFile.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  NSA archived file entry with compression info.
 */

#ifndef TYNSAARCHIVEDFILE_QT_H
#define TYNSAARCHIVEDFILE_QT_H

#include "TYSarArchivedFile_qt.h"
#include <QObject>

// Compression types
enum TYNsaCompressType {
    TYCompressNone = 0,
    TYCompressSPB = 1,
    TYCompressLZSS = 2
};

class TYNsaArchivedFile : public TYSarArchivedFile
{
    Q_OBJECT
    
public:
    // Factory method - replaces +(id)archivedFileoffset:...
    static TYNsaArchivedFile* create(unsigned offset, unsigned length, 
                                        unsigned char type, unsigned exLength);
    
    // Constructor
    TYNsaArchivedFile(unsigned offset, unsigned length, 
                      unsigned char type, unsigned exLength, QObject* parent = nullptr);
    
    // Accessors
    unsigned char compressType() const { return m_compressType; }
    unsigned expandedLength() const { return m_expandedLength; }
    
    // Check if compressed
    bool isCompressed() const { return m_compressType != TYCompressNone; }
    
private:
    unsigned char m_compressType;  // Compression type (0=none, 1=spb, 2=lzss)
    unsigned m_expandedLength;    // Original size before compression
};

#endif // TYNSAARCHIVEDFILE_QT_H