/*
 *  TYShutterEffectGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYShutterEffectGenerater_qt.h"
#include <QPainter>

const int PIXEL_OF_COLUMN = 16;

TYShutterEffectGenerater::TYShutterEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                                                   TYEffectDefinitionValue* effect, QObject* parent)
    : QObject(parent)
    , m_beforeImage(beforeImage)
    , m_afterImage(afterImage)
    , m_beforePhase(0)
    , m_isComplete(false)
{
    TYEffectDefinition effdef = effect->definition();
    
    // Determine shutter direction
    switch (effdef.type) {
    case TYEffectTopShutter:
        m_reverse = true;
        m_horizontal = false;
        break;
    case TYEffectRightShutter:
        m_reverse = true;
        m_horizontal = true;
        break;
    case TYEffectLeftShutter:
        m_reverse = false;
        m_horizontal = true;
        break;
    default:
        m_reverse = false;
        m_horizontal = false;
        break;
    }
    
    m_pixelOfColumn = PIXEL_OF_COLUMN;
    m_numberOfColumn = m_horizontal ? (m_beforeImage.width() / PIXEL_OF_COLUMN) 
                                     : (m_beforeImage.height() / PIXEL_OF_COLUMN);
    m_effectTime = effdef.time;
    m_phaseInterval = effdef.time / 1000.0 / PIXEL_OF_COLUMN;
    m_startDate = QDateTime::currentDateTime();
    m_currentImage = m_beforeImage;
    
    QTimer::singleShot(0, this, SLOT(drawEffect()));
}

TYShutterEffectGenerater::~TYShutterEffectGenerater()
{
}

void TYShutterEffectGenerater::drawEffect()
{
    qint64 elapsed = m_startDate.msecsTo(QDateTime::currentDateTime());
    int phase = (elapsed * PIXEL_OF_COLUMN) / m_effectTime;
    
    if (phase >= PIXEL_OF_COLUMN) {
        m_currentImage = m_afterImage;
        m_isComplete = true;
        emit effectImageChanged(m_currentImage);
        emit effectFinished();
        return;
    }
    
    int movePhase = phase - m_beforePhase;
    if (movePhase == 0) {
        QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
        return;
    }
    
    m_currentImage = m_beforeImage.copy();
    QPainter painter(&m_currentImage);
    
    int w, h, x, y, mx, my;
    if (m_horizontal) {
        w = movePhase;
        h = m_beforeImage.height();
        y = 0;
        my = 0;
        x = m_reverse ? (m_beforeImage.width() - m_beforePhase - w) : m_beforePhase;
        mx = m_reverse ? -PIXEL_OF_COLUMN : PIXEL_OF_COLUMN;
    } else {
        w = m_beforeImage.width();
        h = movePhase;
        x = 0;
        mx = 0;
        y = m_reverse ? (m_beforeImage.height() - m_beforePhase - h) : m_beforePhase;
        my = m_reverse ? -PIXEL_OF_COLUMN : PIXEL_OF_COLUMN;
    }
    
    for (int i = 0; i < m_numberOfColumn; i++, x += mx, y += my) {
        painter.drawImage(x, y, m_afterImage, x, y, w, h);
    }
    
    painter.end();
    m_beforePhase = phase;
    
    emit effectImageChanged(m_currentImage);
    
    QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
}