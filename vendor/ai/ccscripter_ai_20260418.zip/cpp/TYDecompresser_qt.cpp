/*
 *  TYDecompresser.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYDecompresser_qt.h"

TYDecompresser::TYDecompresser(QObject* parent)
    : QObject(parent)
{
}

TYDecompresser::~TYDecompresser()
{
}

// Replaces: +(id)sharedObject
// Uses Qt's q-pointer for singleton pattern
static TYDecompresser* s_sharedInstance = nullptr;

TYDecompresser* TYDecompresser::sharedInstance()
{
    if (!s_sharedInstance) {
        s_sharedInstance = new TYDecompresser();
    }
    return s_sharedInstance;
}