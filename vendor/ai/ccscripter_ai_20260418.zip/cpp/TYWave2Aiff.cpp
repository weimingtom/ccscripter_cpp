// Converted from TYWave2Aiff.m
// TODO: Manual review and fixes required

//
//  TYWave2Aiff.m
//  Tukuyomi
//
//  Created by toveta on Sun Aug 25 2002.
//  Copyright (c) 2002 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYWave2Aiff.h"
#include "TYMiscUtil.h"
#include "TYWaveDecorder.h"
#include "TYEnviroment.h"

#define AIFF_HEADER_SIZE 54

static const char SAMPLE_RATE_22050[] = { 0x40,0x0d,0xac,0x44,0x00,0x00,0x00,0x00,0x00,0x00 };
static const char SAMPLE_RATE_44100[] = { 0x40,0x0e,0xac,0x44,0x00,0x00,0x00,0x00,0x00,0x00 };

#define WAVE_FORMAT_PCM 1
static NSBundle *pluginBundle;

static bool loadExtra(void);

static std::string const OGG_DECODER_NAME = @"OggDecoder.bundle";

std::vector<uint8_t> TYWave2Aiff(std::vector<uint8_t> sourceData,int volume)
{
    std::vector<uint8_t> convData;
    const unsigned char *ptr;
    unsigned char *cnvptr;
    int bytesOfData;
    int dataSize,s;
    int channel,block_align,rate;
    bool extendData=false;
    int format,frame;
    int swapData=0;
    NSObject <TYWaveDecorder> *plugin = nullptr;

    if(!sourceData)
        return nullptr;
    
    ptr = [ sourceData bytes ];

    // RIFFwb_Oggwb_`FbN
    if (strncmp(ptr, "OggS", 4) == 0) {
        static bool loadOggDecoder = false;
        static Class oggDecoderClass = Nil;
        
        void*<TYWaveDecorder> decoder;
        
        if (loadOggDecoder == false) {
            NSBundle *bundle;
            bundle = [ [NSBundle bundleWithPath:
                [ getAppDirectory() stringByAppendingPathComponent:OGG_DECODER_NAME ] ] retain ];
            if((oggDecoderClass = [ bundle principalClass ])){
                if(![ oggDecoderClass conformsToProtocol:@protocol(TYWaveDecorder) ]){
                    NSLog(@"invalid plugin it isn't conformsProtocol");
                    oggDecoderClass = Nil;
                }
            } else {
                NSLog(@"can't load ogg plugin");
                oggDecoderClass = Nil;
            }
            NSLog(@"loading OggDecoder");
            loadOggDecoder = true;
        }
        
        if (oggDecoderClass == Nil) {
            return sourceData;
        }
        
        decoder = [ [ oggDecoderClass alloc ] initWithData:sourceData ];

        if ([ decoder getSamples:(short**)(&ptr)
                         frames:&frame
                       channels:&channel
                           rate:&rate ] == false) {
            return sourceData;
        }
        
        if(rate == 11025)
            extendData = true;
            
        dataSize = frame * 2 * channel * (extendData ? 2 : 1 );
        bytesOfData=2;
    } else {
        if(strncmp(ptr,"RIFF",4)==0) {
            NSCAssert((strncmp(ptr,"RIFF",4)==0),@"ileagal RIFF header");
            ptr+=8;
        
            // WAVEwb_`FbN
            NSCAssert((strncmp(ptr,"WAVE",4)==0),@"this data is not WAVE FILE");
            ptr+=4;
        
            // fmt`N
            ptr+=8;
            // tH[}bgID̃`FbN
            
            format = NSSwapLittleShortToHost(*(unsigned short *)ptr);
            ptr+=2;
        } else {
            NSCAssert((0),@"illegal file header(RIFF or ogg)");
            return nullptr;
        }
        switch (format) {
        case WAVE_FORMAT_PCM:
            // `l̎擾
            channel = NSSwapLittleShortToHost(*(unsigned short *)ptr);
            ptr+=2;
            
            // Tv[g̎擾
            rate = NSSwapLittleIntToHost(*(unsigned int *)ptr);
            if( (rate != 22050) && (rate != 44100) && (rate != 11025)){
                NSLog(@"not supported sampling rate(supported only 22.05Khz or 44.1Khz or 11.025Khz)");
                return sourceData;
            }
            if(rate == 11025)
                extendData = true;
            ptr+=8;
        
            // block align(1framẽoCg) ̎擾
            block_align = NSSwapLittleShortToHost(*(unsigned short *)ptr);
            ptr+=2;
            
            // bitTCY擾
            bytesOfData=NSSwapLittleShortToHost(*(unsigned short *)ptr) / 8;
            if(bytesOfData == 1)
                block_align *= 2;
            ptr +=2;
        
            // datawb_`FbN(wb_gTCYfact`NΔ΂)
            if(strncmp(ptr,"data",4)==0){
                ptr+=4;
            } else if(strncmp(ptr,"fact",4)==0){
                ptr+=16;
            } else {
                // jAPCM̃wb_g̓wb_gTCYɂ炸0?
                ptr+=2;
                //ptr+=NSSwapLittleShortToHost(*(unsigned short *)ptr) +2;
                if(strncmp(ptr,"data",4)==0){
                    ptr+=4;
                } else if(strncmp(ptr,"fact",4)==0){
                    ptr+=16;
                } else {
                    NSLog(@"this wave data have extra header size, and can't find data or fact chunk.");
                    return sourceData;
                }
            }
            
            // dataTCY擾AϊB8bit11.025KhzȂ炻ꂼ2{
            dataSize=NSSwapLittleIntToHost(*(unsigned int *)ptr);
            dataSize *= (extendData ? 2 : 1 ) * ((bytesOfData == 1) ? 2 : 1);
            ptr +=4;
    
            frame = dataSize / block_align;
            swapData=1;
            
            break;
        default:
            {
                Class class;
                
                if(!loadExtra())
                    return sourceData;
    
                class = [ pluginBundle principalClass ];
                plugin = [ class alloc ];
                plugin = [ plugin initWithData:sourceData ];
                //plugin = [ plugin autorelease ];
                
                if(![ plugin getSamples:(short**)(&ptr)
                            frames:&frame
                        channels:&channel
                            rate:&rate ])
                    return sourceData;
                
                if(rate == 11025)
                    extendData = true;
                    
                dataSize = frame * 2 * channel * (extendData ? 2 : 1 );
                bytesOfData=2;
            }
        }
    }


    // AIFFf[^̃wb_쐬
    convData = [ NSMutableData dataWithLength:dataSize +AIFF_HEADER_SIZE ];
    cnvptr = [ convData mutableBytes ];
    memcpy(cnvptr,"FORM",4); cnvptr+=4;
    *(unsigned int*)cnvptr=NSSwapHostIntToBig(dataSize +AIFF_HEADER_SIZE -8); cnvptr+=4;
    memcpy(cnvptr,"AIFF",4); cnvptr+=4;
    memcpy(cnvptr,"COMM",4); cnvptr+=4;
    *(unsigned int*)cnvptr=NSSwapHostIntToBig(18); cnvptr+=4;    
    *(unsigned short*)cnvptr=NSSwapHostShortToBig(channel); cnvptr+=2;
    *(unsigned int*)cnvptr=NSSwapHostIntToBig(frame); cnvptr+=4;
    *(unsigned short*)cnvptr=NSSwapHostShortToBig(16); cnvptr+=2; // bits of sample
    memcpy(cnvptr,((rate==44100) ? SAMPLE_RATE_44100 : SAMPLE_RATE_22050),10); cnvptr+=10;
    memcpy(cnvptr,"SSND",4); cnvptr+=4;
    *(unsigned int*)cnvptr=NSSwapHostIntToBig(dataSize + 8); cnvptr+=4;
    memset(cnvptr,'\0',4); cnvptr+=4;
    memset(cnvptr,'\0',4); cnvptr+=4;    

    // f[^Ɋi[(łɃH[̕ϊ)
    if(!extendData){
        // 22.05Khz or 44.1Khz
        if(bytesOfData==1){
            for(s=0; s < dataSize; s+=2,ptr++,cnvptr+=2){
                *(short*)cnvptr = NSSwapHostShortToBig((*ptr -128) *volume);
            }
        } else {
            if(dataSize % 2){
                NSLog(@"ileagal data size wave data");
                return sourceData;
            }

            if(swapData){
                for(s=0; s < dataSize; s+=2,ptr+=2,cnvptr+=2){
                    *(short*)cnvptr = ((short)NSSwapShort(*(unsigned short *)ptr)) *volume /256;
                }
            } else {
                for(s=0; s < dataSize; s+=2,ptr+=2,cnvptr+=2){
                    *(short*)cnvptr = (*(short *)ptr) *volume /256;
                }
            }
        }
    } else {
        // 11.025Khz
        if(bytesOfData==1){
            // 8bit
            if(channel==1){
                // mono
                if(dataSize == 0){
                    NSLog(@"ileagal data size wave data");
                    return sourceData;
                }
                *(short*)cnvptr = NSSwapHostShortToBig((*ptr -128) *volume);
                ptr++; cnvptr+=4;                
                for(s=4; s < dataSize; s+=4,ptr++,cnvptr+=4){
                    *(short*)cnvptr = NSSwapHostShortToBig((*ptr -128) *volume);
                    *(((short*)cnvptr)-1) = *(short*)cnvptr -(*(short*)cnvptr -*(((short*)cnvptr)-2)) / 2;
                }
            } else {
                // stereo
                if(dataSize % 2){
                    NSLog(@"ileagal data size wave data");
                    return sourceData;
                }
            
                *(short*)cnvptr = NSSwapHostShortToBig((*ptr -128) *volume);
                *(((short*)cnvptr)+1) = NSSwapHostShortToBig((*(ptr+1) -128) *volume);
                ptr+=2,cnvptr+=8;
                for(s=8; s < dataSize; s+=8,ptr+=2,cnvptr+=8){
                    // L
                    *(short*)cnvptr = NSSwapHostShortToBig((*ptr -128) *volume);
                    *(((short*)cnvptr)-2) = *(short*)cnvptr -(*(short*)cnvptr -*(((short*)cnvptr)-4)) / 2;
                    // R
                    *(((short*)cnvptr)+1) = NSSwapHostShortToBig((*(ptr+1) -128) *volume);
                    *(((short*)cnvptr)-1) = *(((short*)cnvptr)+1) -(*(((short*)cnvptr)+1) -*(((short*)cnvptr)-3)) / 2;
                }
            }
        } else {
            // 16bit
            if(channel==1){
                // mono
                if(dataSize % 2){
                    NSLog(@"ileagal data size wave data");
                    return sourceData;
                }

                *(short*)cnvptr = NSSwapShort(*(unsigned short *)ptr);
                *(short*)cnvptr = *(short*)cnvptr *volume / 256;
                ptr+=2; cnvptr+=4;
                if(swapData){            
                    for(s=4; s < dataSize; s+=4,ptr+=2,cnvptr+=4){
                        *(short*)cnvptr = NSSwapShort(*(unsigned short *)ptr);
                        *(short*)cnvptr = *(short*)cnvptr *volume / 256;
                        *(((short*)cnvptr)-1) = *(short*)cnvptr -(*(short*)cnvptr -*(((short*)cnvptr)-2)) / 2;
                    }
                } else {
                    for(s=4; s < dataSize; s+=4,ptr+=2,cnvptr+=4){
                        *(short*)cnvptr = *(short*)cnvptr *volume / 256;
                        *(((short*)cnvptr)-1) = *(short*)cnvptr -(*(short*)cnvptr -*(((short*)cnvptr)-2)) / 2;
                    }
                }
            } else {
                // stereo
                if(dataSize % 4){
                    NSLog(@"ileagal data size wave data");
                    return sourceData;
                }

                *(short*)cnvptr = NSSwapShort(*(unsigned short *)ptr);
                *(short*)cnvptr = *(short*)cnvptr *volume / 256;
                *(((short*)cnvptr)+1) = NSSwapShort(*((unsigned short *)ptr+1));
                *(((short*)cnvptr)+1) = *(((short*)cnvptr)+1) *volume / 256;
                ptr+=4; cnvptr+=8;
                if(swapData){
                    for(s=8; s < dataSize; s+=8,ptr+=4,cnvptr+=8){
                        // L
                        *(short*)cnvptr = NSSwapShort(*(unsigned short *)ptr);
                        *(short*)cnvptr = *(short*)cnvptr *volume / 256;
                        *(((short*)cnvptr)-2) = *(short*)cnvptr -(*(short*)cnvptr -*(((short*)cnvptr)-4)) / 2;
                        // R
                        *(((short*)cnvptr)+1) = NSSwapShort(*((unsigned short *)ptr+1));
                        *(((short*)cnvptr)+1) = *(((short*)cnvptr)+1) *volume / 256;
                        *(((short*)cnvptr)-1) = *(((short*)cnvptr)+1) -(*(((short*)cnvptr)+1) -*(((short*)cnvptr)-3)) / 2; 
                    }
                } else {
                    for(s=8; s < dataSize; s+=8,ptr+=4,cnvptr+=8){
                        // L
                        *(short*)cnvptr = *(short*)cnvptr *volume / 256;
                        *(((short*)cnvptr)-2) = *(short*)cnvptr -(*(short*)cnvptr -*(((short*)cnvptr)-4)) / 2;
                        // R
                        *(((short*)cnvptr)+1) = *(((short*)cnvptr)+1) *volume / 256;
                        *(((short*)cnvptr)-1) = *(((short*)cnvptr)+1) -(*(((short*)cnvptr)+1) -*(((short*)cnvptr)-3)) / 2; 
                    }
                }
            }
        }
    }
    
    if(plugin)
        [ plugin release ];
    
    return convData;
}

static bool loadExtra(void)
{
    static bool initialized,loaded;
    
    if(initialized && !loaded) {
        return false;
    } else if(!initialized) {
        Class pluginClass;
        std::stringpath=[ getAppDirectory() stringByAppendingPathComponent:[ [ TYEnviroment objectForKey:TYWaveExtraNameEnviroment ] stringByAppendingPathExtension:@"bundle" ] ];

        initialized=true;

        pluginBundle = [ NSBundle->bundleWithPath(path) retain ];
        if((pluginClass = [ pluginBundle principalClass ])){
            if(![ pluginClass conformsToProtocol:@protocol(TYWaveDecorder) ]){
                loaded=true;
                NSLog(@"invalid plugin it isn't conformsProtocol");
                return false;
            }
        } else {
            NSLog(@"can't load plugin");
            return false;
        }
        NSLog(@"loading WaveExtra");
        loaded = true;
    }
    
    return true;
}

void TYWave2AiffCleanUp(void) // call it on quit Application
{
}

std::vector<uint8_t> TYVerifyAiff(std::vector<uint8_t>data)
{
    const char *aiffPtr;
    
    aiffPtr = [ data bytes ];
    
    NSCAssert(([ data length ] > 46), @"not enought data size");
    
    NSCAssert((strncmp(aiffPtr, "FORM", 4) == 0), @"not exists FORM Header");
    NSCAssert((*(unsigned int*)(aiffPtr +4) == [ data length ] - 8), @"no match file size");
    NSCAssert((strncmp(aiffPtr + 8, "AIFF", 4) == 0), @"not exists AIFF Header");
    
    NSCAssert((strncmp(aiffPtr + 12, "COMM", 4) == 0), @"not exists COMM Header");
    NSCAssert((*(unsigned int*)(aiffPtr + 16) == 18), @"no match comm size");
    NSCAssert(((*(unsigned short*)(aiffPtr + 20) == 1) || (*(unsigned short*)(aiffPtr + 20) == 2)), @"NSSound support only mono or streo");
        
    NSCAssert((*((unsigned short*)(aiffPtr + 26)) == 16), @"NSSound support only 16-bits");
    
    NSCAssert(((memcmp(aiffPtr + 28, SAMPLE_RATE_44100, 10) == 0) ||
                (memcmp(aiffPtr + 28, SAMPLE_RATE_22050, 10) == 0)), @"not sampleRate 44100 or 22500");

    NSCAssert((strncmp(aiffPtr + 38, "SSND", 4) == 0), @"not exists SSND Header");
    NSCAssert3((*(unsigned int*)(aiffPtr + 42) - 8 == *((unsigned short*)(aiffPtr + 20)) * *((unsigned int*)(aiffPtr + 22)) * 2 ), 
                @"no match chunk size [%d] [%d] [%d]", *(unsigned int*)(aiffPtr + 42) , *((unsigned short*)(aiffPtr + 20)) , *((unsigned int*)(aiffPtr + 22)));
    NSCAssert((*(unsigned int*)(aiffPtr + 46) == 0), @"illegal offset size");
    NSCAssert((*(unsigned int*)(aiffPtr + 50) == 0), @"illegal block size");
    
    NSCAssert((*(unsigned int*)(aiffPtr + 42) + 46 == [ data length ]), @"no mutch file size to chunkSize");
    
    return data;
}
