/*
 *  TYLoopValue.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Loop control for script execution.
 */

#ifndef TYLOOPVALUE_QT_H
#define TYLOOPVALUE_QT_H

#include <QObject>
#include <QVariant>
#include <cstdint>

// Script position/coordinates
struct TYScriptPoint {
    unsigned int line;   // Line number
    unsigned int column; // Column number
};

// Loop structure
struct TYLoopStruct {
    TYScriptPoint point;  // Script position
    QVariant varNo;       // Variable number (can be array)
    int limit;           // Loop limit
    int step;            // Step value
};

// Inline factory (replaces static __inline__)
inline TYLoopStruct TYMakeLoopStruct(TYScriptPoint p, const QVariant& n, int l, int s) {
    TYLoopStruct ls;
    ls.point = p;
    ls.varNo = n;
    ls.limit = l;
    ls.step = s;
    return ls;
}

// Loop value object for script execution
class TYLoopValue : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithStruct:(TYLoopStruct)loop
    explicit TYLoopValue(const TYLoopStruct& loop, QObject* parent = nullptr);
    ~TYLoopValue();
    
    // Get the loop struct
    TYLoopStruct loopStruct() const { return m_loop; }
    
    // Accessors
    TYScriptPoint point() const { return m_loop.point; }
    QVariant varNo() const { return m_loop.varNo; }
    int limit() const { return m_loop.limit; }
    int step() const { return m_loop.step; }
    
private:
    TYLoopStruct m_loop;  // Replaces: NSValue *value
};

#endif // TYLOOPVALUE_QT_H