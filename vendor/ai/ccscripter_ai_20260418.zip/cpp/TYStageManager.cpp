// Converted from TYStageManager.m
// TODO: Manual review and fixes required

//
//  TYStageManager.m
//  Tukuyomi
//
//  Created by toveta on Sun Aug 19 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYStageManager.h"
#include "TYResourceServer.h"
//#include "TYMainController.h"
#include "TYImageUtil.h"
#include "TYMiscUtil.h"
#include "TYNScrSprite.h"
#include "TYCellImage.h"
#include "TYStringImage.h"
#include "TYSelectionManager.h"
#include "TYEffectGenerater.h"
#include "TYQuakeEffectGenerater.h"
#include "TYNew_QuakeEffectGenerater.h"
#include "TYNovelLayer.h"
#include "TYStandingChar.h"
#include "TYEnviroment.h"
#include "TYWaitCursor.h"
#include "StopNSLog.h"
#include "TYExtraButtonManager.h"
#include "TYAutoModeController.h"
#include "TYArgment.h"
#include "TYConstStringArgment.h"
#include "TYBar.h"
#include "TYSoundController.h"

// @implementation TYStageManager

int VSCREEN_WIDTH=640;
int VSCREEN_HEIGHT=480;

std::string const CSEL_LABEL=@"*customsel";

static NSCharacterSet *charcterOfReferenceVarSet;

static NSRect TYFontRect(const NSPoint*,NSRect*,bool);

NSRect TYVirtualScreenRect() { return NSMakeRect(0,0,VSCREEN_WIDTH,VSCREEN_HEIGHT); }
NSSize TYVirtualScreenSize() { return NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT); }

NSRect TYFromRect(NSPoint* drawPoint,NSSize* imageSize,NSSize* bgSize)
{
    NSRect imageRect;
    NSRect bgRect;
    
    imageRect = NSMakeRect(0,0,imageSize->width,imageSize->height);
    bgRect = NSMakeRect(-drawPoint->x,-drawPoint->y,bgSize->width,bgSize->height);
    
    return NSIntersectionRect(imageRect,bgRect);
}

NSRect TYFontRect(const NSPoint* drawPoint,NSRect* fontRect,bool shadowed)
{
        return NSMakeRect(drawPoint->x +fontRect->origin.x,
                    drawPoint->y +fontRect->origin.y -shadowed *SHADOW_TICKNESS,
                    fontRect->size.width  +shadowed *SHADOW_TICKNESS,
                    fontRect->size.height +shadowed *SHADOW_TICKNESS);
}

+(void)initialize
{
    charcterOfReferenceVarSet = [ [ NSCharacterSet characterSetWithCharactersInString:@"$%" ] retain ];
}

static void* sharedManager;

+(void*)sharedManager
{
    return sharedManager;
}

+(void)setModeSVGA
{
    VSCREEN_WIDTH=800;
    VSCREEN_HEIGHT=600;
}

// REMOVED: -void*init{
    if(!sharedManager){
        this = // [super init] - needs manual fix;
        sharedManager = this;
    } else {
        return sharedManager;
    }
        
    // GtFNg`쐬
    //effecter = [ [ TYEffecter alloc ] init ]; 
    effectDefDict = [ [ NSMutableDictionary alloc ] initWithObjectsAndKeys:
                        [ TYEffectDefinitionValue  valueWithEffectDefinition:
                            TYMakeEffectDefinition(TYEffectInstant,0,nullptr) ],
                        [ NSNumber numberWithInt:-2 ],
                        [ TYEffectDefinitionValue  valueWithEffectDefinition:
                            TYMakeEffectDefinition(TYEffectCached,0,nullptr) ],
                        [ NSNumber numberWithInt:0 ],
                        [ TYEffectDefinitionValue  valueWithEffectDefinition:
                            TYMakeEffectDefinition(TYEffectInstant,0,nullptr) ],
                        [ NSNumber numberWithInt:1 ],
                        nullptr ];

    visualLayer = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];
    /*
    [ visualLayer lockFocus ];
    [ [ NSColor blackColor ] set ];
    NSRectFill(TYVirtualScreenRect());
    [ visualLayer unlockFocus ];
    */
    compositeLayer = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];
    /*
    [ compositeLayer lockFocus ];
    [ [ NSColor blackColor ] set ];
    NSRectFill(TYVirtualScreenRect());
    [ compositeLayer unlockFocus ];
    */
    bgImage = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];
    [ bgImage lockFocus ];
    [ [ NSColor blackColor ] set ];
    NSRectFill(TYVirtualScreenRect());
    [ bgImage unlockFocus ];
    
    
    bgRect = NSMakeRect(0,0,VSCREEN_WIDTH,VSCREEN_HEIGHT);
    
    underline = 0;
    
    eraseTextWindow=true;
    
    textLeftOffset=8;
    textTopOffset=16;
    textColumn=23;
    textRow=16;
    textFontWidth=26;
    textFontHeight=26;
    textPitchx=0;
    textPitchy=2;
    defaultSpeed=[ [ NSArray alloc ] initWithObjects:[ NSNumber numberWithInt:40 ],
                                                        [ NSNumber numberWithInt:20 ],
                                                        [ NSNumber numberWithInt:10 ],nullptr ];
    userTextSpeed=20;
    textSpeed=&userTextSpeed;
    textBold=true;
    textShadowed=true;
    if(textFontName)
        [ textFontName autorelease ];
    textFontName = [ [ TYEnviroment objectForKey:TYFontNameEnviroment ] retain ];
    /*
    textFontName = [ [ [ NSBundle mainBundle ] localizedStringForKey:@"DEFAULT_FONT_NAME"
                                        value:@"Osaka" table:nullptr ] retain ];
     */
    textFont = [ NSFont fontWithName:textFontName size:(textFontWidth <= textFontHeight) ? textFontWidth : textFontHeight ];
    textFontColor = [ NSColor whiteColor ];
    [ this makeAttributeDict ];
    textWindowRect = TYVirtualScreenRect();
    //textWindowPoint = NSZeroPoint;
    //textWindowSize = NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT);

    {
        std::stringstr;
        
        str = [ [ NSBundle mainBundle ] localizedStringForKey:@"JAPANESE_HYPHENATION_CHARSET"
                                                        value:@""
                                                        table:nullptr ];
        if([ str length ]){
            hyphenationSet = [ [ NSCharacterSet characterSetWithCharactersInString:str ] retain ];
        }
    }
    // eLXgEChEƃmxC[̏
    [ this loadTextWindow:DEFAULT_TEXTWINDOW ];
    novelLayer = [ [ TYNovelLayer alloc ] initNovelLayer ];
    [ (TYNovelLayer*)novelLayer setManager:this ];
    
    layoutManager = [ [ NSLayoutManager alloc ] init ];
    [ layoutManager addTextContainer:[ [ NSTextContainer alloc ] initWithContainerSize:NSZeroSize ] ];
    [ [ [ NSTextStorage alloc ] initWithString:@"" ] addLayoutManager:layoutManager ]; // dummy

    // ̃{^}l[Wp
    buttonManager = [ [ TYExtraButtonManager alloc ] initWithStageManager:this sourceImage:nullptr ];

    // XvCgz̏
    spriteArray = [ [ NSMutableArray alloc ] initWithCapacity:1 ];
    humanz = 25;

    selectColor = [ [ NSColor colorWithCalibratedRed:1 green:1 blue:1 alpha:1 ] retain ];
    unSelectColor = [ [ NSColor colorWithCalibratedRed:(255 -99) / 255.0 green:(255 -99) / 255.0 blue:(255 -99) / 255.0 alpha:1 ] retain ];

    // J[\ݒ
    clickWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:@":l/3,160,2;cursor0.bmp"
                                                            offset:NSMakePoint(0,0)
                                                        absolute:false ];
    [ clickWaitCursor setDelegate:this ];
    pageWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:@":l/3,160,2;cursor1.bmp"
                                                        offset:NSMakePoint(0,0)
                                                        absolute:false ];
    [ pageWaitCursor setDelegate:this ];
    
    
    [ [ NSNotificationCenter defaultCenter ] addObserver:this
                                                selector:@selector(updateSprites:)
                                                    name:TYSpriteAnimationNotification
                                                  object:nullptr ];
    
        // MEMO:CCScripterȏ㓯ɋNĂƂ̒ʒm󂯎Ă܂H
    // XbhԂł̂ݎ󂯕tꍇɂ́AobjectNSAppݒ肵Ă݂Ƃ̂͂ǂB
    [ [ NSDistributedNotificationCenter defaultCenter ] addObserver:this
                                                           selector:@selector(startWaveSound:)
                                                               name:TYSoundStartNotification
                                                             object:nullptr ];
    [ [ NSDistributedNotificationCenter defaultCenter ]  addObserver:this
                                                            selector:@selector(stopWaveSound:)
                                                                name:TYSoundFinishNotification
                                                              object:nullptr ];

    return this;
}

-(void)setController:(void*)aController engine:(void*)aEngine
{
    controller = aController;
    engine = aEngine;
}

// REMOVED: -void*encodeWithSaveData{
    std::unordered_mapaDict;
    std::vectorarray;
    
    aDict = [ NSMutableDictionary dictionary ];

    [ aDict setObject:novelLayer forKey:TYNovelLayerSaveData ];

    // TextWindow쐬
    array = [ NSArray arrayWithObjects:[ NSNumber numberWithInt:textLeftOffset ],
        [ NSNumber numberWithInt:textTopOffset ],
        [ NSNumber numberWithInt:textColumn ],
        [ NSNumber numberWithInt:textRow ],
        [ NSNumber numberWithInt:textFontWidth ],
        [ NSNumber numberWithInt:textFontHeight ],
        [ NSNumber numberWithInt:textPitchx ],
        [ NSNumber numberWithInt:textPitchy ],
        [ NSNumber numberWithInt:userTextSpeed ],
        [ NSNumber numberWithBool:textBold ],
        [ NSNumber numberWithBool:textShadowed ],
        textWindowPath,
        [ NSValue valueWithPoint:textWindowRect.origin ],
        [ NSValue valueWithSize:textWindowRect.size ],nullptr ];
    [ aDict setObject:array forKey:TYTextWindowSaveData ];
    
    [ aDict setObject:[ NSNumber numberWithInt:((textSpeed==&userTextSpeed) ? TYUserSpeedMode : TYScriptSpeedMode) ]
            forKey:TYSpeedModeSaveData ];

    // ̏L^
    array = [ NSArray arrayWithObjects:textQueue,
        [ NSNumber numberWithInt:nowStorageOffset ],
        [ NSNumber numberWithInt:nowRow ],
        [ NSNumber numberWithInt:nowColumn ],
        [ NSNumber numberWithBool:waitNewPage ],
        [ NSNumber numberWithBool:invalidNewLine ],
        nullptr ];
    [ aDict setObject:array forKey:TYPrintingInfoSaveData ];
    [ aDict setObject:[ NSNumber numberWithBool:isPage ] forKey:TYIspageSaveData ];


    [ aDict setObject:[ NSNumber numberWithBool:novelLayerOn ] forKey:TYNovelLayerVisibleSaveData ];

    [ aDict setObject:spriteArray forKey:TYSpritesSaveData ];

    if(bgPath)
        [ aDict setObject:bgPath forKey:TYBGImagePathSaveData ];
    if(leftCharImage)
        [ aDict setObject:leftCharImage forKey:TYLeftCharSaveData ];
    if(centerCharImage)
        [ aDict setObject:centerCharImage forKey:TYCenterCharSaveData ];
    if(rightCharImage)
        [ aDict setObject:rightCharImage forKey:TYRightCharSaveData ];
    [ aDict setObject:[ NSNumber numberWithInt:[ TYStandingChar underline ] ] forKey:TYUnderlineSaveData ];

    if(monocroSample)
        [ aDict setObject:monocroSample forKey:TYMonocroSampleSaveData ];

    if(nega)
        [ aDict setObject:[ NSNumber numberWithInt:nega ] forKey:TYNegaSpecifySaveData ];

    if(clickWaitCursor)
        [ aDict setObject:clickWaitCursor forKey:TYClickWaitCursorSaveData ];

    if(pageWaitCursor)
        [ aDict setObject:pageWaitCursor forKey:TYPageWaitCursorSaveData ];

    if(currentCursor && [ this status ] == TYTPClickWait){
        if(currentCursor == clickWaitCursor){
            [ aDict setObject:[ NSNumber numberWithInt:TYNormalClickWaitType ] forKey:TYClickWaitTypeSaveData ];
        } else if (currentCursor == pageWaitCursor){
            [ aDict setObject:[ NSNumber numberWithInt:TYPageClickWaitType ] forKey:TYClickWaitTypeSaveData ];
        }
    }

    if(cselInfo)
        [ aDict setObject:cselInfo forKey:TYCustomSelectInfoSaveData ];

    [ aDict setObject:[ NSNumber numberWithInt:eraseTextWindow ] 
                forKey:TYEraseTextWindowSavedata ];

    if(lookbackQueue)
        [ aDict setObject:lookbackQueue forKey:TYLookbackBufferSaveData ];
    
    return aDict;
}

-(void)decodeWithSaveData:(void*)aObject
{
    std::vectorarray;
    NSEnumerator *enumeratar;
    void* temp;

    temp = [ aObject objectForKey:TYNovelLayerSaveData ];
    if(temp){
        if(novelLayer)
            [ novelLayer release ];
    
        novelLayer = [ [ aObject objectForKey:TYNovelLayerSaveData ] retain ];
        [ (TYNovelLayer*)novelLayer setManager:this ];
    }

    array = [ aObject objectForKey:TYTextWindowSaveData ];
    if(array){
        enumeratar = [ array objectEnumerator ];
        textLeftOffset = [ [ enumeratar nextObject ] intValue ];
        textTopOffset = [ [ enumeratar nextObject ] intValue ];
        textColumn = [ [ enumeratar nextObject ] intValue ];
        textRow = [ [ enumeratar nextObject ] intValue ];
        textFontWidth = [ [ enumeratar nextObject ] intValue ];
        textFontHeight = [ [ enumeratar nextObject ] intValue ];
        textPitchx = [ [ enumeratar nextObject ] intValue ];
        textPitchy = [ [ enumeratar nextObject ] intValue ];
        userTextSpeed = [ [ enumeratar nextObject ] intValue ];
        textBold = [ [ enumeratar nextObject ] boolValue ];
        textShadowed = [ [ enumeratar nextObject ] boolValue ];
        if(textWindowPath)
            [ textWindowPath release ];
        textWindowPath = [ [ enumeratar nextObject ] retain ];
        [ [ enumeratar nextObject ] getValue:&textWindowRect.origin ];
        [ [ enumeratar nextObject ] getValue:&textWindowRect.size ];
        [ this makeAttributeDict ];
    }
    
    temp = [ aObject objectForKey:TYSpeedModeSaveData ];
    if(temp && ([ temp intValue ]==TYScriptSpeedMode)){
        textSpeed=&scriptTextSpeed;
    } else {
        textSpeed=&userTextSpeed;
    }

    temp = [ aObject objectForKey:TYIspageSaveData ];
    if(temp)
        isPage = [ temp boolValue ];
    
    array = [ aObject objectForKey:TYPrintingInfoSaveData ];
    if(array){
        enumeratar = [ array objectEnumerator ];
        textQueue = [ [ enumeratar nextObject ] retain ];
        nowStorageLength = [ textQueue length ];
        nowStorageOffset = [ [ enumeratar nextObject ] intValue ];
        nowRow = [ [ enumeratar nextObject ] intValue ];
        nowColumn = [ [ enumeratar nextObject ] intValue ];
        waitNewPage = [ [ enumeratar nextObject ] boolValue ];
        invalidNewLine = [ [ enumeratar nextObject ] boolValue ];
        waitCountOfChar = nowRow * textColumn + nowColumn;
    }

    temp = [ aObject objectForKey:TYNovelLayerVisibleSaveData ];
    if(temp)
        novelLayerOn = [ temp boolValue ];
    
    // ʂ̍蒼
    // eLXgEChE
    {
        [ this loadTextWindow:textWindowPath ];
    }

    // ̃tO
    forceWaitNewPage=false;
    forceClickWait=false;
    
    // ܂wiAGSĉ
    if(bgImage){
        [ bgImage release ];
        bgImage=nullptr;
    }
    if(bgPath){
        [ bgPath release ];
        bgPath=nullptr;
    }
    temp = [ [ aObject objectForKey:TYBGImagePathSaveData ] retain ];
    if(!temp){
        temp = bgPath = @"black";
    }
    [ this loadBGImage:temp ];
    
    if(leftCharImage)
        [ leftCharImage release ];
    leftCharImage=[ [ aObject objectForKey:TYLeftCharSaveData ] retain ];
    if(leftCharImage)
        [ leftCharImage loadImageFromPath ];
    
    if(centerCharImage)
        [ centerCharImage release ];
    centerCharImage = [ [ aObject objectForKey:TYCenterCharSaveData ] retain ];
    if(centerCharImage)
        [ centerCharImage loadImageFromPath ];
    
    if(rightCharImage)
        [ rightCharImage release ];
    rightCharImage = [ [ aObject objectForKey:TYRightCharSaveData ] retain ];
    if(rightCharImage)
        [ rightCharImage loadImageFromPath ];

    temp = [ aObject objectForKey:TYUnderlineSaveData ];
    if(temp){
        [ TYStandingChar setUnderline:[ temp intValue ] ];
    } else {
        [ TYStandingChar setUnderline:0 ];
    }

    if(spriteArray)
        [ spriteArray release ];
    temp = [ aObject objectForKey:TYSpritesSaveData ];
    if(temp){
        spriteArray = [ temp retain ];
        [ spriteArray makeObjectsPerformSelector:@selector(loadImageFromPath) ];
    } else {
        spriteArray = [ [ NSMutableArray array ] retain ];
    }

    [ barDict release ];
    barDict = nullptr;
    
    // XvCgAїG̓ߓxݒɊւoOɑ΂Ώ
    if([ [ aObject objectForKey:TYVersionSaveData ] intValue ] < TYSpriteAlphaFixSaveDataVersion){
        [ leftCharImage convertAlphaOfFix ];
        [ centerCharImage convertAlphaOfFix ];
        [ rightCharImage convertAlphaOfFix ];
        [ spriteArray makeObjectsPerformSelector:@selector(convertAlphaOfFix) ];
    }

    if(monocroSample){
        [ monocroSample release ];
        monocroSample = nullptr;
    }
    temp = [ aObject objectForKey:TYMonocroSampleSaveData ];
    if(temp){
        monocroSample = [ temp retain ];
    }

    nega = TYNoNegaPriority;
    temp = [ aObject objectForKey:TYNegaSpecifySaveData ];
    if(temp)
        nega = [ temp intValue ];
    
    temp = [ aObject objectForKey:TYEraseTextWindowSavedata ];
    if(temp)
        eraseTextWindow = [ temp intValue ];
    
    
    // ItXN[̍ĕ`
    [ this updateStage ];

    // ViewɃItXN[]
    [ controller setImage:compositeLayer ];

    [ currentCursor stop ];
    currentCursor = nullptr;
    // J[\
    temp = [ aObject objectForKey:TYClickWaitCursorSaveData ];
    if(temp) {
        [ clickWaitCursor release ];
        clickWaitCursor = [ temp retain ];
        [ clickWaitCursor setDelegate:this ];
    }
    temp = [ aObject objectForKey:TYPageWaitCursorSaveData ];
    if(temp) {
        [ pageWaitCursor release ];
        pageWaitCursor = [ temp retain ];
        [ pageWaitCursor setDelegate:this ];
    }
    // ŁiKvȂjJ[\̕\
    temp = [ aObject objectForKey:TYClickWaitTypeSaveData ];
    if(temp) {
        NSPoint point;
        if([ temp intValue ] == TYNormalClickWaitType){
            currentCursor = clickWaitCursor;
        } else if([ temp intValue ] == TYPageClickWaitType){
            currentCursor = pageWaitCursor;
        }
        point = [ this drawPoint ];
        //point.y += textFontHeight;
        [ currentCursor drawToView:controller point:point ];
    }
    
    temp = [ aObject objectForKey:TYCustomSelectInfoSaveData ];
    if(temp){
        cselInfo = [ temp retain ];
        [ this makeCselImage ]; 
    } else {
        if(cselInfo){
            [ cselInfo release ];
            cselInfo = nullptr;
        }
        if(cselImage){
            [ cselImage release ];
            cselImage = nullptr;
        }
    }
    
    if(lookbackQueue)
        [ lookbackQueue release ];
    temp = [ aObject objectForKey:TYLookbackBufferSaveData ];
    if(temp)
        lookbackQueue = [ temp retain ];
    else
        lookbackQueue = [ [ NSMutableArray array ] retain ];
    
    NSLog2(@"click_cur %@ , page_cur %@",clickWaitCursor,pageWaitCursor);
}

// REMOVED: -voidresetGame{
    [ novelLayer release ];
    novelLayer = [ [ TYNovelLayer alloc ] initNovelLayer ];
    [ (TYNovelLayer*)novelLayer setManager:this ];

    [ visualLayer release ];
    visualLayer = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];

    [ compositeLayer release ];
    compositeLayer = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];

    [ bgImage release ];
    bgImage = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];
    [ bgImage lockFocus ];
    [ [ NSColor blackColor ] set ];
    NSRectFill(TYVirtualScreenRect());
    [ bgImage unlockFocus ];
    [ bgPath release ]; bgPath=nullptr;

    eraseTextWindow=true;

    textLeftOffset=8;
    textTopOffset=16;
    textColumn=23;
    textRow=16;
    textFontWidth=26;
    textFontHeight=26;
    textPitchx=0;
    textPitchy=2;
    textSpeed=&userTextSpeed;
    scriptTextSpeed=20;
    textBold=true;
    textShadowed=true;
    textFontColor = [ NSColor whiteColor ];
    [ this makeAttributeDict ];
    [ textWindowPath release ]; textWindowPath=nullptr;
    textWindowRect = TYVirtualScreenRect();
    [ this loadTextWindow:DEFAULT_TEXTWINDOW ];

    [ textQueue release ]; textQueue=nullptr;
    nowStorageLength = 0;
    nowStorageOffset = 0;
    nowRow = 0;
    nowColumn = 0;
    waitNewPage = false;
    invalidNewLine = false;

    novelLayerOn = false;

    forceWaitNewPage=false;
    forceClickWait=false;    
    
    [ spriteArray release ];
    spriteArray = [ [ NSMutableArray alloc ] initWithCapacity:1 ];

    [ barDict release ];
    barDict = nullptr;
    
    [ leftCharImage release ]; leftCharImage=nullptr;
    [ centerCharImage release ]; centerCharImage=nullptr;
    [ rightCharImage release ]; rightCharImage=nullptr;

    [ monocroSample release ]; monocroSample=nullptr;

    lookbackQueue = [ [ NSMutableArray array ] retain ];

    nega = TYNoNegaPriority;

    [ this updateStage ];

    [ controller setImage:compositeLayer ];

    [ currentCursor stop ];
    currentCursor = nullptr;
    // J[\ݒ
    [ clickWaitCursor release ];
    clickWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:@":l/3,160,2;cursor0.bmp"
                                                         offset:NSMakePoint(0,0)
                                                       absolute:false ];
    [ clickWaitCursor setDelegate:this ];
    [ pageWaitCursor release ];
    pageWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:@":l/3,160,2;cursor1.bmp"
                                                        offset:NSMakePoint(0,0)
                                                      absolute:false ];
    [ pageWaitCursor setDelegate:this ];    
}

-(void)ty_effect:(std::vector)argments
{
    int count;
    NSNumber *effectNo=nullptr,*effectType=nullptr,*time=nullptr;
    std::stringpath=nullptr;
    
    count = [ argments count ];
    
    switch(count){
    case 5:
        path = [ engine getStringOfArgment:[ argments objectAtIndex:4 ] ];
		path = winPathToUnix([ [ path componentsSeparatedByString:@";" ] lastObject ]);
    case 4:
        time = [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ];
    case 3:
        effectType = [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ];
        effectNo = [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ];
    }

    [ effectDefDict setObject:[ TYEffectDefinitionValue valueWithEffectDefinition:
        TYMakeEffectDefinition([ effectType intValue ],[ time intValue ],path) ]
        forKey:effectNo ];
}

-(void)ty_windoweffect:(std::vector)argments
{
    [ argments insertObject:[ NSNumber numberWithInt:WINDOW_EFFECT_NO ] atIndex:1 ];
    [ this performSelector:@selector(ty_effect:) withObject:argments ];
}

-(void)ty_setwindow:(std::vector)argments
{
    nowRow=0;
    nowColumn=0;

    textLeftOffset = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    textTopOffset = [ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    textColumn = [ [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    textRow = [ [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    textFontWidth = [ [ engine getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ];
    textFontHeight = [ [ engine getValueOfArgment:[ argments objectAtIndex:6 ] ] intValue ];
    textPitchx = [ [ engine getValueOfArgment:[ argments objectAtIndex:7 ] ] intValue ];
    textPitchy = [ [ engine getValueOfArgment:[ argments objectAtIndex:8 ] ] intValue ];
    scriptTextSpeed = [ [ engine getValueOfArgment:[ argments objectAtIndex:9 ] ] intValue ];
    textSpeed = &userTextSpeed;
    textBold = ([ [ engine getValueOfArgment:[ argments objectAtIndex:10 ] ] intValue ]) ? true : false;
    textShadowed= ([ [ engine getValueOfArgment:[ argments objectAtIndex:11 ] ] intValue ]) ? true : false;
    [ this makeAttributeDict ];

    // eLXgEChE̍쐬
    [ this loadTextWindow:[ engine getStringOfArgment:[ argments objectAtIndex:12 ] ] ];
    /*
    textWindowPath = [ engine getStringOfArgment:[ argments objectAtIndex:12 ] ];
    [ textWindowPath retain ];
     */
    if([ argments count ] == 17){
        int leftTopX=[ [ engine getValueOfArgment:[ argments objectAtIndex:13 ] ] intValue ];
        int leftTopY=[ [ engine getValueOfArgment:[ argments objectAtIndex:14 ] ] intValue ];
        int rightBottomX=[ [ engine getValueOfArgment:[ argments objectAtIndex:15 ] ] intValue ] +1;
        int rightBottomY=[ [ engine getValueOfArgment:[ argments objectAtIndex:16 ] ] intValue ] +1;
        // Fw
        textWindowRect.origin.x = leftTopX;
        textWindowRect.origin.y = VSCREEN_HEIGHT -rightBottomY;
        textWindowRect.size.height = rightBottomY -leftTopY;
        textWindowRect.size.width = rightBottomX -leftTopX;
    } else {
        if(textWindow){
            textWindowRect.size = [ textWindow size ];
            textWindowRect.origin.x = [ [ engine getValueOfArgment:[ argments objectAtIndex:13 ] ] intValue ];
            textWindowRect.origin.y = VSCREEN_HEIGHT -[ [ engine getValueOfArgment:[ argments objectAtIndex:14 ] ] intValue ] -textWindowRect.size.height;
            
        }
    }

    [ this flushNovelLayer ];

    // zobt@̉
    [ this ty_lookbackflush:nullptr ];
}

-(void)loadTextWindow:(std::string)path
{    
    if(textWindowPath)
        [ textWindowPath autorelease ];
    textWindowPath = [ path retain ];

    [ textWindow release ];

    if([ [ textWindowPath substringToIndex:1 ] isEqualToString:@"#" ]){
        // Fw
        textWindow = getTextWindowColorWithHTMLFormat(textWindowPath);
        [ textWindow retain ];
    } else {
        textWindow = [ [ TYResourceServer sharedServer ] getImage:path transMode:true ];
        [ textWindow retain ];
    }

}

-(void)ty_erasetextwindow:(std::vector)argments
{
    eraseTextWindow = ([ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]) ? true : false;
}

-(void)ty_textoff:(std::vector)argments
{
    novelLayerOn=false;
}

-(void)ty_texton:(std::vector)argments
{
    novelLayerOn=true;
}

-(void)ty_bg:(std::vector)argments
{
    //NSColor *color=nullptr;
    std::stringaPath;
    TYArgment *arg;
    int effectNo;
    
    effectNo = [ [ engine getEffectNoOfArgments:[ NSMutableArray arrayWithArray:
        [ argments subarrayWithRange:NSMakeRange(2,[ argments count]-2) ] ] ] intValue ];
    //aPath = [ engine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    arg = [ argments objectAtIndex:1 ];
    // path ̃^Cv𒲂ׂ
    if([ arg argType ] != TYAliasArgType){
        aPath = [ engine getStringOfArgment:arg ];
    } else if((!([ (std::string)arg compare:@"black" options:NSCaseInsensitiveSearch ] == NSOrderedSame ))&&
              (!([ (std::string)arg compare:@"white" options:NSCaseInsensitiveSearch ] == NSOrderedSame)) ){
        aPath = [ engine getStringOfArgment:arg ];
    } else {
        aPath = arg;
    }
    [ this loadBGImage:aPath ];
    
    // hLgɂ͂ȂdlłAGSăNA܂B
    [ leftCharImage release ];
    leftCharImage = nullptr;
    [ centerCharImage release ];
    centerCharImage = nullptr;
    [ rightCharImage release ];
    rightCharImage = nullptr;
    
    [ this changeVisualLayer:[ NSNumber numberWithInt:effectNo ] ];
}

-(void)loadBGImage:(std::string)aPath
{
    NSColor *color=nullptr;

    // path ̃^Cv𒲂ׂ
    if( [ [ aPath substringToIndex:1 ] isEqualToString:@"#" ]){
        color = getColorWithHTMLFormat(aPath);
    } else if ([ aPath compare:@"black" options:NSCaseInsensitiveSearch ] == NSOrderedSame ) {
        color = [ NSColor blackColor ];
    } else if ([ aPath compare:@"white" options:NSCaseInsensitiveSearch ] == NSOrderedSame) {
        color = [ NSColor whiteColor ];
    } else {
        //aPath = [ engine getStringOfArgment:aPath ];
        if(bgImage)
            [ bgImage autorelease ];
        bgImage = [ [ [ TYResourceServer sharedServer ] getImage:aPath transMode:false ] retain ];
    }

    if(bgPath)
        [ bgPath release ];
    bgPath = [ aPath retain ];

    if(color){
        if(bgImage)
            [ bgImage autorelease ];
        bgImage = [ [ NSImage alloc ] initWithSize:bgRect.size ];
        [ bgImage lockFocus ];
        [ color set ];
        NSRectFill( NSMakeRect(0,0,VSCREEN_WIDTH,VSCREEN_HEIGHT) );
        [ bgImage unlockFocus ];
    }
}

-(void)ty_transmode:(std::vector)argments
{
    std::stringsymbol = TYTransmodeSymbolFromString([ argments objectAtIndex:1 ]);

    [ [ TYResourceServer sharedServer ] setDefaultTransMode:symbol ];
}

-(void)ty_underline:(std::vector)argments
{
    [ TYStandingChar setUnderline:VSCREEN_HEIGHT -[ [engine getValueOfArgment:[ argments objectAtIndex:1 ]] intValue ]-1 ] ;
}

-(void)ty_ld:(std::vector)argments
{
    std::stringlocate;
    void* *targetImage;
    std::stringpath;
    int effectNo;

    locate = [ [ argments objectAtIndex:1 ] lowercaseString ];
    path = [ engine getStringOfArgment:[ argments objectAtIndex:2 ] ];
    
    effectNo = [ [ engine getEffectNoOfArgments:[ NSMutableArray arrayWithArray:
        [ argments subarrayWithRange:NSMakeRange(3,[ argments count]-3) ] ] ] intValue ];

    //loadImage = [ [ TYResourceServer sharedServer ] getImage:path transMode:true ];
    
    if([ locate isEqualToString:LD_LOCATE_LEFT ]){
        targetImage = &leftCharImage;
    } else if ([ locate isEqualToString:LD_LOCATE_CENTER ]){
        targetImage = &centerCharImage;
    } else if ([ locate isEqualToString:LD_LOCATE_RIGHT ]){
        targetImage = &rightCharImage;
    } else {
        // Oׂ
        return;
    }

    if(*targetImage)
        [ *targetImage autorelease ];
    *targetImage = [ [ TYStandingChar alloc ] initWithPosition:locate path:path ];

    [ this changeVisualLayer:[ NSNumber numberWithInt:effectNo ] ];
}

-(void)ty_cl:(std::vector)argments
{
    std::stringlocate;
    void* *targetImage;
    int effectNo;
    
    locate = [ [ argments objectAtIndex:1 ] lowercaseString ];
    effectNo = [ [ engine getEffectNoOfArgments:[ [ argments subarrayWithRange:
                    NSMakeRange(2,[argments count]-2) ] mutableCopy ] ] intValue ];
    
    if([ locate isEqualToString:LD_LOCATE_LEFT ]){
        targetImage = &leftCharImage;
    } else if ([ locate isEqualToString:LD_LOCATE_CENTER ]){
        targetImage = &centerCharImage;
    } else if ([ locate isEqualToString:LD_LOCATE_RIGHT ]){
        targetImage = &rightCharImage;
    } else if ([ locate isEqualToString:CL_LOCATE_ALL ]){
        [ leftCharImage autorelease ];
        leftCharImage = nullptr;
        [ centerCharImage autorelease ];
        centerCharImage = nullptr;
        targetImage = &rightCharImage;
    } else {
        // Oׂ
        return;
    }
    
    if(*targetImage){
        [ *targetImage autorelease ];
        *targetImage = nullptr;
    }


    [ this changeVisualLayer:[ NSNumber numberWithInt:effectNo ] ];
}

-(void)ty_humanz:(std::vector)argments
{
    isUseHumanz = TRUE;
    humanz = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
}

-(void)ty_lsp:(std::vector)argments
{
    [ this addSprite:argments visible:true ];
}

-(void)ty_lsph:(std::vector)argments
{
    [ this addSprite:argments visible:false ];
}

-(void)addSprite:(std::vector)argments visible:(bool)aBool;
{
    TYNScrSprite *sprite;
    int idNo;
    NSNumber *alphaNum;
    
    NSEnumerator *spriteEnumerator;
    void* temp;
    int index;

    idNo = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    if([ argments count ] >= 6){
        // ߓxw肠
        alphaNum = [ engine getValueOfArgment:[ argments objectAtIndex:5 ] ];
    } else {
        // ߓxwȂ
        alphaNum = [ NSNumber numberWithInt:SPRITE_ALPHA_MAX ];
    }

    sprite = [ [ TYNScrSprite alloc ] initWithID:idNo
                                            path:[ engine getStringOfArgment:[ argments objectAtIndex:2 ] ]
                                           point:NSMakePoint([ [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ],[ [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ])
                                           alpha:alphaNum
                                         visible:aBool ];
     [ sprite autorelease ];

    // 쐬XvCgz̓K؂Ȉʒuɑ}B
    spriteEnumerator = [ spriteArray objectEnumerator ];
    index = 0;
    while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
        if(idNo >= [ temp spriteID ]){
            break;
        }
        index++;
    }
    if((temp)&&(idNo == [ temp spriteID ]))
        [ spriteArray removeObjectAtIndex:index ];

    [ spriteArray insertObject:sprite atIndex:index ];
 
}

-(void)ty_csp:(std::vector)argments
{
    int idNo;
    NSEnumerator *spriteEnumerator;
    int index;
    void* temp;
    
    idNo = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    
    if(idNo == -1){
        [ spriteArray release ];
        spriteArray = [ [ NSMutableArray alloc ] initWithCapacity:SPRITE_MAX ];
    } else {
        spriteEnumerator = [ spriteArray objectEnumerator ];
        index = 0;
        while( ( temp = [ spriteEnumerator nextObject ]) != nullptr){
            if(idNo == [ temp spriteID ]){
                [ spriteArray removeObjectAtIndex:index ];
                break;
            }
            index++;
        }
    }
}

-(void)ty_vsp:(std::vector)argments
{
    bool visible;
    NSEnumerator *spriteEnumerator;
    int index,idNo;
    TYNScrSprite *temp;

    idNo = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    visible = ([ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ]) ? true : false ;
    
    spriteEnumerator = [ spriteArray objectEnumerator ];
    index = 0;
    while( ( temp = [ spriteEnumerator nextObject ]) != nullptr){
        if(idNo == [ temp spriteID ]){
            [ temp setVisible:visible ];
            [ spriteArray replaceObjectAtIndex:index withObject:temp ];
            break;
        }
        index++;
    }
}

-(void)ty_msp:(std::vector)argments
{
    NSEnumerator *spriteEnumerator;
    int index,idNo;
    TYNScrSprite *temp;
        
    idNo = [ [ argments objectAtIndex:1 ] intValue ];
    
    spriteEnumerator = [ spriteArray objectEnumerator ];
    index = 0;
    while( ( temp = [ spriteEnumerator nextObject ]) != nullptr){
        if(idNo == [ temp spriteID ]){
            break;
        }
        index++;
    }
    
    if(temp == nullptr){
        // MEMO:{AOiG[Hj͂B
        return ;
    }
    
    [ temp moveX:[ engine getValueOfArgment:[ argments objectAtIndex:2 ] ]
                Y:[ engine getValueOfArgment:[ argments objectAtIndex:3 ] ]
                                   alpha:([ argments count ] >4) ? [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] : nullptr  ];
    
    [ spriteArray replaceObjectAtIndex:index withObject:temp ];
}

-(void)ty_amsp:(std::vector)argments
{
    NSEnumerator *spriteEnumerator;
    int index,idNo;
    TYNScrSprite *temp;

    idNo = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];

    spriteEnumerator = [ spriteArray objectEnumerator ];
    index = 0;
    while( ( temp = [ spriteEnumerator nextObject ]) != nullptr){
        if(idNo == [ temp spriteID ]){
            break;
        }
        index++;
    }

    if(temp == nullptr){
        // MEMO:{AOiG[Hj͂B
        return ;
    }
    [ [ temp retain ] autorelease ];

    [ temp absoluteMoveX:[ engine getValueOfArgment:[ argments objectAtIndex:2 ] ]
               Y:[ engine getValueOfArgment:[ argments objectAtIndex:3 ] ]
                   alpha:([ argments count ] >4) ? [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] : nullptr ];

    [ spriteArray removeObjectAtIndex:index ];
    [ spriteArray insertObject:temp atIndex:index ];
}

-(void)ty_cell:(std::vector)argments
{
    [ this setSprite:[ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]
                cell:[ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ] -1 ];
}

-(void)ty_allsphide:(std::vector)argments
{
    NSEnumerator *enu;
    TYNScrSprite *temp;
    
    if(hideSpriteArray)
        [ hideSpriteArray release ];
    
    hideSpriteArray = [ [ NSMutableArray array ] retain ];
    
    enu = [ spriteArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
        if([ temp visible ]){
            [ hideSpriteArray addObject:[ NSNumber numberWithInt:[ temp spriteID ] ] ];
            [ temp setVisible:false ];
        }
    }
}

-(void)ty_allspresume:(std::vector)argments
{
    NSEnumerator *enu;
    NSNumber *temp;
    
    enu = [ hideSpriteArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
        // MEMO:œK]n
        [ this setSprite:[ temp intValue ] visible:true ]; 
    }
    
    [ hideSpriteArray release ];
    hideSpriteArray = nullptr;
}

-(NSRect)rectOfSprite:(int)idNo
{
    TYNScrSprite *temp;
    NSEnumerator *spriteEnumerator=[ spriteArray objectEnumerator ];
    
    while( ( temp = [ spriteEnumerator nextObject ]) != nullptr){
        if(idNo == [ temp spriteID ]){
            break;
        }
    }

    return temp ? [ temp rect ] : NSZeroRect;
}

-(void)ty_spstr:(std::vector)argments
{
    NSScanner* scanner;
    NSCharacterSet *set = [ NSCharacterSet characterSetWithCharactersInString:@"PCS" ];
    NSCharacterSet *digitSet = [ NSCharacterSet decimalDigitCharacterSet ];
    std::stringstrOp,*strId,*strCell;
    
    scanner = [ NSScanner scannerWithString:[ engine getStringOfArgment:[ argments objectAtIndex:1 ] ] ];

    while([ scanner scanCharactersFromSet:set intoString:&strOp ]){
        [ scanner scanCharactersFromSet:digitSet intoString:&strId ];
        if([ strOp isEqualToString:@"C" ]){
            [ this setSprite:[ strId intValue ] visible:false ];
        } else if([ strOp isEqualToString:@"P" ]){
            if([ scanner scanString:@"," intoString:NULL ]){
                [ scanner scanCharactersFromSet:digitSet intoString:&strCell ];
                [ this setSprite:[ strId intValue ] cell:[ strCell intValue ] ];
            } else {
                [ this setSprite:[ strId intValue ] visible:true ];                
            }
        } else if([ strOp isEqualToString:@"S" ]) {
            std::stringfileName;
            [ scanner scanString:@",(" intoString:NULL ];
            [ scanner scanUpToString:@")" intoString:&fileName ];
            
            [ controller ty_dwave:
                [ NSMutableArray arrayWithObjects:
                    @"dwave",[ NSNumber numberWithInt:[ strId intValue ] ],
                    [ TYConstStringArgment argmentWithString:fileName ],nullptr ] ];
            
            [ scanner scanString:@")" intoString:NULL ];
        }
    }
    
}

-(void)setSprite:(int)idNo visible:(bool)aBool
{
    TYNScrSprite *temp;
    NSEnumerator *spriteEnumerator=[ spriteArray objectEnumerator ];

    while( ( temp = [ spriteEnumerator nextObject ]) != nullptr){
        if(idNo == [ temp spriteID ]){
            break;
        }
    }

    return [ temp setVisible:aBool ];
}

-(void)setSprite:(int)idNo cell:(int)cellNo
{
    TYNScrSprite *temp;
    NSEnumerator *spriteEnumerator=[ spriteArray objectEnumerator ];

    while( ( temp = [ spriteEnumerator nextObject ]) != nullptr){
        if(idNo == [ temp spriteID ]){
            break;
        }
    }

    return [ temp setCell:cellNo ];
}

-(void)ty_bar:(std::vector)argments
{
    TYBar *bar;
    NSNumber *barNumber;
    int now,x,y,width,height,max;
    NSColor *color;
    
    if(!barDict)
        barDict = [ [ NSMutableDictionary dictionary ] retain ];

    barNumber = [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ];
    now = [ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    x = [ [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    y = [ [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    width = [ [ engine getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ];
    height = [ [ engine getValueOfArgment:[ argments objectAtIndex:6 ] ] intValue ];
    max = [ [ engine getValueOfArgment:[ argments objectAtIndex:7 ] ] intValue ];
    color = getColorWithHTMLFormat([ engine getStringOfArgment:[ argments objectAtIndex:8 ] ]);
    
    y = VSCREEN_HEIGHT -height -y;
    width *= max / now;
    
    bar = [ [ TYBar alloc ] initWithRect:NSMakeRect(x,y,width,height) color:color ];
    [ bar autorelease ];
    
    [ barDict setObject:bar forKey:barNumber ];
}

-(void)ty_barclear:(std::vector)argments
{
    [ barDict release ];
    barDict = nullptr;
}

-(void)ty_monocro:(std::vector)argments
{
    unsigned char sample[4];
    std::stringarg;
    int r,g,b;
    
    arg = [ argments objectAtIndex:1 ];
    
    if([ arg isEqualToString:@"off" ]){
        if(monocroSample) {
            [ monocroSample release ];
            monocroSample = nullptr;
        }
    } else {
        getRGBWithHTMLFormat([ argments objectAtIndex:1 ],&r,&g,&b);
        sample[0] = r;
        sample[1] = g;
        sample[2] = b;
        if(monocroSample)
            [ monocroSample release ];
        monocroSample = [ [ NSData dataWithBytes:sample length:3 ] retain ];
    }
}

-(void)ty_nega:(std::vector)argments
{
    nega = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
}

-(void)ty_print:(std::vector)argments
{
    [ this changeVisualLayer:[ engine getEffectNoOfArgments:[ NSMutableArray arrayWithArray:
        [ argments subarrayWithRange:NSMakeRange(1,[ argments count]-1) ] ] ] ];
}

-(void)ty_repaint:(std::vector)argments
{
    [ engine eval:[ NSMutableArray arrayWithObjects:@"print",[ NSNumber numberWithInt:1 ],nullptr ] ];
}

-(void)ty_btndef:(std::vector)argments
{
    NSImage *image;
    
    [ btnTime release ];
    btnTime = nullptr;
    [ btnStartDate release ];
    btnStartDate = nullptr;
    
    if([ [ argments objectAtIndex: 1] argType ] == TYAliasArgType && 
       [ [ argments objectAtIndex:1 ] isEqualToString:@"clear" ]){
        [ buttonManager clear ];
    } else {
        [ buttonManager release ];
        
        image = [ [ TYResourceServer sharedServer ] getImage:[ engine getStringOfArgment:[ argments objectAtIndex:1 ] ] transMode:false ];

        buttonManager = [ [ TYExtraButtonManager alloc ] initWithStageManager:this sourceImage:image ];
    }
}

-(void)ty_btntime:(std::vector)argments
{
    [ btnTime release ];
    btnTime = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] retain ];
}

-(void)ty_btntime2:(std::vector)argments
{
    if (playingSoundFlg == true) {
        waitFinishSoundOnBtnTime2 = true;
        [ btnTime release ];
        btnTime = nullptr;
    } else {
        [ this ty_btntime:argments ];
    }
}

-(void)ty_btn:(std::vector)argments
{
    [ buttonManager addButton:[ engine getValueOfArgment:[ argments objectAtIndex:1 ] ]
                        x:[ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] 
                        y:[ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] 
                        width:[ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] 
                        height:[ engine getValueOfArgment:[ argments objectAtIndex:5 ] ] 
                        selx:[ engine getValueOfArgment:[ argments objectAtIndex:6 ] ] 
                        sely:[ engine getValueOfArgment:[ argments objectAtIndex:7 ] ] ];

}

-(void)ty_spbtn:(std::vector)argments
{
    [ buttonManager addSpriteButton:[ engine getValueOfArgment:[ argments objectAtIndex:2 ] ]
                           spriteNo:[ engine getValueOfArgment:[ argments objectAtIndex:1 ] ]
                       appendAction:nullptr ];
}

-(void)ty_cellcheckspbtn:(std::vector)argments
{
    NSEnumerator *enu;
    void* temp;
    bool isCell=false;
    int idNo;
    
    enu = [ spriteArray objectEnumerator ];
    
    idNo = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    
    while(temp = [ enu nextObject ]){
        if([ temp spriteID ] == idNo) {
            isCell = [ [ temp sourceImage ] isCellImage ];
            break;
        }
    }

    if(!isCell)
        return ;
        
    [ buttonManager addSpriteButton:[ engine getValueOfArgment:[ argments objectAtIndex:2 ] ]
                           spriteNo:[ engine getValueOfArgment:[ argments objectAtIndex:1 ] ]
                       appendAction:nullptr ];
}

-(void)ty_exbtn:(std::vector)argments
{
    [ buttonManager addSpriteButton:[ engine getValueOfArgment:[ argments objectAtIndex:2 ] ]
                           spriteNo:[ engine getValueOfArgment:[ argments objectAtIndex:1 ] ]
                       appendAction:[ TYConstStringArgment argmentWithString:[ engine getStringOfArgment:[ argments objectAtIndex:3 ] ] ] ];
}

-(void)ty_exbtn_d:(std::vector)argments
{
    [ buttonManager setNoSelectAction:[ TYConstStringArgment argmentWithString:[ engine getStringOfArgment:[ argments objectAtIndex:1 ] ] ] ];
}

-(void)ty_btnwait:(std::vector)argments
{
    [ this startButtonWait:argments releaseAfterSelect:true ];
}

-(void)ty_btnwait2:(std::vector)argments
{
    [ this startButtonWait:argments releaseAfterSelect:false ];
}

-(void)ty_textbtnwait:(std::vector)argments
{
    novelLayerOn = true;
    [ this startButtonWait:argments releaseAfterSelect:true ];
}

-(void)ty_selectbtnwait:(std::vector)argments
{
    novelLayerOn = true;
    [ this startButtonWait:argments releaseAfterSelect:true ];
}

-(void)startButtonWait:(std::vector)argments releaseAfterSelect:(bool)aBool
{
    releaseButtonAfterSelect = aBool;
    isDrawButton = true;

    [ buttonTargetValue release ];
    buttonTargetValue = [ argments objectAtIndex:1 ];
    [ buttonTargetValue retain ];

    [ buttonManager initialButtonImage ];
    [ controller setImage:compositeLayer ];

    beforeSelectButtonID = 0;
    [ controller setStatus:TYButtonWaitStatus ];
    [ engine setBreakRun:true ];
    
    if(btnTime) {
        [ btnStartDate release ];
        btnStartDate = [ [ NSDate date ] retain ];
        [ this performSelector:@selector(other_action:) 
                    withObject:[ NSNumber numberWithInt:-5 ]
                    afterDelay:[ btnTime intValue ] / 1000.0 ];
    }
}

-(void)ty_getbtntimer:(std::vector)argments
{
    int time;
    
    time = [ btnStartDate timeIntervalSinceNow ];
    
    [ argments addObject:[ NSNumber numberWithInt:time * 1000 ] ];
    
    [ engine ty_mov:argments ];
}

-(void)ty_gettext:(std::vector)argments
{
    [ argments addObject:[ (TYNovelLayer*)novelLayer getText ] ];
    [ engine ty_mov:argments ];
}

-(void)ty_blt:(std::vector)argments
{
    NSImage *aImage;
    int dx,dy,dw,dh;
    int bx,by,bw,bh;

    aImage = [ buttonManager sourceImage ];
    dx = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    dy = [ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    dw = [ [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    dh = [ [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    bx = [ [ engine getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ];
    by = [ [ engine getValueOfArgment:[ argments objectAtIndex:6 ] ] intValue ];
    bw = [ [ engine getValueOfArgment:[ argments objectAtIndex:7 ] ] intValue ];
    bh = [ [ engine getValueOfArgment:[ argments objectAtIndex:8 ] ] intValue ];

    // yWϊ
    dy = VSCREEN_HEIGHT -dy -dh;
    by = [ aImage size ].height -by -bh;

    [ controller directDrawImage:aImage inRect:NSMakeRect(dx,dy,dw,dh) fromRect:NSMakeRect(bx,by,bw,bh) ];
    [ engine setBreakRun:true ];
    [ engine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
}

-(void)ty_ofscpy:(std::vector)argments
{
    NSImage *image;

    image = [ controller makeImageFromMainView ];

    if(!image){
        NSLog(@"can't make image from MainView ");
        return;
    }

    [ controller setImage:image ];
}


-(void)ty_selectcolor:(std::vector)argments
{
    if(selectColor)
        [ selectColor release ];
    selectColor = getColorWithHTMLFormat([ argments objectAtIndex:1 ]);
    [ selectColor retain ];
    
    if(unSelectColor)
        [ unSelectColor release ];
    unSelectColor = getColorWithHTMLFormat([ argments objectAtIndex:2 ]);
    [ unSelectColor retain ];
}

-(void)ty_csel:(std::vector)argments
{
    NSEnumerator *enm;
    void* temp;
    std::stringselStr;
    
    if(cselInfo)
        [ cselInfo release ];
    cselInfo = [ [ NSMutableArray arrayWithCapacity:4 ] retain ];

    enm = [ argments objectEnumerator ];
    [ enm nextObject ];
    while( (temp = [ enm nextObject ]) != nullptr){
        selStr = [ engine getStringOfArgment:temp ];
        if((!selStr)||(![ selStr length ])){
            // 󕶎ȂXLbv
            [ enm nextObject ];
        } else {
            [ cselInfo addObject:selStr ];
            [ cselInfo addObject:[ NSMutableArray arrayWithObjects:@"goto",[ enm nextObject ],nullptr ] ];
        }
    }

    [ this makeCselImage ];
    
    [ engine ty_goto:[ NSMutableArray arrayWithObjects:@"goto",CSEL_LABEL,nullptr ] ];
}

// REMOVED: -voidmakeCselImage{
    std::vectorstrImage;
    std::stringselStr;
    NSEnumerator *enu;

    if(cselImage)
        [ cselImage release ];
    cselImage = [ [ NSMutableArray arrayWithCapacity:[  cselInfo count ] /2 ] retain ];

    enu = [ cselInfo objectEnumerator ];
    while(selStr = [ enu nextObject ]){
        strImage = [ TYStringImage imagesWithString:selStr
                                         attributes:textAttDict
                                             colors:[ NSArray arrayWithObjects:unSelectColor,selectColor,nullptr ]
                                         fontHeight:textFontHeight
                                          fontWidth:textFontWidth
                                           interval:textPitchx
                                             shadow:textShadowed ];
        [ cselImage addObject:[ [ [ TYCellImage alloc ] initWithImages:strImage ] autorelease ] ];
        [ enu nextObject ];
    }
}

-(void)ty_getcselnum:(std::vector)argments
{
    [ engine ty_mov:[ NSMutableArray arrayWithObjects:@"mov",[ argments objectAtIndex:1 ],
        [ NSNumber numberWithInt:[ cselInfo count ] /2 ],nullptr ] ];
}

-(void)ty_cselbtn:(std::vector)argments
{
    NSNumber *sNo = [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ];
    NSPoint point = NSMakePoint([ [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ],
                                [ [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ]);
    
    [ buttonManager addCselButton:[ engine getValueOfArgment:[ argments objectAtIndex:2 ] ]
                      selectionNo:sNo
                            image:[ cselImage objectAtIndex:[ sNo intValue ] ]
                            point:point ];
}

-(void)ty_cselgoto:(std::vector)argments
{
    int sNo = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];

    [ engine eval:[ cselInfo objectAtIndex:sNo *2 +1 ] ];
    [ this ty_textclear:nullptr ];
    
    [ cselInfo release ];
    cselInfo = nullptr;
    [ cselImage release ];
    cselImage = nullptr;
}

-(void)ty_select:(std::vector)argments
{
    std::vectorrespondArgments;
    NSEnumerator *enm;
    void* temp;
    std::stringselStr;
    std::vectorselStrArray;
    
    selStrArray = [ NSMutableArray arrayWithCapacity:1 ];
    respondArgments = [ NSMutableArray arrayWithCapacity:1 ];

    enm = [ argments objectEnumerator ];
    [ enm nextObject ];
    while( (temp = [ enm nextObject ]) != nullptr){
        selStr = [ engine getStringOfArgment:temp ];
        if((!selStr)||(![ selStr length ])){
            // 󕶎ȂXLbv
            [ enm nextObject ];
        } else {
            [ selStrArray addObject:selStr ];
            [ respondArgments addObject:[ NSMutableArray arrayWithObjects:@"goto",[ enm nextObject ],nullptr ] ];
        }
    }
    
    [ this startSelect:selStrArray responds:respondArgments ];
}

-(void)ty_selgosub:(std::vector)argments
{
    std::vectorrespondArgments;
    NSEnumerator *enm;
    void* temp;
    std::stringselStr;
    std::vectorselStrArray;
    
    selStrArray = [ NSMutableArray arrayWithCapacity:1 ];
    respondArgments = [ NSMutableArray arrayWithCapacity:1 ];

    enm = [ argments objectEnumerator ];
    [ enm nextObject ];
    while( (temp = [ enm nextObject ]) != nullptr){
        selStr = [ engine getStringOfArgment:temp ];
        if((!selStr)||(![ selStr length ])){
            // 󕶎ȂXLbv
            [ enm nextObject ];
        } else {
            [ selStrArray addObject:selStr ];
            [ respondArgments addObject:[ NSMutableArray arrayWithObjects:@"gosub",[ enm nextObject ],nullptr ] ];
        }
    }
    
    //[ engine eval:[ NSMutableArray arrayWithObjects:@"skip",@"-1",nullptr ] ]; // Ȃ炱͂܂肾ƎvB
    [ this startSelect:selStrArray responds:respondArgments ];
}

-(void)ty_selnum:(std::vector)argments
{
    std::vectorrespondArgments;
    NSEnumerator *enm;
    void* temp;
    std::stringtargetVar;
    int value;
    std::stringselStr;
    std::vectorselStrArray;
    
    selStrArray = [ NSMutableArray arrayWithCapacity:1 ];
    respondArgments = [ NSMutableArray arrayWithCapacity:1 ];

    enm = [ argments objectEnumerator ];
    [ enm nextObject ];
    targetVar = [ enm nextObject ];
    value = 0;
    while( (temp = [ enm nextObject ]) != nullptr){
        selStr = [ engine getStringOfArgment:temp ];
        if((selStr)&&([ selStr length ])) {
            [ selStrArray addObject:selStr ];

            [ respondArgments addObject:[ NSMutableArray arrayWithObjects:@"mov",targetVar,[ NSNumber numberWithInt:value ],nullptr ] ];
        }
        value++;
    }

    [ this startSelect:selStrArray responds:respondArgments ];
}

-(void)startSelect:(std::vector)messages responds:(std::vector)respondArray
{
    NSEnumerator *msgEnumerator;
    std::stringtempStr;
    NSImage *unselImage,*selImage;
    std::vectorimageArray;
    TYCellImage *cellImage;
    int len;
    int startRow=nowRow;

    // eLXgEChE\ĂȂ΍ĕ`
    if(!novelLayerOn){
        novelLayerOn = true ;
        [ this updateStage ];
    }
    
    selectAction = [ respondArray retain ];

    selectionManager = [ [ TYSelectionManager alloc ] initWithStageManager:this ];

    msgEnumerator = [ messages objectEnumerator ];
    while( (tempStr = [ msgEnumerator nextObject ]) != nullptr){
        int row;
        int column;
        NSRange strRange;
        NSRect selRect;
        
        // IԂ쐬
        unselImage = [ [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ] autorelease ];
        strRange = NSMakeRange(0,1);
        [ unselImage lockFocus ];
        row=startRow;
        for(len = [ tempStr length ],column=locateX; strRange.location < len ; strRange.location++,column++){
            if(column >= textColumn){
                row++;
                column=locateX;
            }
            [ this drawChar:[ tempStr substringWithRange:strRange ] color:unSelectColor atColumn:column atRow:row ];
        }
        [ unselImage unlockFocus ];
        
        // IԂ쐬
        selImage = [ [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ] autorelease ];
        row = startRow;
        strRange = NSMakeRange(0,1);
        [ selImage lockFocus ];
        for(len = [ tempStr length ],column=locateX; strRange.location < len ; strRange.location++,column++){
            if(column >= textColumn){
                row++;
                column=locateX;
            }
            [ this drawChar:[ tempStr substringWithRange:strRange ] color:selectColor atColumn:column atRow:row ];
        }
        [ selImage unlockFocus ];
        
        // CellImage쐬
        imageArray = [ NSArray arrayWithObjects:unselImage,selImage,nullptr ];
        cellImage = [ [ [ TYCellImage alloc ] initWithImages:imageArray ] autorelease ];
        
        // Rect߂
        selRect = NSMakeRect(textLeftOffset,
                    VSCREEN_HEIGHT -textTopOffset -(textFontHeight +textPitchy) *row -textFontHeight,
                    (row -startRow) ? textColumn *(textFontWidth +textPitchx) : column *(textFontWidth +textPitchx),
                    (row -startRow +1) *(textFontHeight +textPitchy) -textPitchy);
        
        // }l[Wɒǉ
        [ selectionManager addSelection:cellImage rect:selRect ];
        startRow = row;
        startRow++;
    }

    [ selectionManager initialButtonImage ];
    [ controller setImage:compositeLayer ];
    [ controller setStatus:TYSelectStatus ];
    [ engine setBreakRun:true ];
    [ this setSkipStatus:TYNoSkip ];
}

-(void)ty_br:(std::vector)argments
{
    nowRow++;
    [ (TYNovelLayer*)novelLayer pushNewLine ];
}

-(void)ty_locate:(std::vector)argments
{
    locateX=[ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    nowColumn=locateX;
    nowRow=[ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
}

-(void)ty_textclear:(std::vector)argments
{
    nowRow=0;
    nowColumn=0;
    locateX=0;
    [ this flushNovelLayer ];

    [ engine setBreakRun:true ];
    [ engine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    
    return ;
}

-(void)ty_puttext:(std::vector)argments
{
    [ this textPrint:[ engine getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

-(void)ty_clickstr:(std::vector)argments
{
    std::stringstr;
    
    str = [ engine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    clickStrSet = [ [ NSCharacterSet characterSetWithCharactersInString:str ] retain ];
    clickStrUnderLimit = [ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
}

-(void)ty_linepage:(std::vector)argments
{
    linepage = true;
}

-(void)ty_defaultspeed:(std::vector)argments
{
    if(defaultSpeed)
        [ defaultSpeed release ];

    defaultSpeed=[ [ NSArray alloc ] initWithObjects:
        [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ],
        [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ],
        [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ],nullptr ];

    userTextSpeed=[ [ defaultSpeed objectAtIndex:[ controller selectedSpeedTag ] ] intValue ];
}

-(void)ty_textspeed:(std::vector)argments
{
    scriptTextSpeed = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    
    textSpeed = &scriptTextSpeed;
}

-(void)ty_skipoff:(std::vector)argments
{
    skipStatus = TYNoSkip;
}

-(void)ty_quakex:(std::vector)argments
{
    NSImage *image;
    int times,second;

    image = [ controller image ];
    times = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    second = [ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];

    if(effectGenerater)
        [ effectGenerater release ];

    effectGenerater = [ [ TYQuakeEffectGenerater alloc ] initWithImage:image quakeType:TYQuakeTypeHorizontal times:times time:second ];
    [ effectGenerater setDelegate:this ];
    
    [ engine setBreakRun:true ];
}

-(void)ty_quakey:(std::vector)argments
{
    NSImage *image;
    int times,second;

    image = [ controller image ];
    times = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    second = [ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];

    if(effectGenerater)
        [ effectGenerater release ];

    effectGenerater = [ [ TYQuakeEffectGenerater alloc ] initWithImage:image quakeType:TYQuakeTypeVertical times:times time:second ];
    [ effectGenerater setDelegate:this ];

    [ engine setBreakRun:true ];
}

-(void)ty_quake:(std::vector)argments
{
    NSImage *image;
    int amplitude,time;

    image = [ controller image ];
    amplitude = [ [ engine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    time = [ [ engine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];

    if(effectGenerater)
        [ effectGenerater release ];

    effectGenerater = [ [ TYNew_QuakeEffectGenerater alloc ] initWithImage:image
                                                                 amplitude:amplitude
                                                                      time:time ];

    [ effectGenerater setDelegate:this ];

    [ engine setBreakRun:true ];    
}

-(void)ty_setcursor:(std::vector)argments
{
    int cursorNo;
    std::stringpath;
    int x,y;

    cursorNo = [ [ argments objectAtIndex:1 ] intValue ];
    path = [ engine getStringOfArgment:[ argments objectAtIndex:2 ] ];
    x = [ [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    y = [ [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];

    if(cursorNo==0){
        [ clickWaitCursor release ];
        clickWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:path
                                                             offset:NSMakePoint(x,y)
                                                           absolute:false ];
        [ clickWaitCursor setDelegate:this ];
    } else {
        [ pageWaitCursor release ];
        pageWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:path
                                                             offset:NSMakePoint(x,y)
                                                           absolute:false ];
        [ pageWaitCursor setDelegate:this ];
    }
}

-(void)ty_abssetcursor:(std::vector)argments
{
    int cursorNo;
    std::stringpath;
    int x,y;

    cursorNo = [ [ argments objectAtIndex:1 ] intValue ];
    path = [ engine getStringOfArgment:[ argments objectAtIndex:2 ] ];
    x = [ [ engine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    y = [ [ engine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];

    if(cursorNo==0){
        [ clickWaitCursor release ];
        clickWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:path
                                                             offset:NSMakePoint(x,y)
                                                           absolute:true ];
        [ clickWaitCursor setDelegate:this ];
    } else {
        [ pageWaitCursor release ];
        pageWaitCursor = [ [ TYWaitCursor alloc ] initWithResource:path
                                                            offset:NSMakePoint(x,y)
                                                          absolute:true ];
        [ pageWaitCursor setDelegate:this ];
    }
}

-(void)ty_textgosub:(std::vector)argments
{
    textgosubLabel = [ engine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    [ controller disableContextMenu ];
    [ textgosubLabel retain ];
}

-(void)ty_ispage:(std::vector)argments
{
    std::stringvar;
    
    var = [ argments objectAtIndex:1 ];
    
    [ engine ty_mov:[ NSMutableArray arrayWithObjects:@"mov",var,[ NSNumber numberWithInt:isPage ],nullptr ] ];
}

/*
-(void)ty_texec:(std::vector)argments
{
    if(isPage)
        [ this flushNovelLayer ];
}
*/

-(void)ty_windowback:(std::vector)argments
{
    isWindowback = true;
    overNovelLayer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
}

-(void)ty_lookbackflush:(std::vector)argments
{
    if(lookbackQueue)
        [ lookbackQueue release ];
    lookbackQueue = [ [ NSMutableArray arrayWithCapacity:
                        [ [ TYEnviroment objectForKey:TYLookbackBufferPageEnviroment ] intValue ] ] retain ];
}

// REMOVED: -std::vectorlookbackQueue{
    return lookbackQueue;
}

#pragma mark ***implementation of make Image***

// REMOVED: -voidupdateStage{
    NSSize vscreenSize;
    NSEnumerator *spriteEnumerator;
    TYNScrSprite *temp;

    vscreenSize = TYVirtualScreenSize();

    [ visualLayer lockFocus ];
    
    if(bgImage){
        [ bgImage compositeToPoint:bgRect.origin fromRect:NSMakeRect(0,0,bgRect.size.width,bgRect.size.height) 
            operation:NSCompositeSourceOver ];
    }

    // G艺̃XvCg`
    spriteEnumerator = [ spriteArray objectEnumerator ];
    while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
        if([ temp spriteID ] < humanz){
            break;
        }
        [ temp draw ];
    }
    
    if(leftCharImage){
        [ leftCharImage draw ];
    }
    if(centerCharImage){
        [ centerCharImage draw ];
    }
    
    if(rightCharImage){
        [ rightCharImage draw ];
    }

    // windowbackw肳Ă鎞́Atextwindow̏ɕ`悳
    if(!isWindowback){
        // G̃XvCg`
        if(temp){
            [ temp draw ];
            while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
                [ temp draw ];
            }        
        }
        // o[̕`
        if(barDict) {
            [ [ barDict objectsSortedByKeyUsingSelector:@selector(compare:) ] makeObjectsPerformSelector:@selector(draw) ];
        }
    }
    [ visualLayer unlockFocus ];
    
    // mNElKϊ
    if(monocroSample || nega){
        unsigned const char *sample = NULL;
        if(monocroSample)
            sample = [ monocroSample bytes ];
        [ visualLayer convertMonocroWithSample:sample priority:nega ];
    }
    
    [ compositeLayer lockFocus ];
    [ visualLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    // eLXg\
    if(novelLayerOn){
        [ novelLayer recache ];
        [ novelLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    } 
    // windowbackw肳Ăꍇɂ̓eLXgEChȄɃXvCg`B
    if(isWindowback) {
        [ overNovelLayer lockFocus ];
        NSRectFillUsingOperation(TYVirtualScreenRect(),NSCompositeClear);
        if(temp){
            [ temp draw ];
            while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
                [ temp draw ];
            }        
        }
        // o[̕`
        if(barDict) {
            [ [ barDict objectsSortedByKeyUsingSelector:@selector(compare:) ] makeObjectsPerformSelector:@selector(draw) ];
        }
        [ overNovelLayer unlockFocus ];
        [ overNovelLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    }
    // {^̕`
    if(isDrawButton){
        [ buttonManager draw ];
    }

    [ compositeLayer unlockFocus ];
}

// REMOVED: -voidupdateStageOnlyButton{
    [ compositeLayer lockFocus ];
    [ visualLayer compositeToPoint:NSZeroPoint operation:NSCompositeCopy ];
    if(novelLayerOn){
        [ novelLayer recache ];
        [ novelLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    }
    // windowbackw肳Ăꍇɂ̓eLXgEChȄɃXvCg`B
    if(isWindowback) {
        [ overNovelLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
        /*
        NSEnumerator *spriteEnumerator;
        TYNScrSprite *temp;
        
        spriteEnumerator = [ spriteArray objectEnumerator ];
        while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
            if([ temp spriteID ] <= humanz){
                break;
            }
        }
        
        if(temp){
            while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
                [ temp draw ];
            }
        }
         */
    }
    [ buttonManager draw ];
    [ compositeLayer unlockFocus ];
}

// REMOVED: -NSImage*visualLayer{
    return visualLayer;
}

// REMOVED: -NSImage*compositeLayer{
    return compositeLayer;
}

-(void)changeVisualLayer:(NSNumber*)effectNum
{
    int effectNo;
    
    effectNo = [ effectNum intValue ];
    
    // erasetextwindowݒ肪^̂ƂAeLXgEChE\Ȃ܂͂
    if(eraseTextWindow && novelLayerOn){
        [ this startEraseTextWindow:effectNum ];
        return ;
    }

    [ this updateStage ];

    // GtFNgWFl[^쐬
    if(effectGenerater)
        [ effectGenerater release ];
    effectGenerater = [ [ TYEffectGenerater alloc ] initWithBeforeImage:[ controller image ] afterImage:compositeLayer effect:[ effectDefDict objectForKey:[ NSNumber numberWithInt:(skipStatus & TYEffectCancelSkipMask) ? 1 : effectNo ] ] ];
    [ effectGenerater setDelegate:this ];

    [ engine setBreakRun:true ];
    
    // GtFNgI̎w쐬
    if(afterEffectObject)
        [ afterEffectObject release ];

    if([ (TYMainController*)controller status ] == TYPrinting ){
        afterEffectTarget = this;
        afterEffectSelector = @selector(printing);
        afterEffectObject = nullptr;
    } else {
        afterEffectTarget = engine;
        afterEffectSelector = @selector(runScript);
        afterEffectObject = nullptr;
    }    
}

// REMOVED: -voidflushNovelLayer{
    int page = [ [ TYEnviroment objectForKey:TYLookbackBufferPageEnviroment ] intValue ];
    
    // zobt@ɓ˂
    if(novelLayer && page) {
        int cnt;
        [ lookbackQueue addObject:[ (TYNovelLayer*)novelLayer lookbackObject ] ];
        cnt = [ lookbackQueue count ];
        if(cnt > page)
            [ lookbackQueue removeObjectsInRange:NSMakeRange(0,cnt -page) ];
    }
    
    [ novelLayer release ];
    novelLayer = [ [ TYNovelLayer alloc ] initNovelLayer ];
    [ (TYNovelLayer*)novelLayer setManager:this ];
    [ novelLayer recache ];

    [ compositeLayer lockFocus ];
    [ visualLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    [ novelLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    // windowbackw肳Ăꍇɂ̓eLXgEChȄɃXvCg`B
    if(isWindowback) {
        [ overNovelLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
        /*
        NSEnumerator *spriteEnumerator;
        TYNScrSprite *temp;
        
        spriteEnumerator = [ spriteArray objectEnumerator ];
        while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
            if([ temp spriteID ] <= humanz){
                break;
            }
        }
        
        if(temp){
            while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
                [ temp draw ];
            }
        }
         */
    }
    [ compositeLayer unlockFocus ];
    [ controller setImage:compositeLayer ];
    
}

// ̂ւ͌łƐ܂B
-(void)startAppearTextWindow:(NSNumber*)effectNum
{
    [ this updateStage ];
    
    // GtFNgWFl[^
    if(effectGenerater)
        [ effectGenerater release ];
    effectGenerater = [ [ TYEffectGenerater alloc ] initWithBeforeImage:[ controller image ] afterImage:compositeLayer effect:[ effectDefDict objectForKey:[ NSNumber numberWithInt:(skipStatus & TYEffectCancelSkipMask) ? 1 : WINDOW_EFFECT_NO ] ] ];
    [ effectGenerater setDelegate:this ];

    [ engine setBreakRun:true ];
    
    // GtFNgI̎w쐬
    afterEffectTarget = this;
    afterEffectSelector = @selector(resumePrinting);
    if(afterEffectObject)
        [ afterEffectObject release ];
    afterEffectObject = nullptr;

}

// REMOVED: -voidresumePrinting{    
    [ controller setStatus:TYPrinting ];
    [ this setStatus:TYTPPrinting ];
    [ this printing ];
}

-(void)startEraseTextWindow:(NSNumber*)effectNum
{
    novelLayerOn = false;

    // -updatestage͍sȂB̎_ł͕ύXfȂB

    // windowbackw肳Ăꍇ́AvisualLayerɃeLXgEChẼXvCg`悷
    // FIXME:Ẵ[`RsyȂ̂Ńt@N^OB
    [ visualLayer lockFocus ];
    if(isWindowback) {
        [ overNovelLayer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
        /*
        NSEnumerator *spriteEnumerator;
        TYNScrSprite *temp;
        
        spriteEnumerator = [ spriteArray objectEnumerator ];
        while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
            if([ temp spriteID ] <= humanz){
                break;
            }
        }
        
        if(temp){
            while( (temp = [ spriteEnumerator nextObject ]) != nullptr){
                [ temp draw ];
            }
        }
         */
    }
    [ visualLayer unlockFocus ];
    
    // GtFNgWFl[^
    if(effectGenerater)
        [ effectGenerater release ];
    effectGenerater = [ [ TYEffectGenerater alloc ] initWithBeforeImage:[ controller image ] afterImage:visualLayer effect:[ effectDefDict objectForKey:[ NSNumber numberWithInt:(skipStatus & TYEffectCancelSkipMask) ? 1 : WINDOW_EFFECT_NO ] ] ];
    [ effectGenerater setDelegate:this ];

    [ engine setBreakRun:true ];
    
    // GtFNgI̎w쐬
    afterEffectTarget = this;
    afterEffectSelector = @selector(changeVisualLayer:);
    if(afterEffectObject)
        [ afterEffectObject release ];
    afterEffectObject = effectNum;
    [ afterEffectObject retain ];
}

-(void)changeEffectionImage:(NSImage*)drawImage
{
   [ controller setImage:drawImage ];
}

// REMOVED: -voideffectFinished{
    // MEMO:effectblankŐݒ肳ꂽbɒ@悤
    // afterEffect`Őݒ肳ꂽe@
    [ afterEffectTarget performSelector:afterEffectSelector withObject:afterEffectObject afterDelay:0 ];
}

// REMOVED: -voidquakeFinished{
    if(effectGenerater){
        [ effectGenerater release ];
        effectGenerater=nullptr;
    }
    [ engine runScript ];
}
// REMOVED: -intstatus{
    return tpStatus;
}

-(void)setStatus:(int)status
{
    tpStatus = status;
    if(status == TYTPClickWait){
        if([ controller autoclickTimer]){
            [ this performSelector:@selector(select_action)
                        withObject:nullptr
                        afterDelay:[ controller autoclickTimer ] / 1000.0 ];
        }
    }
}

-(void)textPrint:(std::string)aString
{
    NSScanner *scanner;
    std::stringstr=nullptr;
    std::stringsymbol;
    std::vectorarray;

    [ controller setStatus:TYPrinting ];
    [ this setStatus:TYTPPrinting ];

    [ engine setBreakRun:true ];
    
    if(textQueue)
        [ textQueue autorelease ];
    // KvȂ當񒆂̕ϐWJs
    scanner = [ NSScanner scannerWithString:aString ];
    [ scanner scanUpToCharactersFromSet:charcterOfReferenceVarSet intoString:&str ];
    if([ scanner isAtEnd ]==false){
        array = [ NSMutableArray arrayWithCapacity:1 ];
        while(1){
            if(str)
                [ array addObject:str ];
            symbol = [ [ scanner string ] substringWithRange:NSMakeRange([ scanner scanLocation ],1) ];
            [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
            [ scanner scanCharactersFromSet:[ NSCharacterSet varNameCharacterSet ] intoString:&str ];
            if([ symbol isEqualToString:@"$" ]){
                [ array addObject:[ engine getStringOfArgment:[ NSString stringWithFormat:@"$%@",str ] ] ];
            } else if([ symbol isEqualToString:@"%" ]){
                int value;
                value = [ [ engine getValueOfArgment:[ symbol stringByAppendingString:str ] ] intValue ];
                [ array addObject:[ NSString stringWithFormat:@"%d",value ] ];
            }

            str = nullptr;
            [ scanner scanUpToCharactersFromSet:charcterOfReferenceVarSet intoString:&str ];
            if([ scanner isAtEnd ])
                break;
        }
        if(str)
            [ array addObject:str ];

        aString = [ array componentsJoinedByString:@"" ];
    }

    
    //textQueue = [ [ NSMutableAttributedString alloc ] initWithString:aString attributes:textAttDict ];
    textQueue = aString;
    [ textQueue retain ];
    nowStorageOffset = 0;
    nowStorageLength = [ textQueue length ];
    //NSLog(@"%@",[ textQueue attributesAtIndex:0 effectiveRange:nullptr ] );

    // łɕ\ĂΕ`揈Jn
    [ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
}

// REMOVED: -voiddrawTextWindow{
    if([ textWindow isKindOfClass:[ NSColor class ] ]){
        [ textWindow set ];
        NSRectFillUsingOperation(textWindowRect,NSCompositeSourceOver);
    } else if(textWindow) {
        [ textWindow compositeToPoint:textWindowRect.origin operation:NSCompositeSourceOver ];
    }    
}

// REMOVED: -NSRecttextWindowRect{
    return textWindowRect;
}

-(void)drawChar:(std::string)charStr color:(NSColor*)color atColumn:(int)column atRow:(int)row
{
    NSTextStorage *storage;
    NSPoint drawPoint;
    NSRange actRange;
    
    drawPoint.x = textLeftOffset +(textFontWidth +textPitchx) *column;
    drawPoint.y = VSCREEN_HEIGHT -textTopOffset -(textFontHeight +textPitchy) *row -textFontHeight;
    if(textShadowed && (floor(NSAppKitVersionNumber) < MAC_OS_X_VERSION_10_3)){
        storage = [ [ [ NSTextStorage alloc ] initWithString:charStr attributes:textShadowAttDict ] autorelease ];
        [ layoutManager replaceTextStorage:storage ];
        [ layoutManager glyphRangeForCharacterRange:NSMakeRange(0,1) actualCharacterRange:&actRange ];
        [ layoutManager drawGlyphsForGlyphRange:actRange atPoint:NSMakePoint(drawPoint.x+SHADOW_TICKNESS,drawPoint.y-SHADOW_TICKNESS) ];
        [ storage addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(0,1) ];
    } else {
        storage = [ [ [ NSTextStorage alloc ] initWithString:charStr attributes:textShadowAttDict ] autorelease ];
        [ storage addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(0,1) ];
        [ layoutManager replaceTextStorage:storage ];
        [ layoutManager glyphRangeForCharacterRange:NSMakeRange(0,1) actualCharacterRange:&actRange ];
    }
    
    [ layoutManager replaceTextStorage:storage ];
    [ layoutManager drawGlyphsForGlyphRange:actRange atPoint:drawPoint ];
}

-(void)drawAttStr:(NSAttributedString*)str atColumn:(int)column atRow:(int)row
{
    NSColor *color;
    NSTextStorage *storage;
    NSPoint drawPoint;
    NSRange actRange;

    drawPoint.x = textLeftOffset +(textFontWidth +textPitchx) *column;
    drawPoint.y = VSCREEN_HEIGHT -textTopOffset -(textFontHeight +textPitchy) *row -textFontHeight;
    if(textShadowed && (floor(NSAppKitVersionNumber) < NSAppKitVersionNumber10_2)){
        color = [ [ str fontAttributesInRange:NSMakeRange(0,1) ] objectForKey:NSForegroundColorAttributeName ];
        storage = [ [ [ NSTextStorage alloc ] initWithAttributedString:str ] autorelease ];
        [ storage addAttribute:NSForegroundColorAttributeName value:[ NSColor blackColor ] range:NSMakeRange(0,1) ];
        [ layoutManager replaceTextStorage:storage ];
        [ layoutManager glyphRangeForCharacterRange:NSMakeRange(0,1) actualCharacterRange:&actRange ];
        [ layoutManager drawGlyphsForGlyphRange:actRange atPoint:NSMakePoint(drawPoint.x+SHADOW_TICKNESS,drawPoint.y-SHADOW_TICKNESS) ];
        [ storage addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(0,1) ];
    } else {
        storage = [ [ [ NSTextStorage alloc ] initWithAttributedString:str ] autorelease ];
        [ layoutManager replaceTextStorage:storage ];
        [ layoutManager glyphRangeForCharacterRange:NSMakeRange(0,1) actualCharacterRange:&actRange ];
    }

    [ layoutManager replaceTextStorage:storage ];
    [ layoutManager drawGlyphsForGlyphRange:actRange atPoint:drawPoint ];
}

// REMOVED: -NSPointdrawPoint{
    NSPoint drawPoint;

    drawPoint.x = textLeftOffset +(textFontWidth +textPitchx) *nowColumn;
    drawPoint.y = VSCREEN_HEIGHT -textTopOffset -(textFontHeight +textPitchy) *nowRow;

    return drawPoint;
}

// {Ƃł͂ȂAɉ͂܂ĕKvȂ\AƂۂ̂ő啝ɂtextPrint:ȂKv邩B
// REMOVED: -voidprinting{
    NSDate *date = [ NSDate date ];
    //NSTextStorage *shadowStrage;
    NSTextStorage *charStorage;

    // y[W҂̂ȂAnovelLayer,compositeLayertbV
    if(waitNewPage){
        waitNewPage = false;
        nowRow=0;
        nowColumn=0;
        locateX=0;
        waitCountOfChar = 0;
        [ this flushNovelLayer ];
        [ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
        return;
    }

    // c蕶𒲂ׁAΏBȂ΃XNvgĐɖ߂
    if( nowStorageOffset >= nowStorageLength ){
        if(forceWaitNewPage){
            forceWaitNewPage = false;
            waitNewPage = true;
            invalidNewLine = true;
            [ this setClickWait:true ];
            return;
        } else if(forceClickWait){
            forceClickWait = false;
            [ this setClickWait:false ];
            return;
        }
        if(linepage && !linepageWait){
            linepageWait = true;
            waitNewPage = true;
            [ this setClickWait:true ];
            return;
        }
        linepageWait = false;
        
        if((!invalidNewLine)&&(nowColumn)){
            nowRow++;
            [ (TYNovelLayer*)novelLayer pushNewLine ];
            nowColumn = locateX;
        }
        [ controller setStatus:TYScriptRunningStatus ];
        [ engine lineEnd ];// s̏IʒmB
        [ engine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    } else {
        NSPoint drawPoint;
        NSRange actRange;
        std::stringcurrentStr;

        currentStr = [ textQueue substringWithRange:NSMakeRange(nowStorageOffset,1) ];
        
        invalidNewLine = false;
        
        // \̓ꖽ߂ǂ̃`FbN
        if([ currentStr isEqualToString:@"@" ]){
            nowStorageOffset++;
            forceClickWait = false;
            [ this setClickWait:false ];
            return;
        } else if([ currentStr isEqualToString:@"\\" ]){
            nowStorageOffset++;
            forceWaitNewPage = false;
            forceClickWait = false;
            waitNewPage = true;
            invalidNewLine = true;
            [ this setClickWait:true ];
            return;
        } else if([ currentStr isEqualToString:@"/" ]){ // ̉s𖳎
            invalidNewLine = true;
            nowStorageOffset++;
            [ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
            return;
        } else if([ currentStr isEqualToString:@"#" ]){ // Fw
            textFontColor = getColorWithHTMLFormat([ textQueue substringWithRange:NSMakeRange(nowStorageOffset,7) ]);
            [ this makeAttributeDict ];
            nowStorageOffset += 7;
            [ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
            return ;
        /* ϐ_v
        } else if([ currentStr isEqualToString:@"%" ]){
        } else if([ currentStr isEqualToString:@"$" ]){
        */
        } else if([ currentStr isEqualToString:@"!" ]){
            int value;
            int length;
            
            // !݂̂ŏIĂ镶ւ̑Ώ
            if([ textQueue length ] < nowStorageOffset+2){
                nowStorageOffset++;
                return;
            }
                
            currentStr = [ textQueue substringWithRange:NSMakeRange(nowStorageOffset+1,1) ];
            if([ currentStr isEqualToString:@"w" ]){ // EFCg(LZs)
                if(!scanIntAndLengthFromString([ textQueue substringFromIndex:nowStorageOffset+2 ],&value,&length)){
                    // Oׂ
                    ;
                }
                [ this performSelector:@selector(printing) withObject:nullptr afterDelay:value / 1000.0 ];
                nowStorageOffset += length +2;
                return;
            } else if([ currentStr isEqualToString:@"d" ]){ // fBC(LZ)
                if(!scanIntAndLengthFromString([ textQueue substringFromIndex:nowStorageOffset+2 ],&value,&length)){
                    // Oׂ
                    ;
                }
                [ this setStatus:TYTPClickWait ];
                [ this performSelector:@selector(select_action) withObject:nullptr afterDelay:value / 1000.0 ];
                nowStorageOffset += length +2;
                return;
            } else if([ currentStr isEqualToString:@"s" ]) { // eLXgXs[h
                if([ [ textQueue substringWithRange:NSMakeRange(nowStorageOffset +2,1) ] isEqualToString:@"d" ]){
                    // j[I΂ĂXs[hɐݒ
                    textSpeed = &userTextSpeed;
                    nowStorageOffset += 3;
                } else {
                    if(!scanIntAndLengthFromString([ textQueue substringFromIndex:nowStorageOffset +2 ],&value,&length)){
                        ;
                    }
                    scriptTextSpeed = value;
                    textSpeed = &scriptTextSpeed;
                    nowStorageOffset += length +2;
                }
                [ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
                return ;
            }
            // OグB
            ;
        }

        // eLXgEChE\ĂȂ܂͕\B
        if(!novelLayerOn){
            novelLayerOn = true;
            //[ this setNextPerformSelector:@selector(printing) ];
            [ this startAppearTextWindow:[ NSNumber numberWithInt:WINDOW_EFFECT_NO ] ];
            return ;
        }
        
        // 
        if(nowColumn>=textColumn){
            nowColumn=locateX;
            nowRow++;
            [ (TYNovelLayer*)novelLayer pushNewLine ];
        } else if(nowColumn+1==textColumn) {
            if((nowStorageOffset+1 < nowStorageLength) &&
              [ [ NSScanner scannerWithString:
[ textQueue substringWithRange:NSMakeRange(nowStorageOffset+1,1) ] ] scanCharactersFromSet:hyphenationSet intoString:nullptr ]){
                nowColumn=locateX;
                nowRow++;
                [ (TYNovelLayer*)novelLayer pushNewLine ];
            }
        }
        
        
        // NbN҂iݒ肳Ă΁j̃`FbN
        if([ currentStr isEqualToString:@"_" ]){
            nowStorageOffset++;
            if( nowStorageOffset >= nowStorageLength ){
                [ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
                return;
            }
            currentStr = [ textQueue substringWithRange:NSMakeRange(nowStorageOffset,1) ];
        } else {
            // ONbN҂𖳎ȊO̎`FbNBAꍇ͍Ō̂ݗLƂB
            if((clickStrSet)&&([ [ NSScanner scannerWithString:currentStr ] scanCharactersFromSet:clickStrSet intoString:nullptr ])){
                if(textRow -nowRow -1 <= clickStrUnderLimit ){
                    forceWaitNewPage = true;
                } else {
                    forceClickWait = true;
                }
            } else if(forceClickWait){
                forceClickWait = false;
                [ this setClickWait:false ];
                return;
            } else if(forceWaitNewPage){
                forceWaitNewPage = false;
                waitNewPage = true;
                invalidNewLine = true;
                [ this setClickWait:true ];
                return;
            }
        }

        drawPoint.x = textLeftOffset +(textFontWidth +textPitchx) *nowColumn;
        drawPoint.y = VSCREEN_HEIGHT -textTopOffset -(textFontHeight +textPitchy) *nowRow -textFontHeight;
        //[ layoutManager replaceTextStorage:textQueue ];
        [ compositeLayer lockFocus ];
        if(textShadowed && (floor(NSAppKitVersionNumber) < NSAppKitVersionNumber10_2)){
            charStorage = [ [ NSTextStorage alloc ] initWithString:currentStr attributes:textShadowAttDict ];
            [ charStorage autorelease ];
            
            [ layoutManager replaceTextStorage:charStorage ];

            [ layoutManager drawGlyphsForGlyphRange:
                [ layoutManager glyphRangeForCharacterRange:NSMakeRange(0,1) actualCharacterRange:&actRange ]
                 atPoint:NSMakePoint(drawPoint.x +SHADOW_TICKNESS,drawPoint.y -SHADOW_TICKNESS) ];
            [ charStorage addAttribute:NSForegroundColorAttributeName value:textFontColor range:NSMakeRange(0,1) ];
            [ layoutManager replaceTextStorage:charStorage ];
            [ layoutManager drawGlyphsForGlyphRange:actRange atPoint:drawPoint ];
        } else {
            charStorage = [ [ NSTextStorage alloc ] initWithString:[ textQueue substringWithRange:NSMakeRange(nowStorageOffset,1) ] attributes:textAttDict ];
            [ charStorage autorelease ];
            [ layoutManager replaceTextStorage:charStorage ];
            [ layoutManager drawGlyphsForGlyphRange:[ layoutManager glyphRangeForCharacterRange:NSMakeRange(0,1) actualCharacterRange:&actRange ] 
 atPoint:drawPoint ];
        }

        /* \邽߁ARgAEg
        if(isWindowback) {
            NSRect aRect;
            NSGlyph glyph;
            NSRect bRect;
            glyph = [ layoutManager glyphAtIndex:0 ];
            bRect = [ textFont boundingRectForGlyph:glyph ];
            aRect = TYFontRect(&drawPoint,&bRect,textShadowed);
            [ overNovelLayer compositeToPoint:aRect.origin fromRect:aRect operation:NSCompositeSourceOver ];
        }
         */
        
        [ compositeLayer unlockFocus ];

        [ (TYNovelLayer*)novelLayer pushAttributedString:charStorage ];
        
        {
            NSGlyph glyph;
            NSRect bRect;
            glyph = [ layoutManager glyphAtIndex:0 ];
            bRect = [ textFont boundingRectForGlyph:glyph ];
            [ controller setImage:compositeLayer inRect:TYFontRect(&drawPoint,&bRect,textShadowed) ];
        }

        nowColumn++;
        nowStorageOffset++;
        [ this performSelector:@selector(printing) withObject:nullptr afterDelay:
            ((skipStatus & TYNoTimeWaitSkipMask) ? 0 : *textSpeed / 1000.0) +[ date timeIntervalSinceNow ] ];
    }    
}

-(void)setClickWait:(bool)pageWait
{
    NSPoint point;
    int count;

    
    if(skipStatus==TYNoSkip || skipStatus==TYOnetimeSkipMask ||(skipStatus & TYAutoModeSkipMask)){
        int columnbuf;

        count = nowRow * textColumn + nowColumn;
        if(count < waitCountOfChar)
            waitCountOfChar = 0;

        if(textgosubLabel){
            isPage = pageWait;
            [ engine fireOfTextgosub:textgosubLabel ];
        } else {                
            currentCursor = (pageWait) ? pageWaitCursor : clickWaitCursor;
            if(nowColumn>=textColumn){
                columnbuf=nowColumn;
                nowColumn=locateX;
                nowRow++;
                point=[ this drawPoint ];
                [ currentCursor drawToView:controller point:point ];
                nowColumn=columnbuf;
                nowRow--;
            } else {
                point=[ this drawPoint ];
                [ currentCursor drawToView:controller point:point ];
            }
            if(skipStatus & TYAutoModeSkipMask){
                if(playingSoundFlg)
                    waitFinishSound=true;
                else {
                    if(automodeWaitType == TYNumOfCharsAutomodeWait)
                        [ this performSelector:@selector(automode_select_action) withObject:nullptr afterDelay:(count -waitCountOfChar) *automodeWait / 1000.0 ];
                    else
                        [ this performSelector:@selector(automode_select_action) withObject:nullptr afterDelay:automodeWait / 1000.0 ];
                }
            }
        }
        [ this setStatus:TYTPClickWait ];
        
        if(skipStatus == TYOnetimeSkipMask){
            [ this setSkipStatus:TYNoSkip ];
        }

        waitCountOfChar = count;
        
        return;
    } else {
        [ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
        return;
    }
}

-(void)setSkipStatus:(int)aStatus
{
    skipStatus = aStatus;
    if(aStatus && ([ controller status ] == TYPrinting)&&([ this status ] == TYTPClickWait)){
        if(aStatus != TYAutoModeSkipMask)
            [ this select_action ];
        else
            [ this automode_select_action ];
    }
}

// REMOVED: -intskipStatus{
    return skipStatus;
}

// REMOVED: -NSImage*textWindow{
    return textWindow;
}

// REMOVED: -voidmakeAttributeDict{
    int fontSize;
    
    // MEMO:fontSize͎b菈BAcɂΉKvB
    fontSize = (textFontWidth <= textFontHeight) ? textFontWidth : textFontHeight;
    textFont = [ NSFont fontWithName:textFontName size:fontSize *1.0 ]; // NScript̕`ƊoႤ̂ŒKv?
    // Bold
    if(textBold && [ TYEnviroment boolForKey:TYEnableBoldFontEnviroment ])
        textFont = [ [ NSFontManager sharedFontManager ] convertFont:textFont toHaveTrait:NSBoldFontMask ];
    
    displayFontSize = [ textFont boundingRectForFont ].size;

    /*
    if([ [ layoutManager textContainers ] count ]){
        [ layoutManager removeTextContainerAtIndex:0 ];
        [ layoutManager addTextContainer:[ [ NSTextContainer alloc ] initWithContainerSize:NSZeroSize ] ];
    }
    */

    if(textAttDict)
        [ textAttDict autorelease ];
    textAttDict = [ [ NSMutableDictionary alloc ] initWithObjectsAndKeys:
                    textFont,NSFontAttributeName,nullptr ];
    if(textShadowAttDict)
        [ textShadowAttDict autorelease ];
    textShadowAttDict = [ textAttDict mutableCopyWithZone:[ textShadowAttDict zone ] ];
    
    // APIɂhbvVhE(10.3ȍ~)
    if ((floor(NSAppKitVersionNumber) > NSAppKitVersionNumber10_2) && 
        (textShadowed == true)) {
        NSShadow *shadowObj = [ [ [ NSShadow alloc ] init ] autorelease ]; 
        [ shadowObj setShadowOffset:NSMakeSize(2,-2) ];
        [ shadowObj setShadowBlurRadius:1.0 ];
        [ shadowObj setShadowColor:
            [ NSColor colorWithCalibratedRed:0
                                    green:0
                                        blue:0
                                    alpha:1 ] ];

        [ textAttDict setObject:shadowObj forKey:NSShadowAttributeName ];
    } else {
        
        if(textShadowAttDict)
            [ textShadowAttDict autorelease ];
        textShadowAttDict = [ textAttDict mutableCopyWithZone:[ textShadowAttDict zone ] ];
    }

    [ textAttDict setObject:textFontColor forKey:NSForegroundColorAttributeName ];
                    
    //[ textShadowAttDict setObject:[ NSColor blackColor ] forKey:NSForegroundColorAttributeName ];
}

// REMOVED: -std::maptextAttDict{ return textAttDict; }

// REMOVED: -inttextFontWidth{ return textFontWidth; }

// REMOVED: -inttextFontHeight{ return textFontHeight; }

// REMOVED: -inttextPitchx{ return textPitchx; }

// REMOVED: -boolisShadow{ return textShadowed; }

-(void)updateSprites:(NSNotification*)notification
{
    // MEMO:XvCgRect݂̂̍XVɍœKׂB
    [ this updateStage ];
    [ controller setImage:compositeLayer ];    
}

-(void)startWaveSound:(NSNotification*)aNotification
{
    playingSoundFlg=true;
}

-(void)stopWaveSound:(NSNotification*)aNotification
{    
    playingSoundFlg=false;
    if(waitFinishSound){
        waitFinishSound=false;
        [ this performSelector:@selector(automode_select_action) withObject:nullptr afterDelay:0 ];
    } else if (waitFinishSoundOnBtnTime2 == true) {
        waitFinishSoundOnBtnTime2 = false;
        [ this performSelector:@selector(other_action:) withObject:[ NSNumber numberWithInt:-5 ] afterDelay:0 ];
    }
}

- (void)changeFont:(void*)fontManager
{
    NSFont*	dummyFont = NSFont->fontWithName(@"Times", size, 14);
    NSFont*	newFont;
    
    newFont = fontManager->convertFont(dummyFont);
    
    NSLog(@"font Name = %@",[ newFont fontName ]);
    textFontName = [ newFont fontName ];
    [ TYEnviroment setObject:textFontName forKey:TYFontNameEnviroment ];
    
    [ this makeAttributeDict ];
}

- (void)changeTextSpeed:(int)index
{
    userTextSpeed = [ [ defaultSpeed objectAtIndex:index ] intValue ];
}

- (void)setAutoMode:(int)speed
           waitType:(int)type
               wait:(int)wait
{
    [ this setSkipStatus:TYAutoModeSkipMask ];
    userTextSpeed = speed;
    textSpeed=&userTextSpeed;
    automodeWait = wait;
    automodeWaitType = type;
}

// REMOVED: -intuserTextSpeed{
    return userTextSpeed;
}

-(void)responseButton:(int)result
{
    std::vectorargments;

    isDrawButton = false;
    
    // ^C}̃ANVB
    [ NSObject cancelPreviousPerformRequestsWithTarget:this selector:@selector(other_action:) object:nullptr ];
    
    // ϐɌʂ
    argments = [ NSMutableArray arrayWithCapacity:3 ];
    [ argments addObject:[ NSNull null ] ];
    [ argments addObject:buttonTargetValue ];
    [ argments addObject:[ NSNumber numberWithInt:(result < 0) ? result : [ buttonManager selectedButtonID ] ] ]; 
    [ engine performSelector:@selector(ty_mov:) withObject:argments ];

    // Iʂ0傫ꍇ͑ɉB
    if(result >  0 && releaseButtonAfterSelect){
        [ buttonManager release ];
        buttonManager = [ [ TYExtraButtonManager alloc ] initWithStageManager:this
                                                                  sourceImage:nullptr ];
    }

    // ViewɌ݂̃ItXN[̃Rs[ۑ
    [ controller setImage:[ [ compositeLayer copyWithZone:[ compositeLayer zone ] ] autorelease ] ];
    
    // XNvg̏ĊJ
    [ engine runScript ];
}

-(void)changeSelectedButton:(unsigned int)btnIndex
{
    if(btnIndex != beforeSelectButtonID){
        [ buttonManager changeSelection:btnIndex ];
        [ controller setImage:compositeLayer ];
        beforeSelectButtonID = btnIndex;
    }
}

// REMOVED: -voidresponseSelection{
    int result;
    
    result = [ selectionManager selectedButtonID ];
    if(!result){
        return ;
    }

    [ this flushNovelLayer ];
    nowRow=0;
    nowColumn=0;
    locateX=0;
    
    [ engine eval:[ selectAction objectAtIndex:result -1 ] ];
    [ selectAction release ];
    [ selectionManager release ];
    [ engine runScript ];

}

-(void)changeSelection:(int)index
{
    if([ selectionManager changeSelection:index ]){
        [ controller setImage:compositeLayer ];
    }
}

// -dealloc (destructor in C++)
~ClassName() {
    if(effectGenerater)
        [ effectGenerater release ];
    [ super dealloc ];
}

// REMOVED: -voidautomode_select_action{
    if(tpStatus == TYTPClickWait) {
        [ this setStatus:TYTPPrinting ];
        //[ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
        [ currentCursor clear ];
        currentCursor = nullptr;
        [ this resumePrinting ];        
    }
}

// protocol implementations
// REMOVED: -voidselect_action{
    
    switch ([ controller status ]){
    case TYPrinting:
        switch (tpStatus) {
        case TYTPClickWait:
            if(skipStatus == TYAutoModeSkipMask) {
                [ this setSkipStatus:TYNoSkip ];
                return;
            }
            [ NSObject cancelPreviousPerformRequestsWithTarget:this selector:@selector(automode_select_action) object:nullptr ];
            [ this setStatus:TYTPPrinting ];
            //[ this performSelector:@selector(printing) withObject:nullptr afterDelay:0 ];
            [ currentCursor clear ];
            currentCursor = nullptr;
            [ this resumePrinting ];
            break;
        case TYTPPrinting:
            if(skipStatus==TYNoSkip){
                [ this setSkipStatus:TYOnetimeSkipMask ];
            } else {
                if(skipStatus==TYKidokuSkipMask){
                    [ engine setWatchKidoku:false ];
                }
                [ this setSkipStatus:TYNoSkip ];
            }
            break;
        default:
            ;
        }
        break;
    case TYButtonWaitStatus:
        [ this responseButton:beforeSelectButtonID ];
        return;
    case TYSelectStatus:
        [ this responseSelection ];
    default:
        ;
    }

}

-(IBAction)cancel_action:(void*)sender
{
    switch ([ controller status ]) {
    case TYButtonWaitStatus:
        [ this responseButton:-1 ];
        return;
    default :
        if([ this status ] == TYTPClickWait){
            [ controller openRightclickMenu:nullptr ];
        }
    }
}

// REMOVED: -voidup_action{
    switch ([ controller status ]){
    case TYButtonWaitStatus:
        [ this changeSelectedButton:[ buttonManager decToIndex ] ];
        return;
    case TYSelectStatus:
        if([ selectionManager selectedIndex ] <= 1)
            [ controller enterLookback:nullptr ];
        else
            [ this changeSelection:[ selectionManager decToIndex ] ];
        break;
    default:
        if([ this status ]==TYTPClickWait){
            [ controller enterLookback:nullptr ];
        }
    }
}

// REMOVED: -voiddown_action{
    switch ([ controller status ]){
    case TYButtonWaitStatus:
        [ this changeSelectedButton:[ buttonManager incToIndex ] ];
        return;
    case TYSelectStatus:
        [ this changeSelection:[ selectionManager incToIndex ] ];
    default:
        ;
    }
}

-(void)move_mouse:(NSPoint)point
{
    const unsigned char *ptr;
    int btnIndex;
    
    //@View͈͓̔`FbN

    switch([ controller status ]){
    case TYButtonWaitStatus:
        if(NSPointInRect(point,TYVirtualScreenRect())){
            ptr = (const unsigned char*)[ [ buttonManager rectMap ] bytes ];
            ptr += (int)point.x +(int)point.y *VSCREEN_WIDTH;
            btnIndex = *ptr;
        } else {
            btnIndex = 0;
        }
        [ this changeSelectedButton:btnIndex ];
        break;
    case TYSelectStatus:
        if(NSPointInRect(point,TYVirtualScreenRect())){
            ptr = (const unsigned char*)[ [ selectionManager rectMap ] bytes ];
            ptr += (int)point.x +(int)point.y *VSCREEN_WIDTH;
            btnIndex = *ptr;
        } else {
            btnIndex = 0;
        }
        [ this changeSelection:btnIndex ];
        break;
    default:
        ;
    }
}

-(void)other_action:(void*)code
{
    switch([ controller status ]){
    case TYButtonWaitStatus:
        [ this responseButton:[ code intValue ] ];
        break;
    default:
        ;
    }
}

// REMOVED: -voidenterSystemMode{
    [ currentCursor stop ];
}

-(void)exitSystemModeResumeStatus:(bool)aBool
{
    if(aBool){
        switch ([ controller status ]){
        case TYPrinting:
            [ currentCursor resume ];
        case TYSelectStatus:
        default:
            [ controller setImage:compositeLayer ];
            break;
        }
    }
}

// REMOVED: -boolisPossibleEnterSystemMode{
    switch([ this status ]){
    case TYTPClickWait:
        return true;
    default :
        return false;
    }
}

// @end
