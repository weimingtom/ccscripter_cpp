// Converted from TYQTMPController.h
// TODO: Manual review and fixes required

/* TYQTMPController */



class TYQTMPController : public NSObject {
    IBOutlet NSMovieView *MovieViewObject;
}
};
