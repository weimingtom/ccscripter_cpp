QT += core
QT -= gui

CONFIG += c++11
CONFIG += console

TARGET = tukuyomi_qt
TEMPLATE = app

# Main library source files
SOURCES += \
    TYDecompresser_qt.cpp \
    TYArchiver_qt.cpp \
    TYBitOperator_qt.cpp \
    TYImageUtil_qt.cpp \
    TYResourceServer_qt.cpp \
    TYSoundController_qt.cpp \
    TYWave2Aiff_qt.cpp \
    TYWaveBooster_qt.cpp \
    TYMiscUtil_qt.cpp \
    TYEnviroment_qt.cpp \
    TYEffectPatternMap_qt.cpp \
    TYEffecter_qt.cpp \
    TYArgmentArray_qt.cpp \
    TYSarArchiver_qt.cpp \
    TYSarArchivedFile_qt.cpp \
    TYNsaArchiver_qt.cpp \
    TYNsaArchivedFile_qt.cpp \
    spb_qt.cpp \
    TYScripterValues_qt.cpp \
    TYArrayValue_qt.cpp \
    TY_NSStringAddition_qt.cpp \
    TY_NSDataAddtion_qt.cpp \
    TYLoopValue_qt.cpp \
    TYSaveDataCoding_qt.cpp \
    TYFileLog_qt.cpp \
    TYWaveDecorder_qt.cpp \
    TYInstantGenerater_qt.cpp \
    TYCrossFadeGenerater_qt.cpp \
    TYScrollEffectGenerater_qt.cpp \
    TYShutterEffectGenerater_qt.cpp \
    TYCartainEffectGenerater_qt.cpp \
    TYMosaicEffectGenerater_qt.cpp \
    TYQuakeEffectGenerater_qt.cpp \
    TYPatternFadeGenerater_qt.cpp \
    TYPatternCrossFadeGenerater_qt.cpp \
    TYBGLZSSDecorder_qt.cpp \
    TYKeyBind_qt.cpp \
    TYNBZDecompresser_qt.cpp \
    TYSaveLoadManager_qt.cpp \
    TYLIBSNDFileDecorder_qt.cpp \
    TYOggVorbisDecoder_qt.cpp \
    TYCCSProxy_qt.cpp \
    TYExecutablePlugin_qt.cpp \
    TYScriptEngine_qt.cpp \
    TYEffectGenerater_qt.cpp \
    TYAnimationCellImage_qt.cpp \
    TYScriptData_qt.cpp \
    TYScriptStream_qt.cpp \
    TYNScrSprite_qt.cpp \
    TYNovelLayer_qt.cpp \
    TYLookbackLayer_qt.cpp \
    TYPreferencePanelController_qt.cpp \
    TYRespondRectManager_qt.cpp \
    TYSelectionManager_qt.cpp \
    TYStageManager_qt.cpp \
    TYBGMVolumeController_qt.cpp \
    lzss_qt.cpp

HEADERS += \
    TYDecompresser_qt.h \
    TYArchiver_qt.h \
    TYBitOperator_qt.h \
    TYImageUtil_qt.h \
    TYResourceServer_qt.h \
    TYSoundController_qt.h \
    TYWave2Aiff_qt.h \
    TYWaveBooster_qt.h \
    TYMiscUtil_qt.h \
    TYEnviroment_qt.h \
    TYEffectPatternMap_qt.h \
    TYEffecter_qt.h \
    TYArgmentArray_qt.h \
    TYSarArchiver_qt.h \
    TYSarArchivedFile_qt.h \
    TYNsaArchiver_qt.h \
    TYNsaArchivedFile_qt.h \
    spb_qt.h \
    TYScripterValues_qt.h \
    TYArrayValue_qt.h \
    TY_NSStringAddition_qt.h \
    TY_NSDataAddtion_qt.h \
    TYLoopValue_qt.h \
    TYSaveDataCoding_qt.h \
    TYFileLog_qt.h \
    TYWaveDecorder_qt.h \
    TYInstantGenerater_qt.h \
    TYCrossFadeGenerater_qt.h \
    TYScrollEffectGenerater_qt.h \
    TYShutterEffectGenerater_qt.h \
    TYCartainEffectGenerater_qt.h \
    TYMosaicEffectGenerater_qt.h \
    TYQuakeEffectGenerater_qt.h \
    TYPatternFadeGenerater_qt.h \
    TYPatternCrossFadeGenerater_qt.h \
    TYBGLZSSDecorder_qt.h \
    TYKeyBind_qt.h \
    TYNBZDecompresser_qt.h \
    TYSaveLoadManager_qt.h \
    TYLIBSNDFileDecorder_qt.h \
    TYOggVorbisDecoder_qt.h \
    TYCCScripterProxy_qt.h \
    TYCCSProxy_qt.h \
    TYExecutablePlugin_qt.h \
    TYScriptEngine_qt.h \
    TYEffectGenerater_qt.h \
    TYAnimationCellImage_qt.h \
    TYScriptData_qt.h \
    TYScriptStream_qt.h \
    TYNScrSprite_qt.h \
    TYNovelLayer_qt.h \
    TYLookbackLayer_qt.h \
    TYPreferencePanelController_qt.h \
    TYRespondRectManager_qt.h \
    TYSelectionManager_qt.h \
    TYStageManager_qt.h \
    TYBGMVolumeController_qt.h \
    lzss_qt.h

# Build instructions:
# 1. Install Qt6: sudo apt install qt6-base-dev
# 2. Install dependencies: sudo apt install libbz2-dev libvorbis-dev libsndfile1-dev
# 3. Build: qmake tukuyomi_qt.pro && make

# Converted modules (45 modules, 90 files):
# =======================
# Compression: lzss, spb, TYNBZDecompresser
# Archives: TYSarArchiver, TYSarArchivedFile, TYNsaArchiver, TYNsaArchivedFile
# Audio: TYSoundController, TYWave2Aiff, TYWaveBooster, TYWaveDecorder, TYLIBSNDFileDecorder, TYOggVorbisDecoder
# Image/Effects: TYImageUtil, TYEffectPatternMap, TYEffecter + 9 generators
# Script Engine: TYScripterValues, TYArgmentArray, TYLoopValue, TYScriptEngine, TYArrayValue
# Utils: TYEnviroment, TYMiscUtil, TY_NSStringAddition, TY_NSDataAddtion, TYKeyBind, TYFileLog, TYSaveLoadManager
# Plugins: TYCCScripterProxy, TYCCSProxy, TYExecutablePlugin
#
# NOT converted (requires QtWidgets):
# - All UI classes (TYFullScreenContentView, TYMenuModeView, TYButtonManager, TYBar, etc.)
# - NscrParser (requires bison/flex)
# - Video playback (QuickTime)