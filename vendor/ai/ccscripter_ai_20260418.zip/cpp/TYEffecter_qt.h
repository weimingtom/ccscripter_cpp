/*
 *  TYEffecter.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Effect manager and image effect generation.
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSMutableDictionary-> QMap
 *  NSDate            -> QDateTime
 *  NSImage*          -> QImage
 *  NSValue*          -> QVariant
 */

#ifndef TYEFFECTER_QT_H
#define TYEFFECTER_QT_H

#include <QObject>
#include <QImage>
#include <QString>
#include <QMap>
#include <QVariant>
#include <QDateTime>

// Effect types
enum TYEffectType {
    TYEffectCached = 0,           // No change, cached only
    TYEffectInstant,              // Instant display
    TYEffectLeftShutter,          // Left shutter
    TYEffectRightShutter,         // Right shutter
    TYEffectTopShutter,           // Top shutter
    TYEffectBottomShutter,        // Bottom shutter
    TYEffectLeftCartain,          // Left curtain
    TYEffectRightCartain,         // Right curtain
    TYEffectTopCartain,           // Top curtain
    TYEffectBottomCartain,        // Bottom curtain
    TYEffectCrossFadeWithPixel,   // Pixel-based crossfade
    TYEffectLeftScroll,           // Scroll left
    TYEffectRightScroll,          // Scroll right
    TYEffectTopScroll,           // Scroll top
    TYEffectBottomScroll,         // Scroll bottom
    TYEffectFadeWithMask,         // Mask-based fade
    TYEffectMosaicOut,            // Mosaic out
    TYEffectMosaicIn,             // Mosaic in
    TYEffectCrossFadeWithMask,     // Mask-based crossfade
    TYEffectCrossFade             // Default crossfade
};

// Effect direction flags
enum TYEffectDirection {
    TYTopDirection = 1,
    TYBottomDirection = 2,
    TYLeftDirection = 4,
    TYRightDirection = 8
};

// Effect numbers
namespace TYEffectNo {
    const int Window = -2;
    const int Local = -1;
    const int Chached = 0;
    const int Instant = 1;
}

// Effect definition struct (replaces typedef struct)
struct TYEffectDefinition {
    TYEffectType type;
    int time;
    QString path;
};

// Inline factory (replaces static __inline__ TYEffectDefinition TYMakeEffectDefinition)
inline TYEffectDefinition TYMakeEffectDefinition(TYEffectType aType, int aTime, const QString& aPath) {
    TYEffectDefinition effdef;
    effdef.type = aType;
    effdef.time = aTime;
    effdef.path = aPath;
    return effdef;
}

// Effect definition wrapper (replaces TYEffectDefinitionValue)
class TYEffectDefinitionValue : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)valueWithEffectDefinition:(TYEffectDefinition)aDefinition
    static TYEffectDefinitionValue* create(const TYEffectDefinition& definition);
    
    // Replaces: -(id)initWithEffectDefinition:(TYEffectDefinition)aDefinition
    explicit TYEffectDefinitionValue(const TYEffectDefinition& definition, QObject* parent = nullptr);
    
    // Replaces: -(void)getValue:(void *)buffer
    void getValue(TYEffectDefinition* buffer) const;
    
    TYEffectDefinition definition() const { return m_definition; }
    
private:
    TYEffectDefinition m_definition;
};

// Effect register class (replaces TYEffectRegister)
class TYEffectRegister : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)effectRegisterType:(int)type time:(int)time path:(NSString*)path
    static TYEffectRegister* create(int type, int time, const QString& path);
    
    // Replaces: -(id)initWithType:(int)type time:(int)time path:(NSString*)path
    TYEffectRegister(int type, int time, const QString& path, QObject* parent = nullptr);
    
    // Replaces: -(int)getType
    int getType() const { return m_type; }
    
    // Replaces: -(int)getTime
    int getTime() const { return m_time; }
    
    // Replaces: -(NSString*)getPath
    QString getPath() const { return m_path; }
    
private:
    int m_type;
    int m_time;
    QString m_path;
};

// Effecter class - manages effects and effect images (replaces TYEffecter)
class TYEffecter : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)effecter
    static TYEffecter* effecter();
    
    // Replaces: -(id)init
    explicit TYEffecter(QObject* parent = nullptr);
    ~TYEffecter();
    
    // Replaces: -(void)setEffectNo:(int)effectNo type:(int)effectType time:(int)time path:(NSString*)path
    void setEffectNo(int effectNo, int effectType, int time, const QString& path);
    
    // Image management
    // Replaces: -(void)setBeforeImage:(NSImage*)aImage
    void setBeforeImage(const QImage& image);
    
    // Replaces: -(NSImage*)beforeImage
    QImage beforeImage() const { return m_beforeImage; }
    
    // Replaces: -(BOOL)startEffect:(NSImage*)newImage effectNo:(int)effectNo
    bool startEffect(const QImage& newImage, int effectNo);
    
    // Replaces: -(BOOL)getEffectionImage:(NSImage**)drawImage
    bool getEffectionImage(QImage* drawImage);
    
signals:
    // Replaces delegate pattern
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
private:
    QMap<int, TYEffectRegister*> m_effectDict;  // Replaces: NSMutableDictionary *ty_effectDict
    QDateTime m_startDate;                      // Replaces: NSDate *startDate
    double m_beforePercentage;                  // Replaces: NSTimeInterval beforeParsentage
    TYEffectRegister* m_nowEffect;             // Replaces: TYEffectRegister *nowEffect
    QImage m_beforeImage;                       // Replaces: NSImage *beforeImage
    QImage m_afterImage;                        // Replaces: NSImage *afterImage
    QImage m_nowImage;                          // Replaces: NSImage *nowImage
    
    static TYEffecter* s_instance;
};

// Forward declarations for effect generators
class TYEffectGenerater;

#endif // TYEFFECTER_QT_H