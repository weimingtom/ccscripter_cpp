/*
 *  TYNovelLayer.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYNovelLayer_qt.h"
#include "TYLookbackLayer_qt.h"

const QString TYPathVoiceLookbackData = QStringLiteral("TYPathVoiceLookbackData");
const QString TYPointVoiceLookbackData = QStringLiteral("TYPointVoiceLookbackData");

TYNovelLayer::TYNovelLayer(QObject* parent)
    : QObject(parent)
    , m_delegate(nullptr)
    , m_needRefresh(false)
    , m_isDrawTextWindow(false)
    , m_nowColumn(0)
    , m_nowRow(0)
    , m_lookbackLayer(nullptr)
{
}

TYNovelLayer::~TYNovelLayer()
{
    delete m_lookbackLayer;
}

void TYNovelLayer::pushAttributedString(const QString& str)
{
    m_textArray.append(str);
    m_needRefresh = true;
    emit layerChanged();
}

void TYNovelLayer::pushNewLine()
{
    m_nowRow++;
    m_nowColumn = 0;
    m_needRefresh = true;
    emit layerChanged();
}

QString TYNovelLayer::getText() const
{
    return m_textArray.join('\n');
}

void TYNovelLayer::drawImage()
{
    // Would render to buffer image using QtWidgets
    m_needRefresh = false;
}