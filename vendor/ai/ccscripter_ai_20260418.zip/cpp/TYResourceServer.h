// Converted from TYResourceServer.h
// TODO: Manual review and fixes required

//
//  TYResourceServer.h
//  Tukuyomi
//
//  Created by toveta on Thu Jun 14 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */








// NScripter̃ViIt@CȊO̊O\[XǗ܂B
// \[X̗vꍇA܂eA[JCỏzpXƂČAɃfBXN̎t@CT܂B
class TYResourceServer : public NSObject {
    NSMutableArray *ty_archivers;
    NSString *defaultTransmode;
    BOOL filelog;
    NSMutableDictionary *filelogDict;

    NSMutableDictionary *spiPluginDict;
    NSMutableDictionary *soundPressPluginDict;
    NSMutableDictionary *effectPatternDict;
    NSMutableDictionary *executableBundles;
}

+(id)sharedServer;

void addArchiver(NSString* path);;

NSString* getFilePath(NSString* path);; // fBXNɃt@C݂Ȃ炻̃pXԂB
NSData* getData(NSString* path);; // vOCgpɃf[^擾B
NSImage* getImage(NSString* path); transMode:(BOOL)aBool animate:(BOOL)isAnimate;
NSImage* getImage(NSString* path); transMode:(BOOL)aBool; // C[W擾A^Oɏ]HĕԂ
NSImage* getImageFromString(NSString* str);;
NSBitmapImageRep* getBitmap(NSString* path);;
NSImage* transrateImageFromBitmap(NSBitmapImageRep* bitmap); transMode:(NSString*)transmode; // private
NSData* getSoundData(NSString* path);;
TYEffectPatternMap* getEffectPattern(NSString* path);;
NSString* getFilePathMakeTemp(NSString* path);; // t@CfBXNɑ݂Ȃ΁ATempt@C쐬ÃpXԂB

void addSpi(NSString* pluginName); extension:(NSString*)extension;
void addSoundPressPlugin(NSString* pluginName); extension:(NSString*)extension;
void setDefaultTransMode(NSString* transmode);;
void addEffectPattern(NSString* path);;

void executeBundle(NSString* pathAndArg);;

BOOL filelog(NSString* path);;
void addlog(NSString* filename);;
BOOL fchk(NSString* filename);;
BOOL saveLog(NSString* path);;

#define FILELOG_FILENAME @"NScrflog.dat"
#define WIN_PATH_DELIMITER "\\"


};
