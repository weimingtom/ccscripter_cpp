// Converted from TYFileLog.m
// TODO: Manual review and fixes required

//
//  TYFileLog.m
//  Tukuyomi
//
//  Created by toveta on Sat Nov 10 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYFileLog.h"
#include "TY-NSStringAddition.h"
#include "TY_NSDataAddtion.h"
#include <unistd.h>

// @implementation TYFileLog
-(void*)initWithContentsOfFile:(std::string)path
{
    NSFileHandle *handle;
    std::vector<uint8_t>bufData;
    int fileNum;
    int descripter;
    unsigned char buf;
    int i,ret;

    this = [ super init ];
    
    if(!this)
        return nullptr;
    
    logSet = [ [ NSMutableSet alloc ] initWithCapacity:1 ];

    // MEMO:ŃOofBNg̏݌`FbNB
    handle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    if(!handle){
        return this;
    }
    descripter = [ handle fileDescriptor ];
    
    /*
    filelogDict = [ [ NSMutableDictionary alloc ] initWithContentsOfFile:
        [ getAppDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    */


    bufData = [ NSMutableData dataWithCapacity:1 ];
    while(read(descripter,&buf,1)){
        if(buf == 0x0a)
            break;
        else
            [ bufData appendBytes:&buf length:1 ];
    }
    [ bufData appendBytes:"" length:1 ];
    fileNum = atoi([ bufData bytes ]);

    for(i=0; i < fileNum; i++){
        ret = read(descripter,&buf,1);
        if((!ret)||(buf != '"'))
            break;
            
        bufData = [ NSMutableData dataWithCapacity:1 ];
        
        while(read(descripter,&buf,1)&&(buf!='"')){
            [ bufData appendBytes:&buf length:1 ];
        }
        [ bufData XORMaskToAllBytes:132 ]; // XOR}XNĂ̂Ŗ߂B
        [ bufData appendBytes:"" length:1 ];

        [ logSet addObject:[ [ NSString stringWithCSJISString:[ bufData bytes ] ] uppercaseString ] ];
    }
    
    [ handle closeFile ];
    
    return this;
}

-(bool)writeToFile:(std::string)path
{
    char numbuf[12];
    std::vector<uint8_t>writeData;
    std::vector<uint8_t>data;
    int count;
    NSEnumerator *enm;
    void* temp;
    
    writeData = [ NSMutableData dataWithCapacity:2 ];
    count = [ logSet count ];
    sprintf(numbuf,"%d\n",count);
    [ writeData appendBytes:numbuf length:strlen(numbuf) ];
    
    enm = [ logSet objectEnumerator ];
    while((temp = [ enm nextObject ]) != nullptr){
        [ writeData appendBytes:"\"" length:1 ];
        data = [ [ [ temp sjisData ] mutableCopy ] autorelease ];
        [ data XORMaskToAllBytes:132 ];
        [ writeData appendData:data ];
        [ writeData appendBytes:"\"" length:1 ];
    }
 
    return [ writeData writeToFile:path atomically:true ];
}

-(void)addTYFileLog:(TYFileLog*)margeLog
{
    [ logSet unionSet:margeLog->logSet ];
}

-(void)addLog:(std::string)filename
{
    [ logSet addObject:[ filename uppercaseString ] ];
}

-(bool)isRead:(std::string)filename
{
    return [ logSet containsObject:[ filename uppercaseString ] ];
}

// -dealloc (destructor in C++)
~ClassName() {
    [ logSet release ];
    [super dealloc];
}
// @end
