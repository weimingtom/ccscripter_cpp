/*
 *  TYBGLZSSDecorder.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Background LZSS decoder using threads.
 */

#ifndef TYBGLZSSDECORDER_QT_H
#define TYBGLZSSDECORDER_QT_H

#include <QObject>
#include <QByteArray>
#include <QThread>
#include <QMutex>

class QFile;

class TYBGLZSSDecorderThread : public QThread
{
    Q_OBJECT
    
public:
    TYBGLZSSDecorderThread(QFile* file, int encodeSize, int originalSize, QObject* parent = nullptr);
    ~TYBGLZSSDecorderThread();
    
    QByteArray result() const;
    bool isFinished() const;
    
signals:
    void finished();
    
protected:
    void run() override;
    
private:
    QFile* m_file;
    int m_encodeSize;
    int m_originalSize;
    QByteArray m_result;
    bool m_isFinished;
    mutable QMutex m_mutex;
};

#endif // TYBGLZSSDECORDER_QT_H