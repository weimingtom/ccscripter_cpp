/*
 *  TYSaveDataCoding.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Protocol and constants for save/load data.
 */

#ifndef TYSAVEDATACODING_QT_H
#define TYSAVEDATACODING_QT_H

#include <QObject>
#include <QString>
#include <QVariant>

// Save data types
enum TYSaveDataType {
    TYScriptingSaveData,
    TYPrintingWaitSaveData
};

// Click wait types
enum TYClickWaitType {
    TYNormalClickWaitType,
    TYPageClickWaitType
};

// Speed modes
enum TYSpeedMode {
    TYUserSpeedMode,
    TYScriptSpeedMode
};

// Save data version
const int TYSaveDataVersion = 250;
const int TYSpriteAlphaFixSaveDataVersion = 210;

// Interface for save data encoding/decoding (replaces @protocol TYSaveDataCoding)
class TYSaveDataCoding
{
public:
    virtual ~TYSaveDataCoding() = default;
    
    // Replaces: -(id)encodeWithSaveData
    virtual QVariant encodeWithSaveData() const = 0;
    
    // Replaces: -(void)decodeWithSaveData:(id)aObject
    virtual void decodeWithSaveData(const QVariant& aObject) = 0;
};

// Save data keys (namespace instead of extern NSString*)
namespace TYSaveDataKeys {
    extern const QString DataType;
    extern const QString Version;
    extern const QString Number;
    extern const QString LocalValues;
    extern const QString ScriptPoint;
    extern const QString ReturnStack;
    extern const QString MakeDate;
    extern const QString TextWindow;
    extern const QString NovelLayer;
    extern const QString PrintingInfo;
    extern const QString NovelLayerVisible;
    extern const QString Sprites;
    extern const QString BGImagePath;
    extern const QString LeftChar;
    extern const QString CenterChar;
    extern const QString RightChar;
    extern const QString BGMPath;
    extern const QString WavePath;
    extern const QString MonocroSample;
    extern const QString NegaSpecify;
    extern const QString HumanZ;
    extern const QString AutoClickTimer;
    extern const QString ClickWaitCursor;
    extern const QString PageWaitCursor;
    extern const QString Underline;
    extern const QString ClickWaitType;
    extern const QString BGMNoLoop;
    extern const QString SpeedMode;
    extern const QString LoopStack;
    extern const QString TextgosubIndex;
    extern const QString EraseTextWindow;
    extern const QString Ispage;
    extern const QString CustomSelectInfo;
    extern const QString LookbackBuffer;
}

#endif // TYSAVEDATACODING_QT_H