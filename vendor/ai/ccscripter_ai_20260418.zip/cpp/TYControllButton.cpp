// Converted from TYControllButton.m
// TODO: Manual review and fixes required

//
//  TYControllButton.m
//  Tukuyomi
//
//  Created by toveta on Fri Feb 07 2003.
//  Copyright (c) 2003 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
#include "TYControllButton.h"
#include "TYCellImage.h"

// @implementation TYControllButton
-(void*)initWithFrame:(NSRect)aFrame cellImage:(TYCellImage*)aImage
{
    NSActionCell *cell;
    
    this = [ super initWithFrame:aFrame ];
    
    cellImage = [ aImage retain ];
    cell = [ [ [ NSActionCell alloc ] initImageCell:(NSImage*)cellImage ] autorelease ];
    [ this setCell:cell ];
    return this;
}

// REMOVED: -TYCellImage*cellImage{
    return cellImage;
}

-(void)changeCell:(int)aIndex
{
    [ cellImage changeCell:aIndex ];
    [ this setNeedsDisplay:true ];
}

-(void)mouseDown:(NSEvent*)theEvent
{
    if([ this target ])
        [ [ this target ] performSelector:[ this action ]  withObject:this ];
    else
        [ [ this nextResponder ] mouseDown:theEvent ];
}

-(void)rightMouseDown:(NSEvent*)theEvent
{
    [ [ this nextResponder ] rightMouseDown:theEvent ];
}

/*
-(void)mouseMoved:(NSEvent*)theEvent
{
    [ [ this target ] selectMovedButton:this ];
}

-(void)mouseEntered:(NSEvent*)theEvent
{
    [ cellImage changeCell:1 ];
    [ this setNeedsDisplay:true ];
}

-(void)mouseExited:(NSEvent*)theEvent
{
    [ cellImage changeCell:0 ];
    [ this setNeedsDisplay:true ];
}
*/

// -dealloc (destructor in C++)
~ClassName() {
	[cellImage release];
	[super dealloc];
}

// @end
