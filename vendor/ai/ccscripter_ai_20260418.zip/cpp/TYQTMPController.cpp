// Converted from TYQTMPController.m
// TODO: Manual review and fixes required

#include "TYQTMPController.h"
#include "TYQTMusicPlayer.h"

// @implementation TYQTMPController

- (void) applicationDidFinishLaunching  : (NSNotification *) aNote
{
    NSMovie *aMovie;
    TYQTMusicPlayer *player;

    player = [ [ TYQTMusicPlayer alloc ] initWithFrame:NSZeroRect ];
    aMovie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:@"/Users/shohei/SimpleCocoaMovie/MovieFile.mov" ] byReference:true ];
    //[ MovieViewObject setMovie:aMovie ];
    [ player setMovie:aMovie ];
    [ player setLoopMode:NSQTMovieLoopingPlayback ];
    [ player start:nullptr ];
    
}

// @end
