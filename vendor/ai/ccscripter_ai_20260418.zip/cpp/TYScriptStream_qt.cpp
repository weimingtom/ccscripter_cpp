/*
 *  TYScriptStream.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYScriptStream_qt.h"

TYScriptStream* TYScriptStream::s_instance = nullptr;

TYScriptStream::TYScriptStream(QObject* parent)
    : QObject(parent)
    , m_line(0)
{
}

TYScriptStream* TYScriptStream::sharedStream()
{
    if (!s_instance) {
        s_instance = new TYScriptStream();
    }
    return s_instance;
}

bool TYScriptStream::initWithData(const QByteArray& data)
{
    m_data = data;
    m_linePtrArray.clear();
    m_labelDict.clear();
    m_line = 0;
    
    // Parse data into lines
    const char* ptr = data.constData();
    int len = data.size();
    int lineStart = 0;
    int lineNum = 0;
    
    for (int i = 0; i < len; i++) {
        if (ptr[i] == '\n' || ptr[i] == '\r') {
            // End of line
            QByteArray line(ptr + lineStart, i - lineStart);
            m_linePtrArray.insert(lineNum, line);
            lineNum++;
            
            // Skip CRLF
            if (ptr[i] == '\r' && i + 1 < len && ptr[i + 1] == '\n') {
                i++;
            }
            lineStart = i + 1;
        }
    }
    
    // Handle last line if no newline at end
    if (lineStart < len) {
        QByteArray line(ptr + lineStart, len - lineStart);
        m_linePtrArray.insert(lineNum, line);
    }
    
    return true;
}

void TYScriptStream::addNewLine(const char* text)
{
    int lineNum = m_linePtrArray.size();
    m_linePtrArray.insert(lineNum, QByteArray(text));
}

void TYScriptStream::addLabel(const QString& label)
{
    m_labelDict.insert(label, m_line);
}

QByteArray TYScriptStream::objectAtIndex(int index) const
{
    return m_linePtrArray.value(index);
}

const char* TYScriptStream::cStringAtIndex(int index)
{
    QByteArray line = m_linePtrArray.value(index);
    return line.constData();
}