/*
 *  TYLookbackLayer.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYLookbackLayer_qt.h"

TYLookbackLayer::TYLookbackLayer(const QStringList& strings, const QStringList& voices, QObject* parent)
    : TYNovelLayer(parent)
    , m_attributed(false)
{
    // Initialize with strings and voices
    for (const QString& str : strings) {
        pushAttributedString(str);
    }
    // Note: voices would need to be stored separately in a real implementation
    Q_UNUSED(voices);
}

TYLookbackLayer::~TYLookbackLayer()
{
}

void TYLookbackLayer::setAttribute(const QVariantMap& dict)
{
    Q_UNUSED(dict);
    m_attributed = true;
}