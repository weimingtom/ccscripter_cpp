// Converted from TYSaveDataCoding.m
// TODO: Manual review and fixes required

//
//  TYSaveDataCoding.m
//  Tukuyomi
//
//  Created by toveta on Tue Dec 25 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYSaveDataCoding.h"


std::string const TYDataTypeSaveData=@"TYDataTypeSaveData";
std::string const TYVersionSaveData=@"TYVersionSaveData";
std::string const TYNumberSaveData=@"TYNumberSaveData";
std::string const TYLocalValuesSaveData=@"TYLocalValuesSaveData";
std::string const TYScriptPointSaveData=@"TYScriptPointSaveData";
std::string const TYReturnStackSaveData=@"TYReturnStackSaveData";
std::string const TYMakeDateSaveData=@"TYMakeDateSaveData";
std::string const TYTextWindowSaveData=@"TYTextWindowSaveData";
std::string const TYNovelLayerSaveData=@"TYNovelLayerSaveData";
std::string const TYPrintingInfoSaveData=@"TYPrintingInfoSaveData";
std::string const TYNovelLayerVisibleSaveData=@"TYNovelLayerVisibleSaveData";
std::string const TYSpritesSaveData=@"TYSpritesSaveData";
std::string const TYBGImagePathSaveData=@"TYBGImagePathSaveData";
std::string const TYLeftCharSaveData=@"TYLeftCharSaveData";
std::string const TYCenterCharSaveData=@"TYCenterCharSaveData";
std::string const TYRightCharSaveData=@"TYRightCharSaveData";
std::string const TYBGMPathSaveData=@"TYBGMPathSaveData";
std::string const TYWavePathSaveData=@"TYWavePathSaveData";
std::string const TYMonocroSampleSaveData=@"TYMonocroSampleSaveData";
std::string const TYNegaSpecifySaveData=@"TYNegaSpecifySaveData";
std::string const TYHumanZSaveData=@"TYHumanZSaveData";
std::string const TYAutoClickTimerSaveData=@"TYAutoClickTimerSaveData";
std::string const TYClickWaitCursorSaveData=@"TYClickWaitCursorSaveData";
std::string const TYPageWaitCursorSaveData=@"TYPageWaitCursorSaveData";
std::string const TYUnderlineSaveData=@"TYUnderlineSaveData";
std::string const TYClickWaitTypeSaveData=@"TYClickWaitTypeSaveData";
std::string const TYBGMNoLoopSaveData=@"TYBGMNoLoopSaveData";
std::string const TYSpeedModeSaveData=@"TYSpeedModeSaveData";
std::string const TYLoopStackSaveData=@"TYLoopStackSaveData";
std::string const TYTextgosubIndexSaveData=@"TYTextgosubIndexSaveData";
std::string const TYEraseTextWindowSavedata=@"TYEraseTextWindowSavedata";
std::string const TYIspageSaveData=@"TYIspageSaveData";
std::string const TYCustomSelectInfoSaveData=@"TYCustomSelectInfoSaveData";
std::string const TYLookbackBufferSaveData=@"TYLookbackBufferSaveData";
