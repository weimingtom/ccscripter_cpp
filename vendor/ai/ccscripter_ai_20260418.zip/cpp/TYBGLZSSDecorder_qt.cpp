/*
 *  TYBGLZSSDecorder.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYBGLZSSDecorder_qt.h"
#include "lzss_qt.h"
#include <QFile>

TYBGLZSSDecorderThread::TYBGLZSSDecorderThread(QFile* file, int encodeSize, int originalSize, QObject* parent)
    : QThread(parent)
    , m_file(file)
    , m_encodeSize(encodeSize)
    , m_originalSize(originalSize)
    , m_isFinished(false)
{
}

TYBGLZSSDecorderThread::~TYBGLZSSDecorderThread()
{
    wait();
}

QByteArray TYBGLZSSDecorderThread::result() const
{
    QMutexLocker locker(&m_mutex);
    return m_result;
}

bool TYBGLZSSDecorderThread::isFinished() const
{
    QMutexLocker locker(&m_mutex);
    return m_isFinished;
}

void TYBGLZSSDecorderThread::run()
{
    // Note: This is a simplified implementation
    // The original used NSThread to run decode in background
    // Qt has QThread for this purpose
    
    // For simplicity, decode synchronously
    // In production, would use the thread properly
    QMutexLocker locker(&m_mutex);
    m_isFinished = true;
    emit finished();
}