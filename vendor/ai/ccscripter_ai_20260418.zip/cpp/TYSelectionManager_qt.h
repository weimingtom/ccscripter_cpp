/*
 *  TYSelectionManager.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Selection manager for button selections.
 */

#ifndef TYSELECTIONMANAGER_QT_H
#define TYSELECTIONMANAGER_QT_H

#include "TYRespondRectManager_qt.h"

class TYSelectionManager : public TYRespondRectManager
{
    Q_OBJECT
    
public:
    TYSelectionManager(TYStageManager* manager, QObject* parent = nullptr);
    ~TYSelectionManager();
    
    // Initialize button images
    void initialButtonImage() override;
    
    // Change selection
    bool changeSelection(int index) override;
};

#endif // TYSELECTIONMANAGER_QT_H