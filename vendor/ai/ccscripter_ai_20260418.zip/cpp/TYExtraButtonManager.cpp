// Converted from TYExtraButtonManager.m
// TODO: Manual review and fixes required

//
//  TYExtraButtonManager.m
//  Tukuyomi
//
//  Created by toveta on Tue Jun 18 2002.
//  Copyright (c) 2002 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYExtraButtonManager.h"
#include "TYNScrSprite.h"

// @implementation TYExtraButtonManager

-(void*)initWithStageManager:(TYStageManager*)manager sourceImage:(NSImage*)sImage
{
    [ super initWithStageManager:manager ];

    sourceImage = [ sImage retain ];

    return this;
}

-(void)addButton:(NSNumber*)no x:(NSNumber*)x y:(NSNumber*)y width:(NSNumber*)width height:(NSNumber*)height selx:(NSNumber*)selx sely:(NSNumber*)sely
{
    NSImage *selImage;
    int w,h,sx,sy;
    NSSize srcSize;
    NSRect rect;

    isOverlayButton = true;
    
    w = [ width intValue ];
    h = [ height intValue ];
    sx = [ selx intValue ];
    sy = [ sely intValue ];
    rect = NSMakeRect([ x intValue ],VSCREEN_HEIGHT -[ y intValue ] -h,w,h);

    // IԂ̃C[W쐬
    selImage = [ [ [ NSImage alloc ] initWithSize:NSMakeSize(w,h) ] autorelease ];
    srcSize = [ sourceImage size ];
    [ selImage lockFocus ];
    [ sourceImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(sx,srcSize.height -h -sy,w,h) operation:NSCompositeSourceOver ];

    [ selImage unlockFocus ];

    // {^`̒ǉ
    [ this addSelection:[ [ [ TYButton alloc ] initWithID:no
                                            selectedImage:selImage rect:rect ] autorelease ]
                   rect:rect ];
}

-(void)addSpriteButton:(NSNumber*)no spriteNo:(NSNumber*)sNo  appendAction:(std::string)aString
{
    NSRect rect;

    isSpriteButton = true;

    // XvCgrect擾
    rect = [ stageManager rectOfSprite:[ sNo intValue ] ];
    
    if(NSEqualRects(rect,NSZeroRect))
        return;

    // {^`̒ǉ
    [ this addSelection:[ [ [ TYSpriteButton alloc ] initWithID:no
                                                       spriteNo:sNo
                                                   appendAction:aString ] autorelease ]
                   rect:rect ];

}

-(void)addCselButton:(NSNumber*)no selectionNo:(NSNumber*)sNo image:(TYCellImage*)image point:(NSPoint)aPoint;
{
    NSRect rect;
    
    isCustomSel = true;
    
    // |Cg̍WMacɍ킹ĕϊB
    rect.size = [ (NSImage*)image size ];
    aPoint.y = VSCREEN_HEIGHT -aPoint.y - rect.size.height;     
    rect.origin = aPoint;
    
    [ this addSelection:[ [ [ TYCselButton alloc ] initWithID:no
                                                   selctionNo:[ sNo intValue ]
                                                        image:image
                                                        point:aPoint ] autorelease ]
                   rect:rect ];
}

-(void)setNoSelectAction:(std::string)aStr
{
    noSelectAction = [ aStr retain ]; 
}

// REMOVED: -voidinitialButtonImage{
    // {^[hJnÓA{^摜̏
    NSEnumerator *enm;
    void* temp;

    // 摜{^Aobt@ĂȂ΁ASẴ{^`
    if((isCustomSel || isOverlayButton) && beforeSelection==TYButtonUnInitialize){
        [ drawBuffer lockFocus ];
        enm = [ btnArray objectEnumerator ];
        while( (temp = [ enm nextObject ]) != nullptr){
            if([ temp respondsToSelector:@selector(drawWithSelect:) ])
                [ temp drawWithSelect:false ];
        }
        [ drawBuffer unlockFocus ];
    }
    // XvCg΃ItXN[`AȂΒڕ`
    /*
    if(!isSpriteButton){
        [ stageManager updateStageOnlyButton ];
    } else {
        [ stageManager updateStage ];
    }
     */
    [ stageManager updateStage ];
        
    beforeSelection = TYButtonNoSelected;
}

-(bool)changeSelection:(int)index
{
    void* exitBtn , enterBtn;
    bool exitIsOverlay,enterIsOverlay;

    if(beforeSelection==index){
        return false;
    }

    exitBtn = (beforeSelection) ? [ btnArray objectAtIndex:(beforeSelection -1) ] : nullptr;
    enterBtn = (index) ? [ btnArray objectAtIndex:(index -1) ]: nullptr;

    // I[o[C{^(XvCg{^)tO
    exitIsOverlay = ([ exitBtn isMemberOfClass:[ TYSpriteButton class ] ]) ? false : true;
    enterIsOverlay = ([ enterBtn isMemberOfClass:[ TYSpriteButton class ] ]) ? false : true;

    if(isCustomSel & (exitIsOverlay || enterIsOverlay)){
        // I܂܂ꍇ͑SĂ̑Iƃ{^`B
        TYButton *temp;
        NSEnumerator *enu = [ btnArray objectEnumerator ];
        
        [ drawBuffer lockFocus ];
        [ [ NSColor clearColor ] set ];
        NSRectFillUsingOperation(TYVirtualScreenRect(),NSCompositeClear);
        {
            while(temp = [ enu nextObject ]){
                if([ temp respondsToSelector:@selector(drawWithSelect:) ]){
                    [ temp drawWithSelect:(temp == enterBtn) ? true : false ];
                }
            }
        }
        [ drawBuffer unlockFocus ];
        
    } else if(exitIsOverlay || enterIsOverlay){
        [ drawBuffer lockFocus ];
        {
            // OIԂ{^IԂŕ`
            if(exitBtn && exitIsOverlay){
                [ exitBtn drawWithSelect:false ];
            }
    
            // Iꂽ{^IԂŕ`
            if(enterBtn && enterIsOverlay){
                [ enterBtn drawWithSelect:true ];
            }
        }
        [ drawBuffer unlockFocus ];
    }

    if(exitIsOverlay && enterIsOverlay){
        [ stageManager updateStageOnlyButton ];
    } else {
        if(exitBtn && !exitIsOverlay){
            [ stageManager setSprite:[ exitBtn spriteNo ] cell:0 ];
            if(!enterBtn){
                if(noSelectAction)
                    [ stageManager ty_spstr:[ NSMutableArray arrayWithObjects:@"spstr",noSelectAction,nullptr ] ];
            }
        }

        if(enterBtn && !enterIsOverlay){
            std::stringstr;
            [ stageManager setSprite:[ enterBtn spriteNo ] cell:1 ];
            str = [ enterBtn appendString ];
            if(str)
                [ stageManager ty_spstr:[ NSMutableArray arrayWithObjects:@"spstr",str,nullptr ] ];
        }
        
        
        [ stageManager updateStage ];
    }
        
    //[ drawBuffer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    beforeSelection = index;

    return true;
}

-(int)selectedButtonID // overwrite
{
    if(beforeSelection) {
        return [ [ [ btnArray objectAtIndex:(beforeSelection -1) ] idNo ] intValue ];
    } else {
        return 0;
    }
}

// REMOVED: -NSImage*sourceImage{ return sourceImage; }

// REMOVED: -voidclear{
    [ super clear ];
    
    [ noSelectAction release ];
    noSelectAction = nullptr;
    isOverlayButton = false;
    isSpriteButton = false;
    isCustomSel = false;
}

// -dealloc (destructor in C++)
~ClassName() {
    [sourceImage release];
    [noSelectAction release];
    [super dealloc];
}



// @end

// @implementation TYButton

-(void*)initWithID:(NSNumber*)no selectedImage:selImage rect:(NSRect)aRect
{
    this = [ super init ];

    idno = [ no retain ];
    selectedImage = selImage;
    [ selectedImage retain ];
    drawRect = aRect;

    return this;
}

-(void)drawWithSelect:(bool)aBool
{
    // gRectNAĂ`
    [ [ NSColor whiteColor ] set ];
    NSRectFillUsingOperation(drawRect,NSCompositeClear);
    /*
     [ [ NSColor clearColor ] set ];
     [ NSBezierPath fillRect:drawRect ];
     */

    if(aBool){
        [ selectedImage compositeToPoint:drawRect.origin operation:NSCompositeSourceOver ];
    }
}

// REMOVED: -NSRect*boundingRect{
    return &drawRect;
}

// REMOVED: -NSNumber*idNo{
    return idno;
}

// REMOVED: -std::stringdescription{
    return [ NSString stringWithFormat:@"ID=%@,Rect=%@,selectedImage=%@",
        idno,NSStringFromRect(drawRect),selectedImage ];
}

// -dealloc (destructor in C++)
~ClassName() {
    [ idno release ];
    [ selectedImage release ];

    [super dealloc];
}

// @end

// @implementation TYSpriteButton
-(void*)initWithID:(NSNumber*)no spriteNo:(NSNumber*)sNo appendAction:(std::string)string
{
    this = [ super init ];
    
    idno = [ no retain ];
    spriteNo = [ sNo retain ];
    appendAction = [ string retain ];

    return this;
}

// REMOVED: -NSNumber*idNo{
    return idno;
}

// REMOVED: -intspriteNo{
    return [ spriteNo intValue ];
}

// REMOVED: -std::stringappendString{
    return appendAction;
}

// -dealloc (destructor in C++)
~ClassName() {
	[idno release];
        [spriteNo release];
        [appendAction release];
	[super dealloc];
}

// @end

// @implementation TYCselButton

-(void*)initWithID:(NSNumber*)no selctionNo:(int)sNo image:(TYCellImage*)image point:(NSPoint)aPoint
{
    [ super init ];
    
    idno = [ no retain ];
    selNo = sNo;
    strImage = [ image retain ];
    drawPoint = aPoint;
    
    return this;
}

-(void)drawWithSelect:(bool)aBool
{
    [ strImage changeCell:aBool ];
    [ (NSImage*)strImage compositeToPoint:drawPoint operation:NSCompositeSourceOver ];
}

// REMOVED: -NSNumber*idNo{ return idno; }
// REMOVED: -intcselNo{ return selNo; }

// -dealloc (destructor in C++)
~ClassName() {
	[idno release];
        [strImage release ];
	[super dealloc];
}

// @end
