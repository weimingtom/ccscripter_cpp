/*
 *  lzss_qt.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSFileHandle*      -> QFile*
 *  NSData*            -> QByteArray
 *  NSMutableData*     -> QByteArray (mutable)
 *  [data length]     -> data.size()
 *  [data bytes]       -> data.constData()
 *  [data mutableBytes]-> data.data()
 *  [NSData dataWithLength:n] -> QByteArray(n, 0)
 *  [fh readDataOfLength:n]   -> fh.read(n)
 */

#ifndef LZSS_QT_H
#define LZSS_QT_H

#include <QByteArray>
#include <QFile>
#include <cstddef>

// LZSS decompression function for Qt
// Replaces: NSData* TYDataWithLzssDecodeFromFile(NSFileHandle *fh, size_t encode_size, size_t original_size)
QByteArray TYDataWithLzssDecodeFromFile(QFile& fh, size_t encode_size, size_t original_size);

#endif // LZSS_QT_H