/*
 *  TYWaveBooster.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYWaveBooster_qt.h"
#include <QByteArray>
#include <cstring>
#include <cstdint>

inline uint16_t swapLittleShortToHost(uint16_t val) {
    return ((val & 0x00ff) << 8) | ((val & 0xff00) >> 8);
}

inline uint32_t swapLittleIntToHost(uint32_t val) {
    return ((val & 0x000000ff) << 24) |
           ((val & 0x0000ff00) << 8) |
           ((val & 0x00ff0000) >> 8) |
           ((val & 0xff000000) >> 24);
}

// Replaces: NSData* TYWaveBoost(NSData* sourceData, int volume)
QByteArray TYWaveBoost(const QByteArray& sourceData, int volume)
{
    if (sourceData.isEmpty()) {
        return QByteArray();
    }
    
    QByteArray copyData = sourceData;
    uint8_t* ptr = reinterpret_cast<uint8_t*>(copyData.data());
    
    // Check RIFF header
    if (std::strncmp(reinterpret_cast<const char*>(ptr), "RIFF", 4) != 0) {
        return sourceData;
    }
    ptr += 8;
    
    // Check WAVE header
    if (std::strncmp(reinterpret_cast<const char*>(ptr), "WAVE", 4) != 0) {
        return sourceData;
    }
    ptr += 4;
    
    // Skip fmt chunk header (8 bytes) + format ID check
    ptr += 8;
    if (swapLittleShortToHost(*reinterpret_cast<uint16_t*>(ptr)) != 1) {
        return sourceData;  // Not PCM
    }
    ptr += 14;
    
    // Get bits per sample
    int bytesOfData = swapLittleShortToHost(*reinterpret_cast<uint16_t*>(ptr)) / 8;
    ptr += 2;
    
    // Find data chunk
    if (std::strncmp(reinterpret_cast<const char*>(ptr), "data", 4) == 0) {
        ptr += 4;
    } else if (std::strncmp(reinterpret_cast<const char*>(ptr), "fact", 4) == 0) {
        ptr += 16;
    } else {
        ptr += swapLittleShortToHost(*reinterpret_cast<uint16_t*>(ptr)) + 2;
        if (std::strncmp(reinterpret_cast<const char*>(ptr), "data", 4) == 0) {
            ptr += 4;
        } else if (std::strncmp(reinterpret_cast<const char*>(ptr), "fact", 4) == 0) {
            ptr += 16;
        }
    }
    
    // Get data size
    uint32_t dataSize = swapLittleIntToHost(*reinterpret_cast<uint32_t*>(ptr));
    ptr += 4;
    
    if (bytesOfData == 1) {
        // 8-bit: scale around 128
        for (uint32_t s = 0; s < dataSize; s++, ptr++) {
            *ptr = (((*ptr - 128) * volume) >> 7) + 128;
        }
    } else {
        // 16-bit: byte swap and scale
        for (uint32_t s = 0; s < dataSize; s += 2, ptr += 2) {
            // Swap bytes (little-endian)
            uint8_t temp = ptr[0];
            ptr[0] = ptr[1];
            ptr[1] = temp;
            
            // Apply volume
            int16_t sample = *reinterpret_cast<int16_t*>(ptr);
            sample = sample * volume / 256;
            *reinterpret_cast<int16_t*>(ptr) = sample;
            
            // Swap back
            temp = ptr[0];
            ptr[0] = ptr[1];
            ptr[1] = temp;
        }
    }
    
    return copyData;
}