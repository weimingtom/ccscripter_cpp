/*
 *  TYSarArchivedFile.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Represents a file entry in a SAR archive.
 */

#ifndef TYSARARCHIVEDFILE_QT_H
#define TYSARARCHIVEDFILE_QT_H

#include <QObject>
#include <cstdint>

class TYSarArchivedFile : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)archivedFileoffset:(unsigned)offset length:(unsigned)length
    static TYSarArchivedFile* create(unsigned offset, unsigned length);
    
    // Constructor
    explicit TYSarArchivedFile(unsigned offset, unsigned length, QObject* parent = nullptr);
    
    // Replaces: -(void)getFileDataOffset:(int*)fileOffset length:(int*)length
    void getFileDataOffset(unsigned* fileOffset, unsigned* length) const;
    
    unsigned fileOffset() const { return m_fileOffset; }
    unsigned fileLength() const { return m_fileLength; }
    
private:
    unsigned m_fileOffset;   // Replaces: unsigned fileOffset
    unsigned m_fileLength;   // Replaces: unsigned fileLength
};

#endif // TYSARARCHIVEDFILE_QT_H