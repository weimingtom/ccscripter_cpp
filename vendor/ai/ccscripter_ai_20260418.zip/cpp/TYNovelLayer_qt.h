/*
 *  TYNovelLayer.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Novel text layer - manages text display and lookback functionality.
 */

#ifndef TYNOVELLAYER_QT_H
#define TYNOVELLAYER_QT_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QImage>

class TYLookbackLayer;

class TYNovelLayer : public QObject
{
    Q_OBJECT
    
public:
    // Construction
    TYNovelLayer(QObject* parent = nullptr);
    ~TYNovelLayer();
    
    // Delegate
    void setManager(QObject* manager) { m_delegate = manager; }
    
    // Text operations
    void pushAttributedString(const QString& str);
    void pushNewLine();
    
    // Lookback
    TYLookbackLayer* lookbackObject() const { return m_lookbackLayer; }
    
    // String arrays
    QStringList stringArray() const { return m_textArray; }
    QStringList voiceArray() const { return m_voiceArray; }
    
    // Get combined text
    QString getText() const;
    
    // Draw - would need QtWidgets integration
    void drawImage();
    
    // State
    bool needsRefresh() const { return m_needRefresh; }
    void setNeedsRefresh(bool value) { m_needRefresh = value; }
    
    // Position
    int nowColumn() const { return m_nowColumn; }
    int nowRow() const { return m_nowRow; }
    
signals:
    void layerChanged();
    
private:
    QObject* m_delegate;
    QImage m_bufferImage;
    QStringList m_textArray;
    QString m_tempString;
    bool m_needRefresh;
    bool m_isDrawTextWindow;
    int m_nowColumn;
    int m_nowRow;
    QStringList m_voiceArray;
    TYLookbackLayer* m_lookbackLayer;
};

// Extern constants
extern const QString TYPathVoiceLookbackData;
extern const QString TYPointVoiceLookbackData;

#endif // TYNOVELLAYER_QT_H