/*
 *  TYLoopValue.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYLoopValue_qt.h"

TYLoopValue::TYLoopValue(const TYLoopStruct& loop, QObject* parent)
    : QObject(parent)
    , m_loop(loop)
{
    // Note: varNo is QVariant, no retain/release needed in Qt
}

TYLoopValue::~TYLoopValue()
{
    // QVariant handles its own memory
}