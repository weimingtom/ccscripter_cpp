/*
 *  WaveBooster_Main.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Usage: WaveBooster volume infile outfile
 *  Adjusts volume of WAVE sound file.
 */

#include <QCoreApplication>
#include <QFile>
#include <QByteArray>
#include "TYWaveBooster_qt.h"

int main(int argc, const char* argv[])
{
    QCoreApplication app(argc, const_cast<char**>(argv));
    
    if (argc < 4) {
        qWarning() << "usage: WaveBooster volume infile outfile";
        return -1;
    }
    
    int volume = QString(argv[1]).toInt();
    QString infile = QString(argv[2]).replace("~", QDir::homePath());
    QString outfile = QString(argv[3]).replace("~", QDir::homePath());
    
    QFile inFile(infile);
    if (!inFile.open(QIODevice::ReadOnly)) {
        qWarning() << "Cannot open input file:" << infile;
        return -1;
    }
    
    QByteArray waveData = inFile.readAll();
    inFile.close();
    
    QByteArray convData = TYWaveBoost(waveData, volume);
    
    QFile outFile(outfile);
    if (!outFile.open(QIODevice::WriteOnly)) {
        qWarning() << "Cannot open output file:" << outfile;
        return -1;
    }
    
    outFile.write(convData);
    outFile.close();
    
    return 0;
}