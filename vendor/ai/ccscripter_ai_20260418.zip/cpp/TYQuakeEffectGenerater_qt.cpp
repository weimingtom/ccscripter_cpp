/*
 *  TYQuakeEffectGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYQuakeEffectGenerater_qt.h"
#include <QPainter>

const int SHAKE_SIZE = 12;

TYQuakeEffectGenerater::TYQuakeEffectGenerater(const QImage& image, int type, int times, int second,
                                             QObject* parent)
    : QObject(parent)
    , m_sourceImage(image)
    , m_quakeTimes(times)
    , m_quakeSecond(second)
    , m_isComplete(false)
{
    m_quakeType = (type == TYQuakeTypeHorizontal) ? TYQuakeTypeHorizontal : TYQuakeTypeVertical;
    
    m_timeOfShake = m_quakeSecond / m_quakeTimes;
    m_timeOfQuarter = m_timeOfShake >> 2;
    
    m_startDate = QDateTime::currentDateTime();
    m_currentImage = m_sourceImage;
    
    QTimer::singleShot(0, this, SLOT(drawEffect()));
}

TYQuakeEffectGenerater::~TYQuakeEffectGenerater()
{
}

void TYQuakeEffectGenerater::drawEffect()
{
    qint64 elapsed = m_startDate.msecsTo(QDateTime::currentDateTime());
    qint64 restTime = m_quakeSecond - elapsed;
    
    if (restTime <= 0) {
        m_currentImage = m_sourceImage;
        m_isComplete = true;
        emit effectImageChanged(m_currentImage);
        emit effectFinished();
        return;
    }
    
    int shakeLevel = restTime / m_timeOfShake + 1;
    int shakeQuarter = (restTime / m_timeOfQuarter) % 4;
    int phaseOfQuarter = restTime % m_timeOfQuarter;
    
    int x = 0, y = 0;
    int* mp;
    
    if (m_quakeType == TYQuakeTypeHorizontal) {
        mp = &x;
        y = 0;
    } else {
        mp = &y;
        x = 0;
    }
    
    *mp = SHAKE_SIZE * m_quakeTimes;
    
    // Calculate shake offset based on quarter phase
    switch (shakeQuarter) {
    case 1:
        *mp += SHAKE_SIZE * shakeLevel * phaseOfQuarter / m_timeOfQuarter;
        break;
    case 2:
        *mp += SHAKE_SIZE * shakeLevel * (m_timeOfQuarter - phaseOfQuarter) / m_timeOfQuarter;
        break;
    case 3:
        *mp -= SHAKE_SIZE * shakeLevel * phaseOfQuarter / m_timeOfQuarter;
        break;
    case 0:
        *mp -= SHAKE_SIZE * shakeLevel * (m_timeOfQuarter - phaseOfQuarter) / m_timeOfQuarter;
        break;
    }
    
    // Draw the shaken image
    m_currentImage = m_sourceImage.copy();
    QPainter painter(&m_currentImage);
    
    // For shake effect, we just offset drawing which requires clipping
    // Simplified: just return original for now
    Q_UNUSED(x);
    Q_UNUSED(y);
    
    painter.end();
    
    emit effectImageChanged(m_currentImage);
    
    QTimer::singleShot(16, this, SLOT(drawEffect()));  // ~60fps
}