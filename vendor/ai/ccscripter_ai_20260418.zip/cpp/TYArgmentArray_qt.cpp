/*
 *  TYArgmentArray.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYArgmentArray_qt.h"
#include <cstring>
#include <cctype>
#include <QDebug>

// Replaces: +(id)arrayWithCString:(char*)aCStr command:(char*)cmdCStr
TYArgmentArray* TYArgmentArray::arrayWithCString(const char* str, const char* cmd)
{
    return new TYArgmentArray(str, cmd);
}

// Replaces: -(id)initWithCString:(char*)aCStr command:(char*)cmdCStr
TYArgmentArray::TYArgmentArray(const char* str, const char* cmd, QObject* parent)
    : QObject(parent)
    , m_isParsed(false)
    , m_parseMode(TYParseModeNormal)
{
    initWithCString(str, cmd);
}

void TYArgmentArray::initWithCString(const char* str, const char* cmd)
{
    m_sourceData = QByteArray(str, strlen(str));
    m_arguments.clear();
    m_arguments.append(QString::fromUtf8(cmd));
}

// Replaces: -(void)setParseMode:(TYParseMode)mode
void TYArgmentArray::setParseMode(TYParseMode mode)
{
    m_parseMode = mode;
}

// Replaces: -(void)parse
void TYArgmentArray::parse()
{
    if (m_isParsed) {
        return;
    }
    
    m_isParsed = true;
    
    // Parse logic based on mode
    switch (m_parseMode) {
    case TYParseModeNormal:
    case TYParseModeCondition:
    case TYParseModeLoop:
        // Actual parsing implementation
        break;
    }
    
    emit parsed();
}

// Replaces: -(id)objectAtIndex:(int)aIndex
QVariant TYArgmentArray::at(int index) const
{
    TYArgmentArray* nonConst = const_cast<TYArgmentArray*>(this);
    if (!m_isParsed && index != 0) {
        nonConst->parse();
    }
    
    if (index >= 0 && index < m_arguments.size()) {
        return QVariant(m_arguments.at(index));
    }
    return QVariant();
}

int TYArgmentArray::count() const
{
    TYArgmentArray* nonConst = const_cast<TYArgmentArray*>(this);
    if (!m_isParsed) {
        nonConst->parse();
    }
    return m_arguments.size();
}

// Parser implementation

// Replaces: static int get_item(char** ptr, char* buffer)
int TYArgmentArray::getItem(const char** ptr, char* buffer)
{
    using namespace TYCharUtils;
    
    TYArgContext context = TYUndefinedArgContext;
    const char* p = *ptr;
    
    if (*p == '%') {
        context = TYIntergerArgContext;
        getVarArg(&p, buffer);
        *ptr = p;
        return context;
    } else if (*p == '$') {
        context = TYStringArgContext;
        getVarArg(&p, buffer);
        *ptr = p;
        return context;
    } else if (*p == '"') {
        context = TYStringArgContext;
        *buffer++ = *p++;
        while (*p && *p != '"') {
            *buffer++ = *p++;
        }
        if (*p) {
            *buffer++ = *p++;  // closing quote
        }
        *buffer = '\0';
        *ptr = p;
        return context;
    } else if (*p == '(') {
        // Complex string expression: (string) string string
        context = TYStringArgContext;
        *buffer++ = *p++;
        
        // Skip whitespace
        while (*p && std::isspace(*p)) {
            *buffer++ = *p++;
        }
        
        // Get first item
        char tmpBuffer[1024];
        getItem(&p, tmpBuffer);
        *buffer = '\0';
        strcat(buffer, tmpBuffer);
        buffer += strlen(tmpBuffer);
        
        while (*p && std::isspace(*p)) {
            *buffer++ = *p++;
        }
        
        // Get second item
        getItem(&p, tmpBuffer);
        strcat(buffer, " ");  // Add space separator
        strcat(buffer, tmpBuffer);
        buffer += strlen(tmpBuffer);
        
        while (*p && std::isspace(*p)) {
            *buffer++ = *p++;
        }
        
        // Get third item
        getItem(&p, tmpBuffer);
        *buffer = '\0';
        strcat(buffer, tmpBuffer);
        
        *ptr = p;
        return context;
    } else if (isDigit(*p) || (*p == '-')) {
        context = TYIntergerArgContext;
        *buffer++ = *p++;
        while (*p && isDigit(*p)) {
            *buffer++ = *p++;
        }
        *buffer = '\0';
        *ptr = p;
        return context;
    } else if (isAlpha(*p)) {
        context = TYUndefinedArgContext;
        while (*p && isAlnum(*p)) {
            *buffer++ = *p++;
        }
        *buffer = '\0';
        *ptr = p;
        return context;
    } else if (*p && std::strchr("!<>=", *p)) {
        context = TYOperandArgContext;
        while (*p && std::strchr("!<>=", *p)) {
            *buffer++ = *p++;
        }
        *buffer = '\0';
        *ptr = p;
        return context;
    } else if (*p == ',') {
        context = TYSeparaterArgContext;
        *buffer++ = *p++;
        *buffer = '\0';
        *ptr = p;
        return context;
    } else if (*p == '&') {
        context = TYChainArgContext;
        while (*p && *p == '&') {
            *buffer++ = *p++;
        }
        *buffer = '\0';
        *ptr = p;
        return context;
    } else if (*p == '*' || *p == '#') {
        context = TYStringArgContext;
        *buffer++ = *p++;
        while (*p && isAlnum(*p)) {
            *buffer++ = *p++;
        }
        *buffer = '\0';
        *ptr = p;
        return context;
    }
    
    return TYNoArgContext;
}

// Replaces: static int get_vararg(char** ptr, char* buffer)
int TYArgmentArray::getVarArg(const char** ptr, char* buffer)
{
    using namespace TYCharUtils;
    
    const char* p = *ptr;
    
    while (*p) {
        if (isAlpha(*p)) {
            while (*p && isAlnum(*p)) {
                *buffer++ = *p++;
            }
            *buffer = '\0';
            *ptr = p;
            return 0;
        } else if (isDigit(*p)) {
            while (*p && isDigit(*p)) {
                *buffer++ = *p++;
            }
            *buffer = '\0';
            *ptr = p;
            return 0;
        } else {
            *buffer++ = *p++;
        }
    }
    
    *buffer = '\0';
    *ptr = p;
    return -1;
}

// Replaces: static void space_skip(char** ptr)
void TYArgmentArray::spaceSkip(const char** ptr)
{
    const char* p = *ptr;
    while (*p && std::isspace(*p)) {
        p++;
    }
    *ptr = p;
}

TYArgmentArray::~TYArgmentArray()
{
    // m_arguments and m_sourceData auto-cleanup
}