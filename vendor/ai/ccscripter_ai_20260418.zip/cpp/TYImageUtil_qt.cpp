/*
 *  TYImageUtil.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYImageUtil_qt.h"
#include <QColor>
#include <QPainter>
#include <QMap>
#include <QDebug>

void getRGBWithHTMLFormat(const QString& formatStr, int* r, int* g, int* b)
{
    // Replaces: if( [ formatstr cStringLength ] != 7 )
    if (formatStr.length() != 7) {
        return;
    }
    
    // Extract RGB from #rrggbb format
    // Replaces: [ formatstr getCString:formptr ]
    QString hex = formatStr.mid(1);  // Remove '#'
    
    bool ok;
    // Replaces: *b = strtol(&formptr[5],NULL,16);
    *b = hex.mid(4, 2).toInt(&ok, 16);
    // Replaces: *g = strtol(&formptr[3],NULL,16);
    *g = hex.mid(2, 2).toInt(&ok, 16);
    // Replaces: *r = strtol(&formptr[1],NULL,16);
    *r = hex.mid(0, 2).toInt(&ok, 16);
}

QColor getColorWithHTMLFormat(const QString& formatStr)
{
    // Replaces: NSColor *getColorWithHTMLFormat(formatstr)
    int r, g, b;
    getRGBWithHTMLFormat(formatStr, &r, &g, &b);
    
    // Replaces: [ NSColor colorWithCalibratedRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:1 ]
    return QColor(r, g, b, 255);
}

QColor getTextWindowColorWithHTMLFormat(const QString& formatStr)
{
    // Replaces: NSColor* getTextWindowColorWithHTMLFormat(formatstr)
    int r, g, b;
    getRGBWithHTMLFormat(formatStr, &r, &g, &b);
    
    int maxp, minp;
    if (r > g) {
        maxp = (r > b) ? r : b;
        minp = (g < b) ? g : b;
    } else {
        maxp = (g > b) ? g : b;
        minp = (r < b) ? r : b;
    }
    
    // Replaces: [ NSColor colorWithCalibratedRed:(r -minp) / 255.0 ...]
    int newR = r - minp;
    int newG = g - minp;
    int newB = b - minp;
    int alpha = 255 - maxp;
    
    return QColor(newR, newG, newB, alpha);
}

// Replaces: NSImage* ConvertImagePackedAlpha(srcImage)
QImage ConvertImagePackedAlpha(const QImage& srcImage)
{
    // This is complex - packs alpha from separate channel
    // Original creates a new NSBitmapImageRep with 4 channels (RGBA)
    
    if (srcImage.isNull()) {
        return QImage();
    }
    
    int width = srcImage.width();
    int height = srcImage.height();
    
    // Create output image with alpha channel
    QImage destImage(width, height, QImage::Format_ARGB32);
    
    // For now, just copy with full alpha
    // A proper conversion would extract alpha from a second image
    destImage = srcImage.convertToFormat(QImage::Format_ARGB32);
    
    return destImage;
}

// Replaces: NSImage* ConvertImageTransrateLeftTop(NSImage* srcImage)
QImage ConvertImageTransrateLeftTop(const QImage& srcImage)
{
    if (srcImage.isNull()) {
        return QImage();
    }
    
    int width = srcImage.width();
    int height = srcImage.height();
    
    // Get top-left pixel color as transparent color key
    QRgb trColor = srcImage.pixel(0, 0);
    
    QImage destImage(width, height, QImage::Format_ARGB32);
    destImage.fill(Qt::transparent);
    
    QPainter painter(&destImage);
    painter.setCompositionMode(QPainter::CompositionMode_Source);
    
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            QRgb pixel = srcImage.pixel(x, y);
            if (pixel != trColor) {
                // Keep non-transparent pixels
                destImage.setPixel(x, y, qRgba(qRed(pixel), qGreen(pixel), qBlue(pixel), 255));
            }
        }
    }
    
    return destImage;
}

// Replaces: NSImage* ConvertImageWithMaskImage(NSImage* srcImage, NSImage* maskImage)
QImage ConvertImageWithMaskImage(const QImage& srcImage, const QImage& maskImage)
{
    if (srcImage.isNull() || maskImage.isNull()) {
        return QImage();
    }
    
    if (srcImage.size() != maskImage.size()) {
        qWarning() << "Not Equal size of maskImage to sourceImage!!";
        return QImage();
    }
    
    int width = srcImage.width();
    int height = srcImage.height();
    
    QImage destImage(width, height, QImage::Format_ARGB32);
    
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            QRgb srcPixel = srcImage.pixel(x, y);
            QRgb maskPixel = maskImage.pixel(x, y);
            
            // Alpha from mask: 0xFF - average of RGB
            int alpha = 255 - (qRed(maskPixel) + qGreen(maskPixel) + qBlue(maskPixel)) / 3;
            
            destImage.setPixel(x, y, qRgba(
                qRed(srcPixel) * alpha / 255,
                qGreen(srcPixel) * alpha / 255,
                qBlue(srcPixel) * alpha / 255,
                alpha
            ));
        }
    }
    
    return destImage;
}

// Replaces: NSBitmapImageRep* blankBitmap(int width, int height)
QImage blankBitmap(int width, int height)
{
    // Creates a 24-bit RGB image
    return QImage(width, height, QImage::Format_RGB888);
}

// Replaces: NSString* TYTransmodeSymbolFromString(NSString* key)
QString TYTransmodeSymbolFromString(const QString& key)
{
    static QMap<QString, QString> dict;
    
    if (dict.isEmpty()) {
        dict.insert("leftup", TYTRANSMODE_LEFTTOP);
        dict.insert("rightup", TYTRANSMODE_RIGHTTOP);
        dict.insert("copy", TYTRANSMODE_COPY);
        dict.insert("alpha", TYTRANSMODE_ALPHA);
    }
    
    // Replaces: [ dict objectForKey:[ key lowercaseString ] ]
    return dict.value(key.toLower(), QString());
}

// Replaces: [NSImage convertMonocroWithSample:priority:]
void convertMonocroWithSample(QImage& image, const unsigned char* sample, TYNegaPriority priority)
{
    if (image.isNull()) {
        return;
    }
    
    // Convert to 32-bit for manipulation
    image = image.convertToFormat(QImage::Format_ARGB32);
    
    if (priority == TYNegaHighPriority) {
        nega(image);
    }
    
    if (sample) {
        monocro(image, sample);
    }
    
    if (priority == TYNegaLowPriority) {
        nega(image);
    }
}

// Replaces: [NSBitmapImageRep monocro:]
void monocro(QImage& image, const unsigned char* sample)
{
    if (image.isNull()) {
        return;
    }
    
    image = image.convertToFormat(QImage::Format_ARGB32);
    
    int width = image.width();
    int height = image.height();
    
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            QRgb pixel = image.pixel(x, y);
            unsigned char current = (qRed(pixel) + qGreen(pixel) + qBlue(pixel)) / 3;
            image.setPixel(x, y, qRgba(
                sample[0] * current / 255,
                sample[1] * current / 255,
                sample[2] * current / 255,
                qAlpha(pixel)
            ));
        }
    }
}

// Replaces: [NSBitmapImageRep nega]
void nega(QImage& image)
{
    if (image.isNull()) {
        return;
    }
    
    image = image.convertToFormat(QImage::Format_ARGB32);
    
    int width = image.width();
    int height = image.height();
    
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            QRgb pixel = image.pixel(x, y);
            image.setPixel(x, y, qRgba(
                255 - qRed(pixel),
                255 - qGreen(pixel),
                255 - qBlue(pixel),
                qAlpha(pixel)
            ));
        }
    }
}

// Replaces: [NSBitmapImageRep horizontalDivide:]
QList<QImage> horizontalDivide(const QImage& image, int count)
{
    QList<QImage> result;
    
    if (image.isNull() || count <= 0) {
        return result;
    }
    
    int width = image.width();
    int height = image.height();
    int pieceWidth = width / count;
    
    if (pieceWidth == 0) {
        pieceWidth = 1;
    }
    
    for (int i = 0; i < count; ++i) {
        int x = i * pieceWidth;
        // Handle last piece potentially being larger
        int w = (i == count - 1) ? (width - x) : pieceWidth;
        result.append(image.copy(x, 0, w, height));
    }
    
    return result;
}

// Replaces: [NSImageRep resizeToPixelsSize]
void resizeToPixelsSize(QImage& image)
{
    // QImage size is always in pixels, no conversion needed
    // In Qt, size IS pixel size
}