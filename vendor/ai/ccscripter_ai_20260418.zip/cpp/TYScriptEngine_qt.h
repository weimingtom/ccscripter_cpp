/*
 *  TYScriptEngine.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  NScripter script engine - handles script parsing and execution.
 */

#ifndef TYSCRIPTENGINE_QT_H
#define TYSCRIPTENGINE_QT_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QMap>
#include <QStack>
#include <QSet>
#include "TYScripterValues_qt.h"
#include "TYLoopValue_qt.h"
#include "TYSaveDataCoding_qt.h"

// Constants
#define DEFALUT_NSA_ARCHIVE "arc%@.nsa"
#define GLOBAL_SAVEFILE_NAME "gloval.sav"
#define LABELLOG_FILENAME "NScrllog.dat"
#define KIDOKU_FILENAME "ccs_kidoku.dat"

// Exceptions
extern const QString TYNScriptRunTimeErrorException;
extern const QString TYNScriptSyntaxErrorException;

// Script point (line, column)
struct TYScriptPoint {
    unsigned int line;
    unsigned int column;
};

// Forward declarations
class TYFileLog;
class TYArgmentArray;

// Script engine class
class TYScriptEngine : public QObject, public TYSaveDataCoding
{
    Q_OBJECT
    
public:
    // Singleton - replaces +(id)sharedEngine
    static TYScriptEngine* sharedEngine();
    
    // Initialize with script file
    bool initWithContentsOfFile(const QString& path);
    
    // Run script
    void runScript();
    
    // Evaluate command
    bool eval(const QStringList& arguments);
    
    // Break control
    bool breakRun() const { return m_breakRun; }
    void setBreakRun(bool flag) { m_breakRun = flag; }
    
    // Script control
    void lineEnd();
    void jump(unsigned target);
    void labelJump(const QString& label);
    void labelJump(const QString& label, int fromLine, bool reverse);
    void jumpToLoopEnd();
    
    // Save/Load
    void saveExternalData();
    
    // Run line control
    int runLine() const { return m_runLine; }
    void moveRunLine(int delta);
    void incRunColumn();
    void resetRunColumn();
    
    // Loop control
    void registerLoop(const QString& currentChars);
    void registerLoopTargetId(const QVariant& varId, const QVariant& initVal, 
                              const QVariant& limitVal, const QVariant& stepVal);
    
    // Argument parsing
    int splitArgNormal(const QString& currentChars, QStringList& cmdArray);
    int splitArgCondition(const QString& currentChars, bool trueFlag);
    
    // Multi-line command support
    bool isMultLineSupport(const QString& command) const;
    
    // Get next line
    QString nextLine();
    
    // Variable access
    QVariant getIdNoOfArgment(const QString& argment);
    QVariant getArrayIdOfArgment(const QString& argment);
    QVariant getValueOfArgment(const QString& argment);
    QString getStringOfArgment(const QString& argment);
    int getEffectNoOfArgments(const QStringList& argments);
    
    // String processing
    QString stringOfReplaceVars(const QString& str);
    
    // Condition checking
    bool judgefchk(const QString& file);
    bool judgelchk(const QString& label);
    bool judgeCondition(const QString& condition, bool stringMode);
    
    // Label log
    void addLabelLog(const QString& str);
    
    // Variable accessors
    QVariant intNumberWithVarId(const QVariant& varId);
    QString stringValueWithVarId(const QVariant& varId);
    QVariant intNumberWithAlias(const QString& alias);
    QString stringValueWithAlias(const QString& alias);
    
    // Kidoku (read history)
    void enableKidoku();
    void setWatchKidoku(bool enable);
    
    // Game control
    void resetGame();
    
    // Mode queries
    bool isModeSVGA() const { return m_isSVGA; }
    int scanGlobalValue() const { return m_globalValue; }
    
    // TYSaveDataCoding implementation
    QVariant encodeWithSaveData() const override;
    void decodeWithSaveData(const QVariant& data) override;
    
signals:
    void scriptFinished();
    void lineEnded();
    void errorOccurred(const QString& error);
    
private:
    TYScriptEngine(QObject* parent = nullptr);
    
    QString m_nsaDir;
    bool m_breakRun;
    QStringList m_scriptArray;
    QMap<QString, int> m_labelDict;
    QStack<TYScriptPoint> m_returnStack;
    QStack<TYLoopStruct> m_loopStack;
    QMap<QString, QString> m_numAliases;
    QMap<QString, QString> m_strAliases;
    TYScripterValues* m_scripterValues;
    bool m_globalOn;
    TYFileLog* m_labelLog;
    QString m_labelWithTrap;
    bool m_fireOfTrap;
    QSet<QString> m_undefinedComSet;
    bool m_isSVGA;
    int m_globalValue;
    int m_runLine;
    unsigned int m_runColumn;
    
    static TYScriptEngine* s_instance;
};

#endif // TYSCRIPTENGINE_QT_H