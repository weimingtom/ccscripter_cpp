/*
 *  TYCCSProxy.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYCCSProxy_qt.h"
#include <QWindow>

TYCCSProxy* TYCCSProxy::s_instance = nullptr;

TYCCSProxy::TYCCSProxy(QObject* parent)
    : QObject(parent)
    , m_returnCode(0)
{
}

// Replaces: +(id)proxy
TYCCSProxy* TYCCSProxy::proxy()
{
    if (!s_instance) {
        s_instance = new TYCCSProxy();
    }
    return s_instance;
}

// Replaces: -(NSWindow*)mainWindow
QWindow* TYCCSProxy::mainWindow()
{
    // Note: This would need to be connected to the actual main window
    // In a Qt application, this could be QGuiApplication::topLevelWindows()[0]
    return nullptr;
}

// Replaces: -(void)setRetunCode:(int)aInt string:(NSString*)aStr
void TYCCSProxy::setReturnCode(int code, const QString& str)
{
    m_returnCode = code;
    m_returnString = str;
    
    emit returnCodeSet(code, str);
    
    // In original, this triggered script engine to run
    // In Qt, would emit signal or use QTimer::singleShot
}