/*
 *  TYMiscUtil.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYMiscUtil_qt.h"
#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <cstdlib>
#include <ctime>

// Static storage for root directory
static QString s_rootDirectory;

// Replaces: BOOL scanIntAndLengthFromString(NSString*,int*,int*)
bool scanIntAndLengthFromString(const QString& str, int* value, int* length)
{
    if (str.isEmpty()) {
        return false;
    }
    
    bool ok = false;
    int pos = 0;
    int len = str.length();
    
    // Skip leading whitespace
    while (pos < len && str[pos].isSpace()) {
        pos++;
    }
    
    if (pos >= len) {
        return false;
    }
    
    // Check for negative sign
    bool negative = false;
    if (str[pos] == '-') {
        negative = true;
        pos++;
    }
    
    // Parse digits
    int numLen = 0;
    while (pos + numLen < len && str[pos + numLen].isDigit()) {
        numLen++;
    }
    
    if (numLen == 0) {
        return false;
    }
    
    QString numStr = str.mid(pos, numLen);
    int result = numStr.toInt(&ok);
    
    if (ok) {
        *value = negative ? -result : result;
        *length = pos + numLen;
    }
    
    return ok;
}

// Replaces: NSString* getAppDirectory(void)
QString getAppDirectory()
{
    return QCoreApplication::applicationDirPath();
}

// Replaces: NSString* winPathToUnix(NSString*)
QString winPathToUnix(const QString& path)
{
    if (path.isEmpty()) {
        return path;
    }
    
    QString result = path;
    result.replace('\\', '/');
    
    // Handle Windows drive letter (e.g., C: -> /c)
    if (result.length() >= 2 && result[0].isLetter() && result[1] == ':') {
        result = '/' + result[0].toLower() + result.mid(2);
    }
    
    return result;
}

// Replaces: void setNScrRootDirectory(NSString*)
void setNScrRootDirectory(const QString& path)
{
    s_rootDirectory = path;
}

// Replaces: NSString* getNScrRootDirectory(void)
QString getNScrRootDirectory()
{
    if (s_rootDirectory.isEmpty()) {
        return QCoreApplication::applicationDirPath();
    }
    return s_rootDirectory;
}

// Replaces: int TYRandom(int min, int max)
int TYRandom(int min, int max)
{
    static bool initialized = false;
    if (!initialized) {
        std::srand(static_cast<unsigned>(std::time(nullptr)));
        initialized = true;
    }
    
    if (min >= max) {
        return min;
    }
    
    return min + std::rand() % (max - min + 1);
}

// Replaces: NSString* TYWideCharDecimalString(int aInt)
QString TYWideCharDecimalString(int value)
{
    return QString::number(value);
}

// Replaces: NSString* TYWideCharDecimalStringWithString(NSString *decStr)
QString TYWideCharDecimalStringWithString(const QString& decStr)
{
    bool ok = false;
    int value = decStr.toInt(&ok);
    if (ok) {
        return TYWideCharDecimalString(value);
    }
    return QString();
}

// Replaces: +(id)varNameCharacterSet
QString TYCharacterSetUtils::varNameCharacterSet()
{
    // Simplified - return string of valid variable name characters
    return QStringLiteral("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$");
}

template<typename T>
QList<T> TYArrayUtils::subarrayFromIndex(const QList<T>& list, unsigned int index)
{
    if (index >= static_cast<unsigned>(list.size())) {
        return QList<T>();
    }
    return list.mid(index);
}

template<typename T>
QList<T> TYDictionaryUtils::objectsSortedByKey(const QMap<QString, T>& map)
{
    return map.values();
}