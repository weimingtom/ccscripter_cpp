/*
 *  TYPatternCrossFadeGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYPatternCrossFadeGenerater_qt.h"
#include <QPainter>

TYPatternCrossFadeGenerater::TYPatternCrossFadeGenerater(const QImage& beforeImage, const QImage& afterImage,
                                                    TYEffectDefinitionValue* effect, QObject* parent)
    : QObject(parent)
    , m_beforeImage(beforeImage)
    , m_afterImage(afterImage)
    , m_patternMap(nullptr)
    , m_patternPtr(nullptr)
    , m_patternWide(0)
    , m_patternHigh(0)
    , m_isComplete(false)
{
    TYEffectDefinition effdef = effect->definition();
    
    // Load pattern map
    if (TYResourceServer::sharedServer()) {
        m_patternMap = TYResourceServer::sharedServer()->getEffectPattern(effdef.path);
        if (m_patternMap) {
            m_patternPtr = m_patternMap->patternMapData();
            m_patternWide = m_patternMap->pixelsWide();
            m_patternHigh = m_patternMap->pixelsHigh();
        }
    }
    
    if (!m_patternPtr) {
        qWarning() << "Can't load pattern map for effect";
        return;
    }
    
    m_effectTime = effdef.time;
    m_phaseInterval = effdef.time / 1000.0 / 256.0;
    m_startDate = QDateTime::currentDateTime();
    m_currentImage = m_beforeImage;
    
    QTimer::singleShot(0, this, SLOT(drawEffect()));
}

TYPatternCrossFadeGenerater::~TYPatternCrossFadeGenerater()
{
}

void TYPatternCrossFadeGenerater::drawEffect()
{
    qint64 elapsed = m_startDate.msecsTo(QDateTime::currentDateTime());
    int phase = (elapsed * 256) / m_effectTime;
    
    if (phase >= 256) {
        m_currentImage = m_afterImage;
        m_isComplete = true;
        emit effectImageChanged(m_currentImage);
        emit effectFinished();
        return;
    }
    
    QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
    
    m_currentImage = QImage(m_beforeImage.size(), QImage::Format_RGB32);
    
    int width = m_beforeImage.width();
    int height = m_beforeImage.height();
    
    for (int h = 0; h < height; h++) {
        int ph = (h * m_patternHigh) / height;
        if (ph >= m_patternHigh) ph = m_patternHigh - 1;
        
        for (int w = 0; w < width; w++) {
            int pw = (w * m_patternWide) / width;
            if (pw >= m_patternWide) pw = m_patternWide - 1;
            
            int patternValue = -m_patternPtr[ph * m_patternWide + pw] + (phase << 1);
            if (patternValue < 0) patternValue = 0;
            else if (patternValue > 255) patternValue = 255;
            
            QRgb beforePixel = m_beforeImage.pixel(w, h);
            QRgb afterPixel = m_afterImage.pixel(w, h);
            
            int r = (qRed(afterPixel) * patternValue + qRed(beforePixel) * (255 - patternValue)) >> 8;
            int g = (qGreen(afterPixel) * patternValue + qGreen(beforePixel) * (255 - patternValue)) >> 8;
            int b = (qBlue(afterPixel) * patternValue + qBlue(beforePixel) * (255 - patternValue)) >> 8;
            
            m_currentImage.setPixel(w, h, qRgb(r, g, b));
        }
    }
    
    emit effectImageChanged(m_currentImage);
}