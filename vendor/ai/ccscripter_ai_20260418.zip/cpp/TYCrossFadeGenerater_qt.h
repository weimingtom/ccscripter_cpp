/*
 *  TYCrossFadeGenerater.h
 *  Tukuyomi *
 *  Converted to Qt framework
 *
 *  Cross-fade effect between two images.
 */

#ifndef TYCROSSFADEGENERATER_QT_H
#define TYCROSSFADEGENERATER_QT_H

#include <QObject>
#include <QImage>
#include <QTimer>
#include <QDateTime>
#include "TYEffecter_qt.h"

class TYCrossFadeGenerater : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithBeforeImage:afterImage:effect:
    TYCrossFadeGenerater(const QImage& beforeImage, const QImage& afterImage,
                         TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    ~TYCrossFadeGenerater();
    
    // Get current effect image
    QImage currentImage() const { return m_currentImage; }
    
    // Check if effect is still running
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
public slots:
    void drawEffect();
    
private:
    QImage m_beforeImage;
    QImage m_afterImage;
    QImage m_currentImage;
    QDateTime m_startDate;
    int m_effectTime;
    double m_phaseInterval;
    bool m_isComplete;
};

#endif // TYCROSSFADEGENERATER_QT_H