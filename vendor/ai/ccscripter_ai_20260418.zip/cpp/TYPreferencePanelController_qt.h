/*
 *  TYPreferencePanelController.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Preference panel controller - manages application settings.
 *  Note: UI parts would need QtWidgets integration.
 */

#ifndef TYPREFERENCEPANELCONTROLLER_QT_H
#define TYPREFERENCEPANELCONTROLLER_QT_H

#include <QObject>
#include <QString>

class TYPreferencePanelController : public QObject
{
    Q_OBJECT
    
public:
    // Show preference dialog
    static int showDialog();
    
    // Constructor
    TYPreferencePanelController(QObject* parent = nullptr);
    ~TYPreferencePanelController();
    
    // Load settings from environment
    void loadEnvironment();
    
    // Settings accessors
    int bufferPage() const { return m_bufferPage; }
    void setBufferPage(int value) { m_bufferPage = value; }
    
    bool enableAutoReplay() const { return m_enableAutoReplay; }
    void setEnableAutoReplay(bool value) { m_enableAutoReplay = value; }
    
    bool enableBold() const { return m_enableBold; }
    void setEnableBold(bool value) { m_enableBold = value; }
    
    bool enableMovie() const { return m_enableMovie; }
    void setEnableMovie(bool value) { m_enableMovie = value; }
    
    bool hideOtherFullScreen() const { return m_hideOtherFullScreen; }
    void setHideOtherFullScreen(bool value) { m_hideOtherFullScreen = value; }
    
    bool scaleInFullScreen() const { return m_scaleInFullScreen; }
    void setScaleInFullScreen(bool value) { m_scaleInFullScreen = value; }
    
signals:
    void settingsChanged();
    
private:
    int m_bufferPage;
    bool m_enableAutoReplay;
    bool m_enableBold;
    bool m_enableMovie;
    bool m_hideOtherFullScreen;
    bool m_scaleInFullScreen;
};

#endif // TYPREFERENCEPANELCONTROLLER_QT_H