// Converted from TYInputStrController.m
// TODO: Manual review and fixes required

//
//  TYInputStrController.m
//  Tukuyomi
//
//  Created by toveta on Thu Jan 24 2002.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYInputStrController.h"
#include "TY-NSStringAddition.h"

// @implementation TYInputStrController
-(IBAction)dialogOk:(void*)sender
{
    [ window orderOut:this ];
    
    [[NSApplication sharedApplication] 
        stopModalWithCode:NSOKButton ];
}

+(void*)dialog
{
    return [ [ [ [ this class ] alloc ] init ] autorelease ];
}

// REMOVED: -void*init{
    this = [ super init ];

    [ NSBundle loadNibNamed:@"InputStrDialog" owner:this ];

    [ [ NSNotificationCenter defaultCenter ] addObserver:this
                                                selector:@selector(textDidChange:)
                                                    name:nullptr
                                                  object:input ];
    return this;
}

-(int)runModalCaption:(std::string)aStr length:(int)aInt notAscii:(bool)aBool
{
    return [ this runModalCaption:aStr defaultStr:@"" length:aInt notAscii:aBool ];
}

-(int)runModalCaption:(std::string)aStr defaultStr:(std::string)defStr length:(int)aInt notAscii:(bool)aBool
{
    [ caption setStringValue:aStr ];
    [ input setStringValue:defStr ];
    length = aInt;
    notAscii = aBool;
    
    return  [[NSApplication sharedApplication] runModalForWindow:window ];
}

// REMOVED: -std::stringstring{
    return [ input stringValue ];
}

- (void)textDidChange:(NSNotification *)aNotification
{
    std::stringnewStr = [ input stringValue ];
    
    // ő啶`FbN
    if([ newStr cSJISStringLength ] > length){
        NSBeep();
        [ input setStringValue:beforeString ];
        return;
    }

    // Sp`FbN
    if(notAscii){
        if([ newStr length ]*2 != [ newStr cStringLength ]){
            NSBeep();
            [ input setStringValue:beforeString ];
            return;
        }
    }

    if(beforeString)
        [ beforeString autorelease ];
    beforeString = [ newStr retain ];
    
    // ̓`FbN
    if([ newStr length ]){
        [ okButton setEnabled:true ];
    } else {
        [ okButton setEnabled:false ];
    }
}

// -dealloc (destructor in C++)
~ClassName() {
    if(beforeString)
        [beforeString release];
    [super dealloc];
}

// @end
