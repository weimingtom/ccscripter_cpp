// Converted from TYButtonManager.m
// TODO: Manual review and fixes required

//
//  TYButtonManager.m
//  Tukuyomi
//
//  Created by toveta on Thu Oct 11 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYButtonManager.h"
#include "TYStageManager.h"

// @implementation TYButtonManager
-(void*)initWithImage:(NSImage*)srcImage
{
    this = [ super init ];
    
    // C[W̕ێ
    sourceImage = srcImage;
    [ sourceImage retain ];
    
    // CX^X̊m
    btnArray = [ [ NSMutableArray alloc ] initWithCapacity:1 ];

    drawBuffer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    beforeSelection = TYButtonUnInitialize;
    
    rectMap = [ [ NSMutableData dataWithLength:VSCREEN_WIDTH *VSCREEN_HEIGHT ] retain ];
    
    return this;
}

// REMOVED: -NSImage*image{
    return sourceImage;
}

-(void)addButton:(NSNumber*)no x:(NSNumber*)x y:(NSNumber*)y width:(NSNumber*)width height:(NSNumber*)height selx:(NSNumber*)selx sely:(NSNumber*)sely
{
    NSImage *unselImage,*selImage;
    int w,h,sx,sy,i,j;
    NSSize srcSize;
    NSRect rect;
    unsigned char *map,*ptr;
    int index;
    
    w = [ width intValue ];
    h = [ height intValue ];
    sx = [ selx intValue ];
    sy = [ sely intValue ];
    rect = NSMakeRect([ x intValue ],VSCREEN_HEIGHT -[ y intValue ] -h,w,h);
    
    // IԂ̃C[W쐬
    unselImage = [ [ [ NSImage alloc ] initWithSize:NSMakeSize(w,h) ] autorelease ];
    
    // IԂ̃C[W쐬
    selImage = [ [ [ NSImage alloc ] initWithSize:NSMakeSize(w,h) ] autorelease ];
    srcSize = [ sourceImage size ];
    [ selImage lockFocus ];
    [ sourceImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(sx,srcSize.height -h -sy,w,h) operation:NSCompositeSourceOver ];

    [ selImage unlockFocus ];

    // {^`̒ǉ
    [ btnArray addObject:[ [ [ TYButton alloc ] initWithID:no image:unselImage selectedImage:selImage rect:rect ] autorelease ] ];

    // }EXp̃rbg}bv`
    map = (unsigned char*)[ rectMap mutableBytes ];
    index = [ btnArray count ];
    for(i = 0; i < rect.size.height; i++){
        ptr = map +(int)rect.origin.x +( (int)rect.origin.y +i) *VSCREEN_WIDTH; 
        for(j = 0; j < rect.size.width; j++,ptr++){
            *ptr = index;
        }
    }
}

// REMOVED: -std::vector<uint8_t>rectMap{
    return rectMap;
}

// REMOVED: -voidinitialButtonImage{
    // {^[hJnÓA{^摜̏
    NSEnumerator *enm;
    void* temp;
    
    // ĂȂ΁ASẴ{^`
    if(beforeSelection==TYButtonUnInitialize){
        enm = [ btnArray objectEnumerator ];
        while( (temp = [ enm nextObject ]) != nullptr){
            [ temp drawWithSelect:false ];
        }
        beforeSelection = TYButtonNoSelected;
        return;
    }
    
}

// REMOVED: -intselectedButtonID{
    if(beforeSelection) {
        return [ [ [ btnArray objectAtIndex:(beforeSelection -1) ] idNo ] intValue ];
    } else {
        return 0;
    }
}

// REMOVED: -intincToIndex{
    int nowSelection,count;
    
    count = [ btnArray count ];

    if(!count){
        return 0;
    }
    
    nowSelection = beforeSelection +1;
    if(nowSelection > count ){
        return 1;
    } else {
        return nowSelection;
    }
    
}

// REMOVED: -intdecToIndex{
    int nowSelection,count;
    
    count = [ btnArray count ];

    if(!count){
        return 0;
    }

    nowSelection = beforeSelection -1;
    if(nowSelection <= 0){
        return count;
    } else {
        return nowSelection;
    }
}

-(void)drawWithSelection:(int)status
{
    [ drawBuffer lockFocus ];
    {
        // OIԂ{^IԂŕ`
        if(beforeSelection){
            [ [ btnArray objectAtIndex:(beforeSelection -1) ] drawWithSelect:false ];
        }
        
        // Iꂽ{^IԂŕ`
        if(status){
            [ [ btnArray objectAtIndex:(status -1) ] drawWithSelect:true ];
        }
    }
    [ drawBuffer unlockFocus ];
    
    [ drawBuffer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    beforeSelection = status;
}

// REMOVED: -std::stringdescription{
    return [ btnArray description ];
}

// -dealloc (destructor in C++)
~ClassName() {
    [ sourceImage release ];
    [ btnArray release ];
    [ drawBuffer release ];
    [ rectMap release ];

    [super dealloc];
}

// @end

// @implementation TYButton
-(void*)initWithID:(NSNumber*)no image:(NSImage*)unselImage selectedImage:selImage rect:(NSRect)aRect
{
    this = [ super init ];
    
    idno = [ no retain ];
    unselectedImage = unselImage;
    [ unselectedImage retain ];
    selectedImage = selImage;
    [ selectedImage retain ];
    drawRect = aRect;
    
    return this;
}

-(void)drawWithSelect:(bool)aBool
{
    NSImage *drawImage;
    
    // gRectNAĂ`
    [ [ NSColor blackColor ] set ];
    NSRectFillUsingOperation(drawRect,NSCompositeClear);
    /*
    [ [ NSColor clearColor ] set ];
    [ NSBezierPath fillRect:drawRect ];
    */
    
    drawImage = (aBool) ? selectedImage : unselectedImage ;
    [ drawImage compositeToPoint:drawRect.origin operation:NSCompositeSourceOver ];
}

// REMOVED: -NSRect*boundingRect{
    return &drawRect;
}

// REMOVED: -NSNumber*idNo{
    return idno;
}

// REMOVED: -std::stringdescription{
    return [ NSString stringWithFormat:@"ID=%@,Rect=%@,unselImage=%@,selectedImage=%@",
                    idno,NSStringFromRect(drawRect),unselectedImage,selectedImage ];
}

// -dealloc (destructor in C++)
~ClassName() {
    [ idno release ];
    [ unselectedImage release ];
    [ selectedImage release ];
    
    [super dealloc];
}

-(void*)copyWithZone:(NSZone*)zone
{
    void* tempcopy = [ [ [ this class ] allocWithZone:zone ] init ];
    
    // 󂢃Rs[łȁH
    tempcopy->idno = [ idno retain ];
    tempcopy->unselectedImage = [ unselectedImage retain ];
    tempcopy->selectedImage = [ selectedImage retain ];
    tempcopy->drawRect = drawRect;
    
    return tempcopy;
}

// REMOVED: -boolisOverlay{
    return false;
}

// @end
