/*
 *  TYInstantGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Instant effect generator - shows new image immediately.
 */

#ifndef TYINSTANTGENERATER_QT_H
#define TYINSTANTGENERATER_QT_H

#include <QObject>
#include <QImage>
#include "TYEffecter_qt.h"

// Instant effect generator
class TYInstantGenerater : public TYEffectGenerater
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithBeforeImage:afterImage:effect:
    TYInstantGenerater(const QImage& beforeImage, const QImage& afterImage, 
                       TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    
    // Override drawEffect for instant display
    void drawEffect() override;
};

#endif // TYINSTANTGENERATER_QT_H