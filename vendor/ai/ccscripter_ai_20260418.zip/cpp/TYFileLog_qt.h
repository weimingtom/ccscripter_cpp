/*
 *  TYFileLog.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  File logging utility - tracks which files have been read.
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSMutableSet       -> QSet
 *  NSString*         -> QString
 *  NSFileHandle*      -> QFile
 */

#ifndef TYFILELOG_QT_H
#define TYFILELOG_QT_H

#include <QObject>
#include <QString>
#include <QSet>
#include <QFile>

class TYFileLog : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithContentsOfFile:(NSString*)path
    explicit TYFileLog(const QString& path, QObject* parent = nullptr);
    ~TYFileLog();
    
    // Replaces: -(BOOL)writeToFile:(NSString*)path
    bool writeToFile(const QString& path);
    
    // Merge logs
    // Replaces: -(void)addTYFileLog:(TYFileLog*)margeLog
    void addFileLog(TYFileLog* margeLog);
    
    // Add a file to the log
    // Replaces: -(void)addLog:(NSString*)filename
    void addLog(const QString& filename);
    
    // Check if file has been logged
    // Replaces: -(BOOL)isRead:(NSString*)filename
    bool isRead(const QString& filename) const;
    
    // Get all logged files
    QSet<QString> logs() const { return m_logSet; }
    
private:
    void loadFromFile(const QString& path);
    
    QSet<QString> m_logSet;  // Replaces: NSMutableSet *logSet
};

#endif // TYFILELOG_QT_H