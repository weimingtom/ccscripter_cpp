/*
 *  TYNsaArchiver.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  NSA archive management - supports compression (LZSS, SPB).
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  Inherits from TYSarArchiver
 *  NSFileHandle*      -> QFile*
 *  NSData*           -> QByteArray
 */

#ifndef TYNSAARCHIVER_QT_H
#define TYNSAARCHIVER_QT_H

#include "TYSarArchiver_qt.h"
#include <QByteArray>
#include <QString>

// NSA archive modes
enum TYNsaFileMode {
    TYNormalNsaFileMode,
    TY2TypeNsaFileMode,
    TY3TypeNsaFileMode
};

// NSA archive handler (extends SAR archiver with compression support)
class TYNsaArchiver : public TYSarArchiver
{
    Q_OBJECT
    
public:
    // Replaces: +(void)setMode:(TYNsaFileMode)aMode
    static void setMode(TYNsaFileMode mode);
    
    // Replaces: -(id)initWithContentsOfFile:(NSString*)path
    explicit TYNsaArchiver(const QString& path, QObject* parent = nullptr);
    
    // Override - unarchive with decompression
    // Replaces: -(id)unArchivedFile:(NSString*)address
    QByteArray unArchivedFile(const QString& address) override;
    
    // Get archive mode
    static TYNsaFileMode mode() { return s_mode; }
    
private:
    void loadArchive();
    
    static TYNsaFileMode s_mode;  // Replaces: static TYNsaFileMode NsaArchiverMode
};

// NSA archived file with compression info
class TYNsaArchivedFile : public QObject
{
    Q_OBJECT
    
public:
    // Factory method
    static TYNsaArchivedFile* create(unsigned offset, unsigned length, unsigned char type, unsigned exLength);
    
    // Constructor
    TYNsaArchivedFile(unsigned offset, unsigned length, unsigned char type, unsigned exLength, QObject* parent = nullptr);
    
    // Getters
    void getFileDataOffset(unsigned* offset, unsigned* length) const;
    unsigned char compressType() const { return m_compressType; }
    unsigned expandedLength() const { return m_exLength; }
    
private:
    unsigned m_fileOffset;
    unsigned m_fileLength;
    unsigned char m_compressType;  // 0=none, 1=spb, 2=lzss
    unsigned m_exLength;
};

#endif // TYNSAARCHIVER_QT_H