/*
 *  TYImageUtil.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSImage           -> QImage
 *  NSBitmapImageRep  -> QImage
 *  NSColor           -> QColor
 *  NSString*         -> QString
 *  NSArray*          -> QList<QImage>
 *  NSMutableArray*   -> QList<QImage>
 *  [image TIFFRepresentation] -> image
 *  [bitmap bitsPerPixel] -> image.depth() or image.format()
 *  [bitmap pixelsWide] -> image.width()
 *  [bitmap pixelsHigh] -> image.height()
 *  [bitmap bitmapData] -> image.bits()
 *  [image addRepresentation:rep] -> N/A (QImage is single format)
 *  Category extensions -> standalone functions
 */

#ifndef TYIMAGEUTIL_QT_H
#define TYIMAGEUTIL_QT_H

#include <QObject>
#include <QImage>
#include <QColor>
#include <QString>
#include <QList>
#include <QPoint>
#include <QSize>

// Forward declarations
class QImage;

// Constants (replaces #define)
#define TYTRANSMODE_LEFTTOP "l"
#define TYTRANSMODE_RIGHTTOP "r"
#define TYTRANSMODE_COPY "c"
#define TYTRANSMODE_ALPHA "a"
#define TYTRANSMODE_MASK "m"
#define DEFAULT_TRANSMODE "l"

// Enum (replaces typedef enum)
enum TYNegaPriority {
    TYNoNegaPriority = 0,
    TYNegaLowPriority = 1,
    TYNegaHighPriority = 2
};

// External functions (replaces extern functions)
void getRGBWithHTMLFormat(const QString& formatStr, int* r, int* g, int* b);
QColor getColorWithHTMLFormat(const QString& formatStr);
QColor getTextWindowColorWithHTMLFormat(const QString& formatStr);

// Image conversion functions
QImage ConvertImagePackedAlpha(const QImage& srcImage);
QImage ConvertImageTransrateLeftTop(const QImage& srcImage);
QImage ConvertImageWithMaskImage(const QImage& srcImage, const QImage& maskImage);

// Bitmap creation
QImage blankBitmap(int width, int height);

// Transmode
QString TYTransmodeSymbolFromString(const QString& key);

// Category extensions as standalone functions
void convertMonocroWithSample(QImage& image, const unsigned char* sample, TYNegaPriority priority);
void monocro(QImage& image, const unsigned char* sample);
void nega(QImage& image);
QList<QImage> horizontalDivide(const QImage& image, int count);

// ImageRep utility
void resizeToPixelsSize(QImage& image);

#endif // TYIMAGEUTIL_QT_H