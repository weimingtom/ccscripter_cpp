// Converted from main.m
// TODO: Manual review and fixes required

#include <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
