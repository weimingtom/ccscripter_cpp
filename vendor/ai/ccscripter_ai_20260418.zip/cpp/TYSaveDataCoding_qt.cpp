/*
 *  TYSaveDataCoding.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYSaveDataCoding_qt.h"

// Initialize save data key constants
namespace TYSaveDataKeys {
    const QString DataType = QStringLiteral("TYDataTypeSaveData");
    const QString Version = QStringLiteral("TYVersionSaveData");
    const QString Number = QStringLiteral("TYNumberSaveData");
    const QString LocalValues = QStringLiteral("TYLocalValuesSaveData");
    const QString ScriptPoint = QStringLiteral("TYScriptPointSaveData");
    const QString ReturnStack = QStringLiteral("TYReturnStackSaveData");
    const QString MakeDate = QStringLiteral("TYMakeDateSaveData");
    const QString TextWindow = QStringLiteral("TYTextWindowSaveData");
    const QString NovelLayer = QStringLiteral("TYNovelLayerSaveData");
    const QString PrintingInfo = QStringLiteral("TYPrintingInfoSaveData");
    const QString NovelLayerVisible = QStringLiteral("TYNovelLayerVisibleSaveData");
    const QString Sprites = QStringLiteral("TYSpritesSaveData");
    const QString BGImagePath = QStringLiteral("TYBGImagePathSaveData");
    const QString LeftChar = QStringLiteral("TYLeftCharSaveData");
    const QString CenterChar = QStringLiteral("TYCenterCharSaveData");
    const QString RightChar = QStringLiteral("TYRightCharSaveData");
    const QString BGMPath = QStringLiteral("TYBGMPathSaveData");
    const QString WavePath = QStringLiteral("TYWavePathSaveData");
    const QString MonocroSample = QStringLiteral("TYMonocroSampleSaveData");
    const QString NegaSpecify = QStringLiteral("TYNegaSpecifySaveData");
    const QString HumanZ = QStringLiteral("TYHumanZSaveData");
    const QString AutoClickTimer = QStringLiteral("TYAutoClickTimerSaveData");
    const QString ClickWaitCursor = QStringLiteral("TYClickWaitCursorSaveData");
    const QString PageWaitCursor = QStringLiteral("TYPageWaitCursorSaveData");
    const QString Underline = QStringLiteral("TYUnderlineSaveData");
    const QString ClickWaitType = QStringLiteral("TYClickWaitTypeSaveData");
    const QString BGMNoLoop = QStringLiteral("TYBGMNoLoopSaveData");
    const QString SpeedMode = QStringLiteral("TYSpeedModeSaveData");
    const QString LoopStack = QStringLiteral("TYLoopStackSaveData");
    const QString TextgosubIndex = QStringLiteral("TYTextgosubIndexSaveData");
    const QString EraseTextWindow = QStringLiteral("TYEraseTextWindowSavedata");
    const QString Ispage = QStringLiteral("TYIspageSaveData");
    const QString CustomSelectInfo = QStringLiteral("TYCustomSelectInfoSaveData");
    const QString LookbackBuffer = QStringLiteral("TYLookbackBufferSaveData");
}