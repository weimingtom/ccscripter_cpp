/*
 *  TYScriptStream.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Script stream parser - parses NScripter script data into lines.
 */

#ifndef TYSCRIPTSTREAM_QT_H
#define TYSCRIPTSTREAM_QT_H

#include <QObject>
#include <QByteArray>
#include <QMap>
#include <QString>

class TYScriptStream : public QObject
{
    Q_OBJECT
    
public:
    // Singleton - replaces +(id)sharedStream
    static TYScriptStream* sharedStream();
    
    // Initialize with script data
    bool initWithData(const QByteArray& data);
    
    // Add content
    void addNewLine(const char* text);
    void addLabel(const QString& label);
    
    // Access by index
    QByteArray objectAtIndex(int index) const;
    const char* cStringAtIndex(int index);
    
    // Label dictionary
    QMap<QString, int> labelDict() const { return m_labelDict; }
    
    // Current line
    int currentLine() const { return m_line; }
    void setCurrentLine(int line) { m_line = line; }
    
private:
    TYScriptStream(QObject* parent = nullptr);
    
    QByteArray m_data;
    QMap<int, QByteArray> m_linePtrArray;  // line number -> line data
    QMap<QString, int> m_labelDict;       // label -> line number
    int m_line;
    
    static TYScriptStream* s_instance;
};

#endif // TYSCRIPTSTREAM_QT_H