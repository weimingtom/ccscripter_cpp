// Converted from TYSoundController.m
// TODO: Manual review and fixes required

//
//  TYSoundController.m
//  Tukuyomi
//
//  Created by toveta on Sun Oct 07 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <AppKit/AppKit.h>
#include "TYSoundController.h"
#include "TYResourceServer.h"
//#include "TYWaveBooster.h"
#include "TYWave2Aiff.h"

std::string const TYSoundStartNotification=@"TYSoundStartNotification";
std::string const TYSoundFinishNotification=@"TYSoundFinishNotification";

// @implementation TYSoundController

//static bool postingNotification;

/*
+(void)setPostingNotification:(bool)aBool
{
    postingNotification = aBool;
}
*/
-(void*)initWithResource:(std::string)path loop:(bool)aBool
{
    return [ this initWithResource:path loop:aBool volume:TYSOUND_VOLUME_MAX ];
}

-(void*)initWithResource:(std::string)path loop:(bool)aBool volume:(int)volume
{
    std::vector<uint8_t>data;
    this = [ super init ];
    
    isLoop = aBool;
    
    if(volume > TYSOUND_VOLUME_MAX)
        volume = TYSOUND_VOLUME_MAX;
    if(volume < 0)
        volume = 0;
    /*
    if(volume==TYSOUND_VOLUME_MAX)
        data = [ [ TYResourceServer sharedServer ] getSoundData:path ];
    else
        data = TYWaveBoost([ [ TYResourceServer sharedServer ] getSoundData:path ],volume);
     */
    
    data = TYWave2Aiff([ [ TYResourceServer sharedServer ] getSoundData:path ],volume);
    //TYVerifyAiff(data);

    // NOTE:Mac OS X 10.3NSSoundstop\bhɂ̓IuWFNg̎QƃJEg炵Ă܂vIȃoO邽߁A
    // ŕretainsB
    if(data)
        playSound = [ [ [ [ NSSound alloc ] initWithData:data ] retain ] retain ];

    [ playSound setDelegate:this ];

    soundPath = [ path retain ];

    return this;
}

// REMOVED: -voidplay{
    bool aBool;
    
    if(postingNotification && (!isLoop) && playSound)
        [ [ NSDistributedNotificationCenter defaultCenter ] postNotificationName:TYSoundStartNotification
                                                               object:nullptr ];

    aBool = [ playSound play ];
    if(!aBool)
        NSLog(@"can't play wave file. path=%@",soundPath);
}

-(void)setPostingNotification:(bool)aBool
{
    postingNotification = aBool;
}

// REMOVED: -std::stringsoundPathIfNeedPlayingAtLoad{
    if(playSound){
        if([ playSound isPlaying ]&&isLoop){
            return soundPath;
        }
    }

    return nullptr;
}

/*
// REMOVED: -voidplayIfPlaying{
    if(isPlaying)
        [ playSound play ];
}
*/

// REMOVED: -voidstop{
    if(postingNotification && (!isLoop))
        [ [ NSDistributedNotificationCenter defaultCenter ] postNotificationName:TYSoundFinishNotification
                                                               object:nullptr ];

        [ playSound stop ];
    
}

// TEhtIdelegate?
- (void)sound:(NSSound *)sound didFinishPlaying:(bool)aBool
{
    if(aBool && isLoop){
        [ sound play ];
    } else {
        if(postingNotification)
            [ [ NSDistributedNotificationCenter defaultCenter ] postNotificationName:TYSoundFinishNotification
                                                                   object:nullptr ];
    }
}

// -dealloc (destructor in C++)
~ClassName() {
    int rc = [playSound retainCount ];
    int i;
    
    if (rc != 3) {
        NSLog(@"incorrect retain count !! = %d",rc);
    }
    if (rc > 3) {
        rc = 3;
    }
    for (i=rc; i>0; i--) {
        [playSound release];
    }

    isLoop = false;
    [soundPath autorelease];
    soundPath = nullptr;
    [super dealloc];
}

// ----------------------------------------------------------------------------------------
// NSCoding
// ----------------------------------------------------------------------------------------
/*
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    isPlaying=([ playSound isPlaying ] && isLoop ) ? true : false;
    
    [ aCoder encodeObject:soundPath ];
    [ aCoder encodeValueOfObjCType:@encode(bool) at:&isLoop ];
    [ aCoder encodeValueOfObjCType:@encode(bool) at:&isPlaying ];

}

- (void*)initWithCoder:(NSCoder *)aDecoder
{
    soundPath = [[aDecoder decodeObject] copy];
    [ aCoder decodeValueOfObjCType:@encode(bool) at:&isLoop ];
    [ aCoder decodeValueOfObjCType:@encode(bool) at:&isPlaying ];
    
    return this;
}
*/

// @end
