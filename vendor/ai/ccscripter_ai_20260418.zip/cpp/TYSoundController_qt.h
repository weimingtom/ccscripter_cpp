/*
 *  TYSoundController.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSSound           -> QMediaPlayer / QAudioOutput
 *  NSString*          -> QString
 *  NSNotification     -> signals/slots
 *  Delegate pattern   -> signals/slots
 *  [sound play]       -> player->play()
 *  [sound stop]       -> player->stop()
 *  [sound isPlaying]  -> player->playbackState()
 *  retain/release     -> parent/ownership
 */

#ifndef TYSOUNDCONTROLLER_QT_H
#define TYSOUNDCONTROLLER_QT_H

#include <QObject>
#include <QString>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QByteArray>
#include <QFile>
#include <QBuffer>
#include <QTimer>

// Constants
#define TYSOUND_VOLUME_MAX 256

// Notifications as signals (replaces NSNotification)
// In Qt, we use signals instead of NSNotificationCenter
class TYSoundController : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithResource:(NSString*)path loop:(BOOL)aBool
    explicit TYSoundController(const QString& path, bool loop, QObject* parent = nullptr);
    
    // Replaces: -(id)initWithResource:(NSString*)path loop:(BOOL)aBool volume:(int)volume
    TYSoundController(const QString& path, bool loop, int volume, QObject* parent = nullptr);
    
    ~TYSoundController();
    
    // Playback controls
    // Replaces: -(void)play
    void play();
    
    // Replaces: -(void)stop
    void stop();
    
    // Replaces: -(void)setPostingNotification:(BOOL)aBool
    void setPostingNotification(bool aBool);
    
    // Replaces: -(NSString*)soundPathIfNeedPlayingAtLoad
    QString soundPathIfNeedPlayingAtLoad();
    
    // Volume control
    void setVolume(int volume);
    int volume() const;
    
    // Status
    bool isLooping() const { return m_isLoop; }
    bool isPlaying() const;
    
signals:
    // Replaces: NSString* const TYSoundStartNotification
    void soundStarted();
    
    // Replaces: NSString* const TYSoundFinishNotification  
    void soundFinished();
    
public slots:
    // Handle playback state changes
    void handlePlaybackStateChanged();
    
private:
    void init(const QString& path, bool loop, int volume);
    QByteArray loadSoundData(const QString& path, int volume);
    
private:
    QMediaPlayer* m_player;           // Replaces: NSSound *playSound
    QString m_soundPath;              // Replaces: NSString *soundPath
    bool m_isLoop;                    // Replaces: BOOL isLoop
    bool m_postingNotification;       // Replaces: BOOL postingNotification
    QAudioOutput* m_audioOutput;     // For volume control
    int m_volume;                     // 0-256 scale
};

#endif // TYSOUNDCONTROLLER_QT_H