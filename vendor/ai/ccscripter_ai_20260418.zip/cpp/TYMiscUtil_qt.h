/*
 *  TYMiscUtil.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Miscellaneous utility functions for string handling, file paths, etc.
 */

#ifndef TYMISCUTIL_QT_H
#define TYMISCUTIL_QT_H

#include <QString>
#include <QList>
#include <QVariant>

// Scan integer and length from string
// Replaces: extern BOOL scanIntAndLengthFromString(NSString*,int*,int*);
bool scanIntAndLengthFromString(const QString& str, int* value, int* length);

// Get application directory
// Replaces: extern NSString* getAppDirectory(void);
QString getAppDirectory();

// Convert Windows path to Unix path
// Replaces: extern NSString* winPathToUnix(NSString*);
QString winPathToUnix(const QString& path);

// Set/get NScripter root directory
// Replaces: extern void setNScrRootDirectory(NSString*);
void setNScrRootDirectory(const QString& path);

// Replaces: extern NSString* getNScrRootDirectory(void);
QString getNScrRootDirectory();

// Random number in range
// Replaces: extern int TYRandom(int,int);
int TYRandom(int min, int max);

// Wide character decimal string conversion
// Replaces: extern NSString* TYWideCharDecimalString(int aInt);
QString TYWideCharDecimalString(int value);

// Replaces: extern NSString* TYWideCharDecimalStringWithString(NSString *decStr);
QString TYWideCharDecimalStringWithString(const QString& decStr);

// Character set utilities (as static factory methods in Qt)
class TYCharacterSetUtils {
public:
    static QString varNameCharacterSet();
};

// Array utilities
class TYArrayUtils {
public:
    // Replaces: -(id)subarrayFromIndex:(unsigned int)aInt;
    template<typename T>
    static QList<T> subarrayFromIndex(const QList<T>& list, unsigned int index);
};

// Dictionary utilities
class TYDictionaryUtils {
public:
    // Replaces: -(id)objectsSortedByKeyUsingSelector:(SEL)comparator;
    // Note: Comparator should be a function or lambda
    template<typename T>
    static QList<T> objectsSortedByKey(const QMap<QString, T>& map);
};

#endif // TYMISCUTIL_QT_H