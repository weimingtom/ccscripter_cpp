/*
 *  TYMosaicEffectGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYMosaicEffectGenerater_qt.h"
#include <QPainter>

const int PHASE_NUM = 6;

// Block size tables for different screen heights
static const int blockSizeTable[2][PHASE_NUM] = { 
    { 160, 80, 40, 20, 10, 5 },   // 480 height
    { 200, 100, 50, 25, 10, 5 }    // 600 height
};

TYMosaicEffectGenerater::TYMosaicEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                                               TYEffectDefinitionValue* effect, QObject* parent)
    : QObject(parent)
    , m_afterImage(afterImage)
    , m_phase(0)
    , m_phaseNum(PHASE_NUM)
    , m_isComplete(false)
{
    TYEffectDefinition effdef = effect->definition();
    m_inToward = (effdef.type == TYEffectMosaicIn);
    
    if (m_inToward) {
        m_sourceImage = afterImage;
    } else {
        m_sourceImage = beforeImage;
    }
    
    m_phaseInterval = effdef.time / 1000.0 / PHASE_NUM;
    m_currentImage = m_sourceImage;
    
    QTimer::singleShot(0, this, SLOT(drawEffect()));
}

TYMosaicEffectGenerater::~TYMosaicEffectGenerater()
{
}

void TYMosaicEffectGenerater::drawEffect()
{
    if (m_phase >= PHASE_NUM) {
        m_isComplete = true;
        if (m_inToward) {
            m_currentImage = m_afterImage;
            emit effectImageChanged(m_currentImage);
        }
        emit effectFinished();
        return;
    }
    
    QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
    
    int screenHeight = m_sourceImage.height();
    int tableIndex = (screenHeight == 600) ? 1 : 0;
    
    int blockSize;
    if (m_inToward) {
        blockSize = blockSizeTable[tableIndex][m_phase];
    } else {
        blockSize = blockSizeTable[tableIndex][PHASE_NUM - m_phase - 1];
    }
    
    int width = m_sourceImage.width();
    int height = m_sourceImage.height();
    
    // Create mosaic image
    QImage mosaicImage(width, height, QImage::Format_RGB32);
    mosaicImage.fill(m_sourceImage.pixel(0, 0));
    
    // Average color for each block
    for (int h = 0; h < height; h += blockSize) {
        for (int w = 0; w < width; w += blockSize) {
            int r = 0, g = 0, b = 0, count = 0;
            
            // Calculate average color in block
            for (int ph = 0; ph < blockSize && (h + ph) < height; ph++) {
                for (int pw = 0; pw < blockSize && (w + pw) < width; pw++) {
                    QRgb pixel = m_sourceImage.pixel(w + pw, h + ph);
                    r += qRed(pixel);
                    g += qGreen(pixel);
                    b += qBlue(pixel);
                    count++;
                }
            }
            
            if (count > 0) {
                r /= count;
                g /= count;
                b /= count;
            }
            
            QRgb avgColor = qRgb(r, g, b);
            
            // Fill block with average color
            for (int ph = 0; ph < blockSize && (h + ph) < height; ph++) {
                for (int pw = 0; pw < blockSize && (w + pw) < width; pw++) {
                    mosaicImage.setPixel(w + pw, h + ph, avgColor);
                }
            }
        }
    }
    
    m_currentImage = mosaicImage;
    emit effectImageChanged(m_currentImage);
    
    m_phase++;
}