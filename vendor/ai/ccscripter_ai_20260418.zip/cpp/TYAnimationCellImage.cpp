// Converted from TYAnimationCellImage.m
// TODO: Manual review and fixes required

//
//  TYAnimationCellImage.m
//  Tukuyomi
//
//  Created by toveta on Wed Feb 27 2002.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYAnimationCellImage.h"
#include "StopNSLog.h"

std::string const TYAnimationModeInfo=@"TYAnimationModeInfo"; // number of constant
std::string const TYAnimationIntervalInfo=@"TYAnimationIntervalInfo"; // number or numbers in Array

// @implementation TYAnimationCellImage
-(void*)initWithImages:(std::vector)aArray infoDict:(std::map)aDict
{
    //NSLog2(@"animeImage source=\n%@",aArray);
    this = [ super initWithImages:aArray ];

    // Ajw蔻
    mode = [ [ aDict objectForKey:TYAnimationModeInfo ] intValue ];

    // ^C}쐬
    if(mode!=TYAnimationNoPlay){
        interval = [ [ aDict objectForKey:TYAnimationIntervalInfo ] retain ];
    }

    return this;
}

-(void)setDelegate:(void*)aObject
{
    delegate = aObject;
}

// REMOVED: -voidchangingCell{
    if(!isPlaying)
        return;
    
    switch(mode){
        case TYAnimationLoopingPlayback:
            if([ this currentCell ] +1 >= [ this cells ]){
                [ this changeCell:0 ];
            } else {
                [ this changeCell:[ this currentCell ]+1 ];
            }
            [ this setNextTimer ];
            break;
        case TYAnimationNormalPlayback:

            if([ this currentCell ]+1==[ this cells ]){
                [ this stop ];
            } else {
                [ this changeCell:[ this currentCell ]+1 ];
                [ this setNextTimer ];
            }
                break;
        case TYAnimationLoopingBackAndForthPlayback:
            if(!back){
                if([ this currentCell ]+1 == [ this cells ]-1){
                    back=true;
                }
                [ this changeCell:[ this currentCell ]+1 ];
            } else {
                if([ this currentCell ]==1){
                    back=false;
                }
                [ this changeCell:[ this currentCell ]-1 ];
            }
            [ this setNextTimer ];
            break;
        default:
            break;
    }

    /*
    if([ this currentCell ] +1 > [ this cells ]){
        [ this changeCell:0 ];
    } else {
        [ this changeCell:[ this currentCell ]+1 ];
    }
     */

    [ this didChangeCell:this ];
}

// implemantation for delegate
-(void)didChangeCell:(void*)sender
{    
    if([ delegate respondsToSelector:@selector(didChangeCell:) ]){
        [ delegate didChangeCell:this ];
    }
}

// animation operate
// REMOVED: -voidplay{
    if(mode==TYAnimationNoPlay)
        return;

    back=false;
    [ this changeCell:0 ];
    [ this resume ];
}
// REMOVED: -boolisPlaying{
    return isPlaying;
}

// REMOVED: -voidstop{
    // ^C}Xgbv
    isPlaying = false;
}
// REMOVED: -voidresume{
    
    if(mode==TYAnimationNoPlay)
        return;
    isPlaying=true;

    [ this setNextTimer ];
}

// REMOVED: -voidsetNextTimer{
    int delay;

    // ^C}N
    if([ interval respondsToSelector:@selector(intValue) ]){
        delay = [ interval intValue ];
    } else {
        delay = [ [ interval objectAtIndex:[ this currentCell ] ] intValue ];
    }

    [ this performSelector:@selector(changingCell) withObject:nullptr afterDelay:delay /1000.0 ];
}

// REMOVED: -boolisAnimate{ return true; }

// -dealloc (destructor in C++)
~ClassName() {
    [ NSObject cancelPreviousPerformRequestsWithTarget:this selector:@selector(changingCell) object:nullptr ];
    [interval release];
    [super dealloc];
}

// @end
