/*
 *  TYSarArchivedFile.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYSarArchivedFile_qt.h"

TYSarArchivedFile::TYSarArchivedFile(unsigned offset, unsigned length, QObject* parent)
    : QObject(parent)
    , m_fileOffset(offset)
    , m_fileLength(length)
{
}

// Replaces: +(id)archivedFileoffset:(unsigned)offset length:(unsigned)length
TYSarArchivedFile* TYSarArchivedFile::create(unsigned offset, unsigned length)
{
    return new TYSarArchivedFile(offset, length);
}

// Replaces: -(void)getFileDataOffset:(int*)fileOffset length:(int*)length
void TYSarArchivedFile::getFileDataOffset(unsigned* fileOffset, unsigned* length) const
{
    *fileOffset = m_fileOffset;
    *length = m_fileLength;
}