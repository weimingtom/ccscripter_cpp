/*
 *  TYNScrSprite.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYNScrSprite_qt.h"

const QString TYSpriteAnimationNotification = QStringLiteral("TYSpriteAnimationNotification");

TYNScrSprite::TYNScrSprite(int spriteId, const QString& path, const QPoint& point,
                          int alpha, bool visible, QObject* parent)
    : QObject(parent)
    , m_spriteId(spriteId)
    , m_visible(visible)
    , m_registDelegate(false)
    , m_imagePath(path)
    , m_position(point)
    , m_alpha(alpha)
{
    // Load image from path
    if (!path.isEmpty()) {
        m_image.load(path);
    }
}

TYNScrSprite::~TYNScrSprite()
{
}

void TYNScrSprite::moveX(int x, int y, int alpha)
{
    m_position.setX(x);
    m_position.setY(y);
    m_alpha = alpha;
    emit spriteChanged(this);
}

void TYNScrSprite::absoluteMoveX(int x, int y, int alpha)
{
    moveX(x, y, alpha);
}

void TYNScrSprite::draw()
{
    // In QtWidgets integration, this would render the sprite to a QPixmap or QLabel
    // For now, just emit signal
    emit spriteChanged(this);
}