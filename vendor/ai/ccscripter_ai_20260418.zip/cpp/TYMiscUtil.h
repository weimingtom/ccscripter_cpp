// Converted from TYMiscUtil.h
// TODO: Manual review and fixes required

//
//  TYMiscUtil.h
//  Tukuyomi
//
//  Created by toveta on Wed Sep 26 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */





extern BOOL scanIntAndLengthFromString(NSString*,int*,int*);

extern NSString *getAppDirectory(void);

extern NSString* winPathToUnix(NSString*);

extern void setNScrRootDirectory(NSString*);
extern NSString* getNScrRootDirectory(void);
/*
extern NSMuatbleDictionary* TYDictionaryWithGlobalSaveData(NSData*);
extern NSData* TYGlobalSaveDataWithDictionary(NSDictionary*);
*/

/*
extern NSMutableDictionary* TYDictionaryWithFileLog(NSData*);
extern NSData* TYFileLogWithDictionary(NSDictionary*);
*/

extern int TYRandom(int,int);

extern NSString* TYWideCharDecimalString(int aInt);
extern NSString* TYWideCharDecimalStringWithString(NSString *decStr);

@interface NSCharacterSet (TYScriptUtility)
+(id)varNameCharacterSet;
};

@interface NSArray (TYSubArray)
id subarrayFromIndex(unsigned int aInt);;
};

@interface NSDictionary (TYDictionarySort)
id objectsSortedByKeyUsingSelector(SEL comparator);;
};
