/*
 *  lzss_qt.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "lzss_qt.h"

#define EI  8
#define EJ  4
#define P   1  /* If match length <= P then output one character */
#define N (1 << EI)  /* buffer size */
#define F ((1 << EJ) + P)  /* lookahead buffer size */

static int bit_mask;
static unsigned char buffer[N * 2];
static int stream_size;
static const unsigned char *fp;

// Replaces: static void init(NSFileHandle *fh, size_t encode_size)
static void init(QFile& fh, size_t encode_size)
{
    stream_size = static_cast<int>(encode_size);
    
    // Replaces: fp = [ [ fh readDataOfLength:encode_size ] bytes ];
    // Read entire file into memory
    QByteArray fileData = fh.read(encode_size);
    fp = reinterpret_cast<const unsigned char*>(fileData.constData());
    
    // Note: fileData must live as long as we use fp
    // In production, store fileData as static/class member
    static QByteArray storedData;
    storedData = fileData;
    fp = reinterpret_cast<const unsigned char*>(storedData.constData());
    
    bit_mask = 0;
}

static int getbit(int n) /* get n bits */
{
    int i, x;
    static int buf;
    
    x = 0;
    for (i = 0; i < n; i++) {
        if (bit_mask == 0) {
            if (stream_size-- <= 0) return EOF;
            buf = *fp++;
            bit_mask = 128;
        }
        x <<= 1;
        if (buf & bit_mask) x |= 1;
        bit_mask >>= 1;
    }
    return x;
}

/*
 * Qt version of LZSS decompression
 *
 * Objective-C (Cocoa) -> Qt mapping:
 * - NSMutableData *data = [ NSMutableData dataWithLength:original_size ];
 *   -> QByteArray data(original_size, 0);
 *
 * - unsigned char *p = [ data mutableBytes ];
 *   -> unsigned char *p = reinterpret_cast<unsigned char*>(data.data());
 */
QByteArray TYDataWithLzssDecodeFromFile(QFile& fh, size_t encode_size, size_t original_size)
{
    // Replaces: NSMutableData *data = [ NSMutableData dataWithLength:original_size ]; 
    QByteArray data(static_cast<int>(original_size), 0);
    unsigned char* p = reinterpret_cast<unsigned char*>(data.data());  // Replaces: [ data mutableBytes ]
    int i, j, k, r, c;

    init(fh, encode_size);
    
    for (i = 0; i < N - F; i++) buffer[i] = ' ';
    r = N - F;
    while ((c = getbit(1)) != EOF) {
        if (c) {
            if ((c = getbit(8)) == EOF) break;
            *p++ = c;
            buffer[r++] = c;  r &= (N - 1);
        } else {
            if ((i = getbit(EI)) == EOF) break;
            if ((j = getbit(EJ)) == EOF) break;
            for (k = 0; k <= j + 1; k++) {
                c = buffer[(i + k) & (N - 1)];
                *p++ = c;
                buffer[r++] = c;  r &= (N - 1);
            }
        }
    }

    return data;
}