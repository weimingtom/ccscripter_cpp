/*
 *  TYScrollEffectGenerater.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYScrollEffectGenerater_qt.h"
#include <QPainter>

TYScrollEffectGenerater::TYScrollEffectGenerater(const QImage& beforeImage, const QImage& afterImage,
                                                 TYEffectDefinitionValue* effect, QObject* parent)
    : QObject(parent)
    , m_beforeImage(beforeImage)
    , m_afterImage(afterImage)
    , m_isComplete(false)
{
    TYEffectDefinition effdef = effect->definition();
    
    // Determine scroll direction
    switch (effdef.type) {
    case TYEffectBottomScroll:
        m_reverse = true;
        m_horizontal = false;
        break;
    case TYEffectLeftScroll:
        m_reverse = true;
        m_horizontal = true;
        break;
    case TYEffectRightScroll:
        m_reverse = false;
        m_horizontal = true;
        break;
    default:
        m_reverse = false;
        m_horizontal = false;
        break;
    }
    
    // Create union image (before + after side by side)
    if (m_horizontal) {
        m_unionImage = QImage(m_beforeImage.width() * 2, m_beforeImage.height(), QImage::Format_ARGB32);
    } else {
        m_unionImage = QImage(m_beforeImage.width(), m_beforeImage.height() * 2, QImage::Format_ARGB32);
    }
    m_unionImage.fill(Qt::transparent);
    
    QPainter painter(&m_unionImage);
    if (m_reverse) {
        if (m_horizontal) {
            painter.drawImage(m_beforeImage.width(), 0, m_beforeImage);
            painter.drawImage(0, 0, m_afterImage);
        } else {
            painter.drawImage(0, m_beforeImage.height(), m_beforeImage);
            painter.drawImage(0, 0, m_afterImage);
        }
    } else {
        painter.drawImage(0, 0, m_beforeImage);
        if (m_horizontal) {
            painter.drawImage(m_beforeImage.width(), 0, m_afterImage);
        } else {
            painter.drawImage(0, m_beforeImage.height(), m_afterImage);
        }
    }
    painter.end();
    
    m_phaseMax = m_horizontal ? m_beforeImage.width() : m_beforeImage.height();
    m_effectTime = effdef.time;
    m_phaseInterval = effdef.time / 1000.0 / m_phaseMax;
    m_startDate = QDateTime::currentDateTime();
    m_currentImage = m_afterImage;
    
    QTimer::singleShot(0, this, SLOT(drawEffect()));
}

TYScrollEffectGenerater::~TYScrollEffectGenerater()
{
}

void TYScrollEffectGenerater::drawEffect()
{
    qint64 elapsed = m_startDate.msecsTo(QDateTime::currentDateTime());
    int phase = (elapsed * m_phaseMax) / m_effectTime;
    
    if (phase >= m_phaseMax) {
        // Effect complete - show after image
        m_currentImage = m_afterImage;
        m_isComplete = true;
        emit effectImageChanged(m_currentImage);
        emit effectFinished();
        return;
    }
    
    // Calculate offset
    int offset = m_reverse ? (m_phaseMax - phase) : phase;
    
    QRect srcRect;
    if (m_horizontal) {
        srcRect = QRect(offset, 0, m_beforeImage.width(), m_beforeImage.height());
    } else {
        srcRect = QRect(0, offset, m_beforeImage.width(), m_beforeImage.height());
    }
    
    m_currentImage = m_unionImage.copy(srcRect);
    
    emit effectImageChanged(m_currentImage);
    
    QTimer::singleShot(static_cast<int>(m_phaseInterval * 1000), this, SLOT(drawEffect()));
}