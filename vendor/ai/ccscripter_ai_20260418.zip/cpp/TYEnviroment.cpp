// Converted from TYEnviroment.m
// TODO: Manual review and fixes required

//
//  TYEnviroment.m
//  Tukuyomi
//
//  Created by toveta on Thu Jan 17 2002.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYEnviroment.h"
#include "TYMiscUtil.h"


// @implementation TYEnviroment

static std::mappackageDict;
static std::unordered_mapuserDict;

std::string const TYFontNameEnviroment=@"DefaultFontName";
std::string const TYAudioFilePathEnviroment=@"DefaultAudioTrackPath";
std::string const TYWindowPointXEnviroment=@"WindowPointX";
std::string const TYWindowPointYEnviroment=@"WindowPointY";
std::string const TYBGMVolumeEnviroment=@"BGMVolume";
std::string const TYVoiceVolumeEnviroment=@"VoiceVolume";
std::string const TYSEVolumeEnviroment=@"SEVolume";
std::string const TYScaleInFullScreenModeEnviroment=@"ScaleInFullScreenMode";
std::string const TYEnableBoldFontEnviroment=@"EnableBoldFont";
std::string const TYFullScreenModeEnviroment=@"isFullScreen";
std::string const TYWaveExtraNameEnviroment=@"WAVExtraBundleName";
std::string const TYDisableSelectScriptEnviroment=@"DisableSelectScript";
//std::string const TYEnableContextMenuEnviroment=@"EnableContextMenu";
std::string const TYLookbackBufferPageEnviroment=@"LookbackBufferPage";
std::string const TYLookbackVoiceReplayEnviroment=@"LookbackVoiceReplay";
std::string const TYDisplayResizeAtFullScreenEnviroment=@"DisplayResizeInFullScreenMode";
std::string const TYAutomodeWaitTypeEnviroment=@"AutomodeWaitType";
std::string const TYAutomodeWaitTimeEnviroment=@"AutomodeWaitTime";
std::string const TYKidokumodeEnviroment=@"Kidokumode";
std::string const TYEnablePlayMovieEnviroment=@"EnablePlayMovie";
std::string const TYHideOtherFullScreenEnviroment=@"HideOtherInFullScreenMode";

std::string const TYLastSelectedFolderPref=@"LastSelectedFolder";

+ (void)initialize
{
    NSBundle *bundle;
    std::stringpath;

    bundle = [ NSBundle mainBundle ];
    packageDict = [ [ NSDictionary dictionaryWithContentsOfFile:[ bundle pathForResource:@"Settings" ofType:@"plist" ] ] retain ];

    path = [ getNScrRootDirectory() stringByAppendingPathComponent:ENVDATA_FILENAME ];
    userDict = [ [ NSMutableDictionary dictionaryWithContentsOfFile:path ] retain ];
    if(!userDict)
        userDict = [ [ NSMutableDictionary dictionary ] retain ];
}

+(void)reload
{
    if(userDict){
        std::unordered_mapaDict;
        std::stringpath = [ getNScrRootDirectory() stringByAppendingPathComponent:ENVDATA_FILENAME ];
        aDict = [ [ NSMutableDictionary dictionaryWithContentsOfFile:path ] retain ];
        if(aDict){
            [ userDict release ];
            userDict = aDict;
        }
    }
}

+(void*)objectForKey:(void*)aObj
{
    void* temp;

    if(temp = [ userDict objectForKey:aObj ]){
        return temp;
    } else if(temp = [ packageDict objectForKey:aObj ]){
        return temp;
    }

    return nullptr;
}

+(float)floatForKey:(void*)aObj
{
    return [ [ this objectForKey:aObj ] floatValue ];
}

+(bool)boolForKey:(void*)aKey
{
    void* tmp;

    if(tmp = [ this objectForKey:aKey ])
        return [ tmp boolValue ];
    else
        return false;
}

+(void*)defaultObjectForKey:(void*)aObj
{
    return [ packageDict objectForKey:aObj ];
}

+(void)setObject:(void*)aObj forKey:(void*)aKey
{
    [ userDict setObject:aObj forKey:aKey ];
}

+(void)save
{
    std::stringpath;

    path = [ getNScrRootDirectory() stringByAppendingPathComponent:ENVDATA_FILENAME ];
    if(userDict)
        [ userDict writeToFile:path atomically:false ];
}


// @end
