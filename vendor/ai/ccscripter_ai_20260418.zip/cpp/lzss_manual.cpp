/*
 *  lzss.cpp
 *  Tukuyomi
 *
 *  Converted from lzss.m
 *
 *  Original copyright and license apply (see lzss.h)
 */

#include "lzss_manual.h"

#define EI  8
#define EJ  4
#define P   1  /* If match length <= P then output one character */
#define N (1 << EI)  /* buffer size */
#define F ((1 << EJ) + P)  /* lookahead buffer size */

static int bit_mask;
static unsigned char buffer[N * 2];
static int stream_size;
static const unsigned char *fp;

// Replaces: static void init(NSFileHandle *fh,size_t encode_size)
static void init(FILE* fh, size_t encode_size)
{
    stream_size = static_cast<int>(encode_size);
    
    // Allocate buffer and read file data
    // Replaces: fp = [ [ fh readDataOfLength:encode_size ] bytes ];
    unsigned char* data = new unsigned char[encode_size];
    fread(data, 1, encode_size, fh);
    fp = data;
    
    bit_mask = 0;
}

static int getbit(int n) /* get n bits */
{
    int i, x;
    static int buf;
    
    x = 0;
    for (i = 0; i < n; i++) {
        if (bit_mask == 0) {
            if (stream_size-- <= 0) return EOF;
            buf = *fp++;
            bit_mask = 128;
        }
        x <<= 1;
        if (buf & bit_mask) x |= 1;
        bit_mask >>= 1;
    }
    return x;
}

/*
 * NSAアーカイブの復号 LZSS 展開ルーチン (is_compress == 2)
 * 
 * Conversion notes:
 * - NSFileHandle* -> FILE*
 * - NSMutableData -> std::vector<uint8_t>
 * - [data mutableBytes] -> data.data()
 */
std::vector<uint8_t> TYDataWithLzssDecodeFromFile(FILE* fh, size_t encode_size, size_t original_size)
{
    // Replaces: NSMutableData *data = [ NSMutableData dataWithLength:orignal_size ]; 
    std::vector<uint8_t> data(original_size);
    unsigned char* p = data.data();  // Replaces: [ data mutableBytes ]
    int i, j, k, r, c;

    init(fh, encode_size);
    
    for (i = 0; i < N - F; i++) buffer[i] = ' ';
    r = N - F;
    while ((c = getbit(1)) != EOF) {
        if (c) {
            if ((c = getbit(8)) == EOF) break;
            *p++ = c;
            buffer[r++] = c;  r &= (N - 1);
        } else {
            if ((i = getbit(EI)) == EOF) break;
            if ((j = getbit(EJ)) == EOF) break;
            for (k = 0; k <= j + 1; k++) {
                c = buffer[(i + k) & (N - 1)];
                *p++ = c;
                buffer[r++] = c;  r &= (N - 1);
            }
        }
    }

    return data;
}