/*
 *  TYWave2Aiff.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYWave2Aiff_qt.h"
#include "TYMiscUtil_qt.h"
#include "TYEnviroment_qt.h"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QDebug>
#include <cstring>
#include <cstdlib>

// Constants
const char* TYWaveExtraNameEnviroment = "TYWaveExtraName";

#define AIFF_HEADER_SIZE 54

// AIFF sample rate constants (80-bit IEEE 754 extended)
static const uint8_t SAMPLE_RATE_22050[] = { 0x40, 0x0d, 0xac, 0x44, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static const uint8_t SAMPLE_RATE_44100[] = { 0x40, 0x0e, 0xac, 0x44, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

#define WAVE_FORMAT_PCM 1

// Replaces: NSString* const OGG_DECODER_NAME
#define OGG_DECODER_NAME "OggDecoder.bundle"

// Plugin loader (simplified - full implementation would use QPluginLoader)
static QObject* pluginBundle = nullptr;

// Helper functions for endianness
inline uint16_t swapLittleShortToHost(uint16_t val) {
    return ((val & 0x00ff) << 8) | ((val & 0xff00) >> 8);
}

inline uint32_t swapLittleIntToHost(uint32_t val) {
    return ((val & 0x000000ff) << 24) |
           ((val & 0x0000ff00) << 8) |
           ((val & 0x00ff0000) >> 8) |
           ((val & 0xff000000) >> 24);
}

inline uint32_t swapHostIntToBig(uint32_t val) {
    return swapLittleIntToHost(val);  // Same function, different name for clarity
}

inline uint16_t swapHostShortToBig(uint16_t val) {
    return swapLittleShortToHost(val);
}

// Replaces: getAppDirectory()
QString getAppDirectory()
{
    return QCoreApplication::applicationDirPath();
}

// Replaces: NSData* TYWave2Aiff(NSData* sourceData, int volume)
QByteArray TYWave2Aiff(const QByteArray& sourceData, int volume)
{
    if (sourceData.isEmpty()) {
        return QByteArray();
    }
    
    const uint8_t* ptr = reinterpret_cast<const uint8_t*>(sourceData.constData());
    
    // Check for OGG format
    if (strncmp(reinterpret_cast<const char*>(ptr), "OggS", 4) == 0) {
        qDebug() << "OGG format detected - OGG decoder plugin not fully implemented";
        // In real implementation, would load OggDecoder.bundle plugin
        return sourceData;
    }
    
    // Check for RIFF/WAVE format
    if (strncmp(reinterpret_cast<const char*>(ptr), "RIFF", 4) != 0) {
        qWarning() << "Illegal file header - not RIFF or OGG";
        return sourceData();
    }
    
    ptr += 8;  // Skip "RIFF" + size
    
    if (strncmp(reinterpret_cast<const char*>(ptr), "WAVE", 4) != 0) {
        qWarning() << "This data is not WAVE file";
        return sourceData;
    }
    ptr += 4;
    
    // Skip format chunk header (8 bytes)
    ptr += 8;
    
    // Get format ID
    uint16_t format = swapLittleShortToHost(*reinterpret_cast<const uint16_t*>(ptr));
    ptr += 2;
    
    int channel = 0;
    int rate = 0;
    int bytesOfData = 0;
    int dataSize = 0;
    bool extendData = false;
    int frame = 0;
    bool swapData = false;
    
    switch (format) {
    case WAVE_FORMAT_PCM:
        // Get number of channels
        channel = swapLittleShortToHost(*reinterpret_cast<const uint16_t*>(ptr));
        ptr += 2;
        
        // Get sample rate
        rate = swapLittleIntToHost(*reinterpret_cast<const uint32_t*>(ptr));
        if (rate != 22050 && rate != 44100 && rate != 11025) {
            qWarning() << "Not supported sampling rate (supported only 22.05Khz or 44.1Khz or 11.025Khz)";
            return sourceData;
        }
        if (rate == 11025) {
            extendData = true;
        }
        ptr += 8;  // Skip rate + skip bytes
        
        // Get block align
        uint16_t blockAlign = swapLittleShortToHost(*reinterpret_cast<const uint16_t*>(ptr));
        ptr += 2;
        
        // Get bits per sample
        bytesOfData = swapLittleShortToHost(*reinterpret_cast<const uint16_t*>(ptr)) / 8;
        if (bytesOfData == 1) {
            blockAlign *= 2;
        }
        ptr += 2;
        
        // Find data chunk
        if (strncmp(reinterpret_cast<const char*>(ptr), "data", 4) == 0) {
            ptr += 4;
        } else if (strncmp(reinterpret_cast<const char*>(ptr), "fact", 4) == 0) {
            ptr += 16;
        } else {
            // Skip extra header size
            ptr += 2;
            if (strncmp(reinterpret_cast<const char*>(ptr), "data", 4) == 0) {
                ptr += 4;
            } else if (strncmp(reinterpret_cast<const char*>(ptr), "fact", 4) == 0) {
                ptr += 16;
            } else {
                qWarning() << "This wave data has extra header size, and can't find data or fact chunk.";
                return sourceData;
            }
        }
        
        // Get data size
        dataSize = swapLittleIntToHost(*reinterpret_cast<const uint32_t*>(ptr));
        dataSize *= (extendData ? 2 : 1) * ((bytesOfData == 1) ? 2 : 1);
        ptr += 4;
        
        frame = dataSize / blockAlign;
        swapData = true;
        break;
        
    default:
        qWarning() << "Unsupported format:" << format;
        return sourceData;
    }
    
    // Create AIFF data buffer
    QByteArray convData(dataSize + AIFF_HEADER_SIZE, 0);
    uint8_t* cnvptr = reinterpret_cast<uint8_t*>(convData.data());
    
    // Write AIFF header
    memcpy(cnvptr, "FORM", 4); cnvptr += 4;
    *reinterpret_cast<uint32_t*>(cnvptr) = swapHostIntToBig(dataSize + AIFF_HEADER_SIZE - 8); cnvptr += 4;
    memcpy(cnvptr, "AIFF", 4); cnvptr += 4;
    memcpy(cnvptr, "COMM", 4); cnvptr += 4;
    *reinterpret_cast<uint32_t*>(cnvptr) = swapHostIntToBig(18); cnvptr += 4;
    *reinterpret_cast<uint16_t*>(cnvptr) = swapHostShortToBig(channel); cnvptr += 2;
    *reinterpret_cast<uint32_t*>(cnvptr) = swapHostIntToBig(frame); cnvptr += 4;
    *reinterpret_cast<uint16_t*>(cnvptr) = swapHostShortToBig(16); cnvptr += 2;  // 16 bits per sample
    memcpy(cnvptr, (rate == 44100) ? SAMPLE_RATE_44100 : SAMPLE_RATE_22050, 10); cnvptr += 10;
    memcpy(cnvptr, "SSND", 4); cnvptr += 4;
    *reinterpret_cast<uint32_t*>(cnvptr) = swapHostIntToBig(dataSize + 8); cnvptr += 4;
    memset(cnvptr, '\0', 4); cnvptr += 4;
    memset(cnvptr, '\0', 4); cnvptr += 4;
    
    // Convert audio data with volume adjustment
    if (!extendData) {
        // 22.05KHz or 44.1KHz
        if (bytesOfData == 1) {
            // 8-bit
            for (int s = 0; s < dataSize; s += 2, ++ptr, cnvptr += 2) {
                *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToBig((*ptr - 128) * volume);
            }
        } else {
            // 16-bit
            if (dataSize % 2) {
                qWarning() << "Illegal data size wave data";
                return sourceData;
            }
            
            if (swapData) {
                for (int s = 0; s < dataSize; s += 2, ptr += 2, cnvptr += 2) {
                    *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToBig(
                        static_cast<int16_t>(swapLittleShortToHost(*reinterpret_cast<const uint16_t*>(ptr))) * volume / 256);
                }
            } else {
                for (int s = 0; s < dataSize; s += 2, ptr += 2, cnvptr += 2) {
                    *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToBig(
                        *reinterpret_cast<const int16_t*>(ptr) * volume / 256);
                }
            }
        }
    } else {
        // 11.025KHz - upsampling with linear interpolation
        if (bytesOfData == 1) {
            if (channel == 1) {
                // Mono 8-bit
                if (dataSize == 0) {
                    qWarning() << "Illegal data size wave data";
                    return sourceData;
                }
                *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToBig((*ptr - 128) * volume);
                ptr++; cnvptr += 4;
                for (int s = 4; s < dataSize; s += 4, ptr++, cnvptr += 4) {
                    *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToBig((*ptr - 128) * volume);
                    *(((int16_t*)cnvptr) - 1) = *reinterpret_cast<int16_t*>(cnvptr) -
                        (*reinterpret_cast<int16_t*>(cnvptr) - *(((int16_t*)cnvptr) - 2)) / 2;
                }
            } else {
                // Stereo 8-bit
                if (dataSize % 2) {
                    qWarning() << "Illegal data size wave data";
                    return sourceData;
                }
                
                *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToBig((*ptr - 128) * volume);
                *(((int16_t*)cnvptr) + 1) = swapHostShortToBig((*(ptr + 1) - 128) * volume);
                ptr += 2; cnvptr += 8;
                for (int s = 8; s < dataSize; s += 8, ptr += 2, cnvptr += 8) {
                    // L
                    *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToBig((*ptr - 128) * volume);
                    *(((int16_t*)cnvptr) - 2) = *reinterpret_cast<int16_t*>(cnvptr) -
                        (*reinterpret_cast<int16_t*>(cnvptr) - *(((int16_t*)cnvptr) - 4)) / 2;
                    // R
                    *(((int16_t*)cnvptr) + 1) = swapHostShortToBig((*(ptr + 1) - 128) * volume);
                    *(((int16_t*)cnvptr) - 1) = *(((int16_t*)cnvptr) + 1) -
                        (*(((int16_t*)cnvptr) + 1) - *(((int16_t*)cnvptr) - 3)) / 2;
                }
            }
        } else {
            // 16-bit
            if (channel == 1) {
                // Mono 16-bit
                if (dataSize % 2) {
                    qWarning() << "Illegal data size wave data";
                    return sourceData;
                }
                
                *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToHost(*reinterpret_cast<const uint16_t*>(ptr));
                *reinterpret_cast<int16_t*>(cnvptr) = *reinterpret_cast<int16_t*>(cnvptr) * volume / 256;
                ptr += 2; cnvptr += 4;
                if (swapData) {
                    for (int s = 4; s < dataSize; s += 4, ptr += 2, cnvptr += 4) {
                        *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToHost(*reinterpret_cast<const uint16_t*>(ptr));
                        *reinterpret_cast<int16_t*>(cnvptr) = *reinterpret_cast<int16_t*>(cnvptr) * volume / 256;
                        *(((int16_t*)cnvptr) - 1) = *reinterpret_cast<int16_t*>(cnvptr) -
                            (*reinterpret_cast<int16_t*>(cnvptr) - *(((int16_t*)cnvptr) - 2)) / 2;
                    }
                } else {
                    for (int s = 4; s < dataSize; s += 4, ptr += 2, cnvptr += 4) {
                        *reinterpret_cast<int16_t*>(cnvptr) = *reinterpret_cast<const int16_t*>(ptr) * volume / 256;
                        *(((int16_t*)cnvptr) - 1) = *reinterpret_cast<int16_t*>(cnvptr) -
                            (*reinterpret_cast<int16_t*>(cnvptr) - *(((int16_t*)cnvptr) - 2)) / 2;
                    }
                }
            } else {
                // Stereo 16-bit
                if (dataSize % 4) {
                    qWarning() << "Illegal data size wave data";
                    return sourceData;
                }
                
                *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToHost(*reinterpret_cast<const uint16_t*>(ptr));
                *reinterpret_cast<int16_t*>(cnvptr) = *reinterpret_cast<int16_t*>(cnvptr) * volume / 256;
                *(((int16_t*)cnvptr) + 1) = swapHostShortToHost(*(reinterpret_cast<const uint16_t*>(ptr) + 1));
                *(((int16_t*)cnvptr) + 1) = *(((int16_t*)cnvptr) + 1) * volume / 256;
                ptr += 4; cnvptr += 8;
                if (swapData) {
                    for (int s = 8; s < dataSize; s += 8, ptr += 4, cnvptr += 8) {
                        // L
                        *reinterpret_cast<int16_t*>(cnvptr) = swapHostShortToHost(*reinterpret_cast<const uint16_t*>(ptr));
                        *reinterpret_cast<int16_t*>(cnvptr) = *reinterpret_cast<int16_t*>(cnvptr) * volume / 256;
                        *(((int16_t*)cnvptr) - 2) = *reinterpret_cast<int16_t*>(cnvptr) -
                            (*reinterpret_cast<int16_t*>(cnvptr) - *(((int16_t*)cnvptr) - 4)) / 2;
                        // R
                        *(((int16_t*)cnvptr) + 1) = swapHostShortToHost(*(reinterpret_cast<const uint16_t*>(ptr) + 1));
                        *(((int16_t*)cnvptr) + 1) = *(((int16_t*)cnvptr) + 1) * volume / 256;
                        *(((int16_t*)cnvptr) - 1) = *(((int16_t*)cnvptr) + 1) -
                            (*(((int16_t*)cnvptr) + 1) - *(((int16_t*)cnvptr) - 3)) / 2;
                    }
                } else {
                    for (int s = 8; s < dataSize; s += 8, ptr += 4, cnvptr += 8) {
                        // L
                        *reinterpret_cast<int16_t*>(cnvptr) = *reinterpret_cast<const int16_t*>(ptr) * volume / 256;
                        *(((int16_t*)cnvptr) - 2) = *reinterpret_cast<int16_t*>(cnvptr) -
                            (*reinterpret_cast<int16_t*>(cnvptr) - *(((int16_t*)cnvptr) - 4)) / 2;
                        // R
                        *(((int16_t*)cnvptr) + 1) = *(reinterpret_cast<const int16_t*>(ptr) + 1) * volume / 256;
                        *(((int16_t*)cnvptr) - 1) = *(((int16_t*)cnvptr) + 1) -
                            (*(((int16_t*)cnvptr) + 1) - *(((int16_t*)cnvptr) - 3)) / 2;
                    }
                }
            }
        }
    }
    
    return convData;
}

// Replaces: void TYWave2AiffCleanUp(void)
void TYWave2AiffCleanUp()
{
    // Cleanup plugin if needed
    if (pluginBundle) {
        pluginBundle = nullptr;
    }
}

// Replaces: NSData* TYVerifyAiff(NSData *data)
QByteArray TYVerifyAiff(const QByteArray& data)
{
    if (data.length() <= 46) {
        qWarning() << "Not enough data size";
        return QByteArray();
    }
    
    const char* aiffPtr = data.constData();
    
    // Verify AIFF header structure
    if (strncmp(aiffPtr, "FORM", 4) != 0) {
        qWarning() << "Not exists FORM Header";
        return QByteArray();
    }
    
    if (strncmp(aiffPtr + 8, "AIFF", 4) != 0) {
        qWarning() << "Not exists AIFF Header";
        return QByteArray();
    }
    
    if (strncmp(aiffPtr + 12, "COMM", 4) != 0) {
        qWarning() << "Not exists COMM Header";
        return QByteArray();
    }
    
    if (strncmp(aiffPtr + 38, "SSND", 4) != 0) {
        qWarning() << "Not exists SSND Header";
        return QByteArray();
    }
    
    return data;  // Returns original data if valid
}