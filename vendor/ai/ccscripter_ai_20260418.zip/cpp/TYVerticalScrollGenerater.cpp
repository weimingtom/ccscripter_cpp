// Converted from TYVerticalScrollGenerater.m
// TODO: Manual review and fixes required

//
//  TYVerticalScrollGenerater.m
//  Tukuyomi
//
//  Created by toveta on Fri Nov 30 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


#include "TYVerticalScrollGenerater.h"
#include "TYStageManager.h"

// @implementation TYVerticalScrollGenerater
-(void*)initWithBeforeImage:(NSImage*)befImage afterImage:(NSImage*)atImage effect:(TYEffectDefinitionValue*)effect reverse:(bool)aBool
{
    TYEffectDefinition effdef;
    
    this = [ super init ];

    reverse = aBool;
    
    [ effect getValue:&effdef ];
    phaseInterval = effdef.time / 1000.0 / VSCREEN_HEIGHT;
    time = effdef.time;

    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    unionImage = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT*2) ];    
    nowImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    [ unionImage lockFocus ];
        [ befImage compositeToPoint:NSMakePoint(0,VSCREEN_HEIGHT *(reverse)) operation:NSCompositeCopy ];
        [ atImage compositeToPoint:NSMakePoint(0,VSCREEN_HEIGHT *(!reverse)) operation:NSCompositeCopy ];
    [ unionImage unlockFocus ];
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
}

// private method
// REMOVED: -voiddrawEffect{
    int phase;
    // oߎԂ480PʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *VSCREEN_HEIGHT;
    if(phase >= VSCREEN_HEIGHT){
        // GtFNgI
        [ nowImage lockFocus ];
            [ unionImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(0,(VSCREEN_HEIGHT *((reverse) ? -1 : 1)) + VSCREEN_HEIGHT *(reverse),VSCREEN_WIDTH,VSCREEN_HEIGHT) operation:NSCompositeCopy ];
        [ nowImage unlockFocus ];
        [ this changeEffectionImage:nowImage ];
        [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    } else {
        [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];

        [ nowImage lockFocus ];
            [ unionImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(0,(phase *((reverse) ? -1 : 1)) + VSCREEN_HEIGHT *(reverse),VSCREEN_WIDTH,VSCREEN_HEIGHT) operation:NSCompositeCopy ];
        [ nowImage unlockFocus ];
        
        [ this changeEffectionImage:nowImage ];
    }

    return;
} // override

// -dealloc (destructor in C++)
~ClassName() {
    [ startDate release ];
    [unionImage release];
    [ nowImage release ];
    [super dealloc];
}

// @end
