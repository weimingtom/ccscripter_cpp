// Converted from TYEraseModeView.m
// TODO: Manual review and fixes required

//
//  TYEraseModeView.m
//  Tukuyomi
//
//  Created by toveta on Tue Feb 04 2003.
//  Copyright (c) 2003 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
#include "TYEraseModeView.h"
#include "TYMainController.h"

// @implementation TYEraseModeView

- (void*)initWithFrame:(NSRect)frame controller:(void*)aObj {
    this = super->initWithFrame(frame);
    if (this) {
        controller = aObj;
        // Initialization code here.
    }
    return this;
}

- (void)drawRect:(NSRect)rect {
    // Drawing code here.
}

// REMOVED: -boolacceptsFirstResponder{
    return true;
}

- (void)mouseDown:(NSEvent*)theEvent
{
    [ this endMode ];
}

- (void)keyDown:(NSEvent*)theEvent
{
    [ this endMode ];
}

- (void)rightMouseDown:(NSEvent*)theEvent
{
    [ this endMode ];
}

- (void)scrollWheel:(NSEvent *)theEvent
{
    ;
}


// REMOVED: -voidendMode{
    [ [ this window ] makeFirstResponder:[ this superview ] ];
    [ controller exitSystemModeResumeStatus:true ];
    [ [ this retain ] autorelease ];
    [ this removeFromSuperview ];
}

// not implemantaion -dealloc because no object retained.
// @end
