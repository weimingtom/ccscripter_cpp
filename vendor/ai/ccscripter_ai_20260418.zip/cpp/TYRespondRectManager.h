// Converted from TYRespondRectManager.h
// TODO: Manual review and fixes required

//
//  TYRespondRectManager.h
//  Tukuyomi
//
//  Created by toveta on Tue Nov 06 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */





// I[hAj[[hA{^[hȂǂ̎ɉʂ𐧌䂷钊ۃNX
// MEMO:{^̂̃TuNXɈڍs邩H



class TYRespondRectManager : public NSObject {
    TYStageManager* stageManager;
    NSMutableArray *btnArray;
    NSImage *drawBuffer;
    int beforeSelection;
    NSMutableData *rectMap;
}
id initWithStageManager(TYStageManager* manager);;

void addSelection(id aButton); rect:(NSRect)rect;

void initialButtonImage(); // [hJn

int selectedButtonID();
int selectedIndex();
int incToIndex(); // CfbNXЂƂ₷
int decToIndex(); // CfbNXЂƂ炷
NSData* rectMap();
BOOL changeSelection(int index);; // ύXǂԂlŒʒmB

void draw();

void clear();

};
