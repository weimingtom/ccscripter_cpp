/*
 *  TYScriptData.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Manages NScripter script file data.
 */

#ifndef TYSCRIPTDATA_QT_H
#define TYSCRIPTDATA_QT_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QMap>

class TYScriptData : public QObject
{
    Q_OBJECT
    
public:
    // Public initializer
    TYScriptData(const QString& path, QObject* parent = nullptr);
    
    // Alternative initializers
    TYScriptData(const QStringList& pathArray, QObject* parent = nullptr);
    TYScriptData(const QString& encodingFile, bool, QObject* parent = nullptr);
    
    ~TYScriptData();
    
    // Line count queries
    int lineOfLabel() const;
    int lineOfInstantLabelWithNowLine(int nowLine, bool reverse) const;
    
    // Data access
    QString stringAtIndex(int index) const;
    QByteArray dataAtIndex(int index) const;
    
    // Accessors
    int count() const { return m_data.size(); }
    QStringList labels() const { return m_labels; }
    
private:
    void initWithDirectory(const QString& path);
    void initWithTextFiles(const QStringList& pathArray);
    
    QStringList m_data;        // Script lines
    QMap<QString, int> m_labelDict;  // Label -> line mapping
    QStringList m_labels;     // Label names
};

#endif // TYSCRIPTDATA_QT_H