/*
 *  TYBitOperator.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSFileHandle*      -> QFile*
 *  [f retain]         -> (not needed, QFile is implicit shared)
 *  [fh readDataOfLength:n] -> fh.read(n)
 *  [f fileDescriptor] -> fh.handle()
 *  [fh release]       -> (automatic in Qt)
 */

#ifndef TYBITOPERATOR_QT_H
#define TYBITOPERATOR_QT_H

#include <QObject>
#include <QFile>
#include <QByteArray>
#include <cstddef>
#include <cstdint>

class TYBitOperator : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithFileHandle:(NSFileHandle*)f size:(unsigned int)s
    explicit TYBitOperator(QFile* f, size_t s, QObject* parent = nullptr);
    ~TYBitOperator();
    
    // Replaces: -(int)get
    int get();
    
    // Replaces: -(unsigned int)getWithLength:(int)n
    unsigned int getWithLength(int n);
    
    // Replaces: -(void)dealloc (automatic in Qt)

private:
    QFile* fh;          // Replaces: NSFileHandle *fh
    size_t size;        // Replaces: size_t size
    unsigned int mask;  // Replaces: unsigned int mask
    unsigned char tmp;  // Replaces: unsigned char tmp
};

// C-style struct and functions for compatibility
// Replaces: struct tyCoreBitOperater { ... }
struct TYCoreBitOperator {
    int fd;              // Replaces: int fd
    unsigned int mask;   // Replaces: unsigned int mask
    unsigned char tmp;   // Replaces: unsigned char tmp
};

// Replaces: TYCoreBitOperater TYCreateCoreBitOperater(NSFileHandle*, unsigned int)
TYCoreBitOperator* TYCreateCoreBitOperator(QFile* f, unsigned int s);

// Replaces: __inline__ int TYGetCoreBitOperater(TYCoreBitOperater)
inline int TYGetCoreBitOperator(TYCoreBitOperator* mySelf);

// Replaces: __inline__ unsigned int TYGetBitsCoreBitOperater(TYCoreBitOperater, int)
inline unsigned int TYGetBitsCoreBitOperator(TYCoreBitOperator* mySelf, int n);

// Replaces: void TYReleaseCoreBitOperater(TYCoreBitOperater)
void TYReleaseCoreBitOperator(TYCoreBitOperator* mySelf);

#endif // TYBITOPERATOR_QT_H