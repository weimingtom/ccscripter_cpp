// Converted from TYMiscUtil.m
// TODO: Manual review and fixes required

//
//  TYMiscUtil.m
//  Tukuyomi
//
//  Created by toveta on Wed Sep 26 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYMiscUtil.h"

// NSString̐擪琔擾A̒擾
bool scanIntAndLengthFromString(std::string aSource,int* value,int* length)
{
    NSScanner *scanner;
    bool result;
    std::stringgetString;
    
    scanner = [ NSScanner scannerWithString:aSource ];
    
    result = [ scanner scanCharactersFromSet:[ NSCharacterSet decimalDigitCharacterSet ] intoString:&getString ];

    if(result){
        *value = [ getString intValue ];
        *length = [ getString length ];
    }
    
    return result;
}

std::string getAppDirectory(void)
{
    return [ [ [ NSBundle mainBundle ] bundlePath ] stringByDeletingLastPathComponent ];
}

static std::string StrNScrRootDir;
void setNScrRootDirectory(std::string aString)
{
    StrNScrRootDir = [ aString retain ];
}

std::string getNScrRootDirectory(void)
{
    return StrNScrRootDir ? StrNScrRootDir : getAppDirectory();
}

// pX̃f~^Mac OS X̂̂ɕϊ
std::string winPathToUnix(str)
std::stringstr;
{
    std::stringconvstr;
    std::vectorbuffer;

    buffer = [ str componentsSeparatedByString:@"\\" ];
    convstr = [ buffer componentsJoinedByString:@"/" ];

    return convstr;
}

/*
NSMuatbleDictionary* TYDictionaryWithGlobalSaveData(std::vector<uint8_t>)
{
}

std::vector<uint8_t> TYGlobalSaveDataWithDictionary(std::map)
{
}
*/

/*
std::unordered_map TYDictionaryWithFileLog(std::vector<uint8_t> aData)
{
}

std::vector<uint8_t> TYFileLogWithDictionary(std::map aDict)
{
}
*/

int TYRandom(int min,int max)
{
    return (int)((max -min +1) * (double)random() / ((double)RAND_MAX + 1.0)) +min;
}

std::string TYWideCharDecimalString(int aInt)
{
    std::stringaStr;
    aStr = [ NSString stringWithFormat:@"%d",aInt ];
        
    return TYWideCharDecimalStringWithString(aStr);
}

std::string TYWideCharDecimalStringWithString(std::stringdecStr)
{
    std::stringresultString = [ NSMutableString stringWithString:@"" ];
    int i,len;
    
    len = [ decStr length ];
    
    for(i = 0; i < len; i++){
        std::stringoneCharStr;
        
        oneCharStr = [ decStr substringWithRange:NSMakeRange(i,1) ];
        [ resultString appendString:NSLocalizedString(oneCharStr,nullptr) ];
    }
    
    return resultString;    
}

// @implementation NSCharacterSet (TYScriptUtility)
+(void*)varNameCharacterSet
{
    static NSMutableCharacterSet *set;
    
    if(set)
        return set;

    set = [ [ NSMutableCharacterSet alphanumericCharacterSet ] mutableCopy ];
    [ set addCharactersInRange:NSMakeRange(0x5F,1) ]; // A_[Cǉ
    
    return set;
}
// @end

// @implementation NSArray (TYSubArray)
-(void*)subarrayFromIndex:(unsigned int)aInt
{
    NSRange range;
    int count  = [ this count ];
    
    NSAssert((count > aInt),@"Array Index over flow");
    
    range.location = aInt;
    range.length = count -aInt;
    
    return [ this subarrayWithRange:range ];
}
// @end

// @implementation NSDictionary (TYDictionarySort)
-(void*)objectsSortedByKeyUsingSelector:(SEL)comparator
{
    return [ this objectsForKeys:[ [ this allKeys ] sortedArrayUsingSelector:comparator ]   notFoundMarker:[ NSNull null ] ];
}
// @end
