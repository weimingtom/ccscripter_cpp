/*
 *  TYResourceServer.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  This is a central resource server for NScripter external resources.
 *  Manages archives, images, sounds, and effect patterns.
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSMutableArray*    -> QList<TYArchiver*> or QVector
 *  NSMutableDictionary-> QMap<QString, QVariant> or QHash
 *  NSString*          -> QString
 *  NSImage*           -> QImage
 *  NSBitmapImageRep*  -> QImage
 *  NSData*            -> QByteArray
 *  + (id)sharedServer -> static instance() with q-pointer
 *  [dict setObject:forKey:] -> dict[key] = value
 *  [dict objectForKey:] -> dict.value(key)
 */

#ifndef TYRESOURCESERVER_QT_H
#define TYRESOURCESERVER_QT_H

#include <QObject>
#include <QString>
#include <QImage>
#include <QByteArray>
#include <QMap>
#include <QList>
#include <QHash>
#include <QFile>
#include <QVariant>

class TYArchiver;
class TYEffectPatternMap;

class TYResourceServer : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)sharedServer
    static TYResourceServer* sharedServer();
    
    // Destructor
    ~TYResourceServer();
    
    // Archive management
    // Replaces: -(void)addArchiver:(NSString*)path
    void addArchiver(const QString& path);
    
    // Resource retrieval
    // Replaces: -(NSString*)getFilePath:(NSString*)path
    QString getFilePath(const QString& path);
    
    // Replaces: -(NSData*)getData:(NSString*)path
    QByteArray getData(const QString& path);
    
    // Replaces: -(NSImage*)getImage:(NSString*)path transMode:(BOOL)aBool animate:(BOOL)isAnimate
    QImage getImage(const QString& path, bool transMode, bool animate = false);
    
    // Replaces: -(NSImage*)getImage:(NSString*)path transMode:(BOOL)aBool
    QImage getImage(const QString& path, bool transMode);
    
    // Replaces: -(NSImage*)getImageFromString:(NSString*)str
    QImage getImageFromString(const QString& str);
    
    // Replaces: -(NSBitmapImageRep*)getBitmap:(NSString*)path
    QImage getBitmap(const QString& path);
    
    // Replaces: -(NSData*)getSoundData:(NSString*)path
    QByteArray getSoundData(const QString& path);
    
    // Replaces: -(TYEffectPatternMap*)getEffectPattern:(NSString*)path
    TYEffectPatternMap* getEffectPattern(const QString& path);
    
    // Replaces: -(NSString*)getFilePathMakeTemp:(NSString*)path
    QString getFilePathMakeTemp(const QString& path);
    
    // Plugin management
    // Replaces: -(void)addSpi:(NSString*)pluginName extension:(NSString*)extension
    void addSpi(const QString& pluginName, const QString& extension);
    
    // Replaces: -(void)addSoundPressPlugin:(NSString*)pluginName extension:(NSString*)extension
    void addSoundPressPlugin(const QString& pluginName, const QString& extension);
    
    // Replaces: -(void)setDefaultTransMode:(NSString*)transmode
    void setDefaultTransMode(const QString& transmode);
    
    // Replaces: -(void)addEffectPattern:(NSString*)path
    void addEffectPattern(const QString& path);
    
    // Execution
    // Replaces: -(void)executeBundle:(NSString*)pathAndArg
    void executeBundle(const QString& pathAndArg);
    
    // File logging
    // Replaces: -(BOOL)filelog:(NSString*)path
    bool filelog(const QString& path);
    
    // Replaces: -(void)addlog:(NSString*)filename
    void addlog(const QString& filename);
    
    // Replaces: -(BOOL)fchk:(NSString*)filename
    bool fchk(const QString& filename);
    
    // Replaces: -(BOOL)saveLog:(NSString*)path
    bool saveLog(const QString& path);
    
    // Constants
    static const QString FILELOG_FILENAME;
    static const QString WIN_PATH_DELIMITER;
    
private:
    // Constructor is private (singleton)
    explicit TYResourceServer(QObject* parent = nullptr);
    
    // Helper to find file in archives
    QByteArray findInArchives(const QString& path);
    
    // Internal image transformation
    QImage transrateImageFromBitmap(const QImage& bitmap, const QString& transmode);
    
    // Private members (replaces ivars)
    QList<TYArchiver*> m_archivers;              // Replaces: NSMutableArray *ty_archivers
    QString m_defaultTransmode;                    // Replaces: NSString *defaultTransmode
    bool m_filelog;                               // Replaces: BOOL filelog
    QMap<QString, QString> m_filelogDict;         // Replaces: NSMutableDictionary *filelogDict
    QMap<QString, QString> m_spiPluginDict;       // Replaces: NSMutableDictionary *spiPluginDict
    QMap<QString, QString> m_soundPressPluginDict;// Replaces: NSMutableDictionary *soundPressPluginDict
    QMap<QString, TYEffectPatternMap*> m_effectPatternDict; // Replaces: NSMutableDictionary *effectPatternDict
    QMap<QString, QString> m_executableBundles;   // Replaces: NSMutableDictionary *executableBundles
    
    static TYResourceServer* s_instance;  // Replaces: static id sharedObject
};

#endif // TYRESOURCESERVER_QT_H