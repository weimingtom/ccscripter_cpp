/*
 *  TYWave2Aiff.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Converts WAV data to AIFF format with volume adjustment.
 *  Supports 8-bit/16-bit PCM, mono/stereo, 11.025/22.05/44.1 KHz
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSData*            -> QByteArray
 *  NSBundle*          -> QPluginLoader or QLibrary
 *  Protocol @protocol -> abstract class interface
 *  id<TYWaveDecorder> -> TYWaveDecorder*
 */

#ifndef TYWAVE2AIFF_QT_H
#define TYWAVE2AIFF_QT_H

#include <QByteArray>
#include <QObject>
#include <QString>
#include <cstdint>

// Wave decoder interface (replaces @protocol TYWaveDecorder)
class TYWaveDecoder
{
public:
    virtual ~TYWaveDecoder() = default;
    
    // Replaces: -(BOOL)getSamples:(short**)(&ptr) frames:(int*)&frame channels:(int*)&channel rate:(int*)&rate
    virtual bool getSamples(int16_t** samples, int* frames, int* channels, int* rate) = 0;
};

// Main conversion function
// Replaces: NSData* TYWave2Aiff(NSData*, int volume)
QByteArray TYWave2Aiff(const QByteArray& sourceData, int volume);

// Cleanup function
// Replaces: void TYWave2AiffCleanUp(void)
void TYWave2AiffCleanUp();

// Verify AIFF data
// Replaces: NSData* TYVerifyAiff(NSData*)
QByteArray TYVerifyAiff(const QByteArray& data);

// Get application directory (replaces getAppDirectory())
QString getAppDirectory();

// Environment key for wave extra plugin
extern const char* TYWaveExtraNameEnviroment;

#endif // TYWAVE2AIFF_QT_H