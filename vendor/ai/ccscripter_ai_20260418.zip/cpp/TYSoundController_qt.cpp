/*
 *  TYSoundController.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYSoundController_qt.h"
#include "TYResourceServer_qt.h"
#include "TYWave2Aiff_qt.h"
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QFile>
#include <QBuffer>
#include <QDebug>

TYSoundController::TYSoundController(const QString& path, bool loop, QObject* parent)
    : QObject(parent)
    , m_player(nullptr)
    , m_soundPath(path)
    , m_isLoop(loop)
    , m_postingNotification(false)
    , m_audioOutput(nullptr)
    , m_volume(TYSOUND_VOLUME_MAX)
{
    init(path, loop, TYSOUND_VOLUME_MAX);
}

TYSoundController::TYSoundController(const QString& path, bool loop, int volume, QObject* parent)
    : QObject(parent)
    , m_player(nullptr)
    , m_soundPath(path)
    , m_isLoop(loop)
    , m_postingNotification(false)
    , m_audioOutput(nullptr)
    , m_volume(volume)
{
    init(path, loop, volume);
}

void TYSoundController::init(const QString& path, bool loop, int volume)
{
    m_isLoop = loop;
    
    // Clamp volume to valid range
    if (volume > TYSOUND_VOLUME_MAX) {
        volume = TYSOUND_VOLUME_MAX;
    }
    if (volume < 0) {
        volume = 0;
    }
    m_volume = volume;
    
    // Load sound data through resource server
    // Replaces: data = TYWave2Aiff([ [ TYResourceServer sharedServer ] getSoundData:path ],volume);
    QByteArray data = loadSoundData(path, volume);
    
    if (data.isEmpty()) {
        qWarning() << "Failed to load sound:" << path;
        return;
    }
    
    // Create media player
    m_player = new QMediaPlayer(this);
    m_audioOutput = new QAudioOutput(this);
    m_player->setAudioOutput(m_audioOutput);
    
    // Set volume (QAudioOutput uses 0.0-1.0, we use 0-256)
    m_audioOutput->setVolume(static_cast<qreal>(m_volume) / TYSOUND_VOLUME_MAX);
    
    // Use QBuffer to load data
    QBuffer* buffer = new QBuffer(&data, m_player);
    buffer->open(QBuffer::ReadOnly);
    buffer->setParent(m_player);
    
    // Connect signals
    connect(m_player, &QMediaPlayer::playbackStateChanged,
            this, &TYSoundController::handlePlaybackStateChanged);
}

TYSoundController::~TYSoundController()
{
    if (m_player) {
        m_player->stop();
    }
}

QByteArray TYSoundController::loadSoundData(const QString& path, int volume)
{
    // Get sound data from resource server
    // In real implementation, would call TYWave2Aiff to process volume
    // For now, just load the file
    Q_UNUSED(volume);
    
    // Try resource server first
    if (TYResourceServer::sharedServer()) {
        QByteArray data = TYResourceServer::sharedServer()->getSoundData(path);
        if (!data.isEmpty()) {
            return data;
        }
    }
    
    // Fall back to direct file
    QFile file(path);
    if (file.open(QIODevice::ReadOnly)) {
        return file.readAll();
    }
    
    return QByteArray();
}

// Replaces: -(void)play
void TYSoundController::play()
{
    if (!m_player) {
        return;
    }
    
    // Replaces: if(postingNotification && (!isLoop) && playSound)
    //           postNotificationName:TYSoundStartNotification
    if (m_postingNotification && !m_isLoop) {
        emit soundStarted();
    }
    
    // Replaces: aBool = [ playSound play ]
    m_player->play();
    
    if (m_player->error() != QMediaPlayer::NoError) {
        qWarning() << "can't play wave file. path=" << m_soundPath;
    }
}

// Replaces: -(void)setPostingNotification:(BOOL)aBool
void TYSoundController::setPostingNotification(bool aBool)
{
    m_postingNotification = aBool;
}

// Replaces: -(NSString*)soundPathIfNeedPlayingAtLoad
QString TYSoundController::soundPathIfNeedPlayingAtLoad()
{
    if (m_player && m_player->playbackState() == QMediaPlayer::PlayingState) {
        if (m_isLoop) {
            return m_soundPath;
        }
    }
    return QString();
}

// Replaces: -(void)stop
void TYSoundController::stop()
{
    if (!m_player) {
        return;
    }
    
    // Replaces: if(postingNotification && (!isLoop))
    //           postNotificationName:TYSoundFinishNotification
    if (m_postingNotification && !m_isLoop) {
        emit soundFinished();
    }
    
    // Replaces: [ playSound stop ]
    m_player->stop();
}

// Replaces: - (void)sound:(NSSound *)sound didFinishPlaying:(BOOL)aBool
void TYSoundController::handlePlaybackStateChanged()
{
    if (!m_player) {
        return;
    }
    
    if (m_player->playbackState() == QMediaPlayer::StoppedState) {
        // Playback finished
        if (m_isLoop) {
            // Replaces: if(aBool && isLoop) { [ sound play ]; }
            m_player->play();
        } else {
            // Replaces: if(postingNotification)
            //           postNotificationName:TYSoundFinishNotification
            if (m_postingNotification) {
                emit soundFinished();
            }
        }
    }
}

void TYSoundController::setVolume(int volume)
{
    if (volume > TYSOUND_VOLUME_MAX) {
        volume = TYSOUND_VOLUME_MAX;
    }
    if (volume < 0) {
        volume = 0;
    }
    m_volume = volume;
    
    if (m_audioOutput) {
        m_audioOutput->setVolume(static_cast<qreal>(m_volume) / TYSOUND_VOLUME_MAX);
    }
}

int TYSoundController::volume() const
{
    return m_volume;
}

bool TYSoundController::isPlaying() const
{
    return m_player && m_player->playbackState() == QMediaPlayer::PlayingState;
}