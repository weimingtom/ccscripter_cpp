/*
 *  TYNsaArchivedFile.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYNsaArchivedFile_qt.h"

TYNsaArchivedFile::TYNsaArchivedFile(unsigned offset, unsigned length,
                                     unsigned char type, unsigned exLength, QObject* parent)
    : TYSarArchivedFile(offset, length, parent)
    , m_compressType(type)
    , m_expandedLength(exLength)
{
}

// Factory method - replaces +(id)archivedFileoffset:...
TYNsaArchivedFile* TYNsaArchivedFile::create(unsigned offset, unsigned length,
                                              unsigned char type, unsigned exLength)
{
    return new TYNsaArchivedFile(offset, length, type, exLength);
}