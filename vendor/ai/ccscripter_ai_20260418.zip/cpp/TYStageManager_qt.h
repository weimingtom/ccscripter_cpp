/*
 *  TYStageManager.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Main stage manager - coordinates all visual novel display elements.
 *  Note: This is a core class that requires extensive QtWidgets integration.
 */

#ifndef TYSTAGEMANAGER_QT_H
#define TYSTAGEMANAGER_QT_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QImage>
#include <QRect>
#include <QMap>

// Screen dimensions
const int VSCREEN_WIDTH = 640;
const int VSCREEN_HEIGHT = 480;

// Locate definitions
const QString LD_LOCATE_LEFT = QStringLiteral("l");
const QString LD_LOCATE_CENTER = QStringLiteral("c");
const QString LD_LOCATE_RIGHT = QStringLiteral("r");
const QString CL_LOCATE_ALL = QStringLiteral("a");

// Effect numbers
const int WINDOW_EFFECT_NO = -2;

// Constants
const int SHADOW_TICKNESS = 1;
const int SPRITE_MAX = 255;
const int CSEL_SPRITE_NO = 500;

// Skip status masks
enum TYSkipStatusMask {
    TYNoSkip = 0,
    TYOnetimeSkipMask = 1,
    TYSelectionSkipMask = 1 << 1,
    TYKidokuSkipMask = 1 << 2,
    TYAutoModeSkipMask = 1 << 3,
    TYEffectCancelSkipMask = TYSelectionSkipMask | TYKidokuSkipMask,
    TYNoTimeWaitSkipMask = TYOnetimeSkipMask | TYSelectionSkipMask | TYKidokuSkipMask
};

// Text print status
enum TYTPStatus {
    TYTPOff = 0,
    TYTPPrinting,
    TYTPClickWait,
    TYTPTimeWait
};

// Forward declarations
class TYEffectGenerater;
class TYSelectionManager;
class TYStandingChar;
class TYWaitCursor;
class TYExtraButtonManager;
class QImage;

// TYStageManager - Core visual novel stage controller
class TYStageManager : public QObject
{
    Q_OBJECT
    
public:
    // Singleton
    static TYStageManager* sharedManager();
    static void setModeSVGA();
    
    // Setup
    void setController(QObject* controller, QObject* engine);
    
    // System mode
    void enterSystemMode();
    void exitSystemModeResumeStatus(bool resume);
    bool isPossibleEnterSystemMode();
    
    // Resource loading
    void loadTextWindow(const QString& path);
    void loadBGImage(const QString& path);
    
    // Sprite management
    void addSprite(const QStringList& arguments, bool visible);
    
    // Selection
    void startSelect(const QStringList& messages, const QStringList& respondArray);
    
    // Stage updates
    void updateStage();
    void updateStageOnlyButton();
    
    // Layer accessors
    QImage visualLayer() const { return m_visualLayer; }
    QImage compositeLayer() const { return m_compositeLayer; }
    
    // Background
    void changeVisualLayer(int effectNum);
    void flushNovelLayer();
    
    // Text window
    void startEraseTextWindow(int effectNum);
    QStringList lookbackQueue();
    void textPrint(const QString& str);
    void drawTextWindow();
    QRect textWindowRect() const { return m_textWindowRect; }
    
    // Text position
    QPoint drawPoint() const { return QPoint(m_textLeftOffset, m_textTopOffset); }
    void setSkipStatus(int status) { m_skipStatus = status; }
    int skipStatus() const { return m_skipStatus; }
    void setClickWait(bool pageWait);
    
    // Game control
    void resetGame();
    
    // Status
    int status() const { return m_status; }
    void setStatus(int status) { m_status = status; }
    
    // Printing
    void printing();
    void resumePrinting();
    void automode_select_action();
    
    // Commands
    void ty_select(const QStringList& arguments);
    void ty_spstr(const QStringList& arguments);
    void ty_textclear(const QStringList& arguments);
    void ty_lookbackflush(const QStringList& arguments);
    
    // Text attributes
    QMap<QString, QVariant> textAttDict() const { return m_textAttDict; }
    void makeAttributeDict();
    int textFontWidth() const { return m_textFontWidth; }
    int textFontHeight() const { return m_textFontHeight; }
    int textPitchX() const { return m_textPitchX; }
    bool isShadow() const { return m_textShadowed; }
    
    // Auto mode
    void changeFont(QObject* fontManager);
    void changeTextSpeed(int index);
    void setAutoMode(int speed, int type, int wait);
    int userTextSpeed() const { return m_userTextSpeed; }
    
    // Button control
    void startButtonWait(const QStringList& arguments, bool releaseAfterSelect);
    void changeSelectedButton(unsigned int btnIndex);
    void responseButton(int result);
    
    // Selection
    void changeSelection(int index);
    void responseSelection();
    void makeCselImage();
    
    // Sprite operations
    QRect rectOfSprite(int idNo) const;
    void setSprite(int idNo, bool visible);
    void setSprite(int idNo, int cellNo);
    
    // Effect callbacks
    void changeEffectionImage(const QImage& image);
    void effectFinished();
    
    // Notifications
    void updateSprites();
    void startWaveSound();
    void stopWaveSound();
    
signals:
    void stageUpdated();
    void effectFinished();
    void selectionChanged(int index);
    
private:
    TYStageManager(QObject* parent = nullptr);
    
    QObject* m_controller;
    QObject* m_engine;
    QImage m_compositeLayer;
    QImage m_visualLayer;
    QImage m_bgImage;
    QString m_bgPath;
    QRect m_bgRect;
    QImage m_novelLayer;
    QImage m_overNovelLayer;
    
    TYEffectGenerater* m_effectGenerater;
    TYSelectionManager* m_selectionManager;
    TYExtraButtonManager* m_buttonManager;
    TYWaitCursor* m_clickWaitCursor;
    TYWaitCursor* m_pageWaitCursor;
    
    QString m_textWindowPath;
    QRect m_textWindowRect;
    
    TYTPStatus m_tpStatus;
    TYSkipStatusMask m_skipStatus;
    
    int m_humanZ;
    bool m_isUseHumanZ;
    bool m_isWindowback;
    bool m_novelLayerOn;
    bool m_eraseTextWindow;
    
    int m_textLeftOffset;
    int m_textTopOffset;
    int m_textColumn;
    int m_textRow;
    int m_textFontWidth;
    int m_textFontHeight;
    int m_textPitchX;
    int m_textPitchY;
    int m_userTextSpeed;
    int m_scriptTextSpeed;
    int m_selectedSpeedTag;
    bool m_textBold;
    bool m_textShadowed;
    
    int m_locateX;
    int m_nowColumn;
    int m_nowRow;
    int m_nowStorageLength;
    int m_nowStorageOffset;
    
    bool m_waitNewPage;
    bool m_forceClickWait;
    bool m_forceWaitNewPage;
    bool m_invalidNewLine;
    int m_clickStrUnderLimit;
    
    int m_beforeSelectButtonID;
    QString m_buttonTargetValue;
    bool m_releaseButtonAfterSelect;
    bool m_isDrawButton;
    
    int m_beforeSelectIndex;
    QStringList m_selectAction;
    QString m_textgosubLabel;
    bool m_isPage;
    
    int m_automodeWait;
    int m_automodeWaitType;
    int m_waitCountOfChar;
    bool m_playingSoundFlg;
    bool m_waitFinishSound;
    
    QMap<QString, QVariant> m_textAttDict;
    QMap<QString, QVariant> m_textShadowAttDict;
    QString m_textFontName;
    int m_textFontSize;
    QColor m_textFontColor;
    
    QMap<int, QRect> m_spriteRects;
    QMap<int, bool> m_spriteVisibility;
    QMap<int, int> m_spriteCells;
    QStringList m_lookbackQueue;
    QMap<int, QVariant> m_barDict;
    
    static TYStageManager* s_instance;
};

// Screen size function
QSize TYVirtualScreenSize();
QRect TYVirtualScreenRect();

#endif // TYSTAGEMANAGER_QT_H