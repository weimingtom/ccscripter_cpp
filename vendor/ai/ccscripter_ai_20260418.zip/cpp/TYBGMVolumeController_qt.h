/*
 *  TYBGMVolumeController.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  BGM volume control.
 */

#ifndef TYBGMVOLUMECONTROLLER_QT_H
#define TYBGMVOLUMECONTROLLER_QT_H

#include <QObject>

class TYBGMVolumeController : public QObject
{
    Q_OBJECT
    
public:
    TYBGMVolumeController(float volume, QObject* parent = nullptr);
    ~TYBGMVolumeController();
    
    void setDelegate(QObject* delegate) { m_delegate = delegate; }
    
    void showDialog();
    void setBGMVolume(float volume);
    float bgmVolume() const { return m_volume; }
    
signals:
    void volumeChanged(float volume);
    
private:
    QObject* m_delegate;
    float m_volume;
};

#endif // TYBGMVOLUMECONTROLLER_QT_H