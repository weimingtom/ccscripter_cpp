/*
 *  TYNScrSprite.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  NScripter sprite - positioned sprite with visibility control.
 *  Note: Actual drawing requires QtWidgets integration.
 */

#ifndef TYNSSCRSPRITE_QT_H
#define TYNSSCRSPRITE_QT_H

#include <QObject>
#include <QString>
#include <QPoint>
#include <QImage>

class TYNScrSprite : public QObject
{
    Q_OBJECT
    
public:
    // Constants
    static const int INVALID_SPRITE_ID = -1;
    
    // Constructor
    TYNScrSprite(int spriteId, const QString& path, const QPoint& point, 
                int alpha, bool visible, QObject* parent = nullptr);
    ~TYNScrSprite();
    
    // Position control
    void moveX(int x, int y, int alpha);
    void absoluteMoveX(int x, int y, int alpha);
    
    // Visibility
    void setVisible(bool visible) { m_visible = visible; }
    bool visible() const { return m_visible; }
    
    // Sprite ID
    int spriteID() const { return m_spriteId; }
    
    // Image path
    QString imagePath() const { return m_imagePath; }
    
    // Position
    QPoint position() const { return m_position; }
    void setPosition(const QPoint& pos) { m_position = pos; }
    
    // Alpha
    int alpha() const { return m_alpha; }
    void setAlpha(int alpha) { m_alpha = alpha; }
    
    // Drawing - would be implemented with QtWidgets in real integration
    void draw();
    
signals:
    void spriteChanged(TYNScrSprite* sprite);
    
private:
    int m_spriteId;
    bool m_visible;
    bool m_registDelegate;
    QString m_imagePath;
    QPoint m_position;
    int m_alpha;
    QImage m_image;
};

// Notification name
extern const QString TYSpriteAnimationNotification;

#endif // TYNSSCRSPRITE_QT_H