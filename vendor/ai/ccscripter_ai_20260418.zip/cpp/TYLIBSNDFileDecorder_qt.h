/*
 *  TYLIBSNDFileDecorder.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Audio decoder using libsndfile.
 */

#ifndef TYLIBSNDFILEDECORDER_QT_H
#define TYLIBSNDFILEDECORDER_QT_H

#include "TYWaveDecorder_qt.h"
#include <QString>
#include <cstdint>

class TYLIBSNDFileDecoder : public TYWaveDecoder
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithData:(NSData*)sourceData
    explicit TYLIBSNDFileDecoder(const QByteArray& sourceData, QObject* parent = nullptr);
    ~TYLIBSNDFileDecoder();
    
    // TYWaveDecoder implementation
    bool initWithData(const QByteArray& sourceData) override;
    bool getSamples(int16_t** samples, int* frames, int* channels, int* rate) override;
    
private:
    QString m_tempPath;
    int16_t* m_samples;
    int m_frames;
    int m_channels;
    int m_sampleRate;
};

#endif // TYLIBSNDFILEDECORDER_QT_H