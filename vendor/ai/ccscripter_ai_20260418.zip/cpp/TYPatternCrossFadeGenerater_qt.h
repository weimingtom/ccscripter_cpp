/*
 *  TYPatternCrossFadeGenerater.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Pattern-based cross-fade transition effect generator.
 */

#ifndef TYPATTERNCROSSFADEGENERATER_QT_H
#define TYPATTERNCROSSFADEGENERATER_QT_H

#include <QObject>
#include <QImage>
#include <QTimer>
#include <QDateTime>
#include "TYEffecter_qt.h"
#include "TYEffectPatternMap_qt.h"

class TYPatternCrossFadeGenerater : public QObject
{
    Q_OBJECT
    
public:
    TYPatternCrossFadeGenerater(const QImage& beforeImage, const QImage& afterImage,
                               TYEffectDefinitionValue* effect, QObject* parent = nullptr);
    ~TYPatternCrossFadeGenerater();
    
    QImage currentImage() const { return m_currentImage; }
    bool isEffectComplete() const { return m_isComplete; }
    
signals:
    void effectImageChanged(const QImage& image);
    void effectFinished();
    
public slots:
    void drawEffect();
    
private:
    QImage m_beforeImage;
    QImage m_afterImage;
    QImage m_currentImage;
    TYEffectPatternMap* m_patternMap;
    const uint8_t* m_patternPtr;
    int m_patternWide;
    int m_patternHigh;
    QDateTime m_startDate;
    int m_effectTime;
    double m_phaseInterval;
    bool m_isComplete;
};

#endif // TYPATTERNCROSSFADEGENERATER_QT_H