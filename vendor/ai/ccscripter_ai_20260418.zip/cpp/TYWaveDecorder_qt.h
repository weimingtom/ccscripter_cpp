/*
 *  TYWaveDecorder.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Wave decoder protocol for audio plugins.
 */

#ifndef TYWAVEDECORDER_QT_H
#define TYWAVEDECORDER_QT_H

#include <QByteArray>
#include <cstdint>

// Wave decoder interface (replaces @protocol TYWaveDecorder)
class TYWaveDecoder
{
public:
    virtual ~TYWaveDecoder() = default;
    
    // Replaces: -(id)initWithData:(NSData*)sourceData
    virtual bool initWithData(const QByteArray& sourceData) = 0;
    
    // Replaces: -(BOOL)getSamples:(short**)samples_ptr frames:(int*)frames channels:(int*)channels rate:(int*)rate
    virtual bool getSamples(int16_t** samples, int* frames, int* channels, int* rate) = 0;
};

#endif // TYWAVEDECORDER_QT_H