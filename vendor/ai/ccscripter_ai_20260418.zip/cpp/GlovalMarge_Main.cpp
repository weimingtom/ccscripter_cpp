/*
 *  GlovalMarge_Main.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Utility to merge global variable files.
 *  Usage: GlovalMarge baseFile supportFile margeFile
 *
 *  Merges global variables from supportFile into baseFile.
 */

#include <QCoreApplication>
#include <QString>
#include "TYScripterValues_qt.h"

int main(int argc, const char* argv[])
{
    QCoreApplication app(argc, const_cast<char**>(argv));
    
    if (argc < 4) {
        qWarning() << "usage: GlovalMarge baseFile supportFile margeFile";
        return -1;
    }
    
    QString path1 = QString::fromLocal8Bit(argv[1]);
    QString path2 = QString::fromLocal8Bit(argv[2]);
    QString path3 = QString::fromLocal8Bit(argv[3]);
    
    TYScripterValues* val1 = new TYScripterValues();
    TYScripterValues* val2 = new TYScripterValues();
    
    val1->loadGlobalValues(path1);
    val2->loadGlobalValues(path2);
    
    val1->mergeGlobalValues(val2);
    val1->saveGlobalValues(path3);
    
    delete val1;
    delete val2;
    
    return 0;
}