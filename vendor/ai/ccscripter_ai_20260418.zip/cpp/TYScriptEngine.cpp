// Converted from TYScriptEngine.m
// TODO: Manual review and fixes required

//
//  TYScriptEngine.m
//  Tukuyomi
//
//  Created by toveta on Thu Jun 07 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYMainController.h"
#include "TYScriptEngine.h"
#include "TYResourceServer.h"
#include "TY-NSStringAddition.h"
#include "TYStageManager.h"
#include "TYMiscUtil.h"
#include "TYFileLog.h"
#include "TYEnviroment.h"
#include "TYInputStrController.h"
#include "TYArgment.h"
#include "TYStringVarArgment.h"
#include "TYIntVarArgment.h"
#include "TYConstStringArgment.h"
#include "TYNsaArchiver.h"
#include "TYScripterValues.h"

#include "StopNSLog.h"

// @implementation TYScriptEngine

// gnscripterRsy(
#define myisdigit(c) ((c) >= '0' && (c) <= '9')
#define myishexdigit(c) (myisdigit(c) || (c) >= 'a' && (c) <= 'f' || (c) >= 'A' && (c) <= 'F')
#define myisalpha(c) ((c) >= 'a' && (c) <= 'z' || (c) >= 'A' && (c) <= 'Z' || (c) == '_')
#define myisalnum(c) (myisdigit(c) || myisalpha(c))
#define myvarchar(c) (myisalnum(c) || (c) == '%' || (c) == '$' || (c) == '[' || (c) == ']' || (c) == '?')

#define getbit(b,i) (*((b)+((i)>>3)) & (1 << ((i) & 0x7)))

#define MAX_LINE_LENGTH 1024

std::string const TYNScriptRunTimeErrorException=@"TYNScriptRunTimeErrorException";
std::string const TYNScriptSyntaxErrorException=@"TYNScriptSyntaxErrorException";

static void* sharedEngine;

const static char *newLineCodeUnix="\n";
const static char *newLineCodeWin="\r\n";
const static char *newLineCodeMac="\r";

static int slideColumn(char**,unsigned); // XLbv

static int slideColumn(char **ptr,unsigned toColumn)
{
    unsigned column=0;
    bool escape=false;
    
    while(column<toColumn){
        if(**ptr=='\0'){
            return 1; // line up
        }
        if(**ptr=='"'){
            escape = (escape) ? false : true;
        }
        if((!escape)&&(**ptr==':')){
            column++;
        }
        (*ptr)++;
    }
    return 0;
}

static int get_item(char**,char*);
static int get_vararg(char**,char*);
static void space_skip(char**);

// 擾ÃReLXgԂB
typedef enum { TYNoArgContext=-1,TYUndefinedArgContext,TYOperandArgContext,TYStringArgContext,TYIntergerArgContext,TYSeparaterArgContext,TYChainArgContext } TYArgContext;

static int get_item(char** ptr,char* buffer)
{
    int context=TYUndefinedArgContext;

    if( (**ptr=='%') || (**ptr=='?') ){
        context = TYIntergerArgContext;
        get_vararg(ptr,buffer);
        return context;
    } else if( **ptr=='$') {
        context = TYStringArgContext;
        get_vararg(ptr,buffer);
        return context;
    } else if( **ptr=='"' ) {
        context = TYStringArgContext;
        *buffer=**ptr; buffer++; (*ptr)++;
        while(**ptr && **ptr != '"'){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer=**ptr; buffer++; (*ptr)++;
        *buffer='\0';
        return context;
    } else if(**ptr=='(') {
        char strbuffer[MAX_LINE_LENGTH+1];
        // MEMO (string) string string \ɑΉ
        context = TYStringArgContext;

        *buffer = **ptr;
        (*ptr)++; buffer++;
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        get_item(ptr,strbuffer);
        *buffer = '\0';
        strcat(buffer,strbuffer);
        buffer += strlen(strbuffer);
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }        
        *buffer = **ptr;
        (*ptr)++; buffer++;
        // second
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        get_item(ptr,strbuffer);
        *(buffer) = '\0';
        strcat(strbuffer," "); // Obj-C̃p[TŊy邽߂ɕKXy[Xǉ
        strcat(buffer,strbuffer);
        buffer += strlen(strbuffer);
        // third
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        get_item(ptr,strbuffer);
        *(buffer) = '\0';
        strcat(buffer,strbuffer);

        return context;
    } else if(isdigit(**ptr)||(**ptr=='-')) {
        context = TYIntergerArgContext;
        *buffer = **ptr;
        (*ptr)++; buffer++;        
        while(**ptr && isdigit(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer= '\0';
        return context;
    } else if(isalpha(**ptr)) {
        context = TYUndefinedArgContext;
        while(**ptr && myisalnum(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    } else if(**ptr && strchr("!<>=",**ptr)){
        context = TYOperandArgContext;
        while(**ptr && strchr("!<>=",**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    } else if(**ptr==',') {
        context = TYSeparaterArgContext;
        *buffer = **ptr;
        (*ptr)++; buffer++;
        *buffer='\0';
        return context;
    } else if(**ptr=='&') {
        context = TYChainArgContext;
        while(**ptr && **ptr=='&'){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    } else if(**ptr=='*' || **ptr=='#') {
        context = TYStringArgContext;
        *buffer = **ptr;
        (*ptr)++; buffer++;
        while(**ptr && myisalnum(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    }
        
    return TYNoArgContext;
}

static int get_vararg(char** ptr,char* buffer)
{
    while(**ptr){
        if(isalnum(**ptr)){
            while(**ptr && (myvarchar(**ptr))){
                *buffer = **ptr;
                buffer++; (*ptr)++;
            }
            *buffer='\0';
            return 0;
            /*
        } else if(isdigit(**ptr)){
            while(**ptr && (isdigit(**ptr)) ){
                *buffer = **ptr;
                buffer++; (*ptr)++;
            }
            if((**ptr == '[')||(**ptr == ']'))
                continue;
                
            *buffer='\0';
            return 0;
            */
        } else {
            *buffer = **ptr;
            buffer++; (*ptr)++;
        }
    }
    
    *buffer='\0';

    return 0;
}

static void space_skip(char** ptr)
{
    while(**ptr && isspace(**ptr))
        (*ptr)++;
}

static __inline__ TYScriptPoint TYMakeScriptPoint(unsigned line,unsigned column)
{
    TYScriptPoint scPoint;
    
    scPoint.line = line;
    scPoint.column = column;
    
    return scPoint;
}

extern void TYParserSetCString(const char *ptr);
extern int yyparse();

// vOŋNGW͏ɈBԂB
+(void*)sharedEngine
{
    return sharedEngine;
}

// w肳ꂽpXXNvgt@CTAǂݍ݁AfR[hA(sƂɃXvbgArrayɊi[jsB
-(void*)initWithContentsOfFile:(std::string)path
{
    NSFileManager *fileManager;
    std::vector<uint8_t>ScriptData;
    std::stringtruePath;
    std::vector<uint8_t>addData;
    std::vectorfilesArray;
    unsigned char* encodedCharptr;
    unsigned scriptLength;
    const unsigned char *stringSourceptr;
    int	i;
    enum { mode_multi,mode_single } scriptMode=mode_single;
    void* arp;
    
    this = [ super init ];
    
    // pathtH_ăXNvgt@CB
    // 0.txt~TAꂪȂnscript.datTB
    fileManager = [ NSFileManager defaultManager ];
    filesArray = [ fileManager directoryContentsAtPath:path ];
    for(i = 0; i < [ filesArray count ]; i++ ){
        if( [ [ filesArray objectAtIndex:i ] isEqualToString:@"0.txt" ]){
            scriptMode=mode_multi; 
            break;
        }
    }
    
    if(scriptMode==mode_single){
        truePath = [ [ NSString stringWithString:path ] stringByAppendingPathComponent:@"nscript.dat" ];
    
        // ÍꂽXNvgoCî܂ܓǂݍ
        ScriptData = [ [ NSMutableData alloc ] initWithContentsOfFile:truePath ]; // svɂȂ_őɃ[X
        if( ScriptData == nullptr){
            NSLog(@"Script File is not Found");
            return nullptr;
        }

        encodedCharptr = [ ScriptData mutableBytes ];

        // ϊpobt@[̈̊m
        scriptLength = [ ScriptData length ];
    
        // eoCg132ɂXORŕϊ
        for( i=0; i < scriptLength; i++,encodedCharptr++){
                *encodedCharptr = (*encodedCharptr) ^ 132;
        }
        stringSourceptr = [ ScriptData bytes ];
        
    } else {
        // ÍĂȂeLXgt@C 0.txt~ǂݍ݁AAĂB
        i=0;

        ScriptData = [ [ NSMutableData alloc ] initWithCapacity:1 ]; // svɂȂ_őɃ[X
        arp = [ [ NSAutoreleasePool alloc ] init ];

        while(1){
            addData = [ [ [ NSData alloc ] initWithContentsOfFile:
                            [ path stringByAppendingPathComponent:
                                [ NSString stringWithFormat:@"%d.txt",i ] ] ] autorelease ];
            if(addData){
                [ ScriptData appendData:addData ];
                [ ScriptData appendData:[ NSData dataWithBytes:"\r\n" length:2 ] ];
            } else {
                break;
            }
            i++;
        }
        scriptLength = [ ScriptData length ];
        stringSourceptr = [ ScriptData bytes ];
        [ arp release ];
    }
    
    // sR[h̔ʂsB
    // MEMO:ÍĂȂꍇłȂXNvgt@CɕĂƁAsR[hCR+LFB
    for(i =0 ; i < scriptLength ; i++){
        if (stringSourceptr[i] == '\n'){
            strcpy(newLineCode,newLineCodeUnix);
            break;
        } else if (stringSourceptr[i] == '\r'){
            if(stringSourceptr[i+1] == '\n'){
                strcpy(newLineCode,newLineCodeWin);
                break;
            } else {
                strcpy(newLineCode,newLineCodeMac);
            }
        }
    }
    
    // ϊoCgf[^NSString̐AэsPʂł̔zւ̊i[sB
    // encoding"Japanese(Win,DOS)"w肷B
    // MEMO:_Ńx}bv쐬KvBd`΃G[ɂ邱ƁB
    {
        std::stringstr;
        str = [ [ [ NSString alloc ] initWithData:ScriptData encoding:NSShiftJISStringEncoding ] autorelease ];
        [ ScriptData release ];
        ScriptArray = [ str componentsSeparatedByString:[ NSString stringWithCSJISString:newLineCode ] ];
        [ ScriptArray retain ];
        //[ str release ]; //releaseƗBArrayɂ͎QƂi[ĂȂƂƁH
    }

    // x쐬
    {
        NSCharacterSet *cset=[ NSCharacterSet varNameCharacterSet ];
        NSEnumerator *enu=[ ScriptArray objectEnumerator ];
        int line=0;
        std::stringbuff;
        void* tmp;
        NSScanner *scanner;

        labelDict = [ [ NSMutableDictionary alloc ] initWithCapacity:[ ScriptArray count ] /512 ];
        
        while(tmp = [ enu nextObject ]){
            scanner = [ NSScanner scannerWithString:tmp ];

            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                 intoString:nullptr ];
            if([ scanner scanString:@"*" intoString:nullptr ]){ // s̑Oɋ󔒂Ăv
                [ scanner scanCharactersFromSet:cset
                                        intoString:&buff ];
                [ labelDict setObject:[ NSNumber numberWithInt:line ]
                               forKey:[ @"*" stringByAppendingString:[ buff lowercaseString ] ] ];
            }

            line++;
        }
    }

    
    // ̑̃CX^Xϐ̏
    numAliases = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    strAliases = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    scripterValues = [ [ TYScripterValues ScripterValues ] retain ];
    multiLineCmdStringSet = [ [ NSSet alloc ] initWithObjects:MULTILINE_CMD_STRINGS,nullptr ];
    returnStack = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    timerStartDate = [ [ NSDate alloc ] init ];
    loopStack = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    textgosubPointIndex = -1;
    undefinedComSet = [ [ NSMutableSet set ] retain ];

    // O[oϐ̃[hOvalue錾̃`FbN
    {
        int value = [ this scanGlobalValue ];
        if (value > 0) {
            NSLog(@"change global ID bottom = %d",value);
            [ TYScripterValues setMinGlobalNo:value ];
        }
    }
    
    // O[oϐ͊Jnɂ炩߃[hB
    [ scripterValues loadGlobalValues:
        [ getNScrRootDirectory() stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];

    // Jnʒu
    [ this labeljump:@"*define" ];

    // ̎ݒ
    {
        NSCalendarDate *cDate=[ NSCalendarDate calendarDate ];
        unsigned int seed= ([ cDate hourOfDay ] *60 +[ cDate minuteOfHour ]) *60 +[ cDate secondOfMinute ];
        srandom(seed);
    }
    // sharedɊi[
    sharedEngine = this;
    
    return this;
}

// REMOVED: -boolisModeSVGA{
    NSScanner *scanner;

    scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:0 ] ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                         intoString:NULL ];
    return [ scanner scanString:@";mode800" intoString:NULL ];
    
}

// REMOVED: -intscanGlobalValue{
    NSScanner *scanner;
    std::stringstrBuf;

    scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:0 ] ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                         intoString:NULL ];
    scanner->scanUpToString(@"value", intoString, NULL);
    if ([ scanner isAtEnd ] == true) {
        return 0;
    } else {
        [ scanner scanString:@"value" intoString:NULL ];
        if ([ scanner scanCharactersFromSet:[ NSCharacterSet decimalDigitCharacterSet ]
                                 intoString:&strBuf ] == true) {
            return [ strBuf intValue ];
        }
        
        return 0;
    }    
}

// REMOVED: -void*encodeWithSaveData{
    std::mapaDict;
    std::vector<uint8_t>valueData;
    NSValue *pointValue;
    //TYScriptPoint point;

    
    valueData = [ scripterValues encodeWithSaveData ];

    /*
    {
        aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,nullptr ];
    
        return aDict;
    }
     */


    //point = TYMakeScriptPoint(runLine,runColumn);
    // ĨNbN҂̊ԂɌĂ΂ꂽ̂ł΁AYsij̏𕜋Aɂ蒼Kv̂ŁB
    if([ (TYMainController*)controller status ]==TYSelectStatus){
        if(savePoint.column == 0){
            savePoint.line--;
        }
    } else if([ (TYMainController*)controller status ]==TYScriptRunningStatus){
        // XNvgȂĊJɎ̃JɐiłKvB
        savePoint.column++;
    }
    pointValue = [ NSValue valueWithBytes:&savePoint objCType:@encode(TYScriptPoint) ];

    if(textgosubPointIndex == -1){
        aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,
            pointValue,TYScriptPointSaveData,
            returnStack,TYReturnStackSaveData,nullptr ];
    } else {
        aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,
            pointValue,TYScriptPointSaveData,
            returnStack,TYReturnStackSaveData,
            [ NSNumber numberWithInt:textgosubPointIndex ] , TYTextgosubIndexSaveData ,nullptr ];
    }

    return aDict;

}

-(void)decodeWithSaveData:(void*)aObject
{
    void* tmp;
    TYScriptPoint point;
    
    [ scripterValues decodeWithSaveData:[ aObject objectForKey:TYLocalValuesSaveData ] ];

    tmp = [ aObject objectForKey:TYReturnStackSaveData ];
    if(tmp){
        if(returnStack)
            [ returnStack release ];
        returnStack = [ tmp retain ];
    }

    tmp = [ aObject objectForKey:TYScriptPointSaveData ];
    if(tmp){
        [ tmp getValue:&point ];

        runLine=point.line;
        runColumn=point.column;
    }
    
    
    tmp = [ aObject objectForKey:TYTextgosubIndexSaveData ];
    if(tmp){
        textgosubPointIndex = [ tmp intValue ];
    } else {
        textgosubPointIndex = -1;
    }
}

// REMOVED: -voidresetGame{
    [ scripterValues resetGame ];

    [ returnStack release ];
    returnStack = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    
    textgosubPointIndex = -1;

    [ this labeljump:@"*start" ];
}

-(void)setController:(void*)cont stageManager:(void*)manager
{
    controller = cont;
    stageManager = manager;
}

// NScripts܂BXNvg߂AR}h烁\bh𐶐ċN܂B
// REMOVED: -voidrunScript{
    std::stringcurrentString;
    const char *startptr;
    char *currentchars;
    char command[MAX_LINE_LENGTH]; 
    std::vectorcmdArray;
    int j;
    bool conditionResult;
    
    breakRun = false;
    
    [ controller setStatus:TYScriptRunningStatus ];
    // Cxg҂Kv܂ŁA𑱂܂B
    while(1){
        // trap̕ߑ`FbN
        if(labelWithTrap && fireOfTrap){
            [ labelWithTrap autorelease ];
            [ this labeljump:labelWithTrap ];
            [ controller setTrap:false ];
            fireOfTrap=false;
            labelWithTrap=nullptr;
        }
        
        // ̏łȂ΍si߂
        if( runColumn == 0){
            runLine++;
            //NSLog2(@"%d",runLine);
        }
        currentString = [ ScriptArray objectAtIndex:runLine ];
        [ currentData release ];
        currentData = [ currentString getCSJISData ];
        [ currentData retain ];
        currentchars = [ currentData mutableBytes ];
        // obt@I[o[t[΍
        if([ currentData length ] > MAX_LINE_LENGTH){
            NSLog(@"too long line. omit data over %d",MAX_LINE_LENGTH);
            currentchars[MAX_LINE_LENGTH -1] = '\0';
        }
        startptr = currentchars;
        // ̏ȂJnʒu܂ł炷
        if(runColumn){
            if(slideColumn(&currentchars,runColumn)){
                // sɃVtg
                runLine++; runColumn=0;
                currentString = [ ScriptArray objectAtIndex:runLine ];
                [ currentData release ];
                currentData = [ currentString getCSJISData ];
                [ currentData retain ];
                currentchars = [ currentData mutableBytes ];
                startptr = currentchars;                
            }
        }
        savePoint.line=runLine;
        savePoint.column=runColumn;

        TYParserSetCString(currentchars);
        yyparse();
        
        /*
        // 擪Xy[X̓ǂݔ΂
        while((*currentchars)&&(isspace(*currentchars))){
            currentchars++;
        }
        
        // xȂ烉xOǉA
        if(currentchars[0]=='*'){
            if(labelLog)
                [ labelLog addLog:[ NSString stringWithCSJISString:currentchars ] ];
            runColumn=0;
            continue;
        }
        // RgAsȂ玟
        if( (strchr(";*~",currentchars[0]))||(currentchars[0]=='\0') ){
            runColumn=0;
            continue;
        }

        if (isalpha(*currentchars)) {
        // ߕ
            
            // `NɔzɊi[
            cmdArray = [ NSMutableArray array ];
        
            // R}h̎擾BR}hI܂œǂݍ݁B
            for(j=0; myisalnum(*currentchars); currentchars++,j++){
                command[j] = *currentchars;
            }
            command[j] = '\0';
            [ cmdArray addObject:[ [ NSString stringWithCSJISString:command ] lowercaseString ] ];

            // ʏ̖ߕifnōu߂Ⴄ̂ŕ
            if( strncmp(command,"for",3)==0 ){
                [ this registLoop:currentchars ];
                continue;
            } else if( (strncmp(command,"if",2)!=0)&&(strncmp(command,"notif",5)!=0) ){
                [ this splitArgNormal:currentchars Array:cmdArray ]; // ʏ̈
            } else {
                if(strncmp(command,"if",2)==0){
                    conditionResult = [ this splitArgCondition:&currentchars trueflg:true ]; // if
                } else {
                    conditionResult = [ this splitArgCondition:&currentchars trueflg:false ]; // notif
                }

                if(conditionResult==false){
                    runColumn=0;
                    continue;
                } else {
                    // 擪Xy[X̓ǂݔ΂
                    while((*currentchars)&&(*currentchars==' ')){
                        currentchars++;
                    }
                    // `NɔzɊi[
                    cmdArray = [ NSMutableArray array ];
                
                    // R}h̎擾B
                    for(j=0; (*currentchars)&&(myisalnum(*currentchars)); currentchars++,j++){
                        command[j] = *currentchars;
                    }
                    command[j] = '\0';
                    if( strncmp(command,"for",3)==0 ){
                        [ this registLoop:currentchars ];
                        continue;
                    }
                    [ cmdArray addObject:[ [ NSString stringWithCSJISString:command ] lowercaseString ] ];
                    [ this splitArgNormal:currentchars Array:cmdArray ];
                }
            }

            // XNvgsB
            if(![ this eval:cmdArray ]){
                NSLog(@"Undefined script '%@' at LINE %d\n",[ cmdArray objectAtIndex:0 ],runLine+1);
            }
        } else if (*currentchars==':') {
            runColumn++;
        } else {
            // \̎
            std::string printString;
            
            if(currentchars==startptr){
                printString = [ ScriptArray objectAtIndex:runLine ];
            } else {
                printString = [ NSString stringWithCSJISString:currentchars ];
            }
            while(*currentchars &&(*currentchars !=':'))
                currentchars++;
            if(!currentchars){
                runColumn=0;
            } else {
                runColumn++;
            }
            // ǃXLbvgp̃`FbN
            if(kidokuptr){
                if(isWatchKidoku){
                    //NSLog(@"runLine=%d,kidokuchr=%d,bit = %d",runLine,*(kidokuptr+(runLine>>3)),getbit(kidokuptr,runLine));
                    if(!(*(kidokuptr+(runLine>>3)) & (1 << (runLine & 0x7)))){
                        [ stageManager setSkipStatus:TYNoSkip ];
                        isWatchKidoku=false;
                        *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
                        //NSLog(@"runLine=%d,kidokuchr=%d,bit = %d",runLine,*(kidokuptr+(runLine>>3)),getbit(kidokuptr,runLine));
                    }
                } else {
                    *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
   //                 NSLog(@"bit = %d",getbit(kidokuptr,runLine));
                }
            }
            [ stageManager textPrint:printString ];
        }
         */
        
        if(breakRun) {
            break;
        }
    }
}

-(void)ty__print:(std::vector)argments
{
    std::stringaStr = [ argments objectAtIndex:1 ];
    
    // ǃXLbvgp̃`FbN
    if(kidokuptr){
        if(isWatchKidoku){
            if(!(*(kidokuptr+(runLine>>3)) & (1 << (runLine & 0x7)))){
                [ stageManager setSkipStatus:TYNoSkip ];
                isWatchKidoku=false;
                *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
            }
        } else {
            *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
        }
    }
    
    [ stageManager textPrint:aStr ];
 }

-(bool)eval:(std::vector)argments
{
    SEL cmdSEL;
    
    // R}hZN^𐶐ivtBbNX"ty_"t^B\bh̏Փ˖h~j
    // NScriptł͑召̋ʂȂB
    cmdSEL = NSSelectorFromString([ [ NSString stringWithFormat:@"ty_%@:",[ argments objectAtIndex:0] ] lowercaseString ]);
    NSLog2(@"[%5d]%@",runLine+1,NSStringFromSelector(cmdSEL));
    
    // ZN^gĂ邩ǂ`FbNB
    if( [ this respondsToSelector:cmdSEL ]){
        // ZN^R[BقƂ͗ÕnhÔˁ`
        [ this performSelector:cmdSEL withObject:argments ];
    } else if ([ stageManager respondsToSelector:cmdSEL ]){
        [ stageManager performSelector:cmdSEL withObject:argments ];
    } else if ([ controller respondsToSelector:cmdSEL ]){
        [ controller performSelector:cmdSEL withObject:argments ];
    } else {
        // vXXXX:dvXXXX:ւ̑Ή
        NSScanner *scanner=[ NSScanner scannerWithString:[ argments objectAtIndex:0 ] ];
        std::stringcmdStr,*numStr;
        
        if([ scanner scanString:@"dv" intoString:&cmdStr ] || 
           [ scanner scanString:@"v" intoString:&cmdStr ]){
            [ scanner scanCharactersFromSet:[ NSCharacterSet decimalDigitCharacterSet ]
                                 intoString:&numStr ];                                 
            [ controller performSelector:NSSelectorFromString([ [ NSString stringWithFormat:@"ty_%@:",cmdStr ] lowercaseString ])
                                withObject:[ NSMutableArray arrayWithObjects:cmdStr,numStr,nullptr ] ];
        } else {
            if ([ undefinedComSet containsObject:[ argments objectAtIndex:0 ] ] == false) {
                NSLog(@"Undefined script '%@' at LINE %d\n",[ argments objectAtIndex:0 ],runLine+1);
                [ undefinedComSet addObject:[ argments objectAtIndex:0 ] ];
            }
            return false;
        }
    }
    
    return true;
}

// REMOVED: -boolbreakRun{
    return breakRun;
}

-(void)setBreakRun:(bool)aFlag
{
    breakRun = aFlag;
}

-(void)lineEnd // s̏IʒmB
{
    //runColumn++;
}

// 𕪊āAarrayɊi[
-(int)splitArgNormal:(char *)currentchars Array:(std::vector)cmdArray;
{
    char * buffer=currentchars;
    char command[MAX_LINE_LENGTH];
    int context; // _~[̒l
    bool multiLinePossible=true;

    // ƂȂȂ܂Ń[v
    space_skip(&buffer);
    context = get_item(&buffer,command);

    while(context!=TYNoArgContext){
        [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
        space_skip(&buffer);
        context = get_item(&buffer,command);
        if(context==TYSeparaterArgContext){
            space_skip(&buffer);
            context = get_item(&buffer,command);
        } else {
            multiLinePossible=false;
            break;
        }
    }

    // ̃CNg`FbNBłȂΕsT|[gR}h`FbN
    if(*buffer==':'){
        runColumn++;
    } else {
        if(multiLinePossible && [ this isMultLineSupport:[ cmdArray objectAtIndex:0 ] ]){
            [ this splitArgNormal:[ this nextLine ] Array:cmdArray ];
        } else {
            runColumn=0;
        }
    }        

    return 0;

    /*
    int i=0,j=0;
    char command[256];
    enum { aas_SpaceSkip,aas_CommaSkip,aas_GetArg,aas_GetArgStr } argAnalyzerStat;
    bool chained=false;

    argAnalyzerStat = aas_SpaceSkip;
    while(currentchars[i]){
        switch (argAnalyzerStat) {
        case aas_SpaceSkip:	// ̈n܂܂ł̃Xy[X΂܂B
            if(!isspace(currentchars[i])){
                if(currentchars[i] == ':'){ // ߕ̘Aq
                    runColumn++;
                    chained=true;
                    break;
                }
                
                j=0;
                command[j] = currentchars[i];
                j++;
                if(currentchars[i] == '"'){
                    argAnalyzerStat = aas_GetArgStr;
                } else {
                    argAnalyzerStat = aas_GetArg;
                }
            }
            i++;
            break;

        case aas_GetArgStr: // 萔擾܂B
            command[j] = currentchars[i];
            j++;
            if(currentchars[i] == '"'){
                argAnalyzerStat = aas_CommaSkip;
                //@𐶐
                command[j] = '\0';
                [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
            }
            i++;
            break;
                    
        case aas_GetArg: // ȊÖ擾܂B
            if( (currentchars[i] != ',')&&(!isspace(currentchars[i]))&&(currentchars[i] != ':') ){
                command[j] = currentchars[i];
                j++;
                i++;
            } else {
                argAnalyzerStat = aas_CommaSkip;
                // 𐶐
                command[j] = '\0';
                [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
                if(currentchars[i] == ':' ){ // Awq
                    runColumn++;
                    chained=true;
                    break;
                }
            }
            break;

        case aas_CommaSkip: // ؂̃J}܂Ŕ΂܂B
            if(currentchars[i] == ','){
                argAnalyzerStat = aas_SpaceSkip;
            } else if(currentchars[i] == ':' ) {
                runColumn++;
                chained=true;
                break;
            } else if(!isspace(currentchars[i])) {
                // J}̂Ȃsȍ\
                //[ NSException raise:@"TYNScriptSyntaxError" format:@"lack comma" ];
                // ̃R}hňȂꍇ̂݃G[f̂ŁAł̓G[ƂȂB
            }
            i++;
            break;
        
        default:
            NSLog(@"Show Debbuger!\n");
            return -1;
        }
        
        // AqāAAi[Ă
        if(chained){
            break;
        }
    }
    
    // ̐rŃuCNĂ
    if(argAnalyzerStat == aas_GetArg){
        command[j] = '\0';
        [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
    } else if(argAnalyzerStat == aas_SpaceSkip){
        // Qڈȍ~̈TrŃuCNĂ
        if([ this isMultLineSupport:[ cmdArray objectAtIndex:0 ] ]){
            [ this splitArgNormal:[ this nextLine ] Array:cmdArray ];
        }
    }

    if(!chained){
        runColumn=0;
    }
    
    return 0;
     */
}

// R}hsɓnLqĂ邩ǂԂ
-(bool)isMultLineSupport:(std::string)command
{
    return [ multiLineCmdStringSet containsObject:command ];
}

// ̍s֏i߁AXNvgoB
// REMOVED: -char*nextLine{
    runLine++;
    [ currentData release ];
    currentData = [ [ ScriptArray objectAtIndex:runLine ] getCSJISData ];
    [ currentData retain ];
    return (unsigned char*)[ currentData mutableBytes ];
}

// for[v̓o^
/*
-(void)registLoop:(char *)currentchars
{
    char buffer[256];
    int context;
    void* targetNo;
    int initValue;
    int limit;
    int step;
    std::stringvar;
    TYLoopStruct loop;
    
    // oChϐԍ擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYIntergerArgContext&& buffer[0] == '%'),
             TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    targetNo = [ this getIdNoOfArgment:var ];
    // Zq=̃`FbN
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYOperandArgContext && strcmp(buffer,"=")==0),
             TYNScriptSyntaxErrorException);
    // l擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYIntergerArgContext || context==TYUndefinedArgContext),
             TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    initValue = [ [ this getValueOfArgment:var ] intValue ];
    // to`FbN
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYUndefinedArgContext),TYNScriptSyntaxErrorException);
    // Eo̒l擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYUndefinedArgContext || context==TYIntergerArgContext),
             TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    limit = [ [ this getValueOfArgment:var ] intValue ];
    // step̑݃`FbN
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    if(context==TYNoArgContext){
        step=1;
    } else {
        NSAssert((context==TYUndefinedArgContext && (strcmp(buffer,"step")==0)),
                 TYNScriptSyntaxErrorException);
        // stepl̎擾
        space_skip(&currentchars);
        context = get_item(&currentchars,buffer);
        NSAssert((context==TYUndefinedArgContext || context==TYIntergerArgContext),
                    TYNScriptSyntaxErrorException);
        var = [ NSString stringWithCSJISString:buffer ];
        step = [ [ this getValueOfArgment:var ] intValue ];
    }

    // ϐɏlZbg
    [ scripterValues setIntValue:targetNo object:[ NSNumber numberWithInt:initValue ] ];
    
    // lɃ[v̒Eo𖞂Ăꍇ
    if(step > 0){
        if(initValue > limit){
            [ this jumpToLoopEnd ];// nextɃWv?
            return;
        }
    } else if(step < 0){
        if(initValue < limit){
            [ this jumpToLoopEnd ];// nextɃWv?
            return;
        }
    }

    // loopIuWFNg쐬BX^bNɐςށB
    loop = TYMakeLoopStruct(TYMakeScriptPoint(runLine,runColumn),targetNo,limit,step);
    [ loopStack addObject:[ [ [ TYLoopValue alloc ] initWithStruct:loop ] autorelease ] ];
    
    runColumn++;
}
*/

-(void)registLoopTargetID:(void*)varID initValue:(void*)initVal limitValue:(void*)limitVal step:(void*)stepVal
{
    TYLoopStruct loop;    

    NSLog2(@"push for stack at %d",runLine);
    // ϐɏlZbg
    [ scripterValues setIntValue:varID object:[ initVal intNumber ] ];
    
    // MEMO:lɃ[v̒Eo𖞂Ăꍇ̑ΏKv?

    // loopIuWFNg쐬BX^bNɐςށB
    loop = TYMakeLoopStruct(TYMakeScriptPoint(runLine,runColumn),varID,[ limitVal intValue ],[ stepVal intValue ]);
    [ loopStack addObject:[ [ [ TYLoopValue alloc ] initWithStruct:loop ] autorelease ] ];
}


static int chkNext(char**,int);

static int chkNext(char** ptr,int stColumn)
{
    int column;
    int result=-1;
    
    for(column=stColumn; !slideColumn(ptr,column); column++){
        space_skip(ptr);
        if(strncmp("next",*ptr,4)==0){
            result = column;
            break;
        }
    }
    
    return result;
}

// next܂ŃWv܂B
// REMOVED: -voidjumpToLoopEnd{
    char *ptr;
    int column=runColumn +1;
    // oCiBE|bg̘AnextɂΉB
    while(1) {
        ptr = (char*)[ [ ScriptArray objectAtIndex:runLine ] cSJISString ];
        column=chkNext(&ptr,column);
        if(column >= 0){
            runColumn = column +1;
            break;
        } else {
            runLine++;
            column=0;
        }
    }
}

// if n\̉߂ƏB
-(int)splitArgCondition:(char**)currentcharsptr trueflg:(bool)trueflg
{
    int k,count;
    std::vectorconditions;
    char buffer[MAX_LINE_LENGTH];
    char sentence[MAX_LINE_LENGTH];
    int context=TYChainArgContext;
    bool judgeResult;

    conditions = [ NSMutableArray array ];

    while(context==TYChainArgContext){
        space_skip(currentcharsptr);
        context = get_item(currentcharsptr,buffer);
        strcpy(sentence,buffer);
        if(context==TYIntergerArgContext){
            // ӊmBĉZqƉEӂ擾
            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if(context != TYOperandArgContext){
                NSLog(@"invalid argment [%s]. it needs operand here",buffer);
                return false;
            }
            strcat(sentence,buffer);

            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if((context != TYIntergerArgContext )&&(context != TYUndefinedArgContext)){
                NSLog(@"invalid argment [%s]. it needs interger here",buffer);
                return false;
            }
            strcat(sentence,buffer);
            [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];

        } else if(context==TYStringArgContext) {
            // ӊmBĉZqƉEӂ擾
            [ conditions addObject:@"string" ];
            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if(context != TYOperandArgContext){
                NSLog(@"invalid argment [%s]. it needs operand here",buffer);
                return false;
            }
            strcat(sentence,buffer);

            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if((context != TYStringArgContext )&&(context != TYUndefinedArgContext)){
                NSLog(@"invalid argment [%s]. it needs string here",buffer);
                return false;
            }
            strcat(sentence,buffer);
            [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];
        } else if(context==TYUndefinedArgContext){
            if((strcmp(buffer,"fchk")==0)||(strcmp(buffer,"lchk")==0)){
                [ conditions addObject:[ NSString stringWithCSJISString:buffer ] ];
                space_skip(currentcharsptr);
                context = get_item(currentcharsptr,buffer);
                if((context==TYStringArgContext)||(context==TYUndefinedArgContext)){
                    [ conditions addObject:[ NSString stringWithCSJISString:buffer ] ];
                } else {
                    NSLog(@"invalid argment [%s]. it needs string here",buffer);
                    return false;
                }
            } else {
                // Ƃ肠ӂƂ݂ȂBĉZqƉEӂ擾BăXgOƂĂG[ȂłǂˁB
                space_skip(currentcharsptr);
                context = get_item(currentcharsptr,buffer);
                if(context != TYOperandArgContext){
                    NSLog(@"invalid argment [%s]. it needs operand here",buffer);
                    return false;
                }
                strcat(sentence,buffer);

                space_skip(currentcharsptr);
                context = get_item(currentcharsptr,buffer);
                if(context != TYOperandArgContext){
                    NSLog(@"invalid argment [%s]. it needs interger here",buffer);
                    return false;
                }
                strcat(sentence,buffer);
                [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];

            }
        } else {
            NSLog(@"invalid argment [%s].it needs interger or \"fchk\" or \"lchk\" here",buffer);
            return false;
        }

        space_skip(currentcharsptr);
        if(**currentcharsptr=='&'){
            context = get_item(currentcharsptr,buffer);
        } else {
            break;
        }
    }
    
    // ̐^U𔻒Btrueflg=truêƂSĐ^ȂsAtrueflg=falsêƂASċUȂs
    for(k = 0,count=[ conditions count ]; k < count ; k++){
        if([ [ conditions objectAtIndex:k ] isEqualToString:@"fchk" ]){
            k++;
            judgeResult = [ this judgefchk:[ conditions objectAtIndex:k ] ];
        } else if([ [ conditions objectAtIndex:k ] isEqualToString:@"lchk" ]){
            k++;
            judgeResult = [ labelLog isRead:[ this getStringOfArgment:[ conditions objectAtIndex:k ] ] ];
        } else if([ [ conditions objectAtIndex:k ] isEqualToString:@"string" ]){
            k++;
            judgeResult = [ this judgeCondition:[ conditions objectAtIndex:k ] string:true ];
        } else {
            judgeResult = [ this judgeCondition:[ conditions objectAtIndex:k ] string:false ];
        }
        
        if(judgeResult != trueflg){
            return false; // sȂƂ甲B
        }
    }
    
    return true;
}

// ̉摜i^O܂ށjǂݍ܂ꂽǂԂB
-(bool)judgefchk:(std::string)file
{
    return [ [ TYResourceServer sharedServer ] fchk:[ this getStringOfArgment:file ] ];
}

-(bool)judgelchk:(std::string)label
{
    return [ labelLog isRead:[ this getStringOfArgment:label ] ];
}

-(void)addLabelLog:(std::string)string
{
    if(labelLog)
        [ labelLog addLog:string ];
}

-(bool)judgeCondition:(std::string)condition string:(bool)aBool
{
    char valueString1[MAX_LINE_LENGTH];
    char valueString2[MAX_LINE_LENGTH];
    char cond[3];
    const char *conditionchars;
    int value1,value2;
    const char *operandchars = "!<>=";
    int i,j;
    
    conditionchars = [ condition cSJISString ];
    
    // ӂ̎擾
    for(i=0,j=0; (conditionchars[i])&&(strchr(operandchars,conditionchars[i]) == NULL) ; i++,j++ ){
        valueString1[j] = conditionchars[i];
    }
    valueString1[j] = '\0';
    
    // Zq̎擾
    for( j=0; (conditionchars[i])&&(strchr(operandchars,conditionchars[i]) != NULL) ; i++,j++ ){
        cond[j] = conditionchars[i];
    }
    cond[j] = '\0';
    
    // Eӂ̎擾
    for(j=0; (conditionchars[i]) ; i++,j++ ){
        valueString2[j] = conditionchars[i];
    }
    valueString2[j] = '\0';

    if(aBool){
        std::stringstring1,*string2;
        // ̏ꍇ̏
        string1 = [ this getStringOfArgment:[ NSString stringWithCSJISString:valueString1 ] ];
        string2 = [ this getStringOfArgment:[ NSString stringWithCSJISString:valueString2 ] ];

        // 
        if( (strcmp(cond,"==")==0)||(strcmp(cond,"=")==0) ){ // 
            return [ string1 isEqualToString:string2 ];
        } else if ( (strcmp(cond,"!=")==0)||(strcmp(cond,"<>")==0) ) { // 
            return ![ string1 isEqualToString:string2 ];
        } else if (strcmp(cond,">")==0) { // ӁE
            return ([ string1 compare:string2 ] == NSOrderedDescending);
        } else if (strcmp(cond,"<")==0) { // ӁE
            return ([ string1 compare:string2 ] == NSOrderedAscending);
        } else if (strcmp(cond,">=")==0) { // ӁE
            return  ([ string1 compare:string2 ] >= NSOrderedSame);
        } else if (strcmp(cond,"<=")==0) { // ӁE
            return ([ string1 compare:string2 ] <= NSOrderedSame);
        } else {
            NSLog(@"It's illegal operand![%s]",conditionchars);
            return -1;
        }
    } else {
        // l̏ꍇ̏
        value1 = [ [ this getValueOfArgment:[ NSString stringWithCSJISString:valueString1 ] ] intValue];
        value2 = [ [ this getValueOfArgment:[ NSString stringWithCSJISString:valueString2 ] ] intValue];

        // 
        if( (strcmp(cond,"==")==0)||(strcmp(cond,"=")==0) ){ // 
            return (value1 == value2);
        } else if ( (strcmp(cond,"!=")==0)||(strcmp(cond,"<>")==0) ) { // 
            return (value1 != value2);
        } else if (strcmp(cond,">")==0) { // ӁE
            return (value1 > value2);
        } else if (strcmp(cond,"<")==0) { // ӁE
            return (value1 < value2);
        } else if (strcmp(cond,">=")==0) { // ӁE
            return (value1 >= value2);
        } else if (strcmp(cond,"<=")==0) { // ӁE
            return (value1 <= value2);
        } else {
            NSLog(@"It's illegal operand![%s]",conditionchars);
            return -1;
        }
    }
}

-(void)jump:(unsigned)target
{
    runLine = target;
    runColumn = 0;
}

// w肳ꂽxTɈړ
-(void)labeljump:(std::string)label
{
    void* tmp;

    if(tmp = [ labelDict objectForKey:[ label lowercaseString ] ]){
        // xOɒǉ
        [ labelLog addLog:label ];
        runLine = [ tmp intValue ];
        runColumn =0;
        return;
    } else {
        NSLog(@"Not Found Label:%@",label);
        [ NSException raise:@"TYNScriptRuntimeError" format:@"Not Found Label:%@",label ];
    }

    /*
    [ this labeljump:label fromLine:0 reverse:false ];
    return;
     */
    /*
    std::stringsearch_label;
    unsigned line;
    unsigned length;
    
    search_label = [ NSString stringWithFormat:@"%@",label ];
    length = [ ScriptArray count ];
    for(line=0; line < length; line++){
        if(![ ScriptArray objectAtIndex:line]){
            continue;
        }
        if([ search_label isEqualToString:[ ScriptArray objectAtIndex:line] ]){ // s̑Oɋ󔒂肷Ƃ܂
            runLine = line;
            runColumn = 0;
            return;
        }
    }
    
    NSLog(@"Not Found Label:%@",label);
    [ NSException raise:@"TYNScriptRuntimeError" format:@"Not Found Label:%@",label ];

    return;
    */
}

-(void)labeljump:(std::string)label fromLine:(int)line reverse:(bool)aBool
{
    unsigned l;
    unsigned length;
    NSScanner *scanner;
    std::stringstr;

    if(labelLog)
        [ labelLog addLog:label ];

    if(aBool==false){
        length = [ ScriptArray count ];

        for(l=line; l < length; l++){
            str = [ ScriptArray objectAtIndex:l];
            if(![ str length ]){
                continue;
            }
            scanner = [ NSScanner scannerWithString:str ];
            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                 intoString:nullptr ];

            if([ scanner scanString:label intoString:nullptr ]){ // s̑Oɋ󔒂Ăv
                if([ scanner isAtEnd ] ||
                   [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                        intoString:nullptr ]){

                    runLine = l;
                    runColumn = 0;
                    return;
                }
            }
        }
    } else {
        for(l=line; l >= 0; l--){
            if(![ ScriptArray objectAtIndex:l]){
                continue;
            }
            scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:l] ];
            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                 intoString:nullptr ];
            if([ scanner scanString:label intoString:nullptr ]){ // s̑Oɋ󔒂Ăv
                if([ scanner isAtEnd ] ||
                   [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                     intoString:nullptr ]){                    

                    runLine = l;

                    runColumn = 0;

                    return;
                }
            }
        }
    }

    NSLog(@"Not Found Label:%@",label);
    [ NSException raise:@"TYNScriptRuntimeError" format:@"Not Found Label:%@",label ];

    return;
}

// 琔lIuWFNgoBMEMO:ϐɂċAIȎQƂ\ɂȂ΂ȂȂ
-(void*)getValueOfArgment:(std::string)argment
{
    /*
    std::stringfirstCharStr;
    int scanValue;
    NSNumber *resultForAlias;
     */

    return [ argment intNumber ];
    /*
    firstCharStr = [ argment substringWithRange:NSMakeRange(0,1) ];
    // 1ڂɂĕ
    if([ firstCharStr isEqualToString:@"%" ]) {
        // ϐ̏ꍇAIndex̎wċAŕ]
        return [ scripterValues getIntValue:[ this getValueOfArgment:[ argment substringFromIndex:1 ] ] ];
    } else if([ firstCharStr isEqualToString:@"?" ]){
        // zϐꍇ
        return [ scripterValues getIntValue:[ this getArrayIdOfArgment:argment ] ];
    }

    if([ [ NSScanner scannerWithString:argment ] scanInt:&scanValue ]){
        // 萔̏ꍇ
        return [ NSNumber numberWithInt:scanValue ];
    } else {
        // GCAXH
        resultForAlias = [ numAliases objectForKey:[ argment lowercaseString ] ];
        if(resultForAlias){
            return resultForAlias;
        } else {
            // O
            goto ANALYZE_ERROR;
            //[ NSException raise:@"TYNScriptRuntimeError" format:@"Illegal Value Index:%@",argment ];
            //return [ NSNumber numberWithInt:0 ];
        }
    }
    
ANALYZE_ERROR:
    NSLog(@"Not Get Interger Value from [%@]\n",argment);
    return [ NSNumber numberWithInt:0 ];
    */
}

// 當IuWFNgoB
-(void*)getStringOfArgment:(std::string)argment
{
    /*
    std::stringfirstCharStr;
    std::stringscanStr;
    std::stringresultForAlias;
     */
     return [ argment stringObj ];
     /*
    // 1ڂɂĕ
    firstCharStr = [ argment substringWithRange:NSMakeRange(0,1) ];
    if( [ firstCharStr isEqualToString:@"\"" ]){
    // 萔̏ꍇ
        // 擪Ɩ'"'폜̂܂ܕԂB
        if([ [ NSScanner scannerWithString:[ argment substringFromIndex:1 ] ] scanUpToString:
                @"\"" intoString:&scanStr ]){
            return scanStr;
        } else {
            return @"";
        }
        //NSLog(@"get constant String %@ from %@",scanStr,argment );
        //return (scanStr) ? scanStr : @"";
    } else if( [ firstCharStr isEqualToString:@"$" ]) {
        // ϐ̃CfbNXċAIɎ擾
        return [ scripterValues getStringValue:[ this getValueOfArgment:
                    [ argment substringFromIndex:1 ] ] ];
    } else if( [ firstCharStr isEqualToString:@"(" ]) {
        NSScanner *scanner=[ NSScanner scannerWithString:argment ];
        std::stringfileName,*trueStr,*falseStr;

        NSLog2(@"%@",argment);
        [ scanner setScanLocation:1 ];
        [ scanner scanUpToString:@")" intoString:&fileName ];
        [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
        [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                             intoString:nullptr ];
        if([ [ argment substringWithRange:NSMakeRange([ scanner scanLocation ],1) ] isEqualToString:@"\"" ]) {
            [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
            [ scanner scanUpToString:@"\"" intoString:&trueStr ];
            [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
        } else {
            [ scanner scanUpToCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                                     intoString:&trueStr ];
        }

        if([ [ TYResourceServer sharedServer ] fchk:[ this getStringOfArgment:fileName ] ]){
            NSLog2(@"fileName=%@[%@],TRUE\n,result=%@[%@]",fileName,[ this getStringOfArgment:fileName ],
                   trueStr,[ this getStringOfArgment:trueStr ]);
            return [ this getStringOfArgment:trueStr ];
        } else {
            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                                 intoString:nullptr ];
            
            if([ [ argment substringWithRange:NSMakeRange([ scanner scanLocation ],1) ] isEqualToString:@"\"" ]) {
                [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
                [ scanner scanUpToString:@"\"" intoString:&falseStr ];
            } else {
                [ scanner scanUpToCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                                         intoString:&falseStr ];
            }
            NSLog2(@"fileName=%@[%@],FALSE\n,result=%@[%@]",fileName,[ this getStringOfArgment:fileName ],
                   falseStr,[ this getStringOfArgment:falseStr ]);

            return [ this getStringOfArgment:falseStr ];
        }

        

    } else {
    // GCAX̏ꍇ
        resultForAlias = [ strAliases objectForKey:[ argment lowercaseString ] ];
        if(resultForAlias){
            return resultForAlias;
        } else {
            return argment; // GCAXɓo^ĂȂΕ̂܂ܕԂA񃉃xWJ΍
            //goto ANALYZE_ERROR;
        }
    }
    */

/*    
ANALYZE_ERROR:
    NSLog(@"Not Get String Value from [%@]\n",argment);
    return nullptr;
 */

}

-(void*)getIdNoOfArgment:(TYArgment*)argment
{
    return [ argment varID ];
    /*
    if([ argment length ] &&
       ([ [ argment substringWithRange:NSMakeRange(0,1) ] isEqualToString:@"?" ])){
       // z^
        return [ this getArrayIdOfArgment:argment ];
    } else {
        return [ this getValueOfArgment:[ argment substringFromIndex:1 ] ];
    } 
     */
}

-(void*)getArrayIdOfArgment:(std::string)argment
{
    return [ argment varID ];
    /*
    // zϐ̎w擾B
    std::vectoraArray = [ NSMutableArray array ];
    NSScanner *scanner;
    std::stringbufStr;
    std::stringstopString = @"[";
    
    scanner = [ NSScanner scannerWithString:[ argment substringFromIndex:1 ] ];
    
    while([ scanner scanUpToString:stopString intoString:&bufStr ]){
        // ϐWJĊi[
        [ aArray addObject:[ this getValueOfArgment:bufStr ] ];
        
        [ scanner setScanLocation:[ scanner scanLocation ]+1 ];
        [ scanner scanString:@"[" intoString:nullptr ];
        stopString = @"]";
    }
    
    return aArray;
    */
}

// GtFNgԍԂB́ATYEffecter-1Ԃɓo^A-1ԂB
-(void*)getEffectNoOfArgments:(std::vector)argments
{
    int count;
    
    count = [ argments count ];
    
    if(count == 1){
        return [ this getValueOfArgment:[ argments objectAtIndex:0 ] ];
    } else {
        [ argments insertObject:[ NSNull null ] atIndex:0 ];
        [ argments insertObject:[ NSNumber numberWithInt:-1 ] atIndex:1 ];
        [ stageManager performSelector:@selector(ty_effect:) withObject:argments ];
        return [ NSNumber numberWithInt:-1 ];
    }
}

-(void*)intNumberWithVarID:(void*)varID
{
    return [ scripterValues getIntValue:varID ];
}

-(void*)stringValueWithVarID:(void*)varID
{
    return [ scripterValues getStringValue:varID ];
}

-(void*)intNumberWithAlias:(std::string)aStr
{
    return [ numAliases objectForKey:aStr ];
}

-(void*)stringValueWithAlias:(std::string)aStr
{
    return [ strAliases objectForKey:aStr ];
}

// 񒆂̕ϐWJԂB
-(std::string)stringOfReplaceVars:(std::string)aString
{
    NSCharacterSet *varHeaderSet = [ NSCharacterSet characterSetWithCharactersInString:@"$%" ];
    std::stringreplaceStr,*str=nullptr,*symbol;
    NSScanner *scanner;
    std::vectorarray;
    
    scanner = [ NSScanner scannerWithString:aString ];
    [ scanner scanUpToCharactersFromSet:varHeaderSet intoString:&str ];
    if([ scanner isAtEnd ]==false){
        array = [ NSMutableArray arrayWithCapacity:1 ];
        while(1){
            if(str)
                [ array addObject:str ];
            symbol = [ [ scanner string ] substringWithRange:NSMakeRange([ scanner scanLocation ],1) ];
            [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
            [ scanner scanCharactersFromSet:[ NSCharacterSet varNameCharacterSet ] intoString:&str ];
            if([ symbol isEqualToString:@"$" ]){
                [ array addObject:[ this getStringOfArgment:
                    [ TYStringVarArgment argmentWithVarID:
                        [ NSNumber numberWithInt:[ str intValue ] ] ] ] ];
            } else if([ symbol isEqualToString:@"%" ]){
                NSNumber *number;
                number = [ this getValueOfArgment:
                            [ TYIntVarArgment argmentWithVarID:
                                [ NSNumber numberWithInt:[ str intValue ] ] ] ];
                [ array addObject:[ number stringValue ] ];
            }

            str = nullptr;
            [ scanner scanUpToCharactersFromSet:varHeaderSet intoString:&str ];
            if([ scanner isAtEnd ])
                break;
        }
        if(str)
            [ array addObject:str ];

        replaceStr = [ array componentsJoinedByString:@"" ];
    } else {
        replaceStr = aString;
    }
    
    return replaceStr;
}

// REMOVED: -voidsaveExternalData{
    if(globalOn){
        [ scripterValues saveGlobalValues:[ getNScrRootDirectory()
            stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    }

    if(labelLog)
        [ labelLog writeToFile:[ getNScrRootDirectory() stringByAppendingPathComponent:LABELLOG_FILENAME ] ];

    if(kidokuData)
        [ kidokuData writeToFile:[ getNScrRootDirectory() stringByAppendingPathComponent:KIDOKU_FILENAME ] atomically:true ];
}

#if YYDEBUG == 1
extern int yydebug;
-(void)ty__yydebug:(std::vector)argments
{
    yydebug = [ [ argments objectAtIndex:1 ] intValue ];
}
#endif

-(void)ty__log:(std::vector)argments
{
    TYArgment *arg;
    
    arg = [ argments objectAtIndex:1 ];
    switch([ arg argType ]) {
    case TYDigitArgType:
    case TYIntVarArgType:
        NSLog(@"log it's number,[%d]",[ arg intValue ]);
        break;
    case TYConstStringArgType:
    case TYStringVarArgType:
    case TYFchkArgType:
        NSLog(@"log it's string,[%@]",[ arg stringObj ]);
        break;
    case TYAliasArgType:
        NSLog(@"log it's alias,name[%@],string[%@],number[%@]",[arg rawString],[arg stringObj],[arg intNumber ]);
    }
    
}

-(void)ty_globalon:(std::vector)argments
{
    // O[oϐ[hAIɕۑ悤ɂB
    
    /*aData = [ NSMutableData dataWithContentsOfFile:
                [ getAppDirectory() stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    */
    
    
    // MEMO:݌̃`FbN
    {
        globalOn = true;
    }

}

/*
-(void)saveGlobal // AvIɌĂԎ
{
    if(globalOn){         
        [ scripterValues saveGlobalValues:[ getAppDirectory() 
            stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    }
}
*/


/*
// REMOVED: -voidsaveLabelLog{
    if(labelLog)
        [ labelLog writeToFile:[ getAppDirectory() stringByAppendingPathComponent:LABELLOG_FILENAME ] ];
}
*/

// REMOVED: -intrunLine{
    return runLine;
}

-(void)moveRunLine:(int)aInt
{
    runLine += aInt;
}

// REMOVED: -voidincRunColumn{
    runColumn++;
}

// REMOVED: -voidresetRunColumn{
    runColumn=0;
}

-(void)ty_labellog:(std::vector)argments
{
    labelLog = [ [ TYFileLog alloc ] initWithContentsOfFile:[ getNScrRootDirectory()  	stringByAppendingPathComponent:LABELLOG_FILENAME ] ];
    
}

-(void)ty_getversion:(std::vector)argments
{
    NSNumber *verNum;
    void* idno;
    verNum = [ TYEnviroment objectForKey:@"NScripterVersion" ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    [ scripterValues setIntValue:idno object:verNum ];
}

// zϐ̐錾
-(void)ty_dim:(std::vector)argments
{
    void* idno;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    [ scripterValues defineArrayValue:idno ];
}

-(void)ty_movl:(std::vector)argments
{
    void* idno;
    NSEnumerator *enu;
    std::vectorarray = [ NSMutableArray array ];
    void* tmp;
    
    enu = [ argments objectEnumerator ];
    [ enu nextObject ];
    
    idno = [ this getArrayIdOfArgment:[ enu nextObject ] ];
    
    while(tmp = [ enu nextObject ]){
        [ array addObject:[ this getValueOfArgment:tmp ] ];
    }
    
    [ scripterValues setArrayLine:idno values:array ];

}

//  ϐɑ
-(void)ty_mov:(std::vector)argments
{
    TYVarType type;
    void* arg;
    void* idno;

    type = [ [ argments objectAtIndex:1 ] varType ];
    
    // ϐID擾
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
        
    if(type == TYStringVarType){
        arg = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
        [ scripterValues setStringValue:idno object:arg ];
    } else if(type & TYDigitVarTypeMask) {
        arg = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
        [ scripterValues setIntValue:idno object:arg ];
    }
}

-(void)ty_mov3:(std::vector)argments
{
    [ this movRepeat:3 argments:(std::vector)argments ];
}

-(void)ty_mov4:(std::vector)argments
{
    [ this movRepeat:4 argments:(std::vector)argments ];
}

-(void)ty_mov5:(std::vector)argments
{
    [ this movRepeat:5 argments:(std::vector)argments ];
}

-(void)ty_mov6:(std::vector)argments
{
    [ this movRepeat:6 argments:(std::vector)argments ];
}

-(void)ty_mov7:(std::vector)argments
{
    [ this movRepeat:7 argments:(std::vector)argments ];
}

-(void)ty_mov8:(std::vector)argments
{
    [ this movRepeat:8 argments:(std::vector)argments ];
}

-(void)ty_mov9:(std::vector)argments
{
    [ this movRepeat:9 argments:(std::vector)argments ];
}

-(void)ty_mov10:(std::vector)argments
{
    [ this movRepeat:10 argments:(std::vector)argments ];
}

-(void)movRepeat:(int)repeat_times argments:(std::vector)argments
{
    TYVarType type;
    int i;
    int intId;
    NSEnumerator *enm;
    void* temp;

    enm = [ argments objectEnumerator ];
    [ enm nextObject ];

    temp = [ enm nextObject ];
    type = [ temp varType ];
    intId = [ [ this getIdNoOfArgment:temp ] intValue ];

    if(type & TYDigitVarTypeMask){
        for(i=0; i < repeat_times; i++,intId++){
            [ scripterValues setIntValue:[ NSNumber numberWithInt:intId ] object:[ this getValueOfArgment:[ enm nextObject ] ] ];
        }
    } else if(type == TYStringVarType) {
        for(i=0; i < repeat_times; i++,intId++){
            [ scripterValues setStringValue:[ NSNumber numberWithInt:intId ] object:[ this getStringOfArgment:[ enm nextObject ] ] ];
        }
    } else {
        NSLog(@"movX,error of arg 1,invalid context");
    }
}

-(void)ty_intlimit:(std::vector)argments
{
    [ scripterValues setIntLimitID:[ this getValueOfArgment:[ argments objectAtIndex:1 ] ]
                               low:[ this getValueOfArgment:[ argments objectAtIndex:2 ] ] 				      high:[ this getValueOfArgment:[ argments objectAtIndex:3 ] ] ];
}

// ϐ̃CNg
-(void)ty_inc:(std::vector)argments
{
    void* idno;
    NSNumber *number;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] +1 ];
    [ scripterValues setIntValue:idno object:number ];
    
}
// ϐ̃fNg
-(void)ty_dec:(std::vector)argments
{
    void* idno;
    NSNumber *number;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] -1 ]; 
    [ scripterValues setIntValue:idno object:number ];
    
}

// ϐ̑Z ȂA
-(void)ty_add:(std::vector)argments
{
    void* idno;
    NSNumber *number;
    NSNumber *argnum;
    std::stringstring;
    std::stringargstr;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    if( [ [ argments objectAtIndex:1 ] varType ] == TYStringVarType ){
        argstr = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
        string = [ scripterValues getStringValue:idno ];
        string = [ NSString stringWithFormat:@"%@%@",string,argstr ];
        [ scripterValues setStringValue:idno object:string ];
    } else {
        argnum = [ this getValueOfArgment:argments->objectAtIndex(2) ];
        number = [ scripterValues getIntValue:idno ];
        number = [ NSNumber numberWithInt:[ number intValue] +[ argnum intValue ] ];
        [ scripterValues setIntValue:idno object:number ];
    }
    
    return ;
}

// ϐ̈Z
-(void)ty_sub:(std::vector)argments
{
    void* idno;
    NSNumber *number;
    NSNumber *argnum;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] -[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_mul:(std::vector)argments
{
    void* idno;
    NSNumber *number;
    NSNumber *argnum;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] *[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_div:(std::vector)argments
{
    void* idno;
    NSNumber *number;
    NSNumber *argnum;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] /[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_mod:(std::vector)argments
{
    void* idno;
    NSNumber *number;
    NSNumber *argnum;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] % [ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_cmp:(std::vector)argments
{
    void* idno;
    int result;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    result = [ (std::string)[ this getStringOfArgment:[ argments objectAtIndex:2 ] ] compare: 
                [ this getStringOfArgment:[ argments objectAtIndex:3 ] ] ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];            
    
}

-(void)ty_atoi:(std::vector)argments
{
    void* idno;
    std::stringstr;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    str = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];

    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:[ str intValue ] ] ];
}

-(void)ty_itoa:(std::vector)argments
{
    void* idno;
    int value;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    value = [ [ this getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];

    [ scripterValues setStringValue:idno object:[ NSString stringWithFormat:@"%d",value ] ];
}

-(void)ty_len:(std::vector)argments
{
    void* idno;
    unsigned length;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    length = [ [ this getStringOfArgment:[ argments objectAtIndex:2 ] ] cSJISStringLength ];

    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:length ] ];
}

-(void)ty_mid:(std::vector)argments
{
    void* idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    std::stringinStr = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
    int offset = [ [ this getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    int length = [ [ this getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    
    [ scripterValues setStringValue:idno object:[ inStr substringSJISRange:NSMakeRange(offset,length) ] ];
}

-(void)ty_splitstring:(std::vector)argments
{
    std::stringscrStr;
    std::stringtmpStr;
    NSEnumerator *argEnu,*scrEnu;
    
    argEnu = [ argments objectEnumerator ];
    [ argEnu nextObject ];
    scrStr = [ [ argEnu nextObject ] stringObj ];
    scrEnu = [ [ scrStr componentsSeparatedByString:[ [ argEnu nextObject ] stringObj ] ] objectEnumerator ];
    while(tmpStr = [ scrEnu nextObject ]) {
        [ this ty_mov:[ NSMutableArray arrayWithObjects:@"mov",
                            [ argEnu nextObject ],
                            [ TYConstStringArgment argmentWithString:tmpStr ],nullptr ]  ];
    }
}

-(void)ty_rnd:(std::vector)argments
{
    void* idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    int max = [ [ this getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    int result;
    
    result = TYRandom(0,max -1);
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];
}

-(void)ty_rnd2:(std::vector)argments
{
    int min,max,result;
    void* idno;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    min = [ [ this getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    max = [ [ this getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];

    result = TYRandom(min,max);

    //NSLog(@"random,min=%d,max=%d,result=%d",min,max,result);
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];
}

-(void)ty_date:(std::vector)argments
{
    NSCalendarDate *cDate;
    void* idno;
    int d;

    cDate = [ NSCalendarDate calendarDate ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    d = [ cDate yearOfCommonEra ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    d = [ cDate monthOfYear ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:3 ] ];
    d = [ cDate dayOfMonth ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
}

-(void)ty_time:(std::vector)argments
{
    NSCalendarDate *cDate;
    void* idno;
    int d;

    cDate = [ NSCalendarDate calendarDate ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    d = [ cDate hourOfDay ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    d = [ cDate minuteOfHour ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:3 ] ];
    d = [ cDate secondOfMinute ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
}

// GCAX̓o^
-(void)ty_stralias:(std::vector)argments
{
    [ strAliases setObject: [ this getStringOfArgment:[ argments objectAtIndex:2 ] ] 
                forKey:[ [ argments objectAtIndex:1 ] lowercaseString ] ];
    return;
}

// GCAX̓o^
-(void)ty_numalias:(std::vector)argments
{
    [ numAliases setObject:[ this getValueOfArgment:[ argments objectAtIndex:2 ] ]
                forKey:[ [ argments objectAtIndex:1 ] lowercaseString ] ];
    return;
}

// A[JCoo^
-(void)ty_arc:(std::vector)argments
{
    [ [ TYResourceServer sharedServer ] addArchiver:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

// NSAA[JCuǂ
-(void)ty_nsa:(std::vector)argments
{
    int i;
    std::stringdir = ( nsaDir ) ? nsaDir : @"";

    [ [ TYResourceServer sharedServer ] addArchiver:
        [ dir stringByAppendingPathComponent:[ NSString stringWithFormat:DEFALUT_NSA_ARCHIVE,@"" ] ] ];

    for(i=1;i<=9;i++){
        [ [ TYResourceServer sharedServer ] addArchiver:
            [ dir stringByAppendingPathComponent:[ NSString stringWithFormat:DEFALUT_NSA_ARCHIVE,[ NSString stringWithFormat:@"%d",i ] ] ] ];
    }

}

-(void)ty_nsadir:(std::vector)argments
{
    nsaDir = [ [ this getStringOfArgment:[ argments objectAtIndex:1 ] ] retain ];
}

-(void)ty_ns2:(std::vector)argments
{
    [ TYNsaArchiver setMode:TY2TypeNsaFileMode ];
    [ this ty_nsa:nullptr ];
}

-(void)ty_ns3:(std::vector)argments
{
    [ TYNsaArchiver setMode:TY3TypeNsaFileMode ];
    [ this ty_nsa:nullptr ];
}

// EChE^Cg̕ύX
/*-(void)ty_caption:(std::vector)argments
{
    [ controller ty_caption:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    return;
}*/


// GtFNgo^
/*-(void)ty_effect:(std::vector)argments
{
    int count;
    NSNumber *effectNo=nullptr,*effectType=nullptr,*time=nullptr;
    std::stringpath=nullptr;
    
    count = [ argments count ];
    
    switch(count){
    case 5:
        path = [ this getStringOfArgment:[ argments objectAtIndex:4 ] ];
    case 4:
        time = [ this getValueOfArgment:[ argments objectAtIndex:3 ] ];
    case 3:
        effectType = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
        effectNo = [ this getValueOfArgment:[ argments objectAtIndex:1 ] ];
    }
    
    [ [ stageManager effecter ] setEffectNo:[ effectNo intValue ]
                                type:[ effectType intValue ]
                                time:[ time intValue ]
                                path:path ];
                                
}*/

/*-(void)ty_bg:(std::vector)argments
{
    NSNumber *effNo;
    
    effNo = [ this getEffectNoOfArgments:[ NSMutableArray arrayWithArray:
        [ argments subarrayWithRange:NSMakeRange(2,[ argments count]-2) ] ] ];

    [ stageManager ty_bg:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] effectNo:[ effNo intValue ] ];
}*/

/*-(void)ty_click:(std::vector)argments
{
    [ this setBreakRun:true ];
    [ controller ty_click ];
}*/


/*-(void)ty_wait:(std::vector)argments
{
    [ this setBreakRun:true ];
    [ controller setStatus:TYTimeWaitStatus ];
    [ this performSelector:@selector(runScript) withObject:nullptr afterDelay:
        [ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] / 10 ];
}*/

-(void)ty_jumpf:(std::vector)argments
{
    [ this labeljump:@"~" fromLine:runLine reverse:false ];
}

-(void)ty_jumpb:(std::vector)argments
{
    [ this labeljump:@"~" fromLine:runLine reverse:true ];
}

-(void)ty_goto:(std::vector)argments
{
    [ this labeljump:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

-(void)ty_gosub:(std::vector)argments
{
    TYScriptPoint sPoint;
    sPoint = TYMakeScriptPoint(runLine,runColumn);
    [ returnStack addObject:[ NSValue valueWithBytes:&sPoint objCType:@encode(TYScriptPoint) ] ];
    [ this labeljump:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

-(void)ty_return:(std::vector)argments
{
    TYScriptPoint sPoint;
    [ [ returnStack lastObject ] getValue:&sPoint ];
    [ this jump:sPoint.line ];
    runColumn = sPoint.column;
    [ returnStack removeLastObject ];
    
    // VXeJX^}CYAtextgosubŌĂ΂ꂽƂ납ԂȂ
    if((textgosubPointIndex > -1) &&
       (textgosubPointIndex == [ returnStack count ])){
       [ this setBreakRun:true ];
       [ stageManager resumePrinting ];
       textgosubPointIndex = -1;
    }
}

-(void)ty_tablegoto:(std::vector)argments
{
    int num=[ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    [ this ty_goto:[ NSMutableArray arrayWithObjects:@"goto",[ argments objectAtIndex:2+num ],nullptr ] ];
}

-(void)ty_skip:(std::vector)argments
{
    int step = [ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    if(step)
        runLine += step -1;
}

-(void)ty_next:(std::vector)argments
{
    TYLoopStruct loop;
    int now;

    NSAssert(([ loopStack count ] > 0),@"do next,but no loop stack");
    [ [ loopStack lastObject ] getValue:&loop ];

    now=[ [ scripterValues getIntValue:loop.varNo ] intValue ]+loop.step;
    [ scripterValues setIntValue:loop.varNo object:[ NSNumber numberWithInt:now ] ];

    if((loop.step>0 && now>loop.limit) || (loop.step<0 && now<loop.limit)){
        NSLog2(@"remove for stack");
        [ loopStack removeLastObject ];
    } else {
        runLine=loop.point.line;
        runColumn=loop.point.column;
        if(runColumn==0)
            runColumn++;
    }
}

-(void)ty_break:(std::vector)argments
{
    NSLog2(@"remove for stack");
    [ loopStack removeLastObject ];
    if([ argments count ] >= 2) {
        [ this ty_goto:argments ];
    } else
        [ this jumpToLoopEnd ];
}

-(void)ty_game:(std::vector)argments
{
    [ this labeljump:@"*start" ];
}

-(void)ty_resettimer:(std::vector)argments
{
    [ timerStartDate release ];
    timerStartDate = [ [ NSDate alloc ] init ];
}

-(void)ty_waittimer:(std::vector)argments
{
    int timerValue;
    NSTimeInterval interval=[ timerStartDate timeIntervalSinceNow ];
    NSTimeInterval delay;

    timerValue = [ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];

    delay = timerValue / 1000.0 +interval;
    if(delay < 0)
        delay = 0;

    [ this setBreakRun:true ];    

    [ this performSelector:@selector(runScript) withObject:nullptr afterDelay:
        timerValue / 1000.0 +[ timerStartDate timeIntervalSinceNow ] ];
}

-(void)ty_gettimer:(std::vector)argments
{
    void* idno;
    NSNumber *number;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    number = [ NSNumber numberWithInt:-[ timerStartDate timeIntervalSinceNow ] *1000 ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_loadgame:(std::vector)argments
{
    NSNumber *number;

    number = [ this getValueOfArgment:[ argments objectAtIndex:1 ] ];

    [ controller loadLocalData:number ];    
}

-(void)ty_savegame:(std::vector)argments
{
    NSNumber *number;

    number = [ this getValueOfArgment:[ argments objectAtIndex:1 ] ];

    [ controller saveLocalData:number ];
}

// vȌI
-(void)ty_end:(std::vector)argments
{
    // ݒ̃Z[u
    // O[oϐ̃Z[u
    [ NSApp terminate:this ];
}

-(void)ty_inputstr:(std::vector)argments
{
    void* idno;
    TYInputStrController *input;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    input = [ TYInputStrController dialog ];
    [ input runModalCaption:[ this getStringOfArgment:[ argments objectAtIndex:2 ] ]
                     length:[ [ this getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ]
                   notAscii:[ [ this getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ] ];

    [ scripterValues setStringValue:idno object:[ input string ] ];

}

-(void)ty_input:(std::vector)argments
{
    void* idno;
    TYInputStrController *input;

    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    input = [ TYInputStrController dialog ];
    [ input runModalCaption:[ this getStringOfArgment:[ argments objectAtIndex:2 ] ]
                 defaultStr:[ this getStringOfArgment:[ argments objectAtIndex:3 ] ]
                     length:[ [ this getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ]
                   notAscii:[ [ this getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ] ];

    [ scripterValues setStringValue:idno object:[ input string ] ];

}

-(void)ty_mesbox:(std::vector)argments
{
    NSRunInformationalAlertPanel([ this getStringOfArgment:[ argments objectAtIndex:2 ] ],[ this getStringOfArgment:[ argments objectAtIndex:1 ] ],@"OK",nullptr,nullptr);
    
}

-(void)ty_getreg:(std::vector)argments
{
    std::mapaDict=[ NSDictionary dictionaryWithContentsOfFile:[ getNScrRootDirectory() stringByAppendingPathComponent:REGISTRY_NAME ] ];
    std::stringkey;
    std::stringname;
    std::stringvalue;
    std::mapkeyDict;
    void* idno;

    key = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
    name = [ this getStringOfArgment:[ argments objectAtIndex:3 ] ];

    if((aDict)&&(keyDict = [ aDict objectForKey:key ])){
        value = [ keyDict objectForKey:name ];
        idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
        [ scripterValues setStringValue:idno object:value ];
    }
    
}

-(void)ty_getcursorpos:(std::vector)argments
{
    NSPoint point;
    void* varX,varY;
    
    varX = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    varY = [ this getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    
    point = [ stageManager drawPoint ];
    [ scripterValues setIntValue:varX object:[ NSNumber numberWithInt:point.x ] ];
    [ scripterValues setIntValue:varY object:[ NSNumber numberWithInt:VSCREEN_HEIGHT -point.y ] ];
}

-(void)ty_lr_trap:(std::vector)argments 
{
    [ this ty_trap:argments ];
}

-(void)ty_trap:(std::vector)argments
{
    std::stringarg=[ argments objectAtIndex:1 ];
    std::stringcarg = [ this getStringOfArgment:arg ];

    if([ arg compare:@"off" options:NSCaseInsensitiveSearch ]==NSOrderedSame){
        if(labelWithTrap)
            [ labelWithTrap release ];
        labelWithTrap=nullptr;
        fireOfTrap = false;
        [ controller setTrap:false ];
    } else if([ arg compare:@"stop" options:NSCaseInsensitiveSearch ]==NSOrderedSame){
        fireOfTrap = false;
        [ controller setTrap:false ];        
    } else if([ arg compare:@"resume" options:NSCaseInsensitiveSearch ]==NSOrderedSame){
        fireOfTrap = false;
        [ controller setTrap:true ];    
    } else {
        labelWithTrap=[ carg retain ];
        fireOfTrap = false;
        [ controller setTrap:true ];
    }
}

// REMOVED: -voidfireOfTrap{
    if(labelWithTrap)
        fireOfTrap=true;
}

-(void)fireOfTextgosub:(std::string)aLabel
{
    TYScriptPoint point;
    point = TYMakeScriptPoint(runLine,runColumn);
    [ this ty_gosub:[ NSMutableArray arrayWithObjects:@"gosub",aLabel,nullptr ] ];
    textgosubPointIndex = [ returnStack count ] -1;
    [ this runScript ];
}

// REMOVED: -voidenableKidoku{
    kidokuData=[ [ NSMutableData alloc ] initWithContentsOfFile:
        [ getNScrRootDirectory() stringByAppendingPathComponent:KIDOKU_FILENAME ] ];
    if(!kidokuData){
        kidokuData = [ [ NSMutableData alloc ] initWithLength:[ ScriptArray count ] / 8 +1 ];
    } else {
        if([ kidokuData length ] < [ ScriptArray count ] / 8 +1){
            [ kidokuData setLength:[ ScriptArray count ] / 8 +1 ];
        }
    }

    kidokuptr = (unsigned char*)[ kidokuData mutableBytes ];
}

-(void)setWatchKidoku:(bool)aBool
{
    isWatchKidoku = aBool;
}

// @end
