/*
 *  TYCCSProxy.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Proxy implementation for executable plugins.
 */

#ifndef TYCCSPROXY_QT_H
#define TYCCSPROXY_QT_H

#include "TYCCScripterProxy_qt.h"
#include <QObject>
#include <QString>

class TYCCSProxy : public QObject, public TYCCScripterProxy
{
    Q_OBJECT
    
public:
    // Singleton - replaces +(id)proxy
    static TYCCSProxy* proxy();
    
    // TYCCScripterProxy implementation
    QWindow* mainWindow() override;
    void setReturnCode(int code, const QString& str) override;
    int returnCode() const override { return m_returnCode; }
    QString returnString() const override { return m_returnString; }
    
signals:
    void returnCodeSet(int code, const QString& str);
    
private:
    TYCCSProxy(QObject* parent = nullptr);
    
    int m_returnCode;
    QString m_returnString;
    
    static TYCCSProxy* s_instance;
};

#endif // TYCCSPROXY_QT_H