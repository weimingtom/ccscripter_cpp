// Converted from TYBGMVolumeController.h
// TODO: Manual review and fixes required

/* TYBGMVolumeController */



class TYBGMVolumeController : public NSObject {
    IBOutlet NSSlider *BGMSlider;

    id delegate;
}
IBAction changeBGMVolume(id sender);;
IBAction dialogOK(id sender);;

id initWithBGMVolume(float volume);;
void setDelegate(id aObj);;
void showDialog();
void setBGMVolume(float volume);;
};
