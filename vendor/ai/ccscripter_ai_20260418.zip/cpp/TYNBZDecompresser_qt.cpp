/*
 *  TYNBZDecompresser.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYNBZDecompresser_qt.h"
#include <QFile>
#include <bzlib.h>
#include <cstdio>
#include <cstring>

// Static instance
static TYNBZDecompresser* s_sharedInstance = nullptr;

// Replaces: +(id)sharedObject
TYNBZDecompresser* TYNBZDecompresser::sharedInstance()
{
    if (!s_sharedInstance) {
        s_sharedInstance = new TYNBZDecompresser();
    }
    return s_sharedInstance;
}

/*
 * NBZ format:
 * +00h : DWORD(BE32) original size
 * +04h-: bzip -1 original_file
 */
 
// Replaces: -(NSData*)decodeDataWithFileHandle:(NSFileHandle*)handle length:(int)encode_size
QByteArray TYNBZDecompresser::decodeData(QFile& handle, int encodeSize)
{
    Q_UNUSED(encodeSize);
    
    // Read original size (4 bytes big-endian)
    QByteArray sizeData = handle.read(4);
    if (sizeData.size() < 4) {
        return QByteArray();
    }
    
    // Decode big-endian to host
    unsigned int decodeSize = (static_cast<unsigned char>(sizeData[0]) << 24) |
                              (static_cast<unsigned char>(sizeData[1]) << 16) |
                              (static_cast<unsigned char>(sizeData[2]) << 8) |
                              (static_cast<unsigned char>(sizeData[3]));
    
    // Open file descriptor for bzlib
    int fd = handle.handle();
    if (fd < 0) {
        return QByteArray();
    }
    
    FILE* fp = fdopen(fd, "r");
    if (!fp) {
        return QByteArray();
    }
    
    // Allocate output buffer
    QByteArray decodedData(decodeSize, 0);
    unsigned char* outPtr = reinterpret_cast<unsigned char*>(decodedData.data());
    unsigned char* outEnd = outPtr + decodeSize;
    
    // Bzip2 decompression
    unsigned char unused[BZ_MAX_UNUSED];
    int bzerr = BZ_OK;
    BZFILE* bzf = BZ2_bzReadOpen(&bzerr, fp, 0, 0, unused, 0);
    
    if (bzf == nullptr || bzerr != BZ_OK) {
        return QByteArray();
    }
    
    while (bzerr == BZ_OK) {
        if (outPtr >= outEnd) {
            break;
        }
        
        int nread = BZ2_bzRead(&bzerr, bzf, outPtr, 5000);
        if ((bzerr != BZ_OK && bzerr != BZ_STREAM_END) || nread <= 0) {
            break;
        }
        outPtr += nread;
    }
    
    BZ2_bzReadClose(&bzerr, bzf);
    
    if (bzerr != BZ_STREAM_END) {
        return QByteArray();
    }
    
    return decodedData;
}

// Replaces: -(NSBitmapImageRep*)decodeBitmapWithFileHandle:(NSFileHandle*)handle length:(int)encode_size
QImage TYNBZDecompresser::decodeBitmap(QFile& handle, int encodeSize)
{
    QByteArray data = decodeData(handle, encodeSize);
    if (data.isEmpty()) {
        return QImage();
    }
    
    QImage image;
    image.loadFromData(data);
    return image;
}