/*
 *  TY_NSStringAddition.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TY_NSStringAddition_qt.h"
#include <QTextCodec>
#include <cstring>

// For Shift-JIS encoding in Qt
static QTextCodec* s_sjisCodec = nullptr;

QTextCodec* getSJISCodec()
{
    if (!s_sjisCodec) {
        s_sjisCodec = QTextCodec::codecForName("Shift-JIS");
        if (!s_sjisCodec) {
            s_sjisCodec = QTextCodec::codecForLocale();
        }
    }
    return s_sjisCodec;
}

// Replaces: +(NSString*)stringWithCSJISString:(const char*)cString
QString TYStringUtils::stringWithCSJISString(const char* cString)
{
    if (!cString || !cString[0]) {
        return QString();
    }
    
    QTextCodec* codec = getSJISCodec();
    if (codec) {
        return codec->toUnicode(cString, strlen(cString));
    }
    return QString::fromLatin1(cString);
}

// Replaces: +(NSString*)stringWithCSJISString:(const char*)cString length:(unsigned int)aInt
QString TYStringUtils::stringWithCSJISString(const char* cString, unsigned int length)
{
    if (!cString || length == 0) {
        return QString();
    }
    
    QTextCodec* codec = getSJISCodec();
    if (codec) {
        return codec->toUnicode(cString, length);
    }
    return QString::fromLatin1(cString, length);
}

// Replaces: -(const char*)cSJISString
QByteArray TYStringUtils::toCSJISString(const QString& str)
{
    QTextCodec* codec = getSJISCodec();
    if (codec) {
        QByteArray result = codec->fromUnicode(str);
        result.append('\0');  // Add null terminator
        return result;
    }
    return str.toLatin1();
}

// Replaces: -(NSMutableData*)getCSJISData
QByteArray TYStringUtils::getCSJISData(const QString& str)
{
    QTextCodec* codec = getSJISCodec();
    if (codec) {
        QByteArray result = codec->fromUnicode(str);
        result.append('\0');  // Add null terminator
        return result;
    }
    return str.toLatin1() + '\0';
}

// Replaces: -(NSData*)sjisData
QByteArray TYStringUtils::toSJISData(const QString& str)
{
    QTextCodec* codec = getSJISCodec();
    if (codec) {
        return codec->fromUnicode(str);
    }
    return str.toLatin1();
}

// Replaces: -(unsigned)cSJISStringLength
unsigned int TYStringUtils::csjisStringLength(const QString& str)
{
    return toSJISData(str).size();
}

// Replaces: -(void)getCSJISString:(char *)buffer
void TYStringUtils::getCSJISString(const QString& str, char* buffer)
{
    QByteArray data = toCSJISString(str);
    std::memcpy(buffer, data.constData(), data.size());
    buffer[data.size() - 1] = '\0';  // Ensure null terminator
}

// Replaces: -(NSString*)substringSJISRange:(NSRange)range
QString TYStringUtils::substringSJISRange(const QString& str, int location, int length)
{
    QByteArray sjisData = toSJISData(str);
    
    // Clamp location to valid range
    if (location < 0 || location >= sjisData.size()) {
        return QString();
    }
    
    // Clamp length to available data
    int available = sjisData.size() - location;
    if (length > available) {
        length = available;
    }
    
    QTextCodec* codec = getSJISCodec();
    if (codec) {
        return codec->toUnicode(sjisData.constData() + location, length);
    }
    return QString::fromLatin1(sjisData.constData() + location, length);
}

// Replaces: NSString* getBackSlashString()
QString TYStringUtils::getBackSlashString()
{
    // Backslash in Shift-JIS is 0x5C
    char bs = 0x5C;
    QTextCodec* codec = getSJISCodec();
    if (codec) {
        return codec->toUnicode(&bs, 1);
    }
    return QStringLiteral("\\");
}

// TYNSString implementation

TYNSString TYNSString::fromCSJIS(const char* cString)
{
    return TYNSString(TYStringUtils::stringWithCSJISString(cString));
}

TYNSString TYNSString::fromCSJIS(const char* cString, int length)
{
    return TYNSString(TYStringUtils::stringWithCSJISString(cString, length));
}

QByteArray TYNSString::toCSJIS() const
{
    return TYStringUtils::toCSJISString(*this);
}

const char* TYNSString::cSJISString() const
{
    static QByteArray s_buffer;
    s_buffer = toCSJIS();
    return s_buffer.constData();
}

unsigned TYNSString::cSJISStringLength() const
{
    return TYStringUtils::csjisStringLength(*this);
}

void TYNSString::getCSJISString(char* buffer) const
{
    TYStringUtils::getCSJISString(*this, buffer);
}

TYNSString TYNSString::substringSJISRange(int location, int length) const
{
    return TYNSString(TYStringUtils::substringSJISRange(*this, location, length));
}