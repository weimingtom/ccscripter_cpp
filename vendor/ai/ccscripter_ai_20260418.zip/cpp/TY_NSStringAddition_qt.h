/*
 *  TY_NSStringAddition.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  String utilities for Shift-JIS (CS-JIS) encoding support.
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSString           -> QString
 *  NSData            -> QByteArray
 *  Category methods   -> Standalone functions
 */

#ifndef TY_NSSTRINGADDITION_QT_H
#define TY_NSSTRINGADDITION_QT_H

#include <QString>
#include <QByteArray>

// String encoding utilities
namespace TYStringUtils {
    
    // Replaces: +(NSString*)stringWithCSJISString:(const char*)cString
    QString stringWithCSJISString(const char* cString);
    
    // Replaces: +(NSString*)stringWithCSJISString:(const char*)cString length:(unsigned int)aInt
    QString stringWithCSJISString(const char* cString, unsigned int length);
    
    // Replaces: -(const char*)cSJISString
    QByteArray toCSJISString(const QString& str);
    
    // Replaces: -(NSMutableData*)getCSJISData
    QByteArray getCSJISData(const QString& str);
    
    // Replaces: -(NSData*)sjisData
    QByteArray toSJISData(const QString& str);
    
    // Replaces: -(unsigned)cSJISStringLength
    unsigned int csjisStringLength(const QString& str);
    
    // Replaces: -(void)getCSJISString:(char *)buffer
    void getCSJISString(const QString& str, char* buffer);
    
    // Replaces: -(NSString*)substringSJISRange:(NSRange)range
    QString substringSJISRange(const QString& str, int location, int length);
    
    // Get backslash string in Shift-JIS
    QString getBackSlashString();
}

// Helper class for NSString-like interface
class TYNSString : public QString
{
public:
    // Construct from CS-JIS encoded string
    static TYNSString fromCSJIS(const char* cString);
    static TYNSString fromCSJIS(const char* cString, int length);
    
    // Convert to CS-JIS
    QByteArray toCSJIS() const;
    QByteArray getCSJISData() const { return toCSJIS(); }
    QByteArray toSJISData() const { return toCSJIS(); }
    const char* cSJISString() const;
    unsigned cSJISStringLength() const;
    void getCSJISString(char* buffer) const;
    
    // Substring with SJIS byte range
    TYNSString substringSJISRange(int location, int length) const;
};

#endif // TY_NSSTRINGADDITION_QT_H