/*
 *  TYArgmentArray.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Parses NScripter script line arguments.
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSMutableArray*   -> QVariantList / QStringList
 *  NSData*           -> QByteArray
 *  NSInvocation       -> Qt method call or QMetaObject
 */

#ifndef TYARGMENTARRAY_QT_H
#define TYARGMENTARRAY_QT_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QByteArray>
#include <QVariant>
#include <QVariantList>

// Parse modes
enum TYParseMode {
    TYParseModeNormal = 0,
    TYParseModeCondition,
    TYParseModeLoop
};

// Argument contexts
enum TYArgContext {
    TYNoArgContext = -1,
    TYUndefinedArgContext,
    TYOperandArgContext,
    TYStringArgContext,
    TYIntergerArgContext,
    TYSeparaterArgContext,
    TYChainArgContext
};

// Script argument parser class
class TYArgmentArray : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: +(id)arrayWithCString:(char*)aCStr command:(char*)cmdCStr
    static TYArgmentArray* arrayWithCString(const char* str, const char* cmd);
    
    // Replaces: -(id)initWithCString:(char*)aCStr command:(char*)cmdCStr
    TYArgmentArray(const char* str, const char* cmd, QObject* parent = nullptr);
    ~TYArgmentArray();
    
    // Replaces: -(void)setParseMode:(TYParseMode)mode
    void setParseMode(TYParseMode mode);
    
    // Parse the arguments
    void parse();
    
    // Access arguments (acts like array)
    QVariant at(int index) const;
    int count() const;
    QVariantList arguments() const { return m_arguments; }
    
    // Operators for array-like access
    QVariant operator[](int index) const { return at(index); }
    
signals:
    void parsed();
    
private:
    void initWithCString(const char* str, const char* cmd);
    
    // Parser helper functions
    int getItem(const char** ptr, char* buffer);
    int getVarArg(const char** ptr, char* buffer);
    void spaceSkip(const char** ptr);
    TYArgContext detectContext(const char* ptr);
    
    QStringList m_arguments;  // Replaces: NSMutableArray *parsedArgments
    bool m_isParsed;         // Replaces: BOOL isParsed
    TYParseMode m_parseMode; // Replaces: TYParseMode parseMode
    QByteArray m_sourceData; // Replaces: NSData *sourceData
};

// Character classification helpers (replaces macros)
namespace TYCharUtils {
    inline bool isDigit(char c) { return c >= '0' && c <= '9'; }
    inline bool isHexDigit(char c) { return isDigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
    inline bool isAlpha(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_'; }
    inline bool isAlnum(char c) { return isDigit(c) || isAlpha(c); }
    inline bool isOperator(char c) { return c == '!' || c == '<' || c == '>' || c == '='; }
}

#endif // TYARGMENTARRAY_QT_H