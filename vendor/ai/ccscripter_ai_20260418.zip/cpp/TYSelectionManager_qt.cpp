/*
 *  TYSelectionManager.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYSelectionManager_qt.h"

TYSelectionManager::TYSelectionManager(TYStageManager* manager, QObject* parent)
    : TYRespondRectManager(manager, parent)
{
}

TYSelectionManager::~TYSelectionManager()
{
}

void TYSelectionManager::initialButtonImage()
{
    // Override to initialize selection button images
}

bool TYSelectionManager::changeSelection(int index)
{
    return TYRespondRectManager::changeSelection(index);
}