/*
 *  TYAnimationCellImage.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Animation cell image - handles animated image sequences.
 *  Note: Actual image handling requires QtWidgets integration.
 */

#ifndef TYANIMATIONCELLIMAGE_QT_H
#define TYANIMATIONCELLIMAGE_QT_H

#include <QObject>
#include <QString>
#include <QVariant>
#include <QTimer>

// Animation modes
enum TYAnimationMode {
    TYAnimationLoopingPlayback = 0,
    TYAnimationNormalPlayback,
    TYAnimationLoopingBackAndForthPlayback,
    TYAnimationNoPlay
};

// Animation info dictionary keys
extern const QString TYAnimationModeInfo;
extern const QString TYAnimationIntervalInfo;

class TYAnimationCellImage : public QObject
{
    Q_OBJECT
    
public:
    // Constructor
    TYAnimationCellImage(const QVariantList& images, const QVariantMap& infoDict, QObject* parent = nullptr);
    ~TYAnimationCellImage();
    
    // Delegate
    void setDelegate(QObject* delegate) { m_delegate = delegate; }
    
    // Cell control
    void changeCell(int index);
    int currentCell() const { return m_currentCell; }
    int cells() const { return m_images.size(); }
    
    // Animation state
    bool isPlaying() const { return m_isPlaying; }
    bool isAnimate() const { return m_mode != TYAnimationNoPlay; }
    
    // Animation control
    void play();
    void stop();
    void resume();
    
signals:
    void cellChanged(int index);
    void animationFinished();
    
private slots:
    void changingCell();
    void setNextTimer();
    
private:
    void advanceCell();
    
    QVariantList m_images;
    QObject* m_delegate;
    QVariant m_interval;  // Can be int or QVariantList
    TYAnimationMode m_mode;
    bool m_isPlaying;
    bool m_intervalIsArray;
    bool m_back;
    int m_currentCell;
    QTimer* m_timer;
};

#endif // TYANIMATIONCELLIMAGE_QT_H