/*
 *  TYScriptEngine.cpp
 *  Tukuyomi
 *
 *  Converted to Qt framework
 */

#include "TYScriptEngine_qt.h"
#include "TYFileLog_qt.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>

// Exception constants
const QString TYNScriptRunTimeErrorException = QStringLiteral("TYNScriptRunTimeErrorException");
const QString TYNScriptSyntaxErrorException = QStringLiteral("TYNScriptSyntaxErrorException");

// Static instance
TYScriptEngine* TYScriptEngine::s_instance = nullptr;

TYScriptEngine::TYScriptEngine(QObject* parent)
    : QObject(parent)
    , m_breakRun(false)
    , m_scripterValues(nullptr)
    , m_globalOn(false)
    , m_labelLog(nullptr)
    , m_fireOfTrap(false)
    , m_isSVGA(false)
    , m_globalValue(0)
    , m_runLine(0)
    , m_runColumn(0)
{
    m_scripterValues = new TYScripterValues(this);
}

TYScriptEngine* TYScriptEngine::sharedEngine()
{
    if (!s_instance) {
        s_instance = new TYScriptEngine();
    }
    return s_instance;
}

bool TYScriptEngine::initWithContentsOfFile(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    
    QTextStream in(&file);
    in.setCodec("Shift-JIS");
    
    m_scriptArray.clear();
    m_labelDict.clear();
    
    // Read all lines
    int lineNum = 0;
    while (!in.atEnd()) {
        QString line = in.readLine();
        m_scriptArray.append(line);
        
        // Check for labels
        if (line.trimmed().endsWith(":")) {
            QString label = line.trimmed().left(line.length() - 1);
            m_labelDict.insert(label, lineNum);
        }
        
        lineNum++;
    }
    
    file.close();
    return true;
}

void TYScriptEngine::runScript()
{
    if (m_scriptArray.isEmpty()) {
        return;
    }
    
    m_breakRun = false;
    
    while (m_runLine < m_scriptArray.size() && !m_breakRun) {
        QString line = m_scriptArray[m_runLine];
        
        // Parse and execute line
        // Simplified - full implementation would parse commands
        
        m_runLine++;
    }
    
    emit scriptFinished();
}

bool TYScriptEngine::eval(const QStringList& arguments)
{
    if (arguments.isEmpty()) {
        return false;
    }
    
    QString cmd = arguments[0].toLower();
    
    // Simplified command dispatch
    // Full implementation would handle all NScripter commands
    
    Q_UNUSED(cmd);
    return true;
}

void TYScriptEngine::lineEnd()
{
    emit lineEnded();
}

void TYScriptEngine::jump(unsigned target)
{
    m_runLine = target;
}

void TYScriptEngine::labelJump(const QString& label)
{
    if (m_labelDict.contains(label)) {
        m_runLine = m_labelDict.value(label);
    }
}

void TYScriptEngine::labelJump(const QString& label, int fromLine, bool reverse)
{
    Q_UNUSED(fromLine);
    Q_UNUSED(reverse);
    labelJump(label);
}

void TYScriptEngine::jumpToLoopEnd()
{
    // Pop loop stack and jump to end
    if (!m_loopStack.isEmpty()) {
        TYLoopStruct loop = m_loopStack.pop();
        m_runLine = loop.point.line;
    }
}

void TYScriptEngine::saveExternalData()
{
    // Save global values
    QString savePath = getNScrRootDirectory() + "/" + GLOBAL_SAVEFILE_NAME;
    m_scripterValues->saveGlobalValues(savePath);
}

void TYScriptEngine::moveRunLine(int delta)
{
    m_runLine += delta;
}

void TYScriptEngine::incRunColumn()
{
    m_runColumn++;
}

void TYScriptEngine::resetRunColumn()
{
    m_runColumn = 0;
}

void TYScriptEngine::registerLoop(const QString& currentChars)
{
    Q_UNUSED(currentChars);
    // Would parse for/next loop parameters
}

void TYScriptEngine::registerLoopTargetId(const QVariant& varId, const QVariant& initVal,
                                        const QVariant& limitVal, const QVariant& stepVal)
{
    TYScriptPoint point = { static_cast<unsigned>(m_runLine), m_runColumn };
    TYLoopStruct loop = TYMakeLoopStruct(point, varId, limitVal.toInt(), stepVal.toInt());
    m_loopStack.push(loop);
}

int TYScriptEngine::splitArgNormal(const QString& currentChars, QStringList& cmdArray)
{
    // Simplified argument splitting
    cmdArray = currentChars.split(' ', Qt::SkipEmptyParts);
    return cmdArray.size();
}

int TYScriptEngine::splitArgCondition(const QString& currentChars, bool trueFlag)
{
    Q_UNUSED(currentChars);
    Q_UNUSED(trueFlag);
    return 0;
}

bool TYScriptEngine::isMultLineSupport(const QString& command) const
{
    static QStringList multiLineCmds = {"select", "selnum", "selgosub", "csel"};
    return multiLineCmds.contains(command.toLower());
}

QString TYScriptEngine::nextLine()
{
    if (m_runLine < m_scriptArray.size()) {
        return m_scriptArray[m_runLine++];
    }
    return QString();
}

QVariant TYScriptEngine::getIdNoOfArgment(const QString& argment)
{
    // Parse variable reference from argument
    // e.g., "%1" -> 1
    if (argment.startsWith("%")) {
        bool ok;
        int id = argment.mid(1).toInt(&ok);
        if (ok) return QVariant(id);
    }
    return QVariant();
}

QVariant TYScriptEngine::getArrayIdOfArgment(const QString& argment)
{
    Q_UNUSED(argment);
    return QVariant();
}

QVariant TYScriptEngine::getValueOfArgment(const QString& argment)
{
    // Get variable value
    QVariant varId = getIdNoOfArgment(argment);
    if (varId.isValid()) {
        return m_scripterValues->getIntValue(varId);
    }
    
    // Try as literal number
    bool ok;
    int val = argment.toInt(&ok);
    if (ok) return QVariant(val);
    
    return QVariant();
}

QString TYScriptEngine::getStringOfArgment(const QString& argment)
{
    if (argment.startsWith("$")) {
        QVariant varId = argment.mid(1).toInt();
        return m_scripterValues->getStringValue(varId);
    }
    return argment;
}

int TYScriptEngine::getEffectNoOfArgments(const QStringList& argments)
{
    Q_UNUSED(argments);
    return 0;
}

QString TYScriptEngine::stringOfReplaceVars(const QString& str)
{
    QString result = str;
    
    // Replace %N with variable values
    // Replace $N with string values
    
    return result;
}

bool TYScriptEngine::judgefchk(const QString& file)
{
    if (m_labelLog) {
        return m_labelLog->isRead(file);
    }
    
    QFileInfo info(getNScrRootDirectory() + "/" + file);
    return info.exists();
}

bool TYScriptEngine::judgelchk(const QString& label)
{
    return m_labelDict.contains(label);
}

bool TYScriptEngine::judgeCondition(const QString& condition, bool stringMode)
{
    Q_UNUSED(condition);
    Q_UNUSED(stringMode);
    return false;
}

void TYScriptEngine::addLabelLog(const QString& str)
{
    if (m_labelLog) {
        m_labelLog->addLog(str);
    }
}

QVariant TYScriptEngine::intNumberWithVarId(const QVariant& varId)
{
    return m_scripterValues->getIntValue(varId);
}

QString TYScriptEngine::stringValueWithVarId(const QVariant& varId)
{
    return m_scripterValues->getStringValue(varId);
}

QVariant TYScriptEngine::intNumberWithAlias(const QString& alias)
{
    if (m_numAliases.contains(alias)) {
        return intNumberWithVarId(m_numAliases.value(alias));
    }
    return QVariant();
}

QString TYScriptEngine::stringValueWithAlias(const QString& alias)
{
    if (m_strAliases.contains(alias)) {
        return stringValueWithVarId(m_strAliases.value(alias));
    }
    return QString();
}

void TYScriptEngine::enableKidoku()
{
    // Enable read history tracking
}

void TYScriptEngine::setWatchKidoku(bool enable)
{
    Q_UNUSED(enable);
}

void TYScriptEngine::resetGame()
{
    // Reset game state
    m_runLine = 0;
    m_runColumn = 0;
    m_loopStack.clear();
    m_returnStack.clear();
}

// TYSaveDataCoding implementation
QVariant TYScriptEngine::encodeWithSaveData() const
{
    QVariantMap data;
    data["runLine"] = m_runLine;
    data["runColumn"] = m_runColumn;
    // Add more state as needed
    return data;
}

void TYScriptEngine::decodeWithSaveData(const QVariant& data)
{
    Q_UNUSED(data);
    // Load state from saved data
}