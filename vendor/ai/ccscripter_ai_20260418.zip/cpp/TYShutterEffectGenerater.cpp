// Converted from TYShutterEffectGenerater.m
// TODO: Manual review and fixes required

//
//  TYShutterEffectGenerater.m
//  Tukuyomi
//
//  Created by toveta on Sat Dec 01 2001.
//  Copyright (c) 2001 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN false EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "TYShutterEffectGenerater.h"
#include "TYStageManager.h"

#define PIXEL_OF_COLUMN 16

// @implementation TYShutterEffectGenerater
-(void*)initWithBeforeImage:(NSImage*)befImage afterImage:(NSImage*)atImage effect:(TYEffectDefinitionValue*)effect
{
    TYEffectDefinition effdef;
    
    this = [ super init ];
    
    [ effect getValue:&effdef ];
    switch(effdef.type){
    case TYEffectTopShutter:
        reverse = true;
        break;
    case TYEffectRightShutter:
        reverse = true;
    case TYEffectLeftShutter:
        horizontal = true;
        break;
    default:
        break;
    }

    phaseInterval = effdef.time / 1000.0 / PIXEL_OF_COLUMN;
    time = effdef.time;
    numberOfColumn = ((horizontal) ? VSCREEN_WIDTH : VSCREEN_HEIGHT ) / PIXEL_OF_COLUMN; 
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    afterImage = [ atImage copyWithZone:[ atImage zone ] ];
    nowImage = [ befImage copyWithZone:[ befImage zone ] ];
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
    
} // override

// REMOVED: -voiddrawEffect{
    int x,y,w,h,mx,my;
    int phase,movePhase;
    int i;
    
    // oߎԂsNZPʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *PIXEL_OF_COLUMN;
    if(phase >= PIXEL_OF_COLUMN){
        [ this changeEffectionImage:afterImage ];
        [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
        return;
    }
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];

    movePhase = phase -beforePhase;
    // ܂A肦ȂƂ͎vB
    if(movePhase==0){
        return;
    }

    if(horizontal){
        w = movePhase;
        h = VSCREEN_HEIGHT;
        y = 0;
        my = 0;
        x = (reverse) ? VSCREEN_WIDTH -beforePhase -w : beforePhase;
        mx = (reverse) ? -PIXEL_OF_COLUMN : PIXEL_OF_COLUMN;
    } else {
        w = VSCREEN_WIDTH;
        h = movePhase;
        x = 0;
        mx =0;
        y = (reverse) ? VSCREEN_HEIGHT -beforePhase -h : beforePhase;
        my = (reverse) ? -PIXEL_OF_COLUMN : PIXEL_OF_COLUMN;
    }
    
    [ nowImage lockFocus ];
    for(i=0; i < numberOfColumn; i++,x+=mx,y+=my){
        [ afterImage compositeToPoint:NSMakePoint(x,y) fromRect:NSMakeRect(x,y,w,h) operation:NSCompositeCopy ];
    }
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];

    beforePhase = phase;
    
    return ;
} // override

// -dealloc (destructor in C++)
~ClassName() {
    [ startDate release ];
    [super dealloc];
}

// @end
