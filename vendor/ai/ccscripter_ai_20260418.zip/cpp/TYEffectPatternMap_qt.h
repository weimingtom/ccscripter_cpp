/*
 *  TYEffectPatternMap.h
 *  Tukuyomi
 *
 *  Converted to Qt framework
 *
 *  Converts bitmap image to pattern map for effects.
 *
 *  Objective-C (Cocoa) -> Qt conversion mapping:
 *  ----------------------------------------
 *  NSObject           -> QObject
 *  NSMutableData      -> QByteArray
 *  NSBitmapImageRep*  -> QImage
 */

#ifndef TYEFFECTPATTERNMAP_QT_H
#define TYEFFECTPATTERNMAP_QT_H

#include <QObject>
#include <QByteArray>
#include <QImage>
#include <cstdint>

class TYEffectPatternMap : public QObject
{
    Q_OBJECT
    
public:
    // Replaces: -(id)initWithBitmap:(NSBitmapImageRep*)bitmap
    explicit TYEffectPatternMap(const QImage& bitmap, QObject* parent = nullptr);
    ~TYEffectPatternMap();
    
    // Replaces: -(const unsigned char*)patternMapData
    const uint8_t* patternMapData() const;
    
    // Replaces: -(unsigned int)pixelsWide
    uint32_t pixelsWide() const { return m_pixelsWide; }
    
    // Replaces: -(unsigned int)pixelsHigh
    uint32_t pixelsHigh() const { return m_pixelsHigh; }
    
private:
    QByteArray m_mapData;   // Replaces: NSMutableData *mapData
    uint32_t m_pixelsWide;  // Replaces: unsigned int pixelsWide
    uint32_t m_pixelsHigh;  // Replaces: unsigned int pixelsHigh
};

#endif // TYEFFECTPATTERNMAP_QT_H