#include "TY-NSStringAddition.h"

// Converted from Objective-C

const char* TY-NSStringAddition::cSJISString()
{
    {
    char nullbyte = '\0';
    NSData *data;
    NSMutableData *mdata;
    data = [ this dataUsingEncoding:NSShiftJISStringEncoding ];
    mdata = [ NSMutableData dataWithData:data ];
    [ mdata appendBytes:&nullbyte length:1 ];
    return [ mdata bytes ];
    
}

NSMutableData* TY-NSStringAddition::getCSJISData()
{
    {
    char nullbyte = '\0';
    NSData *data;
    NSMutableData *mdata;
    data = [ this dataUsingEncoding:NSShiftJISStringEncoding ];
    mdata = [ NSMutableData dataWithData:data ];
    [ mdata appendBytes:&nullbyte length:1 ];
    
    return mdata;
    
}

NSData* TY-NSStringAddition::sjisData()
{
    {
    return [ this dataUsingEncoding:NSShiftJISStringEncoding ];
    
}

unsigned TY-NSStringAddition::cSJISStringLength()
{
    {
    return [ [ this dataUsingEncoding:NSShiftJISStringEncoding ] length ];
    
}

void TY-NSStringAddition::getCSJISString:()
{
    {
    NSData *data;
    data = [ this dataUsingEncoding:NSShiftJISStringEncoding ];
    [ data getBytes:buffer ];
    *(buffer +[ data length ]) = '\0';
    
}

NSString* TY-NSStringAddition::substringSJISRange:()
{
    {
    NSData *scrData;
    NSMutableData *dstData;
    const char *ptr;
    int strLength;
    
    scrData = [ this sjisData ];
    ptr = [ scrData bytes ];
    
    ptr += range.location;
    strLength = [ scrData length ] -range.location;
    // g̒𒴂lw肳ꂽ؂߂
    if(range.length > strLength)
    range.length = strLength;
    
    dstData = [ NSMutableData dataWithBytes:ptr length:range.length ];
    return [ [ [ NSString alloc ] initWithData:dstData encoding:NSShiftJISStringEncoding ] autorelease ];
    
    
    NSString* getBackSlashString()
    {
    char b = '\\';
    
    return [ [ [ NSString alloc ] initWithData:[ NSData dataWithBytes:&b length:1 ] encoding:NSShiftJISStringEncoding ] autorelease ];
    
}

