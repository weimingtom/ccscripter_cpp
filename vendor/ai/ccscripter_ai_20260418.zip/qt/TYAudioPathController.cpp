#include "TYAudioPathController.h"

// Converted from Objective-C

IBAction TYAudioPathController::dialogOk:()
{
    {
    NSString *path;
    NSString *fn;
    NSScanner *scanner;
    
    fn = [ filename stringValue ];
    if([ fn length ]==0){
    NSBeep();
    [ errorField setStringValue:NSLocalizedString(QString::fromUtf8("Please be sure to input a file name."),"file name is blank") ];
    return;
    
    scanner = [ NSScanner scannerWithString:fn ];
    [ scanner scanUpToString:QString::fromUtf8("*") intoString:NULL ];
    if([ scanner isAtEnd ]){
    NSBeep();
    [ errorField setStringValue:NSLocalizedString(QString::fromUtf8("An asterisk is required for a file name."),"") ];
    return;
    
    path = [ [ directory stringValue ] stringByAppendingPathComponent:fn ];
    
    [ this changeAudioPath:path ];
    [ window orderOut:this ];
    
}

IBAction TYAudioPathController::dialogCancel:()
{
    {
    [ window orderOut:this ];
    
}

IBAction TYAudioPathController::restoreDefault:()
{
    {
    NSString *dir,*file;
    
    dir = [ defaultPath stringByDeletingLastPathComponent ];
    file = [ defaultPath lastPathComponent ];
    
    [ directory setStringValue:dir ];
    [ filename setStringValue:file ];
    
}

IBAction TYAudioPathController::selectDirectory:()
{
    {
    int stat;
    NSOpenPanel *op = [ NSOpenPanel openPanel ];
    
    [ op setCanChooseDirectories:true ];
    [ op setCanChooseFiles:false ];
    
    
    stat = [ op runModalForDirectory:[ directory stringValue ]
    file:nullptr
    types:nullptr ];
    
    if(stat==NSOKButton){
    [ directory setStringValue:[ op filename ] ];
    
}

void TYAudioPathController::openWithPath:()
{
    {
    defaultPath = [ defPath retain ];
    initPath = [ aPath retain ];
    
    [ directory setStringValue:[ initPath stringByDeletingLastPathComponent ] ];
    [ filename setStringValue:[ initPath lastPathComponent ] ];
    
    [ window orderFront:this ];
    
}

void TYAudioPathController::setDelegate:()
{
    {
    delegate = aObject;
    
    // delegate implementation
}

void TYAudioPathController::changeAudioPath:()
{
    {
    if(delegate)
    [ delegate changeAudioPath:aPath ];
    
}

void TYAudioPathController::dealloc()
{
    {
    defaultPath->release();
    initPath->release();
    super->dealloc();
    
    
}

