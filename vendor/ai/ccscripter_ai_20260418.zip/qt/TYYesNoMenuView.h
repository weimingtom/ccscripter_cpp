#ifndef TYYESNOMENUVIEW_H
#define TYYESNOMENUVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYYesNoMenuView : public TYMenuModeView
{
    Q_OBJECT
public:
    QObject* initWithFrame:();
};

#endif // TYYESNOMENUVIEW_H
