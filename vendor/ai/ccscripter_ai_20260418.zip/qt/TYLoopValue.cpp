#include "TYLoopValue.h"

// Converted from Objective-C

QObject* TYLoopValue::initWithStruct:()
{
    {
    this = [ super init ];
    
    [ loop.varNo retain ];
    
    value = [ [ NSValue alloc ] initWithBytes:&loop objCType:@encode(TYLoopStruct) ];
    
    return this;
    
}

void TYLoopValue::forwardInvocation:()
{
    {
    SEL sel = [ anInvocation selector ];
    if([ value respondsToSelector:sel ])
    [ anInvocation invokeWithTarget:value ];
    else
    [ this doesNotRecognizeSelector:sel ];
    
}

NSMethodSignature * TYLoopValue::methodSignatureForSelector:()
{
    {
    if([ super respondsToSelector:aSelector ])
    return [ super methodSignatureForSelector:aSelector ];
    return [ value methodSignatureForSelector:aSelector ];
    
    
}

void TYLoopValue::dealloc()
{
    {
    TYLoopStruct loop;
    
    [ value getValue:&loop ];
    [ loop.varNo release ];
    
    value->release();
    super->dealloc();
    
    
    
}

