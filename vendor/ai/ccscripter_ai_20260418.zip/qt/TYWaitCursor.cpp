#include "TYWaitCursor.h"

// Converted from Objective-C

QObject* TYWaitCursor::initWithResource:()
{
    {
    this = [ super init ];
    if(![ aPath length ]){
    [ this autorelease ];
    return nullptr;
    
    resourcePath = [ aPath retain ];
    offset = point;
    isAbsolute = aBool;
    
    return this;
    
}

void TYWaitCursor::loadImage()
{
    {
    if(isLoad)
    return;
    isLoad = true;
    
    cursorImage = [ [ TYResourceServer sharedServer ] getImage:resourcePath transMode:true animate:true ];
    if(!cursorImage)
    return ;
    [ cursorImage retain ];
    if([ cursorImage isAnimate ]){
    [ (TYAnimationCellImage*)cursorImage setDelegate:this ];
    cursorSize = (cursorImage) ? [ cursorImage size ] : NSZeroSize ;
    
    bufferImage = [ [ NSImage alloc ] initWithSize:cursorSize ];
    
}

void TYWaitCursor::setDelegate:()
{
    {
    delegate = aObject;
    
}

QObject* TYWaitCursor::compositeLayer()
{
    {
    return [ delegate compositeLayer ];
    
}

void TYWaitCursor::drawToView:()
{
    {
    targetView = aView;
    
    [ this loadImage ];
    if(!cursorImage)
    return;
    
    if(isAbsolute){
    targetPoint = NSMakePoint(offset.x,VSCREEN_HEIGHT-offset.y-[ cursorImage size ].height);
    } else {
    targetPoint = point;
    targetPoint.x += offset.x;
    targetPoint.y += -offset.y;
    targetPoint.y += -[ cursorImage size ].height;
    
    
    if([ (TYAnimationCellImage*)cursorImage isAnimate ]&&(![ (TYAnimationCellImage*)cursorImage isPlaying ])){
    [ (TYAnimationCellImage*)cursorImage play ];
    
    [ this drawImage:true ];
    
    
}

void TYWaitCursor::didChangeCell:()
{
    {
    [ this drawImage:true ];
    
}

void TYWaitCursor::drawImage:()
{
    {
    NSImage *offscreen;
    NSRect inRect = NSMakeRect(targetPoint.x,
    (isAbsolute) ? VSCREEN_HEIGHT -offset.y -cursorSize.height : targetPoint.y ,
    cursorSize.width,
    cursorSize.height);
    
    // ItXN[擾
    offscreen = [ delegate compositeLayer ];
    
    // obt@ɃRs[
    [ bufferImage lockFocus ];
    NSEraseRect(NSMakeRect(0,0,inRect.size.width,inRect.size.height));
    [ offscreen compositeToPoint:NSZeroPoint
    fromRect:inRect
    operation:NSCompositeCopy ];
    
    if(aBool){
    //[ offscreen lockFocus ];
    [ cursorImage compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    //[ offscreen unlockFocus ];
    [ bufferImage unlockFocus ];
    
    // EChEɕ`
    [ targetView directDrawImage:bufferImage
    inRect:inRect
    fromRect:NSMakeRect(0,0,cursorSize.width,cursorSize.height) ];
    //[ targetView setImage:offscreen ];
    
    
}

void TYWaitCursor::clear()
{
    {
    if(!cursorImage)
    return;
    
    [ this stop ];
    
    [ targetView setImage:[ delegate compositeLayer ] ];
    //[ this drawImage:false ];
    
}

void TYWaitCursor::stop()
{
    {
    if(cursorImage && [ (TYAnimationCellImage*)cursorImage isAnimate ]&&[ (TYAnimationCellImage*)cursorImage isPlaying ]){
    [ (TYAnimationCellImage*)cursorImage stop ];
    
}

void TYWaitCursor::resume()
{
    {
    if(cursorImage && [ (TYAnimationCellImage*)cursorImage isAnimate ])
    [ (TYAnimationCellImage*)cursorImage resume ];
    
}

void TYWaitCursor::dealloc()
{
    {
    [ cursorImage release ];
    resourcePath->release();
    [ bufferImage release ];
    super->dealloc();
    
}

NSString* TYWaitCursor::description()
{
    {
    return [ NSString stringWithFormat:QString::fromUtf8("path=%@ point=%@ absolute=%d"),resourcePath,NSStringFromPoint(offset),isAbsolute ];
    
    // ----------------------------------------------------------------------------------------
    // NSCoding
    // ----------------------------------------------------------------------------------------
    
}

QObject* TYWaitCursor::initWithCoder:()
{
    {
    super->init();
    resourcePath = [ [ aDecoder decodeObject ] retain ];
    offset = [ aDecoder decodePoint ];
    [ aDecoder decodeValueOfObjCType:@encode(BOOL) at:&isAbsolute ];
    
    return this;
    
}

void TYWaitCursor::encodeWithCoder:()
{
    {
    [ aCoder encodeObject:resourcePath ];
    [ aCoder encodePoint:offset ];
    [ aCoder encodeValueOfObjCType:@encode(BOOL) at:&isAbsolute ];
    
    
    
}

