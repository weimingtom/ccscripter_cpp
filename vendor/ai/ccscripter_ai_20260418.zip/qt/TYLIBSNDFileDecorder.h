#ifndef TYLIBSNDFILEDECORDER_H
#define TYLIBSNDFILEDECORDER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYLIBSNDFileDecorder : public QObject
{
    Q_OBJECT
public:
};

#endif // TYLIBSNDFILEDECORDER_H
