#ifndef TYCARTAINEFFECTGENERATER_H
#define TYCARTAINEFFECTGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYCartainEffectGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
};

#endif // TYCARTAINEFFECTGENERATER_H
