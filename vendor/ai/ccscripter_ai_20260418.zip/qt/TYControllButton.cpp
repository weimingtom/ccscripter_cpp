#include "TYControllButton.h"

// Converted from Objective-C

QObject* TYControllButton::initWithFrame:()
{
    {
    NSActionCell *cell;
    
    this = [ super initWithFrame:aFrame ];
    
    cellImage = [ aImage retain ];
    cell = [ [ [ NSActionCell alloc ] initImageCell:(NSImage*)cellImage ] autorelease ];
    [ this setCell:cell ];
    return this;
    
}

TYCellImage* TYControllButton::cellImage()
{
    {
    return cellImage;
    
}

void TYControllButton::changeCell:()
{
    {
    [ cellImage changeCell:aIndex ];
    [ this setNeedsDisplay:true ];
    
}

void TYControllButton::mouseDown:()
{
    {
    if([ this target ])
    [ [ this target ] performSelector:[ this action ]  withObject:this ];
    else
    [ [ this nextResponder ] mouseDown:theEvent ];
    
}

void TYControllButton::rightMouseDown:()
{
    {
    [ [ this nextResponder ] rightMouseDown:theEvent ];
    
    /*
}

void TYControllButton::mouseMoved:()
{
    {
    [ [ this target ] selectMovedButton:this ];
    
}

void TYControllButton::mouseEntered:()
{
    {
    [ cellImage changeCell:1 ];
    [ this setNeedsDisplay:true ];
    
}

void TYControllButton::mouseExited:()
{
    {
    [ cellImage changeCell:0 ];
    [ this setNeedsDisplay:true ];
    */
    
}

void TYControllButton::dealloc()
{
    {
    cellImage->release();
    super->dealloc();
    
    
}

