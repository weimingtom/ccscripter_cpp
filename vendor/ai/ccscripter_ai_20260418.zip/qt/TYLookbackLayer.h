#ifndef TYLOOKBACKLAYER_H
#define TYLOOKBACKLAYER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYLookbackLayer : public TYNovelLayer
{
    Q_OBJECT
public:
    QObject* initWithStrings:();
    void setAttribute:(void value);
};

#endif // TYLOOKBACKLAYER_H
