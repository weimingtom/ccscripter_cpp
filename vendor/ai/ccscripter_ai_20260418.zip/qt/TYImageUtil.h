#ifndef TYIMAGEUTIL_H
#define TYIMAGEUTIL_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class NSImage : public QWidget
{
    Q_OBJECT
public:
    void convertMonocroWithSample:();
    void monocro:();
    void nega();
    NSArray* horizontalDivide:();
    void resizeToPixelsSize();
};

#endif // TYIMAGEUTIL_H
