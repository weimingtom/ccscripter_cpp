#ifndef TYSCRIPTDATA_H
#define TYSCRIPTDATA_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYScriptData : public QObject
{
    Q_OBJECT
public:
    QObject* initWithDirectory:();
    QObject* initWithTextFiles:();
    QObject* initWithEncodingFile:();
    int lineOfLabel();
    int lineOfInstantLabelWithNowLine:();
    QObject* stringAtIndex:();
    QObject* dataAtIndex:();
};

#endif // TYSCRIPTDATA_H
