#include "TYArgmentArray.h"

// Converted from Objective-C

QObject* TYArgmentArray::initWithCString:()
{
    {
    [ super init ];
    
    sourceData = [ [ NSData alloc ] initWithBytes:aCStr length:strlen(aCStr) ];
    parsedArgments = [ [ NSMutableArray alloc ] initWithObjects:[ NSString stringWithCString:cmdCStr ],nullptr ];
    
    return this;
    
    // p[X[h͊Ow肷
}

void TYArgmentArray::setParseMode:()
{
    {
    parseMode = mode;
    
}

void TYArgmentArray::parse()
{
    {
    isParsed = true;
    
    switch(parseMode) {
    case TYParseModeNormal:
    case TYParseModeCondition:
    case TYParseModeLoop:
    break;
    
}

QObject* TYArgmentArray::objectAtIndex:()
{
    {
    if((aIndex!=0)&&(!isParsed)){
    [ this parse ];
    return [ parsedArgments objectAtIndex:aIndex ];
    
}

void TYArgmentArray::forwardInvocation:()
{
    {
    SEL sel = [ anInvocation selector ];
    if([ parsedArgments respondsToSelector:sel ]) {
    // ͂IĂȂΉ͂sȂ
    if(!isParsed)
    [ this parse ];
    [ anInvocation invokeWithTarget:parsedArgments ];
    } else
    [ this doesNotRecognizeSelector:sel ];
    
}

NSMethodSignature * TYArgmentArray::methodSignatureForSelector:()
{
    {
    if([ super respondsToSelector:aSelector ])
    return [ super methodSignatureForSelector:aSelector ];
    return [ parsedArgments methodSignatureForSelector:aSelector ];
    
}

void TYArgmentArray::dealloc()
{
    {
    parsedArgments->release();
    sourceData->release();
    super->dealloc();
    
    
    
}

