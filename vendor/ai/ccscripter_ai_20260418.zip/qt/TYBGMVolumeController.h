#ifndef TYBGMVOLUMECONTROLLER_H
#define TYBGMVOLUMECONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYBGMVolumeController : public QObject
{
    Q_OBJECT
public:
    IBAction changeBGMVolume:();
    IBAction dialogOK:();
    QObject* initWithBGMVolume:();
    void setDelegate:(void value);
    void showDialog();
    void setBGMVolume:(void value);
};

#endif // TYBGMVOLUMECONTROLLER_H
