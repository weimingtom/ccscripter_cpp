#include "TYSaveLoadManager.h"

// Converted from Objective-C

QObject* TYSaveLoadManager::init()
{
    {
    this = [ super init ];
    
    [ this setNames:[ NSArray arrayWithObjects:NSLocalizedString(QString::fromUtf8("<SAVE>"),nullptr),
    NSLocalizedString(QString::fromUtf8("<LOAD>"),nullptr),
    NSLocalizedString(QString::fromUtf8("bookmark"),nullptr),nullptr ] ];
    
    return this;
    
}

void TYSaveLoadManager::setNames:()
{
    {
    if(names)
    [ names release ];
    
    names = [ aArray retain ];
    
}

NSArray* TYSaveLoadManager::names()
{
    {
    return names;
    
}

void TYSaveLoadManager::setNumber:()
{
    {
    int i;
    
    dataNum = number;
    if(bookmarkArray)
    [ bookmarkArray release ];
    if(existsArray)
    [ existsArray release ];
    
    bookmarkArray = [ [ NSMutableArray array ] retain ];
    existsArray = [ [ NSMutableArray array ] retain ];
    
    for(i = 0; i < number; i++){
    [ bookmarkArray addObject:[ NSNull null ] ];
    [ existsArray addObject:[ NSNull null ] ];
    
}

int TYSaveLoadManager::number()
{
    {
    return dataNum;
    
}

void TYSaveLoadManager::resetDateWithNumber:()
{
    {
    NSString *filename,*path;
    NSString *bookMarkBase = [ names objectAtIndex:2 ];
    NSString *bookMark;
    NSFileManager *manager = [ NSFileManager defaultManager ];
    BOOL exists;
    
    if(dataNum < number || number <= 0)
    return;
    
    filename = [ NSString stringWithFormat:SAVEDATA_NAME,number ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
    
    bookMark = [ bookMarkBase stringByAppendingString:TYWideCharDecimalString(number) ];
    if(number < 10)
    bookMark = [ bookMark stringByAppendingString:NSLocalizedString(QString::fromUtf8("WSPACE"),nullptr) ];
    bookMark = [ bookMark stringByAppendingString:NSLocalizedString(QString::fromUtf8("WSPACE"),nullptr) ];
    
    exists = [ manager fileExistsAtPath:path ];
    if(!exists){
    bookMark = [ bookMark stringByAppendingString:
    NSLocalizedString(QString::fromUtf8("NScrNoSaveDataDate"),nullptr) ];
    } else {
    NSDate *aDate;
    NSArray *calArray;
    NSString *dateStr;
    
    aDate = [ [ manager fileAttributesAtPath:path traverseLink:false ] objectForKey:NSFileModificationDate ];
    
    dateStr = [ aDate descriptionWithCalendarFormat:QString::fromUtf8("%m,%d,%H,%M") timeZone:nullptr locale:nullptr ];
    calArray = [ dateStr componentsSeparatedByString:QString::fromUtf8(",") ];
    bookMark = [ bookMark stringByAppendingString:
    [ NSString stringWithFormat:
    NSLocalizedString(QString::fromUtf8("NScrSaveDateFormat"),nullptr),
    TYWideCharDecimalStringWithString([ calArray objectAtIndex:0 ]),
    TYWideCharDecimalStringWithString([ calArray objectAtIndex:1 ]),
    TYWideCharDecimalStringWithString([ calArray objectAtIndex:2 ]),
    TYWideCharDecimalStringWithString([ calArray objectAtIndex:3 ])
    ] ];
    
    [ bookmarkArray replaceObjectAtIndex:number -1 withObject:bookMark ];
    [ existsArray replaceObjectAtIndex:number -1 withObject:[ NSNumber numberWithBool:exists ] ];
    
}

void TYSaveLoadManager::dataLoad()
{
    {
    int i;
    
    if(!loaded){
    loaded = true;
    // Loadされていなければセーブデータファイルを検索
    for(i=1; i <= dataNum; i++){
    [ this resetDateWithNumber:i ];
    
}

NSArray* TYSaveLoadManager::dateStrings:()
{
    {
    NSString *strTitle;
    
    strTitle = [ names objectAtIndex:(isLoad) ? 1 : 0 ];
    
    [ this dataLoad ];
    
    return [ [ NSArray arrayWithObject:strTitle ] arrayByAddingObjectsFromArray:bookmarkArray ];
    
}

NSArray* TYSaveLoadManager::existsArray()
{
    {
    return existsArray;
    
}

void TYSaveLoadManager::dealloc()
{
    {
    names->release();
    bookmarkArray->release();
    existsArray->release();
    super->dealloc();
    
    
}

