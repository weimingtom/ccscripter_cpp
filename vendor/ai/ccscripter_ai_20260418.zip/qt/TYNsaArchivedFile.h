#ifndef TYNSAARCHIVEDFILE_H
#define TYNSAARCHIVEDFILE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYNsaArchivedFile : public TYSarArchivedFile
{
    Q_OBJECT
public:
    QObject* initFileoffset:();
    unsigned compressType();
    unsigned expandedLength();
};

#endif // TYNSAARCHIVEDFILE_H
