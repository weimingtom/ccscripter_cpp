#include "TYCrossFadeGenerater.h"

// Converted from Objective-C

QObject* TYCrossFadeGenerater::initWithBeforeImage:()
{
    {
    TYEffectDefinition effdef;
    
    this = [ super init ];
    
    [ effect getValue:&effdef ];
    phaseInterval = effdef.time / 1000.0 / 256.0;
    time = effdef.time;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    afterImage = [ atImage copyWithZone:[ atImage zone ] ];
    /*
    if(afterImage)
    [ afterImage retain ];
    */
    
    beforeBitmap = [ [ NSBitmapImageRep alloc ] initWithData:[ befImage TIFFRepresentation ] ];
    if(!beforeBitmap){
    beforeBitmap = blankBitmap(VSCREEN_WIDTH,VSCREEN_HEIGHT);
    [ beforeBitmap retain ];
    afterBitmap = [ [ NSBitmapImageRep alloc ] initWithData:[ atImage TIFFRepresentation ] ];
    if(!afterBitmap){
    afterBitmap = blankBitmap(VSCREEN_WIDTH,VSCREEN_HEIGHT);
    [ afterBitmap retain ];
    nowImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    nowBitmapptr = malloc(VSCREEN_WIDTH *VSCREEN_HEIGHT *3);
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
    
    // private method
}

void TYCrossFadeGenerater::drawEffect()
{
    {
    int pixel = VSCREEN_WIDTH *VSCREEN_HEIGHT;
    unsigned char *src,*dst,*now;
    int spps,sppd,sppn;
    int i;
    int phase;
    // oߎԂ256PʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *256;
    if(phase >= 256){
    // GtFNgI
    [ this changeEffectionImage:afterImage ];
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    return;
    } else {
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];
    dst = [ beforeBitmap bitmapData ];
    sppd = [ beforeBitmap samplesPerPixel ];
    src = [ afterBitmap bitmapData ];
    spps = [ afterBitmap samplesPerPixel ];
    now = (unsigned char*)nowBitmapptr;
    sppn =3;
    for(i=0; i < pixel; i++,src+=spps,dst+=sppd,now+=sppn){
    now[0] = (src[0] *phase + dst[0] * ( 0xFF - phase )) >> 8;
    now[1] = (src[1] *phase + dst[1] * ( 0xFF - phase )) >> 8;
    now[2] = (src[2] *phase + dst[2] * ( 0xFF - phase )) >> 8;
    
    [ nowImage lockFocus ];
    
    NSDrawBitmap(TYVirtualScreenRect(),VSCREEN_WIDTH,VSCREEN_HEIGHT,8,3,24,VSCREEN_WIDTH *3,false,false,NSCalibratedRGBColorSpace,&nowBitmapptr);
    
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    } // override
    
}

void TYCrossFadeGenerater::dealloc()
{
    {
    [ startDate release ];
    beforeBitmap->release();
    afterBitmap->release();
    if(nowBitmapptr)
    free((unsigned char*)nowBitmapptr);
    super->dealloc();
    
    
}

