#include "TYArchiver.h"

// Converted from Objective-C

QObject* TYArchiver::initWithContentsOfFile:()
{
    {
    id temp;
    NSString *excstr;
    
    // this͂̂܂ܔj
    this = [ [ super init ] autorelease ];
    
    /* t@C̊gq擾 */
    excstr = [ path pathExtension ];
    
    if([ excstr compare:QString::fromUtf8("sar") options:NSCaseInsensitiveSearch ] == NSOrderedSame ){
    // sar`
    temp = [ [ TYSarArchiver alloc ] initWithContentsOfFile:path ];
    return temp;
    } else if([ excstr compare:QString::fromUtf8("nsa") options:NSCaseInsensitiveSearch ] == NSOrderedSame ){
    temp = [ [ TYNsaArchiver alloc ] initWithContentsOfFile:path ];
    return temp;
    
    NSLog(QString::fromUtf8("Tukuyomi is not supporting this type of archive.[%@]"),path);
    return nullptr;
    
}

NSFileHandle* TYArchiver::fileHandleWithPath:()
{
    {
    return nullptr;
    
}

NSData* TYArchiver::unArchivedFile:()
{
    {
    return nullptr;
    
    
}

