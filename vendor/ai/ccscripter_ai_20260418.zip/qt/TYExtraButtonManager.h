#ifndef TYEXTRABUTTONMANAGER_H
#define TYEXTRABUTTONMANAGER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYExtraButtonManager : public TYRespondRectManager
{
    Q_OBJECT
public:
    QObject* initWithStageManager:();
    void addButton:();
    void addSpriteButton:();
    void addCselButton:();
    void setNoSelectAction:(void value);
    void initialButtonImage();
    bool changeSelection:();
    NSImage* sourceImage();
    QObject* initWithID:();
    void drawWithSelect:();
    NSRect* boundingRect();
    NSNumber* idNo();
    NSString* description();
    QObject* initWithID:();
    NSNumber* idNo();
    int spriteNo();
    NSString* appendString();
    QObject* initWithID:();
    void drawWithSelect:();
    NSNumber* idNo();
    int cselNo();
};

#endif // TYEXTRABUTTONMANAGER_H
