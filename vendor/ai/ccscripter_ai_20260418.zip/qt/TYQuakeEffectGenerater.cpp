#include "TYQuakeEffectGenerater.h"

// Converted from Objective-C

QObject* TYQuakeEffectGenerater::initWithImage:()
{
    {
    this = [ super init ];
    
    afterImage = image;
    if(afterImage)
    [ afterImage retain ];
    
    quakeType = type;
    if(quakeType==TYQuakeTypeHorizontal){
    horizontal=true;
    quakeTimes = times;
    quakeSecond = second;
    timeOfShake = quakeSecond / quakeTimes;
    timeOfQuarter = timeOfShake >> 2;
    
    
    unionImage = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH +SHAKE_SIZE *times *horizontal *2,VSCREEN_HEIGHT +SHAKE_SIZE *times *(!(horizontal)) *2 ) ];
    nowImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    [ unionImage lockFocus ];
    [ [ NSColor blackColor ] set ];
    NSRectFill( NSMakeRect(0,0,VSCREEN_WIDTH+SHAKE_SIZE *quakeTimes *2,VSCREEN_HEIGHT+SHAKE_SIZE *quakeTimes *2));
    [ afterImage compositeToPoint:NSMakePoint(SHAKE_SIZE *times *horizontal,SHAKE_SIZE *times *(!(horizontal))) operation:NSCompositeCopy ];
    [ unionImage unlockFocus ];
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    startDate = [ [ NSDate date ] retain ];
    
    return this;
    
}

void TYQuakeEffectGenerater::drawEffect()
{
    {
    int restTime;
    int shakeLevel;
    int shakeQuarter;
    int x,y,*mp;
    int phaseOfQuarter;
    
    restTime = quakeSecond +[ startDate timeIntervalSinceNow ] *1000;
    shakeLevel = restTime / timeOfShake +1;
    if(restTime <= 0){
    [ this changeEffectionImage:afterImage ];
    [ this performSelector:@selector(quakeFinished) withObject:nullptr afterDelay:0 ];
    return;
    
    if(horizontal){
    mp = &x;
    y=0;
    } else {
    mp = &y;
    x=0;
    *mp = SHAKE_SIZE *quakeTimes;
    
    phaseOfQuarter = restTime % (timeOfQuarter);
    shakeQuarter = ( restTime / (timeOfQuarter) ) % 4;
    // P񕪂̗hꎞԂ4āAǂ̎_߂B
    switch(shakeQuarter){
    case 1:
    *mp += SHAKE_SIZE *shakeLevel *phaseOfQuarter /timeOfQuarter ;
    break;
    case 2:
    *mp += SHAKE_SIZE *shakeLevel *(timeOfQuarter-phaseOfQuarter) /timeOfQuarter;
    break;
    case 3:
    *mp -= SHAKE_SIZE *shakeLevel *phaseOfQuarter /timeOfQuarter;
    break;
    case 0:
    *mp -= SHAKE_SIZE *shakeLevel *(timeOfQuarter -phaseOfQuarter) /timeOfQuarter;
    break;
    
    [ nowImage lockFocus ];
    [ unionImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(x,y,VSCREEN_WIDTH,VSCREEN_HEIGHT) operation:NSCompositeCopy ];
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
}

void TYQuakeEffectGenerater::dealloc()
{
    {
    [ startDate release ];
    [ unionImage release ];
    super->dealloc();
    
    
    @implementation TYEffectGenerater (TYQuakeExtension)
}

void TYQuakeEffectGenerater::quakeFinished()
{
    if(delegate){
    if([ delegate respondsToSelector:@selector(quakeFinished) ]){
    [ delegate quakeFinished ];
    ;
}

