#ifndef TYWAVEDECORDER_H
#define TYWAVEDECORDER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // TYWAVEDECORDER_H
