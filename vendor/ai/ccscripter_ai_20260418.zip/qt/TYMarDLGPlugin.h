#ifndef TYMARDLGPLUGIN_H
#define TYMARDLGPLUGIN_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYMarDLGPlugin : public QObject
{
    Q_OBJECT
public:
    IBAction dialogOK:();
    IBAction dialogCancel:();
};

#endif // TYMARDLGPLUGIN_H
