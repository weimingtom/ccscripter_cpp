#ifndef TY_NSDATAADDTION_H
#define TY_NSDATAADDTION_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class NSData : public QWidget
{
    Q_OBJECT
public:
    int getBitAtIndex:();
    void setBit:(void value);
    void XORMaskToAllBytes:();
    void clearAllBytes();
};

#endif // TY_NSDATAADDTION_H
