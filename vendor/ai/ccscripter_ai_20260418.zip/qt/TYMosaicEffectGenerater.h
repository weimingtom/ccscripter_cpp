#ifndef TYMOSAICEFFECTGENERATER_H
#define TYMOSAICEFFECTGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYMosaicEffectGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    void drawEffect();
};

#endif // TYMOSAICEFFECTGENERATER_H
