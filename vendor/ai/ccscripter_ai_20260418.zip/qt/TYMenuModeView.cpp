#include "TYMenuModeView.h"

// Converted from Objective-C

QObject* TYMenuModeView::initWithFrame:()
{
    {
    // 初期化
    this = super->initWithFrame(aFrame];
    if (!this)
    return nullptr;
    
    return this;
    
}

void TYMenuModeView::setController:()
{
    buttonArray:(id)bArray
    actionArray:(id)aArray
    bgColor:(NSColor*)aColor
    {
    controller = aObj;
    
    selectedButton = nullptr;
    
    btnArray = [ bArray retain ];
    
    actArray = [ aArray retain ];
    
    menuWindowColor = [ aColor retain ];
    
}

IBAction TYMenuModeView::execButton:()
{
    {
    [ this select_action ];
    
}

void TYMenuModeView::drawRect:()
{
    // Drawing code here.
    [ menuWindowColor set ];
    NSRectFillUsingOperation(rect,NSCompositeSourceOver);
    
}

void TYMenuModeView::updatesTrackingRect()
{
    {
    NSEnumerator *enu;
    TYControllButton *temp;
    NSTrackingRectTag tag;
    
    if(btnDict)
    [ this removeAllTrackingRect ];
    
    btnDict = [ [ NSMutableDictionary dictionary ] retain ];
    enu = [ btnArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
    tag = [ this addTrackingRect:[ temp frame ] owner:this userData:nullptr assumeInside:false ];
    [ btnDict setObject:temp forKey:[ NSNumber numberWithInt:tag ] ];
    
}

void TYMenuModeView::removeAllTrackingRect()
{
    {
    NSEnumerator *enu;
    NSNumber *temp;
    
    if(!btnDict)
    return;
    
    if(selectedButton != nullptr) {
    [ selectedButton changeCell:0 ];
    [ selectedButton setNeedsDisplay:true ];
    
    selectedButton = nullptr;
    
    enu = [ btnDict keyEnumerator ];
    while(temp = [ enu nextObject ]){
    [ this removeTrackingRect:[ temp intValue ] ];
    
    [ btnDict release ];
    btnDict = nullptr;
    
}

void TYMenuModeView::setButtonArray:()
{
    {
    if(btnArray)
    [ btnArray autorelease ];
    btnArray = [ aArray retain ];
    
}

void TYMenuModeView::setActionArray:()
{
    {
    if(actArray)
    [ actArray autorelease ];
    actArray = [ aArray retain ];
    
}

bool TYMenuModeView::acceptsFirstResponder()
{
    {
    return true;
    
}

void TYMenuModeView::mouseEntered:()
{
    {
    TYControllButton *btn;
    int no;
    
    no = [ theEvent trackingNumber ];
    btn = [ btnDict objectForKey:[ NSNumber numberWithInt:no ] ];
    [ btn changeCell:1 ];
    [ btn setNeedsDisplay:true ];
    
    if(selectedButton && (btn != selectedButton)){
    [ selectedButton changeCell:0 ];
    
    selectedButton = btn;
    
}

void TYMenuModeView::mouseExited:()
{
    {
    TYControllButton *btn;
    int no;
    
    no = [ theEvent trackingNumber ];
    btn = [ btnDict objectForKey:[ NSNumber numberWithInt:no ] ];
    [ btn changeCell:0 ];
    [ btn setNeedsDisplay:true ];
    
    if(selectedButton == btn)
    selectedButton = nullptr;
    
}

void TYMenuModeView::mouseMoved:()
{
    {
    ;
    
}

void TYMenuModeView::mouseDown:()
{
    {
    ;
    
}

void TYMenuModeView::keyDown:()
{
    {
    [ this performSelector:TYSelectorForKeycode([ theEvent keyCode ]) withObject:nullptr ];
    
}

void TYMenuModeView::scrollWheel:()
{
    {
    if([ theEvent deltaY ] > 0.0){
    [ this up_action ];
    } else {
    [ this down_action ];
    
    
}

void TYMenuModeView::down_action()
{
    {
    TYControllButton *btn;
    int idx;
    
    idx = (selectedButton == nullptr) ? -1 : [ btnArray indexOfObject:selectedButton ];
    
    if((idx == [ btnArray count ] -1) || idx == -1){
    btn = [ btnArray objectAtIndex:0 ];
    } else {
    btn = [ btnArray objectAtIndex:idx +1 ];
    
    if(selectedButton != btn){
    [ selectedButton changeCell:0 ];
    [ selectedButton setNeedsDisplay:true ];
    [ btn changeCell:1 ];
    [ btn setNeedsDisplay:true ];
    selectedButton = btn;
    
}

void TYMenuModeView::rightMouseDown:()
{
    {
    [ this cancel_action:nullptr ];
    
}

void TYMenuModeView::select_action()
{
    {
    int idx;
    
    if(!selectedButton)
    return;
    
    idx = [ btnArray indexOfObject:selectedButton ];
    [ this endMode ];
    [ controller ty_systemcall:[ NSMutableArray arrayWithObjects:QString::fromUtf8("systemcall"),[ actArray objectAtIndex:idx ] ,nullptr ] ];
    
}

void TYMenuModeView::cancel_action:()
{
    {
    /*
    [ controller exitSystemModeResumeStatus:true ];
    [ this removeFromSuperview ];
    */
    [ this endMode ];
    
}

void TYMenuModeView::up_action()
{
    {
    TYControllButton *btn;
    int idx;
    
    idx = (selectedButton == nullptr) ? -1 : [ btnArray indexOfObject:selectedButton ];
    
    if(idx == 0 || idx == -1){
    btn = [ btnArray lastObject ];
    } else {
    btn = [ btnArray objectAtIndex:idx -1 ];
    
    if(selectedButton != btn){
    [ selectedButton changeCell:0 ];
    [ selectedButton setNeedsDisplay:true ];
    [ btn changeCell:1 ];
    [ btn setNeedsDisplay:true ];
    selectedButton = btn;
    
}

void TYMenuModeView::endMode()
{
    {
    [ [ this window ] makeFirstResponder:[ this superview ] ];
    [ this removeAllTrackingRect ];
    [ controller exitSystemModeResumeStatus:true ];
    [ [ this retain ] autorelease ];
    [ this removeFromSuperview ];
    
}

void TYMenuModeView::dealloc()
{
    {
    menuWindowColor->release();
    btnDict->release();
    btnArray->release();
    actArray->release();
    super->dealloc();
    
    
}

