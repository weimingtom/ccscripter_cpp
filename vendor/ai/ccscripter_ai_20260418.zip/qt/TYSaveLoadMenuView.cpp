#include "TYSaveLoadMenuView.h"

// Converted from Objective-C

QObject* TYSaveLoadMenuView::initWithFrame:()
{
    controller:(id)aObj
    layout:(NSMutableDictionary*)layoutDict
    attributes:aDict
    dateStrArray:(NSArray*)dArray
    existsArray:(NSArray*)eArray
    doLoad:(BOOL)doLoad
    {
    int fontWidth;
    int fontHeight;
    int pitchX;
    int pitchY;
    BOOL shadow;
    
    int y,cnt,tag,idx;
    NSEnumerator *denu,*eenu;
    NSString* temp;
    TYCellImage *image;
    NSRect frame;
    NSSize size;
    TYControllButton *button;
    NSArray *buttonColor;
    NSMutableArray *buttonArray;
    NSMutableArray *actionArray;
    NSColor *menuColor;
    
    buttonArray = [ NSMutableArray array ];
    actionArray = [ NSMutableArray array ];
    
    // 初期化
    this = super->initWithFrame(aFrame ];
    
    if (!this)
    return nullptr;
    
    // メニューレイアウトの読み込み
    {
    size = [ [ layoutDict objectForKey:TYRMenuFontSize ] sizeValue ];
    fontWidth = size.width;
    fontHeight = size.height;
    
    size = [ [ layoutDict objectForKey:TYRMenuFontPitchSize ] sizeValue ];
    pitchX = size.width;
    pitchY = size.height;
    
    shadow = [ [ layoutDict objectForKey:TYRMenuShadowed ] boolValue ];
    
    menuColor = [ layoutDict objectForKey:TYRMenuBGColor ];
    
    buttonColor = [ NSArray arrayWithObjects:
    [ layoutDict objectForKey:TYRMenuNoSelectColor ],
    [ layoutDict objectForKey:TYRMenuSelectColor ],nullptr ];
    
    cnt = [ dArray count ];
    denu = [ dArray objectEnumerator ];
    eenu = [ eArray objectEnumerator ];
    
    // 1行目の位置取得。
    y = VSCREEN_HEIGHT -(VSCREEN_HEIGHT + (-fontHeight -pitchY) *(cnt -1)) /2;
    
    tag = 0;
    idx = 0;
    while(temp = [ denu nextObject ]) {
    NSPoint origin;
    NSArray *color;
    NSNumber *existsNum;
    
    if(idx != 0)
    existsNum = [ eenu nextObject ];
    
    if(idx == 0)
    color = [ NSArray arrayWithObject:[ layoutDict objectForKey:TYRMenuSelectColor ] ];
    else if(doLoad && ![ existsNum boolValue ])
    color = [ NSArray arrayWithObject:[ layoutDict objectForKey:TYRMenuNoDataColor ] ];
    else
    color = buttonColor;
    
    // イメージ生成
    image = [ [ TYCellImage alloc ] initWithImages:
    [ TYStringImage imagesWithString:temp
    attributes:aDict
    colors:color
    fontHeight:fontHeight
    fontWidth:fontWidth
    interval:pitchX
    shadow:shadow ] ];
    [ image autorelease ];
    
    // button生成。
    size = [ (NSImage*)image size ];
    frame = NSMakeRect((VSCREEN_WIDTH -size.width) / 2,
    y,size.width,size.height);
    origin = [ (TYStringImage*)image origin ];
    frame.origin.x += origin.x;
    frame.origin.y += origin.y;
    [ (NSArray*)image makeObjectsPerformSelector:@selector(setOriginByValue:)
    withObject:[ NSValue valueWithPoint:NSZeroPoint ] ];
    
    
    button = [ [ [ TYControllButton alloc ] initWithFrame:frame cellImage:image ] autorelease ];
    if(idx != 0 && (!doLoad || [ existsNum boolValue ])){
    [ button setTarget:this ];
    [ button setAction:@selector(execButton:) ];
    [ button setTag:tag++ ];
    [ buttonArray addObject:button ];
    [ actionArray addObject:[ NSString stringWithFormat:
    (doLoad) ? QString::fromUtf8("_qload%d") : QString::fromUtf8("_qsave%d") ,idx ] ];
    
    [ this addSubview:button ];
    
    y -= fontHeight +pitchY;
    idx++;
    
    // 初期化完了
    setController(aObj
    buttonArray:buttonArray
    actionArray:actionArray
    bgColor:menuColor ];
    
    return this;
    
    
    
}

