#ifndef TYNOVELLAYER_H
#define TYNOVELLAYER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYNovelLayer : public QObject
{
    Q_OBJECT
public:
    QObject* initNovelLayer();
    void setManager:(void value);
    void pushAttributedString:();
    void pushNewLine();
    TYLookbackLayer* lookbackObject();
    NSArray* stringArray();
    NSArray* voiceArray();
    NSString* getText();
    void drawImage();
};

#endif // TYNOVELLAYER_H
