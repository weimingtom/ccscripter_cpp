#ifndef TYEFFECTPATTERNMAP_H
#define TYEFFECTPATTERNMAP_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYEffectPatternMap : public QObject
{
    Q_OBJECT
public:
    QObject* initWithBitmap:();
    const unsigned char* patternMapData();
    unsigned int pixelsWide();
    unsigned int pixelsHigh();
};

#endif // TYEFFECTPATTERNMAP_H
