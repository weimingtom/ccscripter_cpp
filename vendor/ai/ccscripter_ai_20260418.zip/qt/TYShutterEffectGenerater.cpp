#include "TYShutterEffectGenerater.h"

// Converted from Objective-C

QObject* TYShutterEffectGenerater::initWithBeforeImage:()
{
    {
    TYEffectDefinition effdef;
    
    this = [ super init ];
    
    [ effect getValue:&effdef ];
    switch(effdef.type){
    case TYEffectTopShutter:
    reverse = true;
    break;
    case TYEffectRightShutter:
    reverse = true;
    case TYEffectLeftShutter:
    horizontal = true;
    break;
    default:
    break;
    
    phaseInterval = effdef.time / 1000.0 / PIXEL_OF_COLUMN;
    time = effdef.time;
    numberOfColumn = ((horizontal) ? VSCREEN_WIDTH : VSCREEN_HEIGHT ) / PIXEL_OF_COLUMN;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    afterImage = [ atImage copyWithZone:[ atImage zone ] ];
    nowImage = [ befImage copyWithZone:[ befImage zone ] ];
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
    
    } // override
    
}

void TYShutterEffectGenerater::drawEffect()
{
    {
    int x,y,w,h,mx,my;
    int phase,movePhase;
    int i;
    
    // oߎԂsNZPʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *PIXEL_OF_COLUMN;
    if(phase >= PIXEL_OF_COLUMN){
    [ this changeEffectionImage:afterImage ];
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    return;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];
    
    movePhase = phase -beforePhase;
    // ܂A肦ȂƂ͎vB
    if(movePhase==0){
    return;
    
    if(horizontal){
    w = movePhase;
    h = VSCREEN_HEIGHT;
    y = 0;
    my = 0;
    x = (reverse) ? VSCREEN_WIDTH -beforePhase -w : beforePhase;
    mx = (reverse) ? -PIXEL_OF_COLUMN : PIXEL_OF_COLUMN;
    } else {
    w = VSCREEN_WIDTH;
    h = movePhase;
    x = 0;
    mx =0;
    y = (reverse) ? VSCREEN_HEIGHT -beforePhase -h : beforePhase;
    my = (reverse) ? -PIXEL_OF_COLUMN : PIXEL_OF_COLUMN;
    
    [ nowImage lockFocus ];
    for(i=0; i < numberOfColumn; i++,x+=mx,y+=my){
    [ afterImage compositeToPoint:NSMakePoint(x,y) fromRect:NSMakeRect(x,y,w,h) operation:NSCompositeCopy ];
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    beforePhase = phase;
    
    return ;
    } // override
    
}

void TYShutterEffectGenerater::dealloc()
{
    {
    [ startDate release ];
    super->dealloc();
    
    
}

