#ifndef TYVERTICALSCROLLGENERATER_H
#define TYVERTICALSCROLLGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYVerticalScrollGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    void drawEffect();
};

#endif // TYVERTICALSCROLLGENERATER_H
