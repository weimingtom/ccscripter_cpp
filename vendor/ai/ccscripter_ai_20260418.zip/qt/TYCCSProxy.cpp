#include "TYCCSProxy.h"

// Converted from Objective-C

NSWindow* TYCCSProxy::mainWindow()
{
    {
    return [ [ TYMainController controller ] mainWindow ];
    
}

void TYCCSProxy::setRetunCode:()
{
    {
    returnCode = aInt;
    [ returnString release ];
    returnString = [ aStr retain ];
    
    [ [ TYScriptEngine sharedEngine ] performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    
}

NSString* TYCCSProxy::returnString()
{
    
    
}

