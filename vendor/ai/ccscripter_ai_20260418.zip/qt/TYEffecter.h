#ifndef TYEFFECTER_H
#define TYEFFECTER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYEffecter : public QObject
{
    Q_OBJECT
public:
    QObject* init();
    void setEffectNo:(void value);
    NSImage * playEffectNo:();
    void setBeforeImage:(void value);
    NSImage* beforeImage();
    TYEffectRegister* getEffect:();
    bool startEffect:();
    bool getEffectionImage:();
    QObject* initWithType:();
    int getType();
    int getTime();
    NSString* getPath();
    QObject* initWithEffectDefinition:();
    void getValue:();
};

#endif // TYEFFECTER_H
