#ifndef TY-NSSTRINGADDITION_H
#define TY-NSSTRINGADDITION_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class NSString : public QWidget
{
    Q_OBJECT
public:
    const char* cSJISString();
    NSMutableData* getCSJISData();
    NSData* sjisData();
    unsigned cSJISStringLength();
    void getCSJISString:();
    NSString* substringSJISRange:();
};

#endif // TY-NSSTRINGADDITION_H
