#ifndef TYSELECTIONMANAGER_H
#define TYSELECTIONMANAGER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYSelectionManager : public TYRespondRectManager
{
    Q_OBJECT
public:
    void initialButtonImage();
    bool changeSelection:();
};

#endif // TYSELECTIONMANAGER_H
