#include "TYEffectGenerater.h"

// Converted from Objective-C

QObject* TYEffectGenerater::initWithBeforeImage:()
{
    {
    TYEffectGenerater *generater;
    TYEffectDefinition def;
    
    this = [ super init ];
    
    [ effect getValue:&def ];
    
    if(def.type==TYEffectCached){
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    return this;
    [ this autorelease ];
    
    switch(def.type){
    case TYEffectInstant:
    generater = [ TYInstantGenerater alloc ];
    break;
    case TYEffectLeftShutter:
    case TYEffectRightShutter:
    case TYEffectTopShutter:
    case TYEffectBottomShutter:
    generater = [ TYShutterEffectGenerater alloc ];
    break;
    case TYEffectLeftCartain:
    case TYEffectRightCartain:
    case TYEffectTopCartain:
    case TYEffectBottomCartain:
    generater = [ TYCartainEffectGenerater alloc ];
    break;
    case TYEffectRightScroll:
    case TYEffectLeftScroll:
    case TYEffectBottomScroll:
    case TYEffectTopScroll:
    generater = [ TYScrollEffectGenerater alloc ];
    break;
    case TYEffectMosaicOut:
    case TYEffectMosaicIn:
    generater = [ TYMosaicEffectGenerater alloc ];
    break;
    case TYEffectFadeWithMask:
    generater = [ [ TYPatternFadeGenerater alloc ] initWithBeforeImage:befImage afterImage:atImage effect:effect ];
    if(generater)
    return generater;
    else
    return [ [ TYCrossFadeGenerater alloc ] initWithBeforeImage:befImage afterImage:atImage effect:effect ];
    break;
    case TYEffectCrossFadeWithMask:
    generater = [ [ TYPatternCrossFadeGenerater alloc ] initWithBeforeImage:befImage afterImage:atImage effect:effect ];
    if(generater)
    return generater;
    else
    return [ [ TYCrossFadeGenerater alloc ] initWithBeforeImage:befImage afterImage:atImage effect:effect ];
    break;
    default :
    generater = [ TYCrossFadeGenerater alloc ];
    
    return [ generater initWithBeforeImage:befImage afterImage:atImage effect:effect ];
    
}

QObject* TYEffectGenerater::initWithImage:()
{
    {
    [ super init ];
    [ this autorelease ];
    
    return [ [ TYQuakeEffectGenerater alloc ] initWithImage:image quakeType:type times:times time:second ];
    
}

void TYEffectGenerater::setDelegate:()
{
    {
    delegate = aDelegate;
    
}

void TYEffectGenerater::changeEffectionImage:()
{
    {
    if(delegate){
    if([ delegate respondsToSelector:@selector(changeEffectionImage:) ]){
    [ delegate changeEffectionImage:drawImage ];
    
}

void TYEffectGenerater::effectFinished()
{
    {
    if(delegate){
    if([ delegate respondsToSelector:@selector(effectFinished) ]){
    [ delegate effectFinished ];
    
}

void TYEffectGenerater::drawEffect()
{
    {
    [ this effectFinished ];
    
}

void TYEffectGenerater::dealloc()
{
    {
    [ beforeImage release ];
    [ afterImage release ];
    [ nowImage release ];
    [ super dealloc ];
    
    
}

