#include "TYNBZDecompresser.h"

// Converted from Objective-C

NSData* TYNBZDecompresser::decodeDataWithFileHandle:()
{
    {
    int fd;
    FILE *fp;
    unsigned decode_size;
    unsigned char unused[BZ_MAX_UNUSED];
    BZFILE *bzf;
    unsigned char *top,*p;
    NSMutableData *decodeData;
    unsigned char *unused_tmp;
    int bzerr;
    int nread;
    int nunused;
    
    decode_size = *(int*)[ [ handle readDataOfLength:4 ] bytes ];
    fd = [ handle fileDescriptor ];
    if((fp = fdopen(fd,"r")) == NULL){
    [ handle closeFile ];
    return nullptr;
    decodeData = [ NSMutableData dataWithLength:decode_size ];
    p = top = [ decodeData mutableBytes ];
    
    nunused = 0;
    bzf = BZ2_bzReadOpen(&bzerr, fp, 0, 0, unused, nunused);
    NSAssert((bzf != NULL && bzerr == BZ_OK),QString::fromUtf8("nbzReadOpen Error"));
    
    while (bzerr == BZ_OK) {
    NSAssert((p < top + decode_size),QString::fromUtf8("nbzReadSize too large"));
    nread = BZ2_bzRead(&bzerr, bzf, p, 5000);
    NSAssert(((bzerr == BZ_OK||bzerr == BZ_STREAM_END) && nread > 0),QString::fromUtf8("nbzReadError"));
    p += nread;
    NSAssert((bzerr == BZ_STREAM_END),QString::fromUtf8("bzerr is not BZ_STREAM_END"));
    
    BZ2_bzReadGetUnused(&bzerr, bzf, (void **)&unused_tmp, &nunused);
    NSAssert((bzerr == BZ_OK),QString::fromUtf8("BZ2_bzReadGetUnused"));
    
    BZ2_bzReadClose(&bzerr, bzf);
    NSAssert((bzerr == BZ_OK),QString::fromUtf8("bzReadClose"));
    
    //NSAssert((nunused == 0),QString::fromUtf8("nunused not equal 0"));
    
    return decodeData;
    
}

NSBitmapImageRep* TYNBZDecompresser::decodeBitmapWithFileHandle:()
{
    {
    return [ [ [ NSBitmapImageRep alloc ] initWithData:[ this decodeDataWithFileHandle:handle length:encode_size ] ] autorelease ];
    
    
}

