#ifndef TYAUTOMODECONTROLLER_H
#define TYAUTOMODECONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYAutoModeController : public QObject
{
    Q_OBJECT
public:
    IBAction dialogOk:();
    IBAction dialogCancel:();
    int runModalTextSpeed:();
    int textSpeed();
    int waitType();
    int waitNum();
};

#endif // TYAUTOMODECONTROLLER_H
