#include "TYSarArchiver.h"

// Converted from Objective-C

QObject* TYSarArchiver::initWithContentsOfFile:()
{
    {
    NSFileHandle *sarhandle;
    NSData *readDatabuf; // ǂݍ݃obt@[
    unsigned char *readbufptr;
    char address[256];
    unsigned filenum;
    int i,j;
    NSAutoreleasePool *arp;
    unsigned fileOffset,fileLength;
    id *objectArray,*objectArrayTop,*keyArray,*keyArrayTop;
    int fd;
    
    // const unsigned readLength = 256;
    
    this = [ super init ];
    
    arp = [ [ NSAutoreleasePool alloc ] init ];
    
    // t@Cǂݍ݃[hŃI[v
    sarhandle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    if(!sarhandle){
    return nullptr;
    
    // t@C̓ǂݏo
    readDatabuf = [ sarhandle readDataOfLength:2 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    filenum = (readbufptr[0] << 8) + readbufptr[1];
    
    // t@C̃IuWFNgւ̃|C^i[̈m
    objectArrayTop = objectArray = malloc(sizeof(id) *filenum);
    NSAssert((objectArray), QString::fromUtf8("malloc failed"));
    keyArrayTop = keyArray = malloc(sizeof(id) *filenum);
    NSAssert((keyArray), QString::fromUtf8("malloc failed"));
    
    // f[^̎n_ItZbg̓ǂݏo
    readDatabuf = [ sarhandle readDataOfLength:4 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    baseOffset = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];
    
    fd = [ sarhandle fileDescriptor ];
    
    // t@C̃CfbNX쐬
    for( i=0; i < filenum; i++){
    
    j = 0;
    while(1){
    /*
    readDatabuf = [ sarhandle readDataOfLength:1 ]; // Ǔ_F܂Ƃ߂256oCg炢ǂނ悤ɂȁB
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    */
    read(fd,readbufptr,1);
    if(readbufptr[0]){
    // obNXbV͂̂ŃXbVɕς܂B
    if(readbufptr[0] == '\\') readbufptr[0] = '/';
    address[j] = readbufptr[0];
    } else {
    address[j] = '\0';
    // AhX當IuWFNg쐬AzɉB
    *keyArray=[ NSString stringWithCString:address ];
    keyArray++;
    
    // _̃ItZbgǂݏo
    readDatabuf = [ sarhandle readDataOfLength:4 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    fileOffset = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];
    
    // t@C̃oCgǂݏo
    readDatabuf = [ sarhandle readDataOfLength:4 ];
    readbufptr = (unsigned char *)[ readDatabuf bytes ];
    fileLength = (readbufptr[0] << 24) +(readbufptr[1] << 16)  +(readbufptr[2] << 8) +readbufptr[3];
    
    // A[JCut@CIuWFNg쐬Azɉ
    *objectArray=[ TYSarArchivedFile archivedFileoffset:fileOffset length:fileLength ];
    objectArray++;
    
    break;
    j++;
    
    
    // o^
    filesDict = [ [ NSDictionary dictionaryWithObjects:objectArrayTop forKeys:keyArrayTop count:filenum ] retain ];
    free(objectArrayTop);
    free(keyArrayTop);
    
    // pXo^
    arcPath = path;
    [ arcPath retain ];
    
    // t@CN[Y
    [ sarhandle closeFile ];
    
    [ arp release ];
    
    return this;
    
    // A[JCũt@Cnh擾Awf[^̊JnʒuɃV[NĕԂB
}

NSFileHandle* TYSarArchiver::fileHandleWithPath:()
{
    {
    NSFileHandle *handle;
    TYSarArchivedFile *tmp;
    int fileOffset;
    
    tmp = [ filesDict objectForKey:aPath ];
    if(!tmp){
    return nullptr;
    handle = [ NSFileHandle fileHandleForReadingAtPath:arcPath ];
    if(!handle){
    return nullptr;
    [ tmp getFileDataOffset:&fileOffset length:length ];
    
    [ handle seekToFileOffset:fileOffset +baseOffset ];
    
    return handle;
    
    // A[JCut@C擾Ă܂B
}

NSData* TYSarArchiver::unArchivedFile:()
{
    {
    TYSarArchivedFile *tmp;
    unsigned fileOffset,fileLength;
    
    //NSLog(QString::fromUtf8("address[%@]\n@"),address);
    //NSLog(QString::fromUtf8("%@\n"),[ [ filesDict allKeys ] description ]);
    tmp = [ filesDict objectForKey:[ address lowercaseString ]];
    
    if(!tmp){
    //NSLog(QString::fromUtf8("failed search for Archive!!\narichive[%@]\npath[%@]\n"),arcPath,address);
    return nullptr;
    [ tmp getFileDataOffset:&fileOffset length:&fileLength ];
    
    return [ this readDataOffset:fileOffset length:fileLength ];
    
}

NSData* TYSarArchiver::readDataOffset:()
{
    {
    NSFileHandle *handle;
    NSData *readData;
    
    handle = [ NSFileHandle fileHandleForReadingAtPath:arcPath ];
    
    if(!handle){
    return nullptr;
    
    [ handle seekToFileOffset:offset +baseOffset];
    readData = [ handle readDataOfLength:length ];
    [ handle closeFile ];
    
    return readData;
    
}

void TYSarArchiver::dealloc()
{
    {
    [ filesDict release ];
    [ arcPath release ];
    
    [ super dealloc ];
    
}

