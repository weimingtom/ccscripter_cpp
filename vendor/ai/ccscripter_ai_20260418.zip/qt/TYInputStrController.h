#ifndef TYINPUTSTRCONTROLLER_H
#define TYINPUTSTRCONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYInputStrController : public QObject
{
    Q_OBJECT
public:
    IBAction dialogOk:();
    int runModalCaption:();
    int runModalCaption:();
    NSString* string();
    void textDidChange:();
};

#endif // TYINPUTSTRCONTROLLER_H
