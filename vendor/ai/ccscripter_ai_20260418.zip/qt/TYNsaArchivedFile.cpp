#include "TYNsaArchivedFile.h"

// Converted from Objective-C

QObject* TYNsaArchivedFile::initFileoffset:()
{
    {
    this = [ super initFileoffset:offset length:length ];
    compressType = type;
    expandedLength = exLength;
    
    return this;
    
}

unsigned TYNsaArchivedFile::compressType()
{
    {
    return compressType;
    
}

unsigned TYNsaArchivedFile::expandedLength()
{
    {
    return expandedLength;
    
    
}

