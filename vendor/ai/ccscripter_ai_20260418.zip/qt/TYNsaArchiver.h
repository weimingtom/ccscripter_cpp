#ifndef TYNSAARCHIVER_H
#define TYNSAARCHIVER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYNsaArchiver : public TYSarArchiver
{
    Q_OBJECT
public:
    QObject* initWithContentsOfFile:();
    QObject* unArchivedFile:();
};

#endif // TYNSAARCHIVER_H
