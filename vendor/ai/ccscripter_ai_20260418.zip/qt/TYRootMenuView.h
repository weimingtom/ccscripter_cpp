#ifndef TYROOTMENUVIEW_H
#define TYROOTMENUVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYRootMenuView : public TYMenuModeView
{
    Q_OBJECT
public:
    QObject* initWithFrame:();
};

#endif // TYROOTMENUVIEW_H
