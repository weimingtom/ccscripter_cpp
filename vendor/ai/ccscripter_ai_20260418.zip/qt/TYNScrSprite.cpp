#include "TYNScrSprite.h"

// Converted from Objective-C

QObject* TYNScrSprite::initWithID:()
{
    {
    NSSize imageSize;
    
    this = [ super init ];
    
    spriteID = idNo;
    imagePath = [ aPath retain ];
    
    visible = aBool;
    [ this loadImageFromPath ];
    
    imageSize = (sourceImage) ? [ sourceImage size ] : NSZeroSize;
    
    drawPoint.x = point.x;
    drawPoint.y = VSCREEN_HEIGHT -imageSize.height -point.y;
    
    if(alphaNum)
    alpha = [ alphaNum intValue ];
    
    /*
    if(visible && sourceImage && [ (TYAnimationCellImage*)sourceImage isAnimate ]){
    [ (TYAnimationCellImage*)sourceImage play ];
    [ sourceImage setDelegate:this ];
    */
    
    return this;
    /*
}

QObject* TYNScrSprite::initWithID:()
{
    {
    NSSize imageSize;
    NSSize vSize;
    
    this = [ super init ];
    
    spriteID = idNo;
    
    sourceImage = aImage;
    [ sourceImage retain ];
    
    // `n_Ä߂B
    imageSize = (aImage) ? [ aImage size ] : NSZeroSize;
    
    drawPoint.x = point.x;
    drawPoint.y = VSCREEN_HEIGHT -imageSize.height -point.y;
    
    alpha = [ alphaNum intValue ];
    
    visible = aBool;
    
    return this;
    */
    
}

void TYNScrSprite::moveX:()
{
    {
    //NSSize imageSize;
    
    drawPoint.x += [ x intValue ];
    drawPoint.y -= [ y intValue ]; // MacłYW]ĂB
    alpha += [ alphaNum intValue ];
    if(alpha < 0)
    alpha = 0;
    else if(alpha > SPRITE_ALPHA_MAX)
    alpha = SPRITE_ALPHA_MAX;
    
    //imageSize = [ sourceImage size ];
    
}

void TYNScrSprite::absoluteMoveX:()
{
    {
    drawPoint.x = [ x intValue ];
    drawPoint.y = VSCREEN_HEIGHT -[ sourceImage size ].height - [ y intValue ];
    if(alphaNum){
    alpha = [ alphaNum intValue ];
    if(alpha < 0)
    alpha = 0;
    else if(alpha > SPRITE_ALPHA_MAX)
    alpha = SPRITE_ALPHA_MAX;
    
}

void TYNScrSprite::setVisible:()
{
    {
    if(visible == aBool) {
    return;
    
    visible = aBool;
    if(sourceImage && [ (TYAnimationCellImage*)sourceImage isAnimate ]){
    if(visible && ![ (TYAnimationCellImage*)sourceImage isPlaying ]){
    [ (TYAnimationCellImage*)sourceImage play ];
    [ sourceImage setDelegate:this ];
    } else if(!visible && [ (TYAnimationCellImage*)sourceImage isPlaying ]){
    [ (TYAnimationCellImage*)sourceImage stop ];
}

bool TYNScrSprite::visible()
{
    
}

int TYNScrSprite::spriteID()
{
    {
    return spriteID;
    
}

void TYNScrSprite::draw()
{
    {
    if(visible)
    [ super draw ];
    
}

void TYNScrSprite::loadImageFromPath()
{
    {
    [ super loadImageFromPath ];
    
    // MEMO:G̃AjΉꍇ͂̃R[h̓X[p[NXɈڂB
    if(sourceImage && [ sourceImage isAnimate ] && visible){
    [ (TYAnimationCellImage*)sourceImage play ];
    [ sourceImage setDelegate:this ];
    
    /*
}

bool TYNScrSprite::isEqual:()
{
    {
    if(![ [ this class ] isMemberOfClass:[ object class ] ]){
    return false;
    
    return ([ this spriteID ] == [ object spriteID ]) ? true : false;
    */
    
    
    // implementation of NSCoding
}

void TYNScrSprite::encodeWithCoder:()
{
    {
    [ super encodeWithCoder:aCoder ];
    
    [ aCoder encodeValueOfObjCType:"i" at:&spriteID ];
    [ aCoder encodeValueOfObjCType:@encode(BOOL) at:&visible ];
    
}

QObject* TYNScrSprite::initWithCoder:()
{
    {
    [ super initWithCoder:aDecoder ];
    [ aDecoder decodeValueOfObjCType:"i" at:&spriteID ];
    [ aDecoder decodeValueOfObjCType:@encode(BOOL) at:&visible ];
    
    return this;
    
}

NSString* TYNScrSprite::description()
{
    {
    return [ NSString stringWithFormat:QString::fromUtf8("ID=%d,point=%@,alpha=%d"),spriteID,NSStringFromPoint(drawPoint),alpha ];
    
}

void TYNScrSprite::didChangeCell:()
{
    {
    [ [ NSNotificationCenter defaultCenter ] postNotificationName:TYSpriteAnimationNotification object:this ];
    
}

void TYNScrSprite::dealloc()
{
    {
    // MEMO:G̃AjΉꍇ͂̃R[h̓X[p[NXɈڂB
    if(sourceImage && [ sourceImage isAnimate ] && [ (TYAnimationCellImage*)sourceImage isPlaying ]){
    [ (TYAnimationCellImage*)sourceImage stop ];
    super->dealloc();
    
    
}

