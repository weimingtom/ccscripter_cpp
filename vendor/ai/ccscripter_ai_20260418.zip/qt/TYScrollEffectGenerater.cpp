#include "TYScrollEffectGenerater.h"

// Converted from Objective-C

QObject* TYScrollEffectGenerater::initWithBeforeImage:()
{
    {
    TYEffectDefinition effdef;
    
    this = [ super init ];
    
    // ̂Wreverse=YESw肵Ă܂A̓vOԈႦĂɍĂ܂łB(m
    [ effect getValue:&effdef ];
    switch(effdef.type){
    case TYEffectBottomScroll:
    reverse = true;
    break;
    case TYEffectLeftScroll:
    reverse = true;
    case TYEffectRightScroll:
    horizontal = true;
    break;
    default:
    break;
    
    phaseMAX = (horizontal) ? VSCREEN_WIDTH : VSCREEN_HEIGHT ;
    phaseInterval = effdef.time / 1000.0 / phaseMAX;
    time = effdef.time;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    unionImage = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH *(horizontal+1),VSCREEN_HEIGHT *((!horizontal) +1) ) ];
    nowImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    [ unionImage lockFocus ];
    {
    int x,y;
    x = VSCREEN_WIDTH *(reverse) *(horizontal);
    y = VSCREEN_HEIGHT *(reverse) *(!horizontal);
    [ befImage compositeToPoint:NSMakePoint(x,y) operation:NSCompositeCopy ];
    x = VSCREEN_WIDTH *(!reverse) *(horizontal);
    y = VSCREEN_HEIGHT *(!reverse) *(!horizontal);
    [ atImage compositeToPoint:NSMakePoint(x,y) operation:NSCompositeCopy ];
    [ unionImage unlockFocus ];
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
    
    } // override
    
}

void TYScrollEffectGenerater::drawEffect()
{
    {
    int x,y;
    int phase;
    
    // oߎԂC[W̍̃sNZPʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *phaseMAX;
    if(phase >= phaseMAX){
    // GtFNgI
    x = VSCREEN_WIDTH *(!reverse) *(horizontal);
    y = VSCREEN_HEIGHT *(!reverse) *(!horizontal);
    [ nowImage lockFocus ];
    [ unionImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(x,y,VSCREEN_WIDTH,VSCREEN_HEIGHT) operation:NSCompositeCopy ];
    [ nowImage unlockFocus ];
    [ this changeEffectionImage:nowImage ];
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    } else {
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];
    x = (VSCREEN_WIDTH *(reverse) +phase *((reverse) ? -1 : 1)) *(horizontal);
    y = (VSCREEN_HEIGHT *(reverse) +phase *((reverse) ? -1 : 1 ))*(!horizontal);
    [ nowImage lockFocus ];
    [ unionImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(x,y,VSCREEN_WIDTH,VSCREEN_HEIGHT) operation:NSCompositeCopy ];
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    return ;
    } // override
    
}

void TYScrollEffectGenerater::dealloc()
{
    {
    [ startDate release ];
    unionImage->release();
    super->dealloc();
    
    
}

