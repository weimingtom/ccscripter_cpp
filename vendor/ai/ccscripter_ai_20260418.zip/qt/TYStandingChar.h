#ifndef TYSTANDINGCHAR_H
#define TYSTANDINGCHAR_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYStandingChar : public TYSprite
{
    Q_OBJECT
public:
    QObject* initWithPosition:();
    void setBaseLine:(void value);
};

#endif // TYSTANDINGCHAR_H
