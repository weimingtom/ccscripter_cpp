#ifndef TYARGMENTARRAY_H
#define TYARGMENTARRAY_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYArgmentArray : public QObject
{
    Q_OBJECT
public:
    QObject* initWithCString:();
    void setParseMode:(void value);
    void parse();
};

#endif // TYARGMENTARRAY_H
