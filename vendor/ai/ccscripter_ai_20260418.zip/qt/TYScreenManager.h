#ifndef TYSCREENMANAGER_H
#define TYSCREENMANAGER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // TYSCREENMANAGER_H
