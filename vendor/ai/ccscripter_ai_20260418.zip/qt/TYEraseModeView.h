#ifndef TYERASEMODEVIEW_H
#define TYERASEMODEVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYEraseModeView : public QWidget
{
    Q_OBJECT
public:
    QObject* initWithFrame:();
    void endMode();
};

#endif // TYERASEMODEVIEW_H
