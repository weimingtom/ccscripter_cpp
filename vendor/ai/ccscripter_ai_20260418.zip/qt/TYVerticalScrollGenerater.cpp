#include "TYVerticalScrollGenerater.h"

// Converted from Objective-C

QObject* TYVerticalScrollGenerater::initWithBeforeImage:()
{
    {
    TYEffectDefinition effdef;
    
    this = [ super init ];
    
    reverse = aBool;
    
    [ effect getValue:&effdef ];
    phaseInterval = effdef.time / 1000.0 / VSCREEN_HEIGHT;
    time = effdef.time;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    unionImage = [ [ NSImage alloc ] initWithSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT*2) ];
    nowImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    [ unionImage lockFocus ];
    [ befImage compositeToPoint:NSMakePoint(0,VSCREEN_HEIGHT *(reverse)) operation:NSCompositeCopy ];
    [ atImage compositeToPoint:NSMakePoint(0,VSCREEN_HEIGHT *(!reverse)) operation:NSCompositeCopy ];
    [ unionImage unlockFocus ];
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
    
    // private method
}

void TYVerticalScrollGenerater::drawEffect()
{
    {
    int phase;
    // oߎԂ480PʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *VSCREEN_HEIGHT;
    if(phase >= VSCREEN_HEIGHT){
    // GtFNgI
    [ nowImage lockFocus ];
    [ unionImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(0,(VSCREEN_HEIGHT *((reverse) ? -1 : 1)) + VSCREEN_HEIGHT *(reverse),VSCREEN_WIDTH,VSCREEN_HEIGHT) operation:NSCompositeCopy ];
    [ nowImage unlockFocus ];
    [ this changeEffectionImage:nowImage ];
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    } else {
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];
    
    [ nowImage lockFocus ];
    [ unionImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(0,(phase *((reverse) ? -1 : 1)) + VSCREEN_HEIGHT *(reverse),VSCREEN_WIDTH,VSCREEN_HEIGHT) operation:NSCompositeCopy ];
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    return;
    } // override
    
}

void TYVerticalScrollGenerater::dealloc()
{
    {
    [ startDate release ];
    unionImage->release();
    [ nowImage release ];
    super->dealloc();
    
    
}

