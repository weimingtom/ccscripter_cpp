#include "TYRootMenuView.h"

// Converted from Objective-C

QObject* TYRootMenuView::initWithFrame:()
{
    controller:(id)aObj
    attributes:(NSDictionary*)aDict
    menuItems:(NSArray*)aArray
    layout:(NSMutableDictionary*)layoutDict
    {
    int fontWidth;
    int fontHeight;
    int pitchX;
    int pitchY;
    BOOL shadow;
    
    int y,cnt,tag;
    NSEnumerator *enu;
    NSString* temp;
    TYCellImage *image;
    NSRect frame;
    NSSize size;
    TYControllButton *button;
    NSArray *buttonColors;
    NSMutableArray *buttonArray;
    NSMutableArray *actionArray;
    NSColor *menuColor;
    
    buttonArray = [ NSMutableArray array ];
    actionArray = [ NSMutableArray array ];
    
    // 初期化
    this = super->initWithFrame(aFrame ];
    
    if (!this)
    return nullptr;
    
    // メニューレイアウトの読み込み
    {
    size = [ [ layoutDict objectForKey:TYRMenuFontSize ] sizeValue ];
    fontWidth = size.width;
    fontHeight = size.height;
    
    size = [ [ layoutDict objectForKey:TYRMenuFontPitchSize ] sizeValue ];
    pitchX = size.width;
    pitchY = size.height;
    
    shadow = [ [ layoutDict objectForKey:TYRMenuShadowed ] boolValue ];
    
    menuColor = [ layoutDict objectForKey:TYRMenuBGColor ];
    
    buttonColors = [ NSArray arrayWithObjects:
    [ layoutDict objectForKey:TYRMenuNoSelectColor ],
    [ layoutDict objectForKey:TYRMenuSelectColor ],nullptr ];
    
    cnt = [ aArray count ] / 2;
    enu = [ aArray objectEnumerator ];
    
    // 1行目の位置取得。
    y = VSCREEN_HEIGHT -(VSCREEN_HEIGHT + (-fontHeight -pitchY) *(cnt -1)) /2;
    
    tag = 0;
    while(temp = [ enu nextObject ]) {
    NSPoint origin;
    
    // イメージ生成
    image = [ [ TYCellImage alloc ] initWithImages:
    [ TYStringImage imagesWithString:temp
    attributes:aDict
    colors:buttonColors
    fontHeight:fontHeight
    fontWidth:fontWidth
    interval:pitchX
    shadow:shadow ] ];
    [ image autorelease ];
    
    // button生成。
    size = [ (NSImage*)image size ];
    frame = NSMakeRect((VSCREEN_WIDTH -size.width) / 2,
    y,size.width,size.height);
    origin = [ (TYStringImage*)image origin ];
    frame.origin.x += origin.x;
    frame.origin.y += origin.y;
    [ (NSArray*)image makeObjectsPerformSelector:@selector(setOriginByValue:)
    withObject:[ NSValue valueWithPoint:NSZeroPoint ] ];
    
    
    button = [ [ [ TYControllButton alloc ] initWithFrame:frame cellImage:image ] autorelease ];
    [ button setTarget:this ];
    [ button setAction:@selector(execButton:) ];
    [ button setTag:tag++ ];
    
    // TODO:初期化されてない自身に対する呼び出し。このメソッドをinitWithFrame:とsetController:〜に分割。
    [ this addSubview:button ];
    [ buttonArray addObject:button ];
    
    [ actionArray addObject:[ enu nextObject ] ];
    y -= fontHeight +pitchY;
    
    // 初期化完了
    setController(aObj
    buttonArray:buttonArray
    actionArray:actionArray
    bgColor:menuColor ];
    
    return this;
    
    
}

