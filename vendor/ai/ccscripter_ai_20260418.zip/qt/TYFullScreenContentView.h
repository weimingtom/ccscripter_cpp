#ifndef TYFULLSCREENCONTENTVIEW_H
#define TYFULLSCREENCONTENTVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYFullScreenContentView : public QWidget
{
    Q_OBJECT
public:
    void drawRect:();
};

#endif // TYFULLSCREENCONTENTVIEW_H
