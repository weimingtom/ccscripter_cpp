#ifndef TYMISCUTIL_H
#define TYMISCUTIL_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class NSCharacterSet : public QWidget
{
    Q_OBJECT
public:
    QObject* subarrayFromIndex:();
    QObject* objectsSortedByKeyUsingSelector:();
};

#endif // TYMISCUTIL_H
