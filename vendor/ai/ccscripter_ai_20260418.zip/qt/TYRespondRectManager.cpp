#include "TYRespondRectManager.h"

// Converted from Objective-C

QObject* TYRespondRectManager::initWithStageManager:()
{
    {
    this = [ super init ];
    
    stageManager = [ manager retain ];
    
    // CX^X̊m
    drawBuffer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    btnArray = [ [ NSMutableArray alloc ] initWithCapacity:1 ];
    
    beforeSelection = -1;
    
    rectMap = [ [ NSMutableData dataWithLength:VSCREEN_WIDTH *VSCREEN_HEIGHT ] retain ];
    
    return this;
    
}

void TYRespondRectManager::addSelection:()
{
    {
    unsigned char *map,*ptr;
    int index,i,j;
    
    // cellImagezɓ˂ށB
    [ btnArray addObject:aButton ];
    
    // rectMapɓo^
    map = (unsigned char*)[ rectMap mutableBytes ];
    index = [ btnArray count ];
    // rect ʃTCY𒴂Ȃ悤
    rect = NSIntersectionRect(rect,TYVirtualScreenRect());
    for(i = 0; i < rect.size.height; i++){
    ptr = map +(int)rect.origin.x +( (int)rect.origin.y +i) *VSCREEN_WIDTH;
    for(j = 0; j < rect.size.width; j++,ptr++){
    *ptr = index;
    
    
}

void TYRespondRectManager::initialButtonImage()
{
    {
    return;
    
}

int TYRespondRectManager::selectedButtonID()
{
    {
    return beforeSelection; // ftHgłindex=idNo;
    
}

int TYRespondRectManager::selectedIndex()
{
    {
    return beforeSelection; // indexԂB
    
}

int TYRespondRectManager::incToIndex()
{
    {
    int nowSelection,count;
    
    count = [ btnArray count ];
    
    if(!count){
    return 0;
    
    nowSelection = beforeSelection +1;
    if(nowSelection > count ){
    return 1;
    } else {
    return nowSelection;
    
    
}

int TYRespondRectManager::decToIndex()
{
    {
    int nowSelection,count;
    
    count = [ btnArray count ];
    
    if(!count){
    return 0;
    
    nowSelection = beforeSelection -1;
    if(nowSelection <= 0){
    return count;
    } else {
    return nowSelection;
    
}

NSData* TYRespondRectManager::rectMap()
{
    {
    return rectMap;
    
}

bool TYRespondRectManager::changeSelection:()
{
    {
    if(beforeSelection == index)
    return false;
    
    beforeSelection = index;
    
    return true;
    
}

void TYRespondRectManager::draw()
{
    {
    [ drawBuffer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    
}

void TYRespondRectManager::clear()
{
    {
    // CX^X̍Ċmۂ܂̓NA[
    if(drawBuffer)
    [ drawBuffer release ];
    drawBuffer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    if(btnArray)
    [ btnArray release ];
    btnArray = [ [ NSMutableArray alloc ] initWithCapacity:1 ];
    
    beforeSelection = -1;
    
    if(rectMap) {
    memset([ rectMap mutableBytes ],0,(size_t)VSCREEN_WIDTH * VSCREEN_HEIGHT);
    
    
}

void TYRespondRectManager::dealloc()
{
    {
    if(stageManager){
    [ stageManager release ];
    drawBuffer->release();
    btnArray->release();
    rectMap->release();
    super->dealloc();
    
    
}

