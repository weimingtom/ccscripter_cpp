#ifndef TYNSCRSPRITE_H
#define TYNSCRSPRITE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYNScrSprite : public TYSprite
{
    Q_OBJECT
public:
    QObject* initWithID:();
    QObject* initWithID:();
    void moveX:();
    void absoluteMoveX:();
    void setVisible:(void value);
    bool visible();
    int spriteID();
    void draw();
};

#endif // TYNSCRSPRITE_H
