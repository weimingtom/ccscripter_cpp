#ifndef TYMENUMODEVIEW_H
#define TYMENUMODEVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYMenuModeView : public QWidget
{
    Q_OBJECT
public:
    QObject* initWithFrame:();
    void setController:(void value);
    void updatesTrackingRect();
    void removeAllTrackingRect();
    void setButtonArray:(void value);
    void setActionArray:(void value);
    IBAction execButton:();
    void endMode();
    void cancel_action:();
    void select_action();
    void up_action();
    void down_action();
};

#endif // TYMENUMODEVIEW_H
