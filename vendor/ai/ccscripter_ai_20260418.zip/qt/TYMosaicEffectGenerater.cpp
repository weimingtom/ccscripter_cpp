#include "TYMosaicEffectGenerater.h"

// Converted from Objective-C

QObject* TYMosaicEffectGenerater::initWithBeforeImage:()
{
    {
    TYEffectDefinition effdef;
    
    this = [ super init ];
    
    [ effect getValue:&effdef ];
    phaseInterval = effdef.time / 1000.0 / PHASE_NUM;
    //time = effdef.time;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    inToward = ( effdef.type == TYEffectMosaicIn ) ? true : false;
    if(inToward){
    sourceBitmap = [ [ NSBitmapImageRep alloc ] initWithData:[ atImage TIFFRepresentation ] ];
    afterImage = [ atImage copyWithZone:[ atImage zone ] ];
    } else {
    sourceBitmap = [ [ NSBitmapImageRep alloc ] initWithData:[ befImage TIFFRepresentation ] ];
    if(!sourceBitmap){
    sourceBitmap = blankBitmap(VSCREEN_WIDTH,VSCREEN_HEIGHT);
    [ sourceBitmap retain ];
    
    nowImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    nowBitmapptr = malloc(VSCREEN_WIDTH *VSCREEN_HEIGHT *3);
    
    phase = 0;
    
    return this;
    
    // private method
}

void TYMosaicEffectGenerater::drawEffect()
{
    {
    unsigned char *src,*now;
    int spps,sppn;
    int blockSize,w,h,wide,high,pw,ph,idx;
    unsigned long total[3];
    
    // oߎԂPHASEPʂŎ擾
    //phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *PHASE_NUM;
    if(phase >= PHASE_NUM){
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    // GtFNgI
    if(inToward){
    [ this changeEffectionImage:afterImage ];
    return;
    phase = PHASE_NUM -1;
    } else {
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];
    
    src = [ sourceBitmap bitmapData ];
    spps = [ sourceBitmap samplesPerPixel ];
    now = (unsigned char*)nowBitmapptr;
    sppn =3;
    wide = [ sourceBitmap pixelsWide ];
    high = [ sourceBitmap pixelsHigh ];
    if(inToward)
    blockSize = blockSizeTable[((VSCREEN_HEIGHT==600) ? 1 : 0)][ phase ];
    else
    blockSize = blockSizeTable[((VSCREEN_HEIGHT==600) ? 1 : 0)][ PHASE_NUM -phase -1];
    
    for(h = 0; h < VSCREEN_HEIGHT; h+=blockSize){
    for(w = 0; w < VSCREEN_WIDTH; w+=blockSize){
    // ubN̕ϒl߂
    total[0] = 0;
    total[1] = 0;
    total[2] = 0;
    for(ph = 0; ph < blockSize; ph++){
    idx = ((h +ph) * VSCREEN_WIDTH +w) *spps;
    for(pw = 0; pw < blockSize; pw++,idx+=spps){
    total[0] += src[idx];
    total[1] += src[idx+1];
    total[2] += src[idx+2];
    // ubN̊esNZɒlݒ
    total[0] /= (blockSize *blockSize);
    total[1] /= (blockSize *blockSize);
    total[2] /= (blockSize *blockSize);
    for(ph = 0; ph < blockSize; ph++){
    idx = ((h +ph) * VSCREEN_WIDTH +w) *sppn;
    for(pw = 0; pw < blockSize; pw++,idx+=sppn){
    now[idx] = total[0];
    now[idx+1] = total[1];
    now[idx+2] = total[2];
    
    [ nowImage lockFocus ];
    
    NSDrawBitmap(TYVirtualScreenRect(),VSCREEN_WIDTH,VSCREEN_HEIGHT,8,3,24,VSCREEN_WIDTH *3,false,false,NSCalibratedRGBColorSpace,&nowBitmapptr);
    
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    phase++;
    
}

void TYMosaicEffectGenerater::dealloc()
{
    {
    sourceBitmap->release();
    if(nowBitmapptr)
    free((unsigned char*)nowBitmapptr);
    super->dealloc();
    
    
}

