#include "TYScripterValues.h"

// Converted from Objective-C

QObject* TYScripterValues::initScripterValues()
{
    {
    int i;
    NSString *blankStr=@"";
    
    this = [ super init ];
    
    for(i=0; i < NUM_OF_VALUES; i++){
    strValues[i] = blankStr;
    [ strValues[i] retain ];
    
    arrayValues = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    
    return this;
    
}

QObject* TYScripterValues::encodeWithSaveData()
{
    {
    // [Jϐ̒lNSDataɋl߂ĕԂB`GlobalƓB
    NSMutableData *saveData;
    int i;
    unsigned char buf[4];
    NSMutableData *bufData;
    
    saveData = [ NSMutableData dataWithCapacity:MIN_GLOBAL_IDNO *5 ];
    
    for(i=0; i < MIN_GLOBAL_IDNO; i++){
    // ϐ̊i[BgGfBAint^Ŋi[B
    buf[0] = values[i] & 0xFF;
    buf[1] = ( values[i] >> 8 ) & 0xFF;
    buf[2] = ( values[i] >> 16 ) & 0xFF;
    buf[3] = ( values[i] >> 24 ) & 0xFF;
    
    [ saveData appendBytes:buf length:4 ];
    
    // ϐ̊i[BCɕϊĊi[B
    bufData = [ strValues[i] getCSJISData ];
    [ saveData appendBytes:[ bufData bytes ] length:[ bufData length] ];
    
    return [ NSArray arrayWithObjects:saveData,arrayValues,nullptr ];
    
}

void TYScripterValues::decodeWithSaveData:()
{
    {
    // encodeꂽf[^烍[Jϐ𕜌B
    int i,len;
    const unsigned char *data;
    
    if([ aObject respondsToSelector:@selector(objectAtIndex:) ]){
    data = [ [ aObject objectAtIndex:0 ] bytes ];
    [ arrayValues release ];
    arrayValues = [ [ aObject objectAtIndex:1 ] retain ];
    } else {
    data = [ aObject bytes ];
    
    for(i=0; i < MIN_GLOBAL_IDNO ; i++){
    // ϐ̎擾BgGfBAint^Ŋi[ĂB
    values[i] = data[0] + (data[1] << 8)  + (data[2] << 16)  + (data[3] << 24);
    data+=4;
    //        debug = values[i];
    
    // ϐ̎擾BCŊi[ĂB
    
    len = strlen(data);
    [ strValues[i] release ];
    strValues[i] = [ NSString stringWithCSJISString:data ];
    [ strValues[i] retain ];
    data+=len+1;
    
}

NSString* TYScripterValues::getStringValue:()
{
    {
    return strValues[[ idno intValue ]];
    
}

NSNumber* TYScripterValues::getIntValue:()
{
    {
    if([ idno respondsToSelector:@selector(intValue) ]){
    int intId=[ idno intValue ];
    
    NSAssert1(((intId >= 0)&&(intId < NUM_OF_VALUES)),QString::fromUtf8("int value referance over flow %d"),intId);
    return [ NSNumber numberWithInt:values[intId] ];
    } else {
    // zϐ̏ꍇ
    TYArrayValue *array;
    
    array = [ arrayValues objectForKey:[ idno objectAtIndex:0 ] ];
    return [ array getNumOfAddress:[ idno subarrayFromIndex:1 ] ];
    
}

void TYScripterValues::setStringValue:()
{
    {
    int intId = [ idno intValue ];
    
    NSAssert(((intId >= 0)&&(intId < NUM_OF_VALUES)),QString::fromUtf8("string value referance over flow"));
    
    [ strValues[intId] autorelease ];
    strValues[intId] = setString;
    [ strValues[intId] retain ];
    
}

void TYScripterValues::setIntValue:()
{
    {
    if([ idno respondsToSelector:@selector(intValue) ]){
    NSArray *limitArray;
    int intId = [ idno intValue ];
    
    NSAssert1(((intId >= 0)&&(intId < NUM_OF_VALUES)),QString::fromUtf8("int value referance over flow %d"),intId);
    values[intId] = [ setNumber intValue ];
    if(limitDict && (limitArray = [ limitDict objectForKey:[ idno stringValue ] ])) {
    if(values[intId] < [ [ limitArray objectAtIndex:0 ] intValue ])
    values[intId] = [ [ limitArray objectAtIndex:0 ] intValue ];
    else if(values[intId] > [ [ limitArray objectAtIndex:1 ] intValue ])
    values[intId] = [ [ limitArray objectAtIndex:1 ] intValue ];
    } else {
    TYArrayValue *value;
    value = [ arrayValues objectForKey:[ idno objectAtIndex:0 ] ];
    [ value setNum:setNumber address:[ idno subarrayFromIndex:1 ] ];
    
}

void TYScripterValues::setArrayLine:()
{
    {
    TYArrayValue *value;
    
    value = [ arrayValues objectForKey:[ idno objectAtIndex:0 ] ];
    [ value setNumbers:aArray  address:[ idno subarrayFromIndex:1 ] ];
    
}

void TYScripterValues::defineArrayValue:()
{
    {
    NSNumber *idNo;
    NSMutableArray *incArray;
    
    idNo = [ aArray objectAtIndex:0 ];
    
    // Y+1̒ۂɂ͊mۂKv邽߁AŉH
    {
    NSEnumerator *enu = [ aArray objectEnumerator ];
    id tmp;
    
    incArray = [ NSMutableArray arrayWithCapacity:[ aArray count ] -1 ];
    
    [ enu nextObject ];
    while(tmp = [ enu nextObject ]){
    [ incArray addObject:[ NSNumber numberWithInt:[ tmp intValue ] +1 ] ];
    
    
    [ arrayValues setObject:[ [ TYArrayValue alloc ] initWithID:[ idNo intValue ]
    limits:incArray ]
    forKey:idNo ];
    
}

void TYScripterValues::setIntLimitID:()
{
    {
    if(!limitDict) {
    limitDict = [ [ NSMutableDictionary dictionary ] retain ];
    
    [ limitDict setObject:[ NSArray arrayWithObjects:aLow,aHigh,nullptr ] forKey:[ idno stringValue ] ];
    
}

bool TYScripterValues::loadGlobalValues:()
{
    {
    NSFileHandle *handle;
    int descripter;
    int i,ret;
    unsigned char buf[4];
    NSMutableData *bufData;
    
    handle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    if(!handle)
    return false;
    
    descripter = [ handle fileDescriptor ];
    for(i=MIN_GLOBAL_IDNO; i < MAX_GLOBAL_IDNO ; i++){
    
    bufData = [ [ NSMutableData alloc ] initWithCapacity:1 ];
    
    // ϐ̎擾BgGfBAint^Ŋi[ĂB
    read(descripter,buf,4);
    values[i] = buf[0] + (buf[1] << 8)  + (buf[2] << 16)  + (buf[3] << 24);
    
    // ϐ̎擾BCŊi[ĂB
    while(1){
    ret = read(descripter,buf,1);
    [ bufData appendBytes:buf length:1 ];
    if(!buf[0] || !ret){
    break;
    if([ bufData length ]){
    [ strValues[i] release ];
    strValues[i] = [ NSString stringWithCSJISString:[ bufData bytes ] ];
    [ strValues[i] retain ];
    [ bufData release ];
    
    //close(descripter);
    [ handle closeFile ];
    
    return true;
    
}

bool TYScripterValues::saveGlobalValues:()
{
    {
    NSMutableData *saveData;
    int i;
    unsigned char buf[4];
    NSMutableData *bufData;
    
    saveData = [ NSMutableData dataWithCapacity:(MAX_GLOBAL_IDNO -MIN_GLOBAL_IDNO) *5 ];
    
    for(i=MIN_GLOBAL_IDNO; i < MAX_GLOBAL_IDNO; i++){
    // ϐ̊i[BgGfBAint^Ŋi[B
    buf[0] = values[i] & 0xFF;
    buf[1] = ( values[i] >> 8 ) & 0xFF;
    buf[2] = ( values[i] >> 16 ) & 0xFF;
    buf[3] = ( values[i] >> 24 ) & 0xFF;
    
    [ saveData appendBytes:buf length:4 ];
    
    // ϐ̊i[BCɕϊĊi[B
    bufData = [ strValues[i] getCSJISData ];
    [ saveData appendBytes:[ bufData bytes ] length:[ bufData length] ];
    
    [ saveData writeToFile:path atomically:true ];
    
    return true;
    
}

void TYScripterValues::margeGlobalValues:()
{
    {
    int i;
    
    for(i=MIN_GLOBAL_IDNO; i < MAX_GLOBAL_IDNO; i++){
    if(!values[i]){
    values[i] = margeValues->values[i];
    if(![ strValues[i] length ]){
    [ strValues[i] release ];
    strValues[i] = margeValues->strValues[i];
    [ strValues[i] retain ];
    
}

void TYScripterValues::resetGame()
{
    {
    int i;
    NSString *zero=@"";
    
    for(i=0; i < MIN_GLOBAL_IDNO ; i++){
    values[i] = 0;
    [ strValues[i] release ];
    strValues[i] = zero;
    // const string reference countɊ֌WȂɏ풓̂retainKvB
    
}

void TYScripterValues::dealloc()
{
    {
    int i;
    
    for(i=0; i < NUM_OF_VALUES; i++){
    [ strValues[i] release ];
    [ arrayValues release ];
    [ limitDict release ];
    
    [ super dealloc ];
    
    
}

