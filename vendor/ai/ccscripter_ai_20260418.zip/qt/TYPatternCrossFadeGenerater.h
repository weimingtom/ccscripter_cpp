#ifndef TYPATTERNCROSSFADEGENERATER_H
#define TYPATTERNCROSSFADEGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYPatternCrossFadeGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    void drawEffect();
};

#endif // TYPATTERNCROSSFADEGENERATER_H
