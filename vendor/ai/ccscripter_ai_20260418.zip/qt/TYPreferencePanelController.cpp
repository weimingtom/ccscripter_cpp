#include "TYPreferencePanelController.h"

// Converted from Objective-C

QObject* TYPreferencePanelController::init()
{
    {
    this = [ super init ];
    [ NSBundle loadNibNamed:QString::fromUtf8("Preference")
    owner:this ];
    return this;
    
}

void TYPreferencePanelController::loadEnviroment()
{
    {
    [ scaleInFullScreen setState:([ TYEnviroment boolForKey:TYDisplayResizeAtFullScreenEnviroment ]) ? NSOnState : NSOffState ];
    [ enableBold setState:([ TYEnviroment boolForKey:TYEnableBoldFontEnviroment ]) ? NSOnState : NSOffState ];
    [ enableAutoReplay setState:([ TYEnviroment boolForKey:TYLookbackVoiceReplayEnviroment ]) ? NSOnState : NSOffState ];
    [ bufferStepper setIntValue:[ [ TYEnviroment objectForKey:TYLookbackBufferPageEnviroment  ] intValue ] ];
    [ bufferPage setIntValue:[ [ TYEnviroment objectForKey:TYLookbackBufferPageEnviroment  ] intValue ] ];
    [ enableMovie setState:([ TYEnviroment boolForKey:TYEnablePlayMovieEnviroment ]) ? NSOnState : NSOffState ];
    [ hideOtherFullScreen setState:([ TYEnviroment boolForKey:TYHideOtherFullScreenEnviroment ]) ? NSOnState : NSOffState ];
    [ hideOtherFullScreen setEnabled:[ scaleInFullScreen state ] ];
    
}

QObject* TYPreferencePanelController::panel()
{
    {
    return panel;
    
}

IBAction TYPreferencePanelController::dialogOK:()
{
    {
    [ panel orderOut:this ];
    [ TYEnviroment setObject:[ NSNumber numberWithBool:([ scaleInFullScreen state ] == NSOnState) ]
    forKey:TYDisplayResizeAtFullScreenEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithBool:([ enableBold state ] == NSOnState) ]
    forKey:TYEnableBoldFontEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithInt:([ enableAutoReplay state ] == NSOnState) ? 1 : 0 ]
    forKey:TYLookbackVoiceReplayEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithInt:[ bufferPage intValue ] ]
    forKey:TYLookbackBufferPageEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithBool:([ enableMovie state ] == NSOnState ) ]
    forKey:TYEnablePlayMovieEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithBool:([ hideOtherFullScreen state ] == NSOnState ) ]
    forKey:TYHideOtherFullScreenEnviroment ];
    
    [NSApplication->sharedApplication() stopModalWithCode:NSOKButton ];
    
}

IBAction TYPreferencePanelController::dialogCancel:()
{
    {
    [ panel orderOut:this ];
    [NSApplication->sharedApplication() stopModalWithCode:NSCancelButton ];
    
}

IBAction TYPreferencePanelController::changeFullScreen:()
{
    {
    [ hideOtherFullScreen setEnabled:[ sender state ] ];
    
    
}

