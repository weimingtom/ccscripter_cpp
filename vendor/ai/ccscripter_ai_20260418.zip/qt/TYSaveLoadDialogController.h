#ifndef TYSAVELOADDIALOGCONTROLLER_H
#define TYSAVELOADDIALOGCONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYSaveLoadDialogController : public QObject
{
    Q_OBJECT
public:
    IBAction dialogOk:();
    IBAction dialogCancel:();
    IBAction doubleClick:();
    NSWindow* window();
    void setTitle:(void value);
    void setNumber:(void value);
    int number();
    void setDate:(void value);
    void setLoaded:(void value);
    bool isLoaded();
    void setLoadMode:(void value);
    int selectedRow();
};

#endif // TYSAVELOADDIALOGCONTROLLER_H
