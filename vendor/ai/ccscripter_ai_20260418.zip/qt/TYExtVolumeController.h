#ifndef TYEXTVOLUMECONTROLLER_H
#define TYEXTVOLUMECONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYExtVolumeController : public TYBGMVolumeController
{
    Q_OBJECT
public:
    void setDefault:(IBAction value);
    QObject* initWithDefaultBGMVolume:();
    float voiceVolume();
    float seVolume();
};

#endif // TYEXTVOLUMECONTROLLER_H
