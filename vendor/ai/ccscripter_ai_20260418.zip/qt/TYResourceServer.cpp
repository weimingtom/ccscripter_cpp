#include "TYResourceServer.h"

// Converted from Objective-C

QObject* TYResourceServer::init()
{
    {
    [ super init ];
    
    ty_archivers = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    effectPatternDict = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    
    defaultTransmode = DEFAULT_TRANSMODE;
    
    // ݂DVDŗpb菈BNBZvOC炩߃[hB
    [ this addSoundPressPlugin:nullptr extension:QString::fromUtf8("nbz") ];
    
    return this;
    
}

void TYResourceServer::addArchiver:()
{
    {
    TYArchiver *arc;
    NSString *arcPath;
    
    // path DLL̎w肪܂܂ĂjB
    arcPath = [ [ path componentsSeparatedByString:QString::fromUtf8("|") ] objectAtIndex:0 ];
    
    arc = [ [ TYArchiver alloc ] initWithContentsOfFile:
    [ getNScrRootDirectory() stringByAppendingPathComponent:arcPath ] ];
    
    if (arc) [ ty_archivers addObject:arc ];
    
}

NSString* TYResourceServer::getFilePath:()
{
    {
    NSString *convPath;
    
    convPath = winPathToUnix(path) ;
    convPath = [ getNScrRootDirectory() stringByAppendingPathComponent:convPath ];
    
    return ([ [ NSFileManager defaultManager ] fileExistsAtPath:convPath
    isDirectory:false ]) ? convPath : nullptr ;
    
    
}

NSString* TYResourceServer::getFilePathMakeTemp:()
{
    {
    NSString *diskPath;
    
    diskPath = [ this getFilePath:path ];
    if(diskPath)
    return diskPath;
    else
    return nullptr;
    
}

NSData* TYResourceServer::getData:()
{
    {
    NSEnumerator *enu;
    TYArchiver *arc;
    NSData *data;
    NSString *convPath;
    
    if((!path)||(![ path length])){
    return nullptr;
    
    path = winPathToUnix(path);
    
    enu = [ ty_archivers objectEnumerator ];
    while( (arc = [ enu nextObject ]) != nullptr ){
    data = [ arc unArchivedFile:path ];
    if(data)
    return data;
    
    // o^ꂽA[JCot@C擾łȂB
    // pXfBXN̂̂ɕϊăt@CB
    convPath = [ getNScrRootDirectory() stringByAppendingPathComponent:path ];
    return [ NSData dataWithContentsOfFile:convPath ];
    
}

NSBitmapImageRep* TYResourceServer::getBitmap:()
{
    {
    NSString* extension;
    TYDecompresser<TYBitmapDecoder> *decompresser;
    NSEnumerator *enu;
    NSFileHandle *handle;
    id decodeObj;
    TYArchiver *arc;
    int length;
    NSDictionary *fileAttDict;
    
    path = [ path lowercaseString ];
    // vOC`΂gBȂł̉R[h
    if(spiPluginDict){
    extension = [ path pathExtension ];
    decompresser = [ spiPluginDict objectForKey:extension ];
    if(decompresser){
    enu = [ ty_archivers objectEnumerator ];
    while( (arc = [ enu nextObject ]) != nullptr ){
    handle = [ arc fileHandleWithPath:path length:&length ];
    if(handle){
    return [ decompresser decodeBitmapWithFileHandle:handle length:length ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:path ];
    if(fileAttDict = [ [ NSFileManager defaultManager ] fileAttributesAtPath:path traverseLink:false ]){
    length = [ [ fileAttDict objectForKey:NSFileSize ] intValue ];
    handle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    return [ decompresser decodeBitmapWithFileHandle:handle length:length ];
    return nullptr;
    
    decodeObj = [ this getData:path ];
    // A[JCuspbkf[^bitmapԂĂ̂
    if([ decodeObj isKindOfClass:[ NSData class ] ]){
    return [ [ [ NSBitmapImageRep alloc ] initWithData:decodeObj ] autorelease ];
    } else {
    return decodeObj;
    
    return nullptr;
    
}

NSImage* TYResourceServer::getImage:()
{
    {
    NSString *filePath;
    NSArray *pathArray,*tagArray;
    NSString *transmode;
    NSBitmapImageRep *bitmap=nullptr;
    //NSArray *interValArray;
    NSNumber *intervalValue;
    NSString *animeOperate;
    //id aObj;
    
    // 摜^O擾
    pathArray = [ path componentsSeparatedByString:QString::fromUtf8(";") ];
    tagArray = ([ pathArray count ] != 1) ? [ [ pathArray objectAtIndex:0 ] componentsSeparatedByString:QString::fromUtf8("/") ] : nullptr;
    if(!aBool){
    transmode = TYTRANSMODE_COPY;
    } else if([ path length ] > 2 &&
    [ [ path substringWithRange:NSMakeRange(0,2) ] isEqualToString:QString::fromUtf8(":s") ]){
    // XvCg
    return [ this getImageFromString:[ path substringFromIndex:2 ] ];
    } else if([ pathArray count ] == 1){
    transmode = defaultTransmode;
    } else {
    transmode = [ tagArray objectAtIndex:0 ];
    transmode = [ transmode substringFromIndex:1 ];
    
    if(filelog){
    [ this addlog:path ];
    
    
    // t@C̃pX؂o
    filePath = winPathToUnix([ [ path componentsSeparatedByString:QString::fromUtf8(";") ] lastObject ]);
    
    bitmap = [ this getBitmap:filePath ];
    
    if(!bitmap){
    NSLog(QString::fromUtf8("failed to load Image from Archives and disk [%@]"),path);
    return nullptr;
    
    // Aj[V^O擾
    if(isAnimate){
    int cellCount;
    //NSBitmapImageRep **bmpArrayPtr;
    //NSImage **imageArrayPtr;
    NSArray *bitmapArray;
    NSMutableArray *imageArray;
    
    if([ tagArray count ] == 2){
    int i;
    NSNumber *loopType;
    NSArray *animeOperateArray;
    //NSImage *trImage;
    
    animeOperate = [ tagArray lastObject ];
    
    /*
    if([ [ animeOperate substringWithRange:NSMakeRange(0,1) ] isEqualToString:QString::fromUtf8(":") ]){
    // AjwȂ
    return [ this transrateImageFromBitmap:bitmap transMode:transmode ];
    */
    
    // Ƃ肠PC^[õ[v݂̂ŁB
    animeOperateArray = [ animeOperate componentsSeparatedByString:QString::fromUtf8(",") ];
    
    cellCount = [ [ animeOperateArray objectAtIndex:0 ] intValue ];
    intervalValue = [ NSNumber numberWithInt:[ [ animeOperateArray objectAtIndex:1 ] intValue ] ];
    loopType = [ NSNumber numberWithInt:[ [ animeOperateArray objectAtIndex:2 ] intValue ] ];
    
    [ bitmap resizeToPixelsSize ];
    bitmapArray = [ bitmap horizontalDivide:cellCount ];
    
    imageArray = [ NSMutableArray array ];
    for(i=0; i < cellCount; i++){
    [ imageArray addObject:[ this transrateImageFromBitmap:[ bitmapArray objectAtIndex:i ] transMode:transmode ] ];
    
    return [ [ [ TYAnimationCellImage alloc ] initWithImages:imageArray
    infoDict:[ NSDictionary dictionaryWithObjectsAndKeys:loopType,TYAnimationModeInfo,intervalValue,TYAnimationIntervalInfo,nullptr ] ] autorelease ];
    
    
    // rbg}bvϊ
    return [ this transrateImageFromBitmap:bitmap transMode:transmode ];
    
    
}

NSImage* TYResourceServer::getImage:()
{
    {
    return [ this getImage:path transMode:aBool animate:false ];
    
}

NSImage* TYResourceServer::transrateImageFromBitmap:()
{
    {
    NSImage *image;
    NSImageRep *rep;
    NSBitmapImageRep *maskBitmap;
    NSImage *maskImage;
    
    image = [ [ [ NSImage alloc ] initWithSize:NSZeroSize ] autorelease ];
    [ image addRepresentation:bitmap ];
    if([ transmode isEqualToString:TYTRANSMODE_ALPHA ]){
    // }XNt摜t@C
    image = ConvertImagePackedAlpha(image);
    } else if ([ transmode isEqualToString:TYTRANSMODE_COPY ]){
    //image = [ [ [ NSImage alloc ] initWithData:aData ] autorelease ];
    ;
    } else if ([ transmode isEqualToString:TYTRANSMODE_LEFTTOP ]){
    image = ConvertImageTransrateLeftTop(image);
    } else if ([ transmode isEqualToString:TYTRANSMODE_MASK ]){
    maskBitmap = [ this getBitmap:[ transmode substringFromIndex:2 ] ];
    maskImage = [ [ [ NSImage alloc ] initWithSize:NSZeroSize ] autorelease ];
    image = ConvertImageWithMaskImage(image,maskImage);
    } else {
    //image = [ [ [ NSImage alloc ] initWithData:aData ] autorelease ];
    ;
    
    // pixelTCYɕ␳
    rep = [ image bestRepresentationForDevice:nullptr ];
    [ rep setSize:NSMakeSize([ rep pixelsWide ],[ rep pixelsHigh ]) ];
    [ image setSize:NSMakeSize([ rep pixelsWide ],[ rep pixelsHigh ]) ];
    
    return image;
    
}

NSImage* TYResourceServer::getImageFromString:()
{
    {
    //NSCharacterSet *cset = [ NSCharacterSet alphanumericCharacterSet ];
    NSString *buffer;
    NSMutableArray *colors = [ NSMutableArray array ];
    int i,len;
    TYStageManager *manager = [ TYStageManager sharedManager ];
    NSArray *images;
    BOOL isOrgSize=false; // TCYwtO
    int fontWidth,fontHeight,fontInterval;
    NSMutableDictionary *textAttDict;
    
    // ̕ϐWJ
    str = [ [ TYScriptEngine sharedEngine ] stringOfReplaceVars:str ];
    
    if([ [ str substringWithRange:NSMakeRange(0,1) ] isEqualToString:QString::fromUtf8("/") ]){
    // TCYwtXvCg
    NSString *substr;
    NSScanner *scanner;
    
    isOrgSize = true;
    scanner = [ NSScanner scannerWithString:[ str substringFromIndex:1 ] ];
    
    [ scanner scanUpToString:QString::fromUtf8(",") intoString:&substr ];
    fontWidth = [ substr intValue ];
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    [ scanner scanUpToString:QString::fromUtf8(",") intoString:&substr ];
    fontHeight = [ substr intValue ];
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    [ scanner scanUpToString:QString::fromUtf8(";") intoString:&substr ];
    fontInterval = [ substr intValue ];
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    // tHgTCY͏cȀɍ킹
    if(fontWidth < fontHeight)
    fontHeight = fontWidth;
    else if(fontWidth > fontHeight)
    fontWidth = fontHeight;
    
    textAttDict = [ [ manager textAttDict ] mutableCopy ];
    {
    NSFont *aFont = [ textAttDict objectForKey:NSFontAttributeName ];
    [ textAttDict setObject:[ NSFont fontWithName:[ aFont fontName ] size:fontHeight ]
    forKey:NSFontAttributeName ];
    
    str = [ [ scanner string ] substringFromIndex:[ scanner scanLocation ] ];
    
    i=0;
    len = [ str length ];
    while((i < len) && [ [ str substringWithRange:NSMakeRange(i,1)] isEqualToString:QString::fromUtf8("#") ]){
    buffer = [ str substringWithRange:NSMakeRange(i,7) ];
    [ colors addObject:getColorWithHTMLFormat(buffer) ];
    i+=7;
    
    images = [ TYStringImage imagesWithString:[ str substringFromIndex:i ]
    attributes:(!isOrgSize) ? [ manager textAttDict ] : textAttDict
    colors:colors
    fontHeight:(!isOrgSize) ? [ manager textFontHeight ] : fontHeight
    fontWidth:(!isOrgSize) ? [ manager textFontWidth ] : fontWidth
    interval:[ manager textPitchx ]
    shadow:[ manager isShadow ] ];
    
    return [ [ [ TYCellImage alloc ] initWithImages:images ] autorelease ];
    
}

void TYResourceServer::addSpi:()
{
    {
    // 摜f[^𓀃vOC̃[h
    
    if(!spiPluginDict){
    spiPluginDict = [ [ NSMutableDictionary dictionary ] retain ];
    
    // MEMO:Ooh̓ǂݍ݂\ɂB
    extension = [ extension lowercaseString ];
    if([ extension isEqualToString:QString::fromUtf8("nbz") ]){
    [ spiPluginDict setObject:[ [ [ TYNBZDecompresser alloc ] init ] autorelease ] forKey:extension ];
    
    
}

void TYResourceServer::addSoundPressPlugin:()
{
    {
    // f[^𓀃vOC̃[h
    
    if(!soundPressPluginDict){
    soundPressPluginDict = [ [ NSMutableDictionary dictionary ] retain ];
    
    // MEMO:Ooh̓ǂݍ݂\ɂB
    extension = [ extension lowercaseString ];
    if([ extension isEqualToString:QString::fromUtf8("nbz") ]){
    [ soundPressPluginDict setObject:[ [ [ TYNBZDecompresser alloc ] init ] autorelease ] forKey:extension ];
    
    
}

NSData* TYResourceServer::getSoundData:()
{
    {
    NSEnumerator *enu;
    TYArchiver *arc;
    NSData *data;
    NSString *convPath;
    NSString *extension;
    TYDecompresser<TYDataDecoder> *decompresser;
    NSFileHandle *handle;
    int length;
    NSDictionary *fileAttDict;
    
    if((!path)||(![ path length])){
    return nullptr;
    
    // pX̃f~^ϊ
    convPath = winPathToUnix(path);
    convPath = [ convPath lowercaseString ];
    
    // vOC`΂gBȂł̉R[h
    if(soundPressPluginDict){
    extension = [ convPath pathExtension ];
    decompresser = [ soundPressPluginDict objectForKey:extension ];
    if(decompresser){
    enu = [ ty_archivers objectEnumerator ];
    while( (arc = [ enu nextObject ]) != nullptr ){
    handle = [ arc fileHandleWithPath:convPath length:&length ];
    if(handle){
    data = [ decompresser decodeDataWithFileHandle:handle length:length ];
    return data;
    convPath = [ getNScrRootDirectory() stringByAppendingPathComponent:convPath ];
    if(fileAttDict = [ [ NSFileManager defaultManager ] fileAttributesAtPath:convPath traverseLink:false ]){
    length = [ [ fileAttDict objectForKey:NSFileSize ] intValue ];
    handle = [ NSFileHandle fileHandleForReadingAtPath:convPath ];
    data = [ decompresser decodeDataWithFileHandle:handle length:length ];
    return data;
    return nullptr;
    
    return [ this getData:convPath ];
    
}

void TYResourceServer::addlog:()
{
    {
    [ filelogDict setObject:[ NSNumber numberWithBool:true ] forKey:[ filename uppercaseString ] ];
    
}

void TYResourceServer::setDefaultTransMode:()
{
    {
    defaultTransmode = [ transmode retain ];
    
}

bool TYResourceServer::fchk:()
{
    {
    return ([ filelogDict objectForKey:[ filename uppercaseString ] ]) ? true : false;
    
}

bool TYResourceServer::filelog:()
{
    {
    NSFileHandle *handle;
    NSMutableData *bufData;
    int fileNum;
    int descripter;
    unsigned char buf;
    int i,ret;
    
    filelogDict = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    
    // MEMO:ł܂OofBNg̏݌`FbNB
    
    filelog=true;
    
    handle = [ NSFileHandle fileHandleForReadingAtPath:path ];
    if(!handle){
    return true;
    descripter = [ handle fileDescriptor ];
    
    /*
    filelogDict = [ [ NSMutableDictionary alloc ] initWithContentsOfFile:
    [ getAppDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    */
    
    
    bufData = [ NSMutableData dataWithCapacity:1 ];
    while(read(descripter,&buf,1)){
    if(buf == 0x0a)
    break;
    else
    [ bufData appendBytes:&buf length:1 ];
    [ bufData appendBytes:"" length:1 ];
    fileNum = atoi([ bufData bytes ]);
    
    for(i=0; i < fileNum; i++){
    ret = read(descripter,&buf,1);
    if((!ret)||(buf != '"'))
    break;
    
    bufData = [ NSMutableData dataWithCapacity:1 ];
    
    while(read(descripter,&buf,1)&&(buf!='"')){
    [ bufData appendBytes:&buf length:1 ];
    [ bufData XORMaskToAllBytes:132 ]; // XOR}XNĂ̂Ŗ߂B
    [ bufData appendBytes:"" length:1 ];
    
    [ filelogDict setObject:[ NSNumber numberWithBool:true ]
    forKey:[ NSString stringWithCSJISString:[ bufData bytes ] ] ];
    
    [ handle closeFile ];
    
    return true;
    
}

bool TYResourceServer::saveLog:()
{
    {
    char numbuf[12];
    NSMutableData *writeData;
    NSMutableData *data;
    int count;
    NSEnumerator *enm;
    id temp;
    
    if(filelog){
    //[ filelogDict writeToFile:[ getAppDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] atomically:true ];
    writeData = [ NSMutableData dataWithCapacity:2 ];
    count = [ filelogDict count ];
    sprintf(numbuf,"%d\n",count);
    [ writeData appendBytes:numbuf length:strlen(numbuf) ];
    
    enm = [ filelogDict keyEnumerator ];
    while((temp = [ enm nextObject ]) != nullptr){
    [ writeData appendBytes:"\"" length:1 ];
    data = [ [ [ temp sjisData ] mutableCopy ] autorelease ];
    [ data XORMaskToAllBytes:132 ];
    [ writeData appendData:data ];
    [ writeData appendBytes:"\"" length:1 ];
    [ writeData writeToFile:path atomically:true ];
    
    return true;
    
}

void TYResourceServer::addEffectPattern:()
{
    {
    TYEffectPatternMap *pattern;
    NSBitmapImageRep *bmp;
    
    bmp = [ this getBitmap:path ];
    if(bmp){
    pattern = [ [ TYEffectPatternMap alloc ] initWithBitmap:bmp ];
    if(pattern){
    [ effectPatternDict setObject:pattern forKey:path ];
    [ pattern release ];
    
}

TYEffectPatternMap* TYResourceServer::getEffectPattern:()
{
    {
    id tmp;
    if(tmp = [ effectPatternDict objectForKey:path ])
    return tmp;
    
    [ this addEffectPattern:path ];
    return [ effectPatternDict objectForKey:path ];
    
}

void TYResourceServer::executeBundle:()
{
    {
    NSString *bundlePath,*argStr = nullptr;
    NSBundle *bundle;
    id<TYExecutablePlugin> plugin;
    
    // DLLƈ̃p[X
    {
    NSScanner *scanner = [ NSScanner scannerWithString:pathAndArg ];
    NSString *str;
    NSString *dllPath;
    
    if(![ scanner scanUpToString:QString::fromUtf8("/") intoString:&str ]) {
    dllPath = pathAndArg;
    } else {
    dllPath = str;
    argStr = [ pathAndArg substringFromIndex:[ scanner scanLocation ] +1 ];
    
    bundlePath = [ [ dllPath stringByDeletingPathExtension ] stringByAppendingPathExtension:QString::fromUtf8("bundle") ];
    
    plugin = [ executableBundles objectForKey:bundlePath ];
    if(plugin == nullptr) {
    bundle = [ NSBundle bundleWithPath:[ getAppDirectory() stringByAppendingPathComponent:bundlePath ] ];
    [ bundle load ];
    plugin = [ [ [ [ bundle principalClass ] alloc ] init ] autorelease ];
    
    if(plugin == nullptr) {
    NSLog(QString::fromUtf8("can't load bundle %@"),bundlePath);
    return;
    
    [ executableBundles setObject:plugin forKey:bundlePath ];
    
    [ plugin execPlugin:[ TYCCSProxy proxy ] argment:argStr];
    
}

void TYResourceServer::dealloc()
{
    {
    [ ty_archivers release];
    super->dealloc();
    
    
}

