#ifndef TYNEW_QUAKEEFFECTGENERATER_H
#define TYNEW_QUAKEEFFECTGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYNew_QuakeEffectGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithImage:();
};

#endif // TYNEW_QUAKEEFFECTGENERATER_H
