#ifndef TYPREFERENCEPANELCONTROLLER_H
#define TYPREFERENCEPANELCONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYPreferencePanelController : public QObject
{
    Q_OBJECT
public:
    void loadEnviroment();
    QObject* panel();
    IBAction dialogOK:();
    IBAction dialogCancel:();
    IBAction changeFullScreen:();
};

#endif // TYPREFERENCEPANELCONTROLLER_H
