#include "TYSarArchivedFile.h"

// Converted from Objective-C

QObject* TYSarArchivedFile::initFileoffset:()
{
    {
    this = [ super init ];
    
    fileOffset = offset;
    fileLength = length;
    
    return this;
    
    /// t@C̓o^ɓĕԂB
}

void TYSarArchivedFile::getFileDataOffset:()
{
    {
    *offsetarg = fileOffset;
    *lengtharg = fileLength;
    
    return;
    
}

