#ifndef TYRESOURCESERVER_H
#define TYRESOURCESERVER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYResourceServer : public QObject
{
    Q_OBJECT
public:
    void addArchiver:();
    NSString* getFilePath:();
    NSData* getData:();
    NSImage* getImage:();
    NSImage* getImage:();
    NSImage* getImageFromString:();
    NSBitmapImageRep* getBitmap:();
    NSImage* transrateImageFromBitmap:();
    NSData* getSoundData:();
    TYEffectPatternMap* getEffectPattern:();
    NSString* getFilePathMakeTemp:();
    void addSpi:();
    void addSoundPressPlugin:();
    void setDefaultTransMode:(void value);
    void addEffectPattern:();
    void executeBundle:();
    bool filelog:();
    void addlog:();
    bool fchk:();
    bool saveLog:();
};

#endif // TYRESOURCESERVER_H
