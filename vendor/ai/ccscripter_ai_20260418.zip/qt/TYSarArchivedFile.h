#ifndef TYSARARCHIVEDFILE_H
#define TYSARARCHIVEDFILE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYSarArchivedFile : public QObject
{
    Q_OBJECT
public:
    QObject* initFileoffset:();
    void getFileDataOffset:();
};

#endif // TYSARARCHIVEDFILE_H
