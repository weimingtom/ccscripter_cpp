#ifndef TYSCRIPTENGINE_H
#define TYSCRIPTENGINE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYScriptEngine : public QObject
{
    Q_OBJECT
public:
    QObject* initWithContentsOfFile:();
    void setController:(void value);
    void runScript();
    bool eval:();
    bool breakRun();
    void setBreakRun:(void value);
    void lineEnd();
    void jump:();
    void labeljump:();
    void labeljump:();
    void jumpToLoopEnd();
    void saveExternalData();
    void saveGlobal();
    void saveLabelLog();
    int runLine();
    void moveRunLine:();
    void incRunColumn();
    void resetRunColumn();
    void registLoop:();
    void registLoopTargetID:();
    int splitArgNormal:();
    int splitArgCondition:();
    bool isMultLineSupport:();
    char* nextLine();
    QObject* getIdNoOfArgment:();
    QObject* getArrayIdOfArgment:();
    QObject* getValueOfArgment:();
    QObject* getStringOfArgment:();
    QObject* getEffectNoOfArgments:();
    NSString* stringOfReplaceVars:();
    bool judgefchk:();
    bool judgelchk:();
    bool judgeCondition:();
    void addLabelLog:();
    QObject* intNumberWithVarID:();
    QObject* stringValueWithVarID:();
    QObject* intNumberWithAlias:();
    QObject* stringValueWithAlias:();
    void movRepeat:();
    void fireOfTrap();
    void fireOfTextgosub:();
    void enableKidoku();
    void setWatchKidoku:(void value);
    void resetGame();
    bool isModeSVGA();
    int scanGlobalValue();
    void startPrint:();
    void ty_mov:();
    void ty_goto:();
    void ty_nsa:();
    void ty_trap:();
};

#endif // TYSCRIPTENGINE_H
