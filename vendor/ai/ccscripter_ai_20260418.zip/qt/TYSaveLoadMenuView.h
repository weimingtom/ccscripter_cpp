#ifndef TYSAVELOADMENUVIEW_H
#define TYSAVELOADMENUVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYSaveLoadMenuView : public TYMenuModeView
{
    Q_OBJECT
public:
    QObject* initWithFrame:();
};

#endif // TYSAVELOADMENUVIEW_H
