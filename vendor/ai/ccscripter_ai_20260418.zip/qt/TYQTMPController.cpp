#include "TYQTMPController.h"

// Converted from Objective-C

void TYQTMPController::applicationDidFinishLaunching()
{
    {
    NSMovie *aMovie;
    TYQTMusicPlayer *player;
    
    player = [ [ TYQTMusicPlayer alloc ] initWithFrame:NSZeroRect ];
    aMovie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:QString::fromUtf8("/Users/shohei/SimpleCocoaMovie/MovieFile.mov") ] byReference:true ];
    //[ MovieViewObject setMovie:aMovie ];
    [ player setMovie:aMovie ];
    [ player setLoopMode:NSQTMovieLoopingPlayback ];
    [ player start:nullptr ];
    
    
    
}

