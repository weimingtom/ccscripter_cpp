#ifndef TYPATTERNFADEGENERATER_H
#define TYPATTERNFADEGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYPatternFadeGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    void drawEffect();
};

#endif // TYPATTERNFADEGENERATER_H
