#include "TYBitOperator.h"

// Converted from Objective-C

QObject* TYBitOperator::initWithFileHandle:()
{
    {
    this = [ super init ];
    
    fh = [ f retain ];
    size = s;
    
    mask = 0x100;
    tmp = *(unsigned char*)[ [ fh readDataOfLength:1 ] bytes ];
    
    return this;
    
}

int TYBitOperator::get()
{
    {
    mask >>= 1;
    if (mask == 0x00) {
    NSAssert((size != 0),QString::fromUtf8("Over Limit Size"));
    size--;
    tmp = *(unsigned char*)[ [ fh readDataOfLength:1 ] bytes ];
    mask = 0x80;
    return (tmp & mask) ? 1 : 0;
    
}

unsigned int TYBitOperator::getWithLength:()
{
    {
    unsigned int v;
    
    NSAssert((n > 0 && n <= 32),QString::fromUtf8("invalid bit length"));
    
    for (v = 0; n > 0; n--) {
    v <<= 1;
    if ([ this get ])
    v |= 1;
    return v;
    
    
}

void TYBitOperator::dealloc()
{
    {
    [ fh release ];
    super->dealloc();
    
    TYCoreBitOperater TYCreateCoreBitOperater(NSFileHandle* f,unsigned int s)
    {
    TYCoreBitOperater mySelf;
    int result;
    
    mySelf = malloc(sizeof(struct tyCoreBitOperater));
    if(mySelf==NULL)
    return NULL;
    
    mySelf->fd = [ f fileDescriptor ];
    //mySelf->size = s;
    mySelf->mask = 0x100;
    result = read(mySelf->fd,&mySelf->tmp,1);
    if(!result){
    TYReleaseCoreBitOperater(mySelf);
    return NULL;
    
    return mySelf;
    
    __inline__ int TYGetCoreBitOperater(TYCoreBitOperater mySelf)
    {
    mySelf->mask >>= 1;
    if (mySelf->mask == 0x00) {
    //NSCAssert((mySelf->size != 0),QString::fromUtf8("Over Limit Size"));
    //mySelf->size--;
    read(mySelf->fd,&mySelf->tmp,1);
    mySelf->mask = 0x80;
    return (mySelf->tmp & mySelf->mask) ? 1 : 0;
    
    __inline__ unsigned int TYGetBitsCoreBitOperater(TYCoreBitOperater mySelf,int n)
    {
    unsigned int v=0;
    
    //NSCAssert((n > 0 && n <= 32),QString::fromUtf8("invalid bit length"));
    
    for (v = 0; n > 0; n--) {
    v <<= 1;
    
    mySelf->mask >>= 1;
    if (mySelf->mask == 0x00) {
    read(mySelf->fd,&mySelf->tmp,1);
    mySelf->mask = 0x80;
    if (mySelf->tmp & mySelf->mask)
    //if (TYGetCoreBitOperater(mySelf))
    v |= 1;
    return v;
    
    void TYReleaseCoreBitOperater(TYCoreBitOperater mySelf)
    {
    free(mySelf);
    
    
}

