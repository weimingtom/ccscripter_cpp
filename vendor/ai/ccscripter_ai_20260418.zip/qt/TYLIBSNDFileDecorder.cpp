#include "TYLIBSNDFileDecorder.h"

// Converted from Objective-C

QObject* TYLIBSNDFileDecorder::initWithData:()
{
    {
    [ super init ];
    
    tempPath = [ [ [ NSBundle bundleForClass:[ this class ] ] resourcePath ] stringByAppendingPathComponent:QString::fromUtf8(".TEMP") ];
    [ tempPath retain ];
    [ sourceData writeToFile:tempPath atomically:false ];
    
    return this;
    
}

bool TYLIBSNDFileDecorder::getSamples:()
{
    frames:(int*)frames
    channels:(int*)channels
    rate:(int*)rate
    {
    SNDFILE *infile;
    SF_INFO in_info;
    
    /*
    if((in_info = malloc(sizeof(SF_INFO))) == NULL){
    NSLog(QString::fromUtf8("can't allocate SF_INFO"));
    return false;
    */
    
    if((infile = sf_open([ tempPath fileSystemRepresentation ],
    SFM_READ,
    &in_info)) == NULL){
    sf_perror(infile);
    return false;
    
    if((samples = malloc(sizeof(short) * in_info.frames * in_info.channels)) == NULL){
    sf_perror(infile);
    return false;
    
    if(sf_readf_short(infile,samples,in_info.frames) != in_info.frames){
    sf_perror(infile);
    return false;
    
    *samples_ptr = samples;
    *frames = in_info.frames;
    *channels = in_info.channels;
    *rate = in_info.samplerate;
    
    sf_close(infile);
    
    return true;
    
}

void TYLIBSNDFileDecorder::dealloc()
{
    {
    [ [ NSFileManager defaultManager ] removeFileAtPath:tempPath handler:nullptr ];
    [ tempPath release ];
    free(samples);
    super->dealloc();
    
    
}

