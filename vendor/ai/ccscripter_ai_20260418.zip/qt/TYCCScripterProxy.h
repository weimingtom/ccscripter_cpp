#ifndef TYCCSCRIPTERPROXY_H
#define TYCCSCRIPTERPROXY_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // TYCCSCRIPTERPROXY_H
