#ifndef TYANIMATIONCELLIMAGE_H
#define TYANIMATIONCELLIMAGE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYAnimationCellImage : public TYCellImage
{
    Q_OBJECT
public:
    QObject* initWithImages:();
    void setDelegate:(void value);
    QObject* delegate();
    void changingCell();
    void didChangeCell:();
    void play();
    bool isPlaying();
    void stop();
    void resume();
    void setNextTimer(void value);
};

#endif // TYANIMATIONCELLIMAGE_H
