#ifndef TYENVIROMENT_H
#define TYENVIROMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYEnviroment : public QObject
{
    Q_OBJECT
public:
};

#endif // TYENVIROMENT_H
