#include "lzss.h"

// Converted from Objective-C

