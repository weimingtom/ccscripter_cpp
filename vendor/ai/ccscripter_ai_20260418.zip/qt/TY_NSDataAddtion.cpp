#include "TY_NSDataAddtion.h"

// Converted from Objective-C

int TY_NSDataAddtion::getBitAtIndex:()
{
    {
    if([ this length ] < (aIndex >> 3))
    return 0;
    
    return *((const unsigned char*)[ this bytes ]+(aIndex >> 3)) & (1 << (aIndex & 0x7));
    
    
    @implementation NSMutableData(TYBitAccess)
}

void TY_NSDataAddtion::setBit:()
{
    {
    int needLength = aIndex >> 3;
    unsigned char* setptr;
    
    if([ this length ] < needLength){
    [ this setLength:needLength ];
    if(!aBit)
    return ;
    *((unsigned char*)[ this mutableBytes ]+(aIndex >> 3)) = 1 << (aIndex & 0x7);
    } else {
    setptr = (unsigned char*)[ this mutableBytes ]+(aIndex >> 3);
    if(aBit)
    *setptr |= 1 << (aIndex & 0x7);
    else
    *setptr &= ~(1 << (aIndex & 0x7));
    
    
    
    @implementation NSMutableData(TY_NSDataAddtion)
    
}

void TY_NSDataAddtion::XORMaskToAllBytes:()
{
    {
    int i,len;
    unsigned char* byte;
    
    byte = [ this mutableBytes ];
    
    for(i = 0,len = [ this length ]; i < len; i++,byte++){
    *byte = *byte ^ code;
    
    
}

