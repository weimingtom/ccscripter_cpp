#ifndef TYWAITCURSOR_H
#define TYWAITCURSOR_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYWaitCursor : public QObject
{
    Q_OBJECT
public:
    QObject* initWithResource:();
    void setDelegate:(void value);
    void loadImage();
    void drawToView:();
    void clear();
    void stop();
    void resume();
    QObject* compositeLayer();
    void drawImage:();
};

#endif // TYWAITCURSOR_H
