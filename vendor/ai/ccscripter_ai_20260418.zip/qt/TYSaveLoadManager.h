#ifndef TYSAVELOADMANAGER_H
#define TYSAVELOADMANAGER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYSaveLoadManager : public QObject
{
    Q_OBJECT
public:
    void setNames:(void value);
    NSArray* names();
    void setNumber:(void value);
    int number();
    void resetDateWithNumber:();
    void dataLoad();
    NSArray* dateStrings:();
    NSArray* existsArray();
};

#endif // TYSAVELOADMANAGER_H
