#ifndef TYMOVIECONTROLLERVIEW_H
#define TYMOVIECONTROLLERVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYMovieControllerView : public QWidget
{
    Q_OBJECT
public:
    void setController:(void value);
};

#endif // TYMOVIECONTROLLERVIEW_H
