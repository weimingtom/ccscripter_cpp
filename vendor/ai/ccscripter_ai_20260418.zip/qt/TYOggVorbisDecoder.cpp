#include "TYOggVorbisDecoder.h"

// Converted from Objective-C

QObject* TYOggVorbisDecoder::initWithData:()
{
    {
    this = [ super init ];
    
    ovData = [ sourceData retain ];
    ovPtr = [ ovData bytes ];
    
    return this;
    
}

bool TYOggVorbisDecoder::getSamples:()
{
    frames:(int*)frames
    channels:(int*)channels
    rate:(int*)rate
    {
    OggVorbis_File vf;
    ov_callbacks cb;
    TYOVFileData fileData;
    cb.read_func = TYOVRead;
    cb.seek_func = TYOVSeek;
    cb.close_func = TYOVClose;
    cb.tell_func = TYOVTell;
    
    // オープン処理
    {
    int ret;
    
    fileData.stPtr = ovPtr;
    fileData.cursor = 0;
    fileData.length = [ ovData length ];
    
    ret = ov_open_callbacks(&fileData, &vf, NULL, 0, cb);
    
    if (ret != 0) {
    NSLog(QString::fromUtf8("can't open ogg vorbis file!"));
    ov_clear(&vf);
    return false;
    
    // ファイル情報の取得
    {
    vorbis_info *vi;
    
    vi = ov_info(&vf, -1);
    
    if (vi == NULL) {
    NSLog(QString::fromUtf8("can't get ogg vorbis info!"));
    ov_clear(&vf);
    return false;
    
    *channels = vi->channels;
    *rate = vi->rate;
    
    // 総サンプル数の取得
    {
    *frames = ov_pcm_total(&vf, -1);
    if (*frames == OV_EINVAL) {
    NSLog(QString::fromUtf8("ogg vorbis invalid pcm total error!"));
    ov_clear(&vf);
    return false;
    
    // 読みこみ
    {
    static const int MAX_BUFFER_LENGTH = 4096;
    int readLength = 0;
    int dataLength = *frames * *channels * 2;
    char *readPtr;
    
    // 読み込み結果格納オブジェクト確保
    sampleData = [ [ NSMutableData alloc ] initWithLength:dataLength ];
    readPtr = [ sampleData mutableBytes ];
    *samples_ptr = [ sampleData mutableBytes ];
    
    while (1) {
    int ret;
    int length;
    
    // 読みこみ長の決定
    if (dataLength -readLength > MAX_BUFFER_LENGTH) {
    length = MAX_BUFFER_LENGTH;
    } else {
    length = dataLength -readLength;
    if (length == 0) {
    break;
    
    // 読み込みと結果チェック
    ret = ov_read(&vf, readPtr, length, 1, 2, 1, NULL);
    if (ret <= 0) {
    if (ret == 0) {
    break;
    } else if (ret == OV_HOLE) {
    NSLog(QString::fromUtf8("OV_HOLE ERROR!"));
    ov_clear(&vf);
    return false;
    } else if (ret == OV_EBADLINK) {
    NSLog(QString::fromUtf8("OV_HOLE ERROR!"));
    ov_clear(&vf);
    return false;
    
    readPtr += ret;
    readLength += ret;
    ov_clear(&vf);
    
    
    return true;
    
}

void TYOggVorbisDecoder::dealloc()
{
    {
    [ ovData release ];
    [ sampleData release ];
    [ super dealloc ];
    
    
    
}

