#ifndef TYSPRITE_H
#define TYSPRITE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYSprite : public QObject
{
    Q_OBJECT
public:
    void loadImageFromPath();
    NSImage* sourceImage();
    void draw();
    NSRect rect();
    void setCell:(void value);
    void convertAlphaOfFix();
};

#endif // TYSPRITE_H
