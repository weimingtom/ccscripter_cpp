#include "TYCellImage.h"

// Converted from Objective-C

QObject* TYCellImage::initWithImages:()
{
    {
    this = [ super init ];
    
    imageArray = [ aArray retain ];
    
    currentImage = [ [ imageArray objectAtIndex:0 ] retain ];
    
    return this;
    
}

void TYCellImage::changeCell:()
{
    {
    currentCell = index;
    
    if(currentImage)
    [ currentImage release ];
    currentImage = [ [ imageArray objectAtIndex:index ] retain ];
    
}

int TYCellImage::currentCell()
{
    {
    return currentCell;
    
}

int TYCellImage::cells()
{
    {
    return [ imageArray count ];
    
}

bool TYCellImage::isAnimate()
{
    
}

void TYCellImage::dealloc()
{
    {
    imageArray->release();
    currentImage->release();
    super->dealloc();
    
}

bool TYCellImage::respondsToSelector:()
{
    {
    return ([ super respondsToSelector:aSelector ] ||
    [ currentImage respondsToSelector:aSelector ] ||
    [ imageArray respondsToSelector:aSelector ]);
    
}

void TYCellImage::forwardInvocation:()
{
    {
    SEL sel = [ anInvocation selector ];
    if([ currentImage respondsToSelector:sel ])
    [ anInvocation invokeWithTarget:currentImage ];
    else if([ imageArray respondsToSelector:sel ])
    [ anInvocation invokeWithTarget:imageArray ];
    else
    [ this doesNotRecognizeSelector:sel ];
    
}

NSMethodSignature * TYCellImage::methodSignatureForSelector:()
{
    {
    if([ super respondsToSelector:aSelector ])
    return [ super methodSignatureForSelector:aSelector ];
    else if([ currentImage respondsToSelector:aSelector ])
    return [ currentImage methodSignatureForSelector:aSelector ];
    else
    return [ imageArray methodSignatureForSelector:aSelector ];
    
}

NSString * TYCellImage::description()
{
    {
    return [ NSString stringWithFormat:QString::fromUtf8("TYCellImage current=%d,images=%@"),currentCell,imageArray ];
    
    
    @implementation NSImage (TYCellImageExtension)
}

bool TYCellImage::isAnimate()
{
    
}

