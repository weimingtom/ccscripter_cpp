#ifndef TYVISUALNOVELVIEW_H
#define TYVISUALNOVELVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYVisualNovelView : public QWidget
{
    Q_OBJECT
public:
    void setMouseDownSelector:(void value);
    void setTarget:(void value);
    void mouseDownSelector:();
    void drawRect:();
    bool isOpaque();
    bool isFlipped();
    NSImage* image();
    void setImage:(void value);
    void directDrawImage:();
    void setScaling:(void value);
    bool isScaling();
    float scale();
    void setNeedsDisplayScalingRect:(void value);
};

#endif // TYVISUALNOVELVIEW_H
