#include "TYEraseModeView.h"

// Converted from Objective-C

QObject* TYEraseModeView::initWithFrame:()
{
    this = super->initWithFrame(frame];
    if (this) {
    controller = aObj;
    // Initialization code here.
    return this;
    
}

void TYEraseModeView::drawRect:()
{
    // Drawing code here.
    
}

bool TYEraseModeView::acceptsFirstResponder()
{
    {
    return true;
    
}

void TYEraseModeView::mouseDown:()
{
    {
    [ this endMode ];
    
}

void TYEraseModeView::keyDown:()
{
    {
    [ this endMode ];
    
}

void TYEraseModeView::rightMouseDown:()
{
    {
    [ this endMode ];
    
}

void TYEraseModeView::scrollWheel:()
{
    {
    ;
    
    
}

void TYEraseModeView::endMode()
{
    {
    [ [ this window ] makeFirstResponder:[ this superview ] ];
    [ controller exitSystemModeResumeStatus:true ];
    [ [ this retain ] autorelease ];
    [ this removeFromSuperview ];
    
    // not implemantaion -dealloc because no object retained.
    
}

