#ifndef TYAUDIOPATHCONTROLLER_H
#define TYAUDIOPATHCONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYAudioPathController : public QObject
{
    Q_OBJECT
public:
    IBAction dialogOk:();
    IBAction dialogCancel:();
    IBAction restoreDefault:();
    IBAction selectDirectory:();
    void openWithPath:();
    void setDelegate:(void value);
    void changeAudioPath:();
};

#endif // TYAUDIOPATHCONTROLLER_H
