#ifndef TYLOOKBACKVIEW_H
#define TYLOOKBACKVIEW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYLookbackView : public QWidget
{
    Q_OBJECT
public:
    QObject* initWithFrame:();
    void setPageIndex:(void value);
    void updatesTrackingRect();
    void endMode();
    void up_action();
    void down_action();
    void cancel_action:();
    IBAction execButton:();
};

#endif // TYLOOKBACKVIEW_H
