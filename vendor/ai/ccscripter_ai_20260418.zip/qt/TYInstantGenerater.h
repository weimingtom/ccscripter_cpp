#ifndef TYINSTANTGENERATER_H
#define TYINSTANTGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYInstantGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    void drawEffect();
};

#endif // TYINSTANTGENERATER_H
