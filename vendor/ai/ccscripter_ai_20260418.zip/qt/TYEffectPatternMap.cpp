#include "TYEffectPatternMap.h"

// Converted from Objective-C

QObject* TYEffectPatternMap::initWithBitmap:()
{
    {
    int pixelSize;
    unsigned char *dp,*bp;
    int i,d;
    
    this = [ super init ];
    
    pixelsWide = [ bitmap pixelsWide ];
    pixelsHigh = [ bitmap pixelsHigh ];
    pixelSize = pixelsWide * pixelsHigh;
    mapData = [ [ NSMutableData alloc ] initWithLength:pixelSize ];
    dp = [ mapData mutableBytes ];
    bp = [ bitmap bitmapData ];
    
    d = [ bitmap bitsPerPixel ];
    if((d != 24) && (d != 32)){
    NSImage *bufferImage;
    
    [ bitmap setSize:NSMakeSize(pixelsWide,pixelsHigh) ];
    bufferImage = [ [ [ NSImage alloc ] initWithSize:NSMakeSize(pixelsWide,pixelsHigh) ] autorelease ];
    [ bufferImage lockFocus ];
    [ [ [ [ NSImage alloc ] initWithData:[ bitmap TIFFRepresentation ] ] autorelease ] compositeToPoint:NSZeroPoint operation:NSCompositeCopy ];
    [ bufferImage unlockFocus ];
    
    bitmap = [ [ [ NSBitmapImageRep alloc ] initWithData:[ bufferImage TIFFRepresentation ] ] autorelease ];
    /*
    bufferImage = [ [ [ NSImage alloc ] initWithData:[ bitmap TIFFRepresentation ] ] autorelease ];
    [ bufferImage recache ];
    bitmap = [ [ [ NSBitmapImageRep alloc ] initWithData:[ bufferImage TIFFRepresentation ] ] autorelease ];
    */
    bp = [ bitmap bitmapData ];
    d = [ bitmap bitsPerPixel ];
    d >>= 3;
    
    for(i=0; i < pixelSize; i++){
    *dp = *bp;
    dp++;
    bp+=d;
    
    return this;
    
}

const unsigned char* TYEffectPatternMap::patternMapData()
{
    {
    return [ mapData bytes ];
    
}

unsigned int TYEffectPatternMap::pixelsHigh()
{
    
}

void TYEffectPatternMap::dealloc()
{
    {
    [ mapData release ];
    [ super dealloc ];
    
}

