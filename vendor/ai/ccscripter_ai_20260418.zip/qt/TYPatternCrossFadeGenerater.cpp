#include "TYPatternCrossFadeGenerater.h"

// Converted from Objective-C

QObject* TYPatternCrossFadeGenerater::initWithBeforeImage:()
{
    {
    TYEffectDefinition effdef;
    TYEffectPatternMap *patternMap;
    
    this = [ super init ];
    
    [ effect getValue:&effdef ];
    patternMap = [ [ TYResourceServer sharedServer ] getEffectPattern:effdef.path ];
    if(!patternMap){
    NSLog(QString::fromUtf8("can't load pattern Map"));
    [ this autorelease ];
    return nullptr;
    patternptr = [ patternMap patternMapData ];
    patternWide = [ patternMap pixelsWide ];
    patternHigh = [ patternMap pixelsHigh ];
    
    phaseInterval = effdef.time / 1000.0 / 256.0;
    time = effdef.time;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    afterImage = [ atImage copyWithZone:[ atImage zone ] ];
    /*
    if(afterImage)
    [ afterImage retain ];
    */
    
    beforeBitmap = [ [ NSBitmapImageRep alloc ] initWithData:[ befImage TIFFRepresentation ] ];
    if(!beforeBitmap){
    beforeBitmap = blankBitmap(VSCREEN_WIDTH,VSCREEN_HEIGHT);
    [ beforeBitmap retain ];
    afterBitmap = [ [ NSBitmapImageRep alloc ] initWithData:[ atImage TIFFRepresentation ] ];
    if(!afterBitmap){
    afterBitmap = blankBitmap(VSCREEN_WIDTH,VSCREEN_HEIGHT);
    [ afterBitmap retain ];
    nowImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    nowBitmapptr = malloc(VSCREEN_WIDTH *VSCREEN_HEIGHT *3);
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
    
    // private method
}

void TYPatternCrossFadeGenerater::drawEffect()
{
    {
    unsigned char *src,*dst,*now;
    int spps,sppd,sppn;
    int phase;
    // oߎԂ256PʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *256;
    if(phase >= 256){
    // GtFNgI
    [ this changeEffectionImage:afterImage ];
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    return;
    } else {
    int w,h,ph,pw,ptval;
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];
    dst = [ beforeBitmap bitmapData ];
    sppd = [ beforeBitmap samplesPerPixel ];
    src = [ afterBitmap bitmapData ];
    spps = [ afterBitmap samplesPerPixel ];
    now = (unsigned char*)nowBitmapptr;
    sppn =3;
    
    for(h=0,ph=0; h < VSCREEN_HEIGHT; h++){
    for(w=0,pw=0; w < VSCREEN_WIDTH; w++){
    ptval = -patternptr[patternWide *ph +pw] +(phase << 1);
    if(ptval < 0)
    ptval = 0;
    else if(ptval > 0xFF)
    ptval = 0xFF;
    now[0] = (src[0] *ptval + dst[0] * ( 0xFF - ptval )) >> 8;
    now[1] = (src[1] *ptval + dst[1] * ( 0xFF - ptval )) >> 8;
    now[2] = (src[2] *ptval + dst[2] * ( 0xFF - ptval )) >> 8;
    pw++;
    if(pw >= patternWide)
    pw=0;
    src+=spps,dst+=sppd,now+=sppn;
    ph++;
    if(ph >= patternHigh)
    ph=0;
    
    [ nowImage lockFocus ];
    
    NSDrawBitmap(TYVirtualScreenRect(),VSCREEN_WIDTH,VSCREEN_HEIGHT,8,3,24,VSCREEN_WIDTH *3,false,false,NSCalibratedRGBColorSpace,&nowBitmapptr);
    
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    } // override
    
}

void TYPatternCrossFadeGenerater::dealloc()
{
    {
    [ startDate release ];
    beforeBitmap->release();
    afterBitmap->release();
    if(nowBitmapptr)
    free((unsigned char*)nowBitmapptr);
    [ super dealloc ];
    
    
    
}

