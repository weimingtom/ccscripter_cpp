#ifndef TYSCROLLEFFECTGENERATER_H
#define TYSCROLLEFFECTGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYScrollEffectGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    void drawEffect();
};

#endif // TYSCROLLEFFECTGENERATER_H
