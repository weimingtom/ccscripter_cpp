#ifndef TYBUTTONMANAGER_H
#define TYBUTTONMANAGER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYButtonManager : public QObject
{
    Q_OBJECT
public:
    QObject* initWithImage:();
    NSImage* image();
    void addButton:();
    void addButtonWithCellImage:();
    void addButtonOfSprite:();
    void clearButtons();
    NSArray* effectiveRectangles();
    NSData* rectMap();
    int selectedButtonID();
    int incToIndex();
    int decToIndex();
    void initialButtonImage();
    void drawWithSelection:();
    NSString* description();
    QObject* initWithID:();
    void drawWithSelect:();
    NSRect* boundingRect();
    NSNumber* idNo();
    NSString* description();
    bool isOverlay();
};

#endif // TYBUTTONMANAGER_H
