#include "TYExtVolumeController.h"

// Converted from Objective-C

IBAction TYExtVolumeController::setDefault:()
{
    {
    [ BGMSlider setFloatValue:defaultBGMVolume ];
    [ VoiceSlider setFloatValue:defaultVoiceVolume ];
    [ SESlider setFloatValue:defaultSEVolume ];
    
}

QObject* TYExtVolumeController::initWithDefaultBGMVolume:()
{
    bgmVolume:(float)bgmVol
    defaultVoiceVolume:(float)defVoiceVol
    voiceVolume:(float)voiceVol
    defaultSEVolume:(float)defSEVol
    seVolume:(float)seVol
    {
    this = [ super init ];
    
    defaultBGMVolume=defBGMVol;
    defaultVoiceVolume=defVoiceVol;
    defaultSEVolume=defSEVol;
    
    [ NSBundle loadNibNamed:QString::fromUtf8("ExtVolume") owner:this ];
    
    [ BGMSlider setFloatValue:bgmVol ];
    [ VoiceSlider setFloatValue:voiceVol ];
    [ SESlider setFloatValue:seVol ];
    
    return this;
    
}

float TYExtVolumeController::voiceVolume()
{
    {
    return [ VoiceSlider floatValue ];
    
}

float TYExtVolumeController::seVolume()
{
    {
    return [ SESlider floatValue ];
    
    
}

