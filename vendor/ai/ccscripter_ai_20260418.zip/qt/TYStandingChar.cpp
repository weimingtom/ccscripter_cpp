#include "TYStandingChar.h"

// Converted from Objective-C

QObject* TYStandingChar::initWithPosition:()
{
    {
    NSSize imageSize;
    
    [ super init ];
    
    position = [ str retain ];
    
    imagePath = [ aPath retain ];
    
    [ this loadImageFromPath ];
    
    imageSize = (sourceImage) ? [ sourceImage size ] : NSZeroSize ;
    drawPoint.y=0;
    if([ str isEqualToString:LD_LOCATE_LEFT ]){
    drawPoint.x=VSCREEN_WIDTH /4 - imageSize.width /2;
    } else if([ str isEqualToString:LD_LOCATE_CENTER ]){
    drawPoint.x=VSCREEN_WIDTH /2 - imageSize.width /2;
    } else if([ str isEqualToString:LD_LOCATE_RIGHT ]){
    drawPoint.x=VSCREEN_WIDTH *3 /4 - imageSize.width /2;
    } else {
    [ this autorelease ];
    return nullptr;
    
    alpha=SPRITE_ALPHA_MAX;
    
    return this;
    
}

void TYStandingChar::draw()
{
    {
    drawPoint.y += underOffset;
    [ super draw ];
    drawPoint.y -= underOffset;
    
}

void TYStandingChar::dealloc()
{
    {
    [ position release ];
    [ super dealloc ];
    
    // ----------------------------------------------------------------------------------------
    // NSCoding
    // ----------------------------------------------------------------------------------------
    
}

QObject* TYStandingChar::initWithCoder:()
{
    {
    super->initWithCoder(aDecoder];
    position = [aDecoder->decodeObject() copy];
    
    return this;
    
}

void TYStandingChar::encodeWithCoder:()
{
    {
    [ super encodeWithCoder:aCoder ];
    aCoder->encodeObject(position];
    
    
}

