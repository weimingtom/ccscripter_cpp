#ifndef TYCROSSFADEGENERATER_H
#define TYCROSSFADEGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYCrossFadeGenerater : public TYEffectGenerater
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    void drawEffect();
};

#endif // TYCROSSFADEGENERATER_H
