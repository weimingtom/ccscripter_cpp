#ifndef TYSCRIPTERVALUES_H
#define TYSCRIPTERVALUES_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYScripterValues : public QObject
{
    Q_OBJECT
public:
    QObject* initScripterValues();
    QObject* getStringValue:();
    QObject* getIntValue:();
    void setStringValue:(void value);
    void setIntValue:(void value);
    void setArrayLine:(void value);
    void setIntLimitID:(void value);
    void defineArrayValue:();
    bool loadGlobalValues:();
    bool saveGlobalValues:();
    void margeGlobalValues:();
    void resetGame();
};

#endif // TYSCRIPTERVALUES_H
