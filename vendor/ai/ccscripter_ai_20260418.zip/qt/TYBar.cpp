#include "TYBar.h"

// Converted from Objective-C

QObject* TYBar::initWithRect:()
{
    {
    this = [ super init ];
    
    barRect = aRect;
    barColor = [ aColor retain ];
    
    return this;
    
}

void TYBar::draw()
{
    {
    [ barColor set ];
    NSRectFill(barRect);
    
}

void TYBar::dealloc()
{
    {
    barColor->release();
    super->dealloc();
    // ----------------------------------------------------------------------------------------
    // NSCoding
    // ----------------------------------------------------------------------------------------
    
}

QObject* TYBar::initWithCoder:()
{
    {
    barRect = aDecoder->decodeRect();
    barColor = [aDecoder->decodeObject() retain ];
    return this;
    
}

void TYBar::encodeWithCoder:()
{
    {
    aCoder->encodeRect(barRect];
    aCoder->encodeObject(barColor];
    
    
}

