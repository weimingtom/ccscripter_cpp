#include "TYNovelLayer.h"

// Converted from Objective-C

QObject* TYNovelLayer::initNovelLayer()
{
    {
    this = [ super init ];
    
    textArray = [ [ NSMutableArray array ] retain ];
    bufferImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    tempString = [ [ NSMutableAttributedString alloc ] initWithString:@"" ];
    voiceArray = [ [ NSMutableArray array ] retain ];
    needRefresh = true;
    
    [ [ NSNotificationCenter defaultCenter ] addObserver:this selector:@selector(playVoice:)  name:TYVoicePlayNotification object:nullptr ];
    
    return this;
    
}

void TYNovelLayer::recache()
{
    {
    if(!needRefresh)
    return;
    needRefresh = false;
    
    [ bufferImage lockFocus ];
    //NSRectFillUsingOperation(TYVirtualScreenRect(),NSCompositeClear);
    [ this drawImage ];
    [ bufferImage unlockFocus ];
    
}

void TYNovelLayer::setManager:()
{
    {
    delegate = manager;
    
}

void TYNovelLayer::pushAttributedString:()
{
    {
    needRefresh = true;
    
    [ tempString appendAttributedString:str ];
    
}

void TYNovelLayer::pushNewLine()
{
    {
    needRefresh = true;
    
    [ textArray addObject:tempString ];
    [ tempString release ];
    tempString = [ [ NSMutableAttributedString alloc ] initWithString:@"" ];
    nowColumn=0;
    
}

TYLookbackLayer* TYNovelLayer::lookbackObject()
{
    {
    return [ [ [ TYLookbackLayer alloc ] initWithStrings:[ this stringArray ]
    voices:[ this voiceArray ] ] autorelease ];
    
}

NSArray* TYNovelLayer::stringArray()
{
    {
    NSMutableArray *array;
    NSEnumerator *enu;
    NSAttributedString *temp;
    
    array = [ NSMutableArray array ];
    enu = [ textArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
    [ array addObject:[ temp string ] ];
    if([ tempString length ])
    [ array addObject:[ tempString string ] ];
    
    return array;
    
}

NSArray* TYNovelLayer::voiceArray()
{
    {
    return ([ voiceArray count ]) ? voiceArray : nullptr;
    
}

void TYNovelLayer::drawImage()
{
    {
    id temp;
    NSRange range;
    NSEnumerator *enm;
    int length,column,row;
    
    if(!isDrawTextWindow){
    [ delegate drawTextWindow ];
    isDrawTextWindow = true;
    
    enm = [ textArray objectEnumerator ];
    range.length = 1;
    column=0;
    row=0;
    while((temp = [ enm nextObject ]) != nullptr){
    if(nowRow <= row){
    length = [ (NSAttributedString*)temp length ];
    for(range.location=0; range.location < length; range.location++,column++){
    [ delegate drawAttStr:[ temp attributedSubstringFromRange:range ] atColumn:column atRow:row ];
    column=0;
    row++;
    
    length = [ tempString length ];
    column = nowColumn;
    for(range.location=nowColumn; range.location < length; range.location++,column++){
    [ delegate drawAttStr:[ tempString attributedSubstringFromRange:range ] atColumn:column atRow:row ];
    
    nowRow = row;
    nowColumn = column;
    
}

void TYNovelLayer::forwardInvocation:()
{
    {
    SEL sel = [ anInvocation selector ];
    if([ bufferImage respondsToSelector:sel ])
    [ anInvocation invokeWithTarget:bufferImage ];
    else
    [ this doesNotRecognizeSelector:sel ];
    
}

NSMethodSignature * TYNovelLayer::methodSignatureForSelector:()
{
    {
    if([ super respondsToSelector:aSelector ])
    return [ super methodSignatureForSelector:aSelector ];
    return [ bufferImage methodSignatureForSelector:aSelector ];
    
}

void TYNovelLayer::playVoice:()
{
    {
    [ voiceArray addObject:[ NSDictionary dictionaryWithObjectsAndKeys:
    [ aNotification object ],
    TYPathVoiceLookbackData,
    [ NSValue valueWithPoint:NSMakePoint([ tempString length ],[ textArray count ]) ],
    TYPointVoiceLookbackData,nullptr ] ];
    
}

NSString* TYNovelLayer::getText()
{
    {
    return [ [ this stringArray ] componentsJoinedByString:@"" ];
    
}

void TYNovelLayer::dealloc()
{
    {
    [ bufferImage release ];
    [ textArray release ];
    [ tempString release ];
    [ voiceArray release ];
    [ [ NSNotificationCenter defaultCenter ] removeObserver:this ];
    super->dealloc();
    
    // implementation of NSCoding
}

void TYNovelLayer::encodeWithCoder:()
{
    {
    [ aCoder encodeObject:textArray ];
    [ aCoder encodeObject:tempString ];
    [ aCoder encodeObject:voiceArray ];
    
}

QObject* TYNovelLayer::initWithCoder:()
{
    {
    textArray = [ [ aDecoder decodeObject ] mutableCopy ];
    tempString = [ [ aDecoder decodeObject ] mutableCopy ];
    if([ aDecoder versionForClassName:QString::fromUtf8("TYNovelLayer") ] >= 1)
    voiceArray = [ [ aDecoder decodeObject ] mutableCopy ];
    
    bufferImage = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    needRefresh = true;
    
    return this;
    
    
}

