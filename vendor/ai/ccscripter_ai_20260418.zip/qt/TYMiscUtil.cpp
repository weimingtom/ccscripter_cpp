#include "TYMiscUtil.h"

// Converted from Objective-C

QObject* TYMiscUtil::subarrayFromIndex:()
{
    {
    NSRange range;
    int count  = [ this count ];
    
    NSAssert((count > aInt),QString::fromUtf8("Array Index over flow"));
    
    range.location = aInt;
    range.length = count -aInt;
    
    return [ this subarrayWithRange:range ];
    
    @implementation NSDictionary (TYDictionarySort)
}

QObject* TYMiscUtil::objectsSortedByKeyUsingSelector:()
{
    {
    return [ this objectsForKeys:[ [ this allKeys ] sortedArrayUsingSelector:comparator ]   notFoundMarker:[ NSNull null ] ];
    
}

