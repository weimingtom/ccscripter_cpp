#include "TYLookbackView.h"

// Converted from Objective-C

QObject* TYLookbackView::initWithFrame:()
{
    controller:(id)aObj
    attributes:(NSDictionary*)aDict
    layout:(NSMutableDictionary*)layoutDic
    buffer:(NSArray*)aArray
    ubutton:(TYCellImage*)uImage
    dbutton:(TYCellImage*)dImage
    {
    this = [ super initWithFrame:aFrame ];
    
    manager = [ TYStageManager sharedManager ];
    
    controller = aObj;
    
    //menuWindowColor = [ [ layoutDic objectForKey:TYRMenuBGColor ] retain ];
    
    attDict = [ aDict retain ];
    
    lookbackArray = [ aArray retain ];
    
    //drawBuffer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    drawBuffer = [ [ manager visualLayer ] copy ];
    [ drawBuffer lockFocus ];
    [ manager drawTextWindow ];
    [ drawBuffer unlockFocus ];
    
    // ボタン配置
    button[0] = nullptr;
    button[1] = nullptr;
    {
    NSRect twrect;
    
    twrect = [ manager textWindowRect ];
    
    if(uImage) {
    btnRect[0].size = [ (NSImage*)uImage size ];
    btnRect[0].origin.x = NSMaxX(twrect) -btnRect[0].size.width;
    btnRect[0].origin.y = NSMaxY(twrect) -btnRect[0].size.height;
    button[0] = [ [ TYControllButton alloc ] initWithFrame:btnRect[0]
    cellImage:uImage ];
    [ this addSubview:button[0] ];
    [ button[0] setTarget:this ];
    [ button[0] setAction:@selector(execButton:) ];
    
    if(dImage) {
    btnRect[1].size = [ (NSImage*)dImage size ];
    btnRect[1].origin.x = NSMaxX(twrect) -btnRect[1].size.width;
    btnRect[1].origin.y = NSMinY(twrect);
    button[1] = [ [ TYControllButton alloc ] initWithFrame:btnRect[1]
    cellImage:dImage ];
    [ this addSubview:button[1] ];
    [ button[1] setTarget:this ];
    [ button[1] setAction:@selector(execButton:) ];
    
    
    [ this setPageIndex:[ lookbackArray count ] -1 ];
    
    return this;
    
}

void TYLookbackView::setPageIndex:()
{
    {
    index = aInt;
    NSArray *voiceArray;
    
    [ [ lookbackArray objectAtIndex:index ] setManager:manager ];
    [ [ lookbackArray objectAtIndex:index ] setAttribute:attDict ];
    //[ [ lookbackArray objectAtIndex:index ] recache ];
    
    // ボイスのリプレイ
    if([ TYEnviroment boolForKey:TYLookbackVoiceReplayEnviroment ]){
    if(voiceArray = [ [ lookbackArray objectAtIndex:index ] voiceArray ]){
    [ controller playWaveChannel:DIRECT_WAVE_REPLAY
    path:[ [ voiceArray objectAtIndex:0 ] objectForKey:TYPathVoiceLookbackData ]
    loop:false ];
    
    // ボタンの表示、非表示
    {
    NSRect frame;
    int cnt = [ lookbackArray count ];
    
    frame = [ button[0] frame ];
    frame.size = (index == 0) ? NSZeroSize : btnRect[0].size ;
    [ button[0] setFrame:frame ];
    
    frame = [ button[1] frame ];
    frame.size = (index == cnt -1) ? NSZeroSize : btnRect[1].size ;
    [ button[1] setFrame:frame ];
    
}

void TYLookbackView::updatesTrackingRect()
{
    {
    if(button[0])
    rectTag[0] = [ this addTrackingRect:btnRect[0] owner:this userData:nullptr assumeInside:false ];
    
    if(button[1])
    rectTag[1] = [ this addTrackingRect:btnRect[1] owner:this userData:nullptr assumeInside:false ];
    
}

void TYLookbackView::removeAllTrackingRect()
{
    {
    if(rectTag[0])
    [ this removeTrackingRect:rectTag[0] ];
    
    if(rectTag[1])
    [ this removeTrackingRect:rectTag[1] ];
    
}

void TYLookbackView::drawRect:()
{
    [ drawBuffer compositeToPoint:rect.origin
    fromRect:rect
    operation:NSCompositeCopy ];
    if(NSEqualRects(rect,TYVirtualScreenRect()))
    [ [ lookbackArray objectAtIndex:index ] drawImage ];
    
}

bool TYLookbackView::isOpaque()
{
    {
    return true;
    
}

IBAction TYLookbackView::execButton:()
{
    {
    if(sender == button[0])
    [ this up_action ];
    else
    [ this down_action ];
    
}

bool TYLookbackView::acceptsFirstResponder()
{
    {
    return true;
    
}

void TYLookbackView::mouseEntered:()
{
    {
    if(rectTag[0] == [ theEvent trackingNumber ])
    [ button[0] changeCell:1 ];
    else
    [ button[1] changeCell:1 ];
    
}

void TYLookbackView::mouseExited:()
{
    {
    if(rectTag[0] == [ theEvent trackingNumber ])
    [ button[0] changeCell:0 ];
    else
    [ button[1] changeCell:0 ];
    
}

void TYLookbackView::mouseMoved:()
{
    {
    ;
    
}

void TYLookbackView::mouseDown:()
{
    {
    ;
    
}

void TYLookbackView::rightMouseDown:()
{
    {
    [ this cancel_action:nullptr ];
    
}

void TYLookbackView::keyDown:()
{
    {
    [ this performSelector:TYSelectorForKeycode([ theEvent keyCode ]) withObject:nullptr ];
    
}

void TYLookbackView::cancel_action:()
{
    {
    [ this endMode ];
    
}

void TYLookbackView::down_action()
{
    {
    if(index +1 >= [ lookbackArray count ]){
    [ this endMode ];
    return;
    
    [ this setPageIndex:index +1 ];
    [ this setNeedsDisplay:true ];
    
}

void TYLookbackView::up_action()
{
    {
    if(index -1 < 0)
    return;
    
    [ this setPageIndex:index -1 ];
    [ this setNeedsDisplay:true ];
    
}

void TYLookbackView::scrollWheel:()
{
    {
    if([ theEvent deltaY ] > 0.0){
    [ this up_action ];
    } else {
    [ this down_action ];
    
}

void TYLookbackView::endMode()
{
    {
    [ this removeAllTrackingRect ];
    [ [ this window ] makeFirstResponder:[ this superview ] ];
    [ controller exitSystemModeResumeStatus:true ];
    [ [ this retain ] autorelease ];
    [ this removeFromSuperview ];
    
    // delegate methods
}

void TYLookbackView::drawAttStr:()
{
    atColumn:(int)col
    atRow:(int)row
    {
    [ manager drawAttStr:str atColumn:col atRow:row ];
    // end delegate methods
    
}

void TYLookbackView::dealloc()
{
    {
    [ drawBuffer release ];
    //menuWindowColor->release();
    attDict->release();
    lookbackArray->release();
    
    [ button[0] release ];
    [ button[1] release ];
    super->dealloc();
    
    
    
}

