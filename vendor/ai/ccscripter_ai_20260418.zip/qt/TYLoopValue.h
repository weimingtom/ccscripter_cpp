#ifndef TYLOOPVALUE_H
#define TYLOOPVALUE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYLoopValue : public QObject
{
    Q_OBJECT
public:
    QObject* initWithStruct:();
};

#endif // TYLOOPVALUE_H
