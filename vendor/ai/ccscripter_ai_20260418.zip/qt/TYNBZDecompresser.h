#ifndef TYNBZDECOMPRESSER_H
#define TYNBZDECOMPRESSER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYNBZDecompresser : public TYDecompresser
{
    Q_OBJECT
public:
};

#endif // TYNBZDECOMPRESSER_H
