#ifndef TYQTMUSICPLAYER_H
#define TYQTMUSICPLAYER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYQTMusicPlayer : public QWidget
{
    Q_OBJECT
public:
    void setMovie:(void value);
    void start:();
    void stop:();
    bool isPlaying();
    void gotoBeginning:();
    void setVolume:(void value);
    float volume();
    void setLoopMode:(void value);
    NSQTMovieLoopMode loopMode();
    void showController:();
    void setEditable:(void value);
    void registProxy:();
    QObject* initWithFrame:();
    void initWithPorts:();
};

#endif // TYQTMUSICPLAYER_H
