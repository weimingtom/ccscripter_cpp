#ifndef TYCELLIMAGE_H
#define TYCELLIMAGE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYCellImage : public QObject
{
    Q_OBJECT
public:
    QObject* initWithImages:();
    QObject* initWithAttributeString:();
    void changeCell:();
    int currentCell();
    int cells();
    bool isCellImage();
    bool isAnimate();
    void forwardInvocation:();
    NSMethodSignature * methodSignatureForSelector:();
    void changeCell:();
    bool isCellImage();
    bool isAnimate();
};

#endif // TYCELLIMAGE_H
