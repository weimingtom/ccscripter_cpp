#ifndef TYFULLSCREENWINDOW_H
#define TYFULLSCREENWINDOW_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYFullScreenWindow : public QMainWindow
{
    Q_OBJECT
public:
    void setLevelToFront(void value);
    void setLevelToNormal(void value);
};

#endif // TYFULLSCREENWINDOW_H
