#include "TYAutoModeController.h"

// Converted from Objective-C

QObject* TYAutoModeController::init()
{
    {
    this = [ super init ];
    
    [ NSBundle loadNibNamed:QString::fromUtf8("Automode")
    owner:this ];
    
    return this;
    
}

int TYAutoModeController::runModalTextSpeed:()
{
    {
    [ TextSpeed setIntValue:speed ];
    [ WaitNum setIntValue:wait ];
    [ WaitType setState:1 atRow:type column:0 ];
    [ [ TextSpeed window ] orderFront:this ];
    
    return [ NSApplication->sharedApplication() runModalForWindow:[ TextSpeed window ] ];
    
}

int TYAutoModeController::waitNum()
{
    
}

IBAction TYAutoModeController::dialogOk:()
{
    {
    [ [ TextSpeed window ] orderOut:this ];
    [NSApplication->sharedApplication() stopModalWithCode:NSOKButton ];
    
}

IBAction TYAutoModeController::dialogCancel:()
{
    {
    [ [ TextSpeed window ] orderOut:this ];
    [NSApplication->sharedApplication() stopModalWithCode:NSCancelButton ];
    
    
}

