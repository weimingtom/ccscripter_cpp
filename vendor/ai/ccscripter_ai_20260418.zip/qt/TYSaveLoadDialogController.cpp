#include "TYSaveLoadDialogController.h"

// Converted from Objective-C

QObject* TYSaveLoadDialogController::init()
{
    {
    this = [ super init ];
    
    dataDict = [ [ NSMutableDictionary dictionary ] retain ];
    dataNum=9;
    
    return this;
    
}

IBAction TYSaveLoadDialogController::dialogOk:()
{
    {
    selectedRow = [ tableView selectedRow ];
    [NSApplication->sharedApplication()
    stopModalWithCode:DIALOG_OK];
    
}

IBAction TYSaveLoadDialogController::dialogCancel:()
{
    {
    [NSApplication->sharedApplication()
    stopModalWithCode:DIALOG_CANCEL];
    
}

IBAction TYSaveLoadDialogController::doubleClick:()
{
    {
    // NbNIuWFNg̃`FbNقƂ͗vBꂾƃJwb_[̃_uNbNɂB
    if([ okButton isEnabled ]){
    [ this dialogOk:this ];
    
}

void TYSaveLoadDialogController::awakeFromNib()
{
    {
    [ tableView setDoubleAction:@selector(doubleClick:) ];
    [ tableView setTarget:this ];
    
}

NSWindow* TYSaveLoadDialogController::window()
{
    {
    return window;
    
}

void TYSaveLoadDialogController::setTitle:()
{
    {
    [ window setTitle:title ];
    
}

void TYSaveLoadDialogController::setNumber:()
{
    {
    dataNum = number;
    
}

void TYSaveLoadDialogController::setDate:()
{
    {
    [ dataDict setObject:aDate forKey:[ NSNumber numberWithInt:number ] ];
    
}

void TYSaveLoadDialogController::setLoaded:()
{
    {
    loaded = aBool;
    
}

bool TYSaveLoadDialogController::isLoaded()
{
    {
    return loaded;
    
}

int TYSaveLoadDialogController::number()
{
    {
    return dataNum;
    
}

int TYSaveLoadDialogController::selectedRow()
{
    {
    return selectedRow;
    
}

void TYSaveLoadDialogController::setLoadMode:()
{
    {
    loadMode = aBool;
    
    // implementation of NSTableDataSource protocol
}

int TYSaveLoadDialogController::numberOfRowsInTableView:()
{
    {
    return dataNum;
    
}

QObject* TYSaveLoadDialogController::tableView:()
{
    {
    id identifier;
    id data;
    
    identifier = [ tableColumn identifier ];
    
    if([ identifier isEqualToString:QString::fromUtf8("No") ]){
    return [ NSString stringWithFormat:QString::fromUtf8("%d"),row+1 ];
    } else if([ identifier isEqualToString:QString::fromUtf8("Date") ]){
    data = [ dataDict objectForKey:[ NSNumber numberWithInt:row+1 ] ];
    if(data==nullptr){
    return QString::fromUtf8("No Data");
    } else {
    return [ data descriptionWithCalendarFormat:NSLocalizedString(QString::fromUtf8("SaveDateFormat"),"") ];
    
    return @"";
    
    // delegate methods of NSTableView
}

void TYSaveLoadDialogController::tableViewSelectionDidChange:()
{
    {
    if(!loadMode){
    [ okButton setEnabled:true ];
    return;
    
    if([ dataDict objectForKey:[ NSNumber numberWithInt:[ [ aNotification object ] selectedRow ]+1 ] ]){
    [ okButton setEnabled:true ];
    } else {
    [ okButton setEnabled:false ];
    
    return;
    
    
}

