#ifndef TYEXECUTABLEPLUGIN_H
#define TYEXECUTABLEPLUGIN_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // TYEXECUTABLEPLUGIN_H
