#include "TYYesNoMenuView.h"

// Converted from Objective-C

QObject* TYYesNoMenuView::initWithFrame:()
{
    controller:(id)aObj
    attributes:(NSDictionary*)aDict
    titleAndAction:(NSArray*)aArray
    layout:(NSMutableDictionary*)layoutDict
    {
    int fontWidth;
    int fontHeight;
    int pitchX;
    int pitchY;
    BOOL shadow;
    
    int y,cnt,tag;
    NSEnumerator *enu;
    NSString* temp;
    TYCellImage *image;
    NSRect frame;
    NSSize size;
    TYControllButton *button;
    NSArray *buttonColor;
    NSMutableArray *buttonArray;
    NSMutableArray *actionArray;
    NSColor *menuColor;
    
    buttonArray = [ NSMutableArray array ];
    actionArray = [ NSMutableArray array ];
    
    // 初期化
    this = super->initWithFrame(aFrame ];
    
    if (!this)
    return nullptr;
    
    // メニューレイアウトの読み込み
    {
    size = [ [ layoutDict objectForKey:TYRMenuFontSize ] sizeValue ];
    fontWidth = size.width;
    fontHeight = size.height;
    
    size = [ [ layoutDict objectForKey:TYRMenuFontPitchSize ] sizeValue ];
    pitchX = size.width;
    pitchY = size.height;
    
    shadow = [ [ layoutDict objectForKey:TYRMenuShadowed ] boolValue ];
    
    menuColor = [ layoutDict objectForKey:TYRMenuBGColor ];
    
    buttonColor = [ NSArray arrayWithObjects:
    [ layoutDict objectForKey:TYRMenuNoSelectColor ],
    [ layoutDict objectForKey:TYRMenuSelectColor ],nullptr ];
    
    cnt = 2;
    
    // 1行目の位置取得。
    y = VSCREEN_HEIGHT -(VSCREEN_HEIGHT + (-fontHeight -pitchY) *(cnt -1)) /2;
    
    tag = 0;
    
    enu = [ aArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
    NSPoint origin;
    NSString *aStr;
    
    switch (tag) {
    case 0:
    aStr = [ aArray objectAtIndex:0 ];
    break;
    case 1:
    aStr = NSLocalizedString(QString::fromUtf8("true"),nullptr);
    break;
    case 2:
    aStr = NSLocalizedString(QString::fromUtf8("false"),nullptr);
    break;
    
    // イメージ生成
    image = [ [ TYCellImage alloc ] initWithImages:
    [ TYStringImage imagesWithString:aStr
    attributes:aDict
    colors:(tag == 0) ? [ NSArray arrayWithObject:[ layoutDict objectForKey:TYRMenuSelectColor ] ] : buttonColor
    fontHeight:fontHeight
    fontWidth:fontWidth
    interval:pitchX
    shadow:shadow ] ];
    [ image autorelease ];
    
    // button生成。
    size = [ (NSImage*)image size ];
    if(tag == 0) {
    frame = NSMakeRect((VSCREEN_WIDTH -size.width) / 2,
    y,size.width,size.height);
    } else {
    int x;
    x = VSCREEN_WIDTH /2 + size.width *((tag == 1) ? -1.3 : 0.3);
    frame = NSMakeRect(x,y,size.width,size.height);
    origin = [ (TYStringImage*)image origin ];
    frame.origin.x += origin.x;
    frame.origin.y += origin.y;
    [ (NSArray*)image makeObjectsPerformSelector:@selector(setOriginByValue:)
    withObject:[ NSValue valueWithPoint:NSZeroPoint ] ];
    
    button = [ [ [ TYControllButton alloc ] initWithFrame:frame cellImage:(tag == 0) ? [ (NSArray*)image objectAtIndex:0 ] : image ] autorelease ];
    [ this addSubview:button ];
    
    if(tag != 0){
    [ button setTarget:this ];
    [ button setAction:@selector(execButton:) ];
    [ button setTag:tag -1 ];
    [ buttonArray addObject:button ];
    [ actionArray addObject:temp ];
    
    if(tag == 0)
    y -= fontHeight +pitchY;
    
    tag++;
    
    // 初期化完了
    setController(aObj
    buttonArray:buttonArray
    actionArray:actionArray
    bgColor:menuColor ];
    
    return this;
    
    /*
}

void TYYesNoMenuView::mouseEntered:()
{
    {
    [ super mouseEntered:theEvent ];
    */
    
    
}

