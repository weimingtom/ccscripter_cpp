#include "TYStringImage.h"

// Converted from Objective-C

QObject* TYStringImage::initWithImage:()
{
    {
    this = [ super init ];
    
    image = [ aImage retain ];
    size=aSize;
    origin = point;
    origin.x *= -1;
    origin.y *= -1;
    
    return this;
    
}

void TYStringImage::setOriginByValue:()
{
    {
    [ pointValue getValue:&origin ];
    
    
}

NSSize TYStringImage::size()
{
    {
    return size;
    
}

void TYStringImage::dissolveToPoint:()
{
    {
    point.x += origin.x;
    point.y += origin.y;
    
    [ image dissolveToPoint:(NSPoint)point fraction:(float)aFloat ];
    
}

void TYStringImage::dissolveToPoint:()
{
    {
    point.x += origin.x;
    point.y += origin.y;
    
    [ image dissolveToPoint:(NSPoint)point fromRect:(NSRect)rect fraction:(float)aFloat ];
    
}

void TYStringImage::compositeToPoint:()
{
    {
    point.x += origin.x;
    point.y += origin.y;
    
    [ image compositeToPoint:(NSPoint)point operation:(NSCompositingOperation)op ];
    
}

void TYStringImage::compositeToPoint:()
{
    {
    point.x += origin.x;
    point.y += origin.y;
    
    [ image compositeToPoint:(NSPoint)point fromRect:(NSRect)rect operation:(NSCompositingOperation)op ];
    
}

void TYStringImage::compositeToPoint:()
{
    {
    point.x += origin.x;
    point.y += origin.y;
    
    [ image compositeToPoint:(NSPoint)point operation:(NSCompositingOperation)op fraction:(float)delta ];
    
}

void TYStringImage::compositeToPoint:()
{
    {
    point.x += origin.x;
    point.y += origin.y;
    
    [ image compositeToPoint:(NSPoint)point operation:(NSCompositingOperation)op fraction:(float)delta ];
    
    
    /* ߂ǂ̂ŕۗi[j
}

void TYStringImage::drawInRect:()
{
    */
}

bool TYStringImage::respondsToSelector:()
{
    {
    return ([ super respondsToSelector:aSelector ] ||
    [ image respondsToSelector:aSelector ]);
    
}

void TYStringImage::forwardInvocation:()
{
    {
    SEL sel = [ anInvocation selector ];
    if([ image respondsToSelector:sel ])
    [ anInvocation invokeWithTarget:image ];
    else
    [ this doesNotRecognizeSelector:sel ];
    
}

NSMethodSignature * TYStringImage::methodSignatureForSelector:()
{
    {
    if([ super respondsToSelector:aSelector ])
    return [ super methodSignatureForSelector:aSelector ];
    return [ image methodSignatureForSelector:aSelector ];
    
}

void TYStringImage::dealloc()
{
    {
    image->release();
    super->dealloc();
    
    
}

