#ifndef TYOGGVORBISDECODER_H
#define TYOGGVORBISDECODER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYOggVorbisDecoder : public QObject
{
    Q_OBJECT
public:
};

#endif // TYOGGVORBISDECODER_H
