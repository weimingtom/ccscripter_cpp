#include "TYSprite.h"

// Converted from Objective-C

void TYSprite::draw()
{
    {
    if(alpha <= 0)
    return;
    else if(alpha<SPRITE_ALPHA_MAX)
    [ sourceImage compositeToPoint:drawPoint operation:NSCompositeSourceOver fraction:alpha *1.0 / SPRITE_ALPHA_MAX  ];
    else
    [ sourceImage compositeToPoint:drawPoint operation:NSCompositeSourceOver ];
    
}

NSRect TYSprite::rect()
{
    {
    NSSize size=[ sourceImage size ];
    
    NSAssert((sourceImage) , QString::fromUtf8("failed to get Rectangle from Sprite,sprite has no Image"));
    
    return NSMakeRect(drawPoint.x,drawPoint.y,size.width,size.height);
    
}

void TYSprite::loadImageFromPath()
{
    {
    if(sourceImage)
    [ sourceImage release ];
    sourceImage = [ [ [ TYResourceServer sharedServer ] getImage:imagePath
    transMode:true
    animate:true ] retain ];
    
}

NSImage* TYSprite::sourceImage()
{
    {
    if(!sourceImage)
    [ this loadImageFromPath ];
    return sourceImage;
    
}

void TYSprite::setCell:()
{
    {
    [ (TYCellImage*)sourceImage changeCell:cellNo ];
    
}

void TYSprite::convertAlphaOfFix()
{
    {
    alpha = alpha *255 /100;
    
    // implementation of NSCoding
}

void TYSprite::encodeWithCoder:()
{
    {
    [ aCoder encodeObject:imagePath ];
    [ aCoder encodeValueOfObjCType:@encode(NSPoint) at:&drawPoint ];
    [ aCoder encodeValueOfObjCType:"i" at:&alpha ];
    
}

QObject* TYSprite::initWithCoder:()
{
    {
    imagePath = [ [ aDecoder decodeObject ] copy ];
    [ aDecoder decodeValueOfObjCType:@encode(NSPoint) at:&drawPoint ];
    [ aDecoder decodeValueOfObjCType:"i" at:&alpha ];
    
    return this;
    
}

void TYSprite::dealloc()
{
    {
    [ sourceImage release ];
    [ imagePath release ];
    super->dealloc();
    
    
}

