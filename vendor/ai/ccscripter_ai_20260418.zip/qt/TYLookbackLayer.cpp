#include "TYLookbackLayer.h"

// Converted from Objective-C

QObject* TYLookbackLayer::initWithStrings:()
{
    voices:(NSArray*)vArray
    {
    this = [ super init ];
    
    textArray = [ aArray retain ];
    
    voiceArray = [ vArray retain ];
    
    tempString = [ [ NSMutableAttributedString alloc ] initWithString:@"" ];
    
    needRefresh = true;
    
    return this;
    
}

void TYLookbackLayer::recache()
{
    {
    nowColumn = 0;
    nowRow = 0;
    
    if(lookBackBuffer)
    [ lookBackBuffer release ];
    lookBackBuffer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    [ lookBackBuffer lockFocus ];
    [ this drawImage ];
    [ lookBackBuffer unlockFocus ];
    
}

void TYLookbackLayer::drawImage()
{
    {
    IMP imp;
    SEL sel;
    id temp;
    NSRange range;
    NSEnumerator *enm;
    int length,column,row;
    
    {
    sel = @selector( drawAttStr: atColumn: atRow: );
    imp = [ delegate methodForSelector:sel ];
    
    enm = [ textArray objectEnumerator ];
    range.length = 1;
    column=0;
    row=0;
    while((temp = [ enm nextObject ]) != nullptr){
    if(nowRow <= row){
    length = [ (NSAttributedString*)temp length ];
    for(range.location=0; range.location < length; range.location++,column++){
    (void(*)( id , SEL , ...))imp(delegate,sel,[ temp attributedSubstringFromRange:range ],column,row);
    //[ delegate drawAttStr:[ temp attributedSubstringFromRange:range ] atColumn:column atRow:row ];
    column=0;
    row++;
    
    
}

void TYLookbackLayer::setAttribute:()
{
    {
    NSMutableArray *newArray;
    NSEnumerator *enu;
    NSString *temp;
    
    if(attributed)
    return;
    
    newArray = [ NSMutableArray array ];
    enu = [ textArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
    [ newArray addObject:[ [ [ NSAttributedString alloc ] initWithString:temp attributes:aDict ] autorelease ] ];
    
    [ textArray release ];
    textArray = [ newArray retain ];
    
    attributed = true;
    
}

void TYLookbackLayer::forwardInvocation:()
{
    {
    SEL sel = [ anInvocation selector ];
    if([ lookBackBuffer respondsToSelector:sel ])
    [ anInvocation invokeWithTarget:lookBackBuffer ];
    else
    [ this doesNotRecognizeSelector:sel ];
    
}

NSMethodSignature * TYLookbackLayer::methodSignatureForSelector:()
{
    {
    if([ super respondsToSelector:aSelector ])
    return [ super methodSignatureForSelector:aSelector ];
    return [ lookBackBuffer methodSignatureForSelector:aSelector ];
    
}

NSArray* TYLookbackLayer::stringArray()
{
    {
    if(attributed)
    return [ super stringArray ];
    else
    return textArray;
    
    // implementation of NSCoding
}

void TYLookbackLayer::encodeWithCoder:()
{
    {
    [ aCoder encodeObject:[ this stringArray ] ];
    [ aCoder encodeObject:voiceArray ];
    
}

QObject* TYLookbackLayer::initWithCoder:()
{
    {
    textArray = [ [ aDecoder decodeObject ] mutableCopy ];
    voiceArray = [ [ aDecoder decodeObject ] mutableCopy ];
    
    needRefresh = true;
    
    return this;
    
    
    
}

