#ifndef TYBAR_H
#define TYBAR_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYBar : public QObject
{
    Q_OBJECT
public:
    QObject* initWithRect:();
    void draw();
};

#endif // TYBAR_H
