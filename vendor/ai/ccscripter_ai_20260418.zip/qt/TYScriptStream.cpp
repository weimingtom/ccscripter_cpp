#include "TYScriptStream.h"

// Converted from Objective-C

QObject* TYScriptStream::initWithData:()
{
    {
    // lex ɂďB
    
}

QObject* TYScriptStream::objectAtIndex:()
{
    {
    // ԂB
    
}

char* TYScriptStream::cStringAtIndex:()
{
    {
    // |C^ԂB
    
}

NSDictionary* TYScriptStream::labelDict()
{
    {
    // 쐬xԂB
    
    
}

