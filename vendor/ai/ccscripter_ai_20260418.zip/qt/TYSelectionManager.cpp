#include "TYSelectionManager.h"

// Converted from Objective-C

void TYSelectionManager::initialButtonImage()
{
    {
    NSEnumerator *enm;
    NSImage *temp;
    
    // SẴ{^`
    enm = [ btnArray objectEnumerator ];
    [ drawBuffer lockFocus ];
    while( (temp = [ enm nextObject ]) != nullptr){
    [ temp compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    [ drawBuffer unlockFocus ];
    
    [ [ stageManager compositeLayer ] lockFocus ];
    [ drawBuffer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    [ [ stageManager compositeLayer ] unlockFocus ];
    
    beforeSelection = 0;
    return;
    
    
}

bool TYSelectionManager::changeSelection:()
{
    {
    int i,count;
    id temp;
    
    if(beforeSelection == index)
    return false;
    
    count = [ btnArray count ];
    
    [ drawBuffer lockFocus ];
    NSRectFillUsingOperation(TYVirtualScreenRect(),NSCompositeClear);
    for(i=0; i < count; i++){
    temp = [ btnArray objectAtIndex:i ];
    
    if(i == index-1){
    [ temp changeCell:1 ];
    } else {
    [ temp changeCell:0 ];
    
    [ temp compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    [ drawBuffer unlockFocus ];
    
    [ [ stageManager compositeLayer ] lockFocus ];
    [ drawBuffer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    [ [ stageManager compositeLayer ] unlockFocus ];
    
    beforeSelection = index;
    
    return true;
    
    
}

