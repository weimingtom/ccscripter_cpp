#ifndef LZSS_H
#define LZSS_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // LZSS_H
