#ifndef TYSTRINGIMAGE_H
#define TYSTRINGIMAGE_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYStringImage : public QObject
{
    Q_OBJECT
public:
    QObject* initWithImage:();
    NSPoint origin();
    void setOrigin:(void value);
    void setOriginByValue:(void value);
};

#endif // TYSTRINGIMAGE_H
