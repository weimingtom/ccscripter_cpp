#include "TYMainController.h"

// Converted from Objective-C

void TYMainController::awakeFromNib()
{
    {
    */
    
    +(id)controller
    {
    return controller;
    
}

QObject* TYMainController::init()
{
    {
    this = [ super init ];
    controller = this;
    return this;
    
    // delegate
}

void TYMainController::applicationDidFinishLaunching()
{
    {
    id aObj;
    //NSImage *aImage;
    //NSBundle *bundle;
    
    // XNvgt@C̓ǂݍ݁A
    ScriptEngine = [ [ TYScriptEngine alloc ] initWithContentsOfFile:getNScrRootDirectory() ];
    if(!ScriptEngine){
    if(![ TYEnviroment boolForKey:TYDisableSelectScriptEnviroment ]){
    NSUserDefaults *def=[ NSUserDefaults standardUserDefaults ];
    NSString *str;
    NSOpenPanel *op = [ NSOpenPanel openPanel ];
    [ op setTitle:NSLocalizedString(QString::fromUtf8("Choose Game Directory"),nullptr) ];
    [ op setCanChooseDirectories:true ];
    [ op setCanChooseFiles:false ];
    [ op runModalForDirectory:[ def objectForKey:TYLastSelectedFolderPref ]
    file:nullptr
    types:nullptr ];
    str = [ op filename ];
    if(str){
    setNScrRootDirectory(str);
    [ TYEnviroment reload ];
    [ def setObject:str forKey:TYLastSelectedFolderPref ];
    [ def synchronize ];
    ScriptEngine = [ [ TYScriptEngine alloc ] initWithContentsOfFile:getNScrRootDirectory() ];
    
    if(!ScriptEngine)
    [ [ this class ] alertAndTerminate:NSLocalizedString(QString::fromUtf8("Do something"),nullptr)
    msg:NSLocalizedString(QString::fromUtf8("not exist 0.txt and nscript.dat"),nullptr) ];
    [ ScriptEngine retain ]; //@i
    
    // MainWindowContentViewݒ
    [ MainView setTarget:this ];
    [ MainView setFrame:TYVirtualScreenRect() ];
    /*
    aImage = [ [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ] autorelease ];
    [ aImage lockFocus ];
    [ [ NSColor blackColor ] set ];
    NSRectFill(TYVirtualScreenRect());
    [ aImage unlockFocus ];
    [ MainView setImage:aImage ];
    */
    
    //NSLog(QString::fromUtf8("%d"),[ MainWindow makeFirstResponder:MainView ]);
    [ MainWindow setContentSize:NSMakeSize(VSCREEN_WIDTH,VSCREEN_HEIGHT) ];
    [ MainWindow setAcceptsMouseMovedEvents:true ];
    //defaultContentView = [ [ MainWindow contentView ] retain ];
    [ [ MainWindow contentView ] addSubview:MainView ];
    //[ (NSWindow*)MainWindow setContentView:MainView ];
    [ MainWindow makeFirstResponder:MainView ];
    //[ MainWindow setNextResponder:MainView ];
    {
    NSNumber *xNum,*yNum;
    NSPoint windowPoint;
    NSRect windowFrame;
    
    if((xNum = [ TYEnviroment objectForKey:TYWindowPointXEnviroment ]) &&
    (yNum = [ TYEnviroment objectForKey:TYWindowPointYEnviroment ])){
    windowPoint.x = [ xNum intValue ];
    windowPoint.y = [ yNum intValue ];
    windowFrame = [ MainWindow frame ];
    windowFrame.origin = windowPoint;
    [ MainWindow setFrame:windowFrame display:false ];
    } else {
    [ MainWindow center ];
    [ MainWindow makeKeyAndOrderFront:this ];
    
    [ (NSWindow*)FullScrrenWindow setContentView:[ [ [ TYFullScreenContentView alloc ] initWithFrame:NSZeroRect ] autorelease ] ];
    
    usingDirectWaveCannelSet = [ [ NSMutableSet alloc ] initWithCapacity:2 ];
    
    // ݒ莫̓ǂݍ
    /* NX܂B
    bundle = [ NSBundle mainBundle ];
    TYSettingsDict = [ [ NSMutableDictionary dictionaryWithContentsOfFile:[ bundle pathForResource:QString::fromUtf8("Settings") ofType:QString::fromUtf8("plist") ] ] retain ];
    */
    
    /*
    audioSearchPath = [ [ NSBundle mainBundle ] localizedStringForKey:QString::fromUtf8("DEFAULT_AUDIO_TRACK_PATH")
    value:QString::fromUtf8("/Volumes/Audio CD/Track *.cdda")
    table:nullptr ];
    */
    // ReLXgj[̐ݒAp~
    /*
    if(![ TYEnviroment boolForKey:TYEnableContextMenuEnviroment ]){
    // Control+clickɔɂmenunilłKv
    [ MainView setMenu:nullptr ];
    */
    
    saveLoadController = [ [ TYSaveLoadManager alloc ] init ];
    [ saveLoadController setNumber:9 ];
    
    // I[fBIpX̎擾
    [ this setAudioPath:[ TYEnviroment objectForKey:TYAudioFilePathEnviroment ] ];
    
    // SVGA[h`FbN
    {
    BOOL isModeSVGA = [ ScriptEngine isModeSVGA ];
    if(isModeSVGA){
    NSRect frame;
    NSLog(QString::fromUtf8("Boot With 800 x 600 mode"));
    [ TYStageManager setModeSVGA ];
    frame = [ MainWindow frame ];
    frame.size = TYVirtualScreenSize();
    [ MainWindow setContentSize:frame.size ];
    frame.origin = NSZeroPoint;
    [ MainView setFrame:frame ];
    [ MainView setNeedsDisplay:true ];
    
    // Xe[W}l[W̏
    StageManager = [ [ TYStageManager alloc ] init ];
    
    // IuWFNgm֘AÂ
    [ ScriptEngine setController:this stageManager:StageManager ];
    [ StageManager setController:this engine:ScriptEngine ];
    
    // H[ݒ̃[h
    defBGMVol= 1.0;
    defVoiceVol=1.0;
    defSEVol=1.0;
    
    //BGMView = [ [ TYQTMusicPlayer alloc ] initWithFrame:NSZeroRect ];
    BGMView = [ [ NSMovieView alloc ] initWithFrame:NSZeroRect ];
    [ MainView addSubview:BGMView ];
    [ BGMView showController:false adjustingSize:false ];
    [ BGMView setEditable:false ];
    aObj = [ TYEnviroment objectForKey:TYBGMVolumeEnviroment ];
    if(aObj)
    BGMVolume = [ aObj floatValue ];
    else
    BGMVolume = 1.0;
    if(aObj = [ TYEnviroment objectForKey:TYVoiceVolumeEnviroment ])
    voiceVol = [ aObj floatValue ] *100 -100;
    if(aObj = [ TYEnviroment objectForKey:TYSEVolumeEnviroment ])
    seVol = [ aObj floatValue ] *100 -100;
    
    // Ԃ̏
    TYStatus = TYScriptRunningStatus;
    
    // Cxgʒm̓o^
    [ [ NSNotificationCenter defaultCenter ] addObserver:this selector:@selector(didChangeKeyWindow:) name:NSWindowDidBecomeKeyNotification object:nullptr ];
    
    // ENbNj[
    rightMenuLayout = [ [ NSMutableDictionary alloc ] initWithCapacity:8 ];
    [ rightMenuLayout setObject:[ NSColor whiteColor ] forKey:TYRMenuSelectColor ];
    [ rightMenuLayout setObject:[ NSColor grayColor ] forKey:TYRMenuNoSelectColor ];
    [ rightMenuLayout setObject:[ NSColor grayColor ] forKey:TYRMenuNoDataColor ];
    [ rightMenuLayout setObject:getTextWindowColorWithHTMLFormat(QString::fromUtf8("#999999")) forKey:TYRMenuBGColor ];
    [ this ty_menusetwindow:[ NSMutableArray arrayWithObjects:QString::fromUtf8("menusetwindow"),
    [ NSNumber numberWithInt:26 ],[ NSNumber numberWithInt:26 ],
    [ NSNumber numberWithInt:0 ],[ NSNumber numberWithInt:2 ],
    [ NSNumber numberWithInt:0 ],[ NSNumber numberWithInt:1 ],
    QString::fromUtf8("#999999"),nullptr ] ];
    
    // EChE[h̕
    if([ TYEnviroment boolForKey:TYFullScreenModeEnviroment ]){
    [ this performSelector:@selector(fullScreenMode:) withObject:this afterDelay:0 ];
    // XNvgJnB܂ContextĂȂ̂ňxCxg[v܂킷B
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    
}

NSApplicationTerminateReply TYMainController::applicationShouldTerminate:()
{
    {
    [ ScriptEngine saveExternalData ];
    [ [ TYResourceServer sharedServer ] saveLog:
    [ getNScrRootDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    {
    NSPoint windowPoint=[ MainWindow frame ].origin;
    [ TYEnviroment setObject:[ NSNumber numberWithInt:windowPoint.x ] forKey:TYWindowPointXEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithInt:windowPoint.y ] forKey:TYWindowPointYEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithBool:(isFullScreenMode) ? true : false ] forKey:TYFullScreenModeEnviroment ];
    
    [ TYEnviroment save ];
    
    if(tmpPath)
    [ [ NSFileManager defaultManager ] removeFileAtPath:tmpPath handler:nullptr ];
    
    TYWave2AiffCleanUp();
    
    if (isFullScreenMode && [ TYEnviroment boolForKey:TYHideOtherFullScreenEnviroment ] ) {
    [ this windowMode:nullptr ];
    [ TYEnviroment setObject:[ NSNumber numberWithBool:true ] forKey:TYFullScreenModeEnviroment ];
    
    return NSTerminateNow;
    
    +(void)alertAndTerminate:(NSString*)title msg:(NSString*)msg
    {
    NSRunAlertPanel(title,msg,QString::fromUtf8("OK"),nullptr,nullptr);
    [ NSApp terminate:nullptr ];
    
}

void TYMainController::disableContextMenu()
{
    {
    // Control+clickɔɂmenunilłKv
    [ MainView setMenu:nullptr ];
    
}

void TYMainController::setAudioPath:()
{
    {
    // pX̓WJ
    aPath = [ aPath stringByExpandingTildeInPath ];
    
    if(aPath->isAbsolutePath() == false){
    aPath = [ getNScrRootDirectory() stringByAppendingPathComponent:aPath ];
    
    audioSearchPath = [ aPath retain ];
    
}

void TYMainController::setStatus:()
{
    {
    TYStatus = aStatus;
    if((aStatus == TYClickWaitStatus)&&(autoclickTimer)){
    [ this performSelector:@selector(select_action) withObject:nullptr afterDelay:autoclickTimer / 1000.0 ];
    } else if((aStatus == TYButtonWaitStatus)||(aStatus == TYSelectStatus)) {
    //[ MainWindow setAcceptsMouseMovedEvents:true ];
    
}

int TYMainController::status()
{
    {
    return TYStatus;
    
}

void TYMainController::saveLocalData:()
{
    {
    NSMutableDictionary *aDict;
    NSMutableDictionary *objDict;
    NSString *filename,*path;
    NSCalendarDate *cDate=[ NSCalendarDate calendarDate ];
    
    aDict = [ NSMutableDictionary dictionaryWithCapacity:5 ];
    
    [ aDict setObject:cDate forKey:TYMakeDateSaveData ];
    [ aDict setObject:number forKey:TYNumberSaveData ];
    [ aDict setObject:[ NSNumber numberWithInt:TYSaveDataVersion ] forKey:TYVersionSaveData ];
    
    // ȀԂ肷B
    if([ this status ]==TYScriptRunningStatus){
    [ aDict setObject:[ NSNumber numberWithInt:TYScriptingSaveData ] forKey:TYDataTypeSaveData ];
    } else if( ([ this status ]==TYPrinting)&&([ StageManager status ]==TYTPClickWait) ){
    [ aDict setObject:[ NSNumber numberWithInt:TYPrintingWaitSaveData ] forKey:TYDataTypeSaveData ];
    } else {
    [ aDict setObject:[ NSNumber numberWithInt:TYScriptingSaveData ] forKey:TYDataTypeSaveData ];
    
    objDict = [ this encodeWithSaveData ];
    if(objDict)
    [ aDict addEntriesFromDictionary:objDict ];
    
    objDict = [ ScriptEngine encodeWithSaveData ];
    if(objDict)
    [ aDict addEntriesFromDictionary:objDict ];
    
    objDict = [ StageManager encodeWithSaveData ];
    if(objDict)
    [ aDict addEntriesFromDictionary:objDict ];
    
    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ number intValue ] ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
    [ NSArchiver archiveRootObject:aDict toFile:path ];
    //[ aDict writeToFile:path atomically:true ];
    
    // f[^ꗗXV
    [ saveLoadController resetDateWithNumber:[ number intValue ] ];
    
    // O[of[^̃Z[uɍsB
    [ ScriptEngine saveExternalData ];
    [ [ TYResourceServer sharedServer ] saveLog:
    [ getNScrRootDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    
    
}

bool TYMainController::loadLocalData:()
{
    {
    NSString *filename,*path;
    NSDictionary *aDict;
    int scriptStatus;
    
    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ number intValue ] ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
    
    aDict = [ NSUnarchiver unarchiveObjectWithFile:path ];
    //aDict = [ NSDictionary dictionaryWithContentsOfFile:path ];
    if(!aDict)
    return false;
    
    [ this decodeWithSaveData:aDict ];
    [ ScriptEngine decodeWithSaveData:aDict ];
    [ StageManager decodeWithSaveData:aDict ];
    
    if([ this status ] == TYScriptRunningStatus){
    [ ScriptEngine setBreakRun:true ];
    
    scriptStatus = [ [ aDict objectForKey:TYDataTypeSaveData ] intValue ];
    if(scriptStatus==TYScriptingSaveData){
    [ this setStatus:TYScriptRunningStatus ];
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    } else {
    [ this setStatus:TYPrinting ];
    [ StageManager setStatus:TYTPClickWait];
    
    return true;
    
}

QObject* TYMainController::encodeWithSaveData()
{
    {
    NSMutableDictionary *dict = [ NSMutableDictionary dictionary ];
    
    NSString *wavePath;
    
    if(waveController){
    wavePath = [ waveController soundPathIfNeedPlayingAtLoad ];
    if(wavePath)
    [ dict setObject:wavePath forKey:TYWavePathSaveData ];
    
    if(bgmPath){
    if([ BGMView loopMode ]==NSQTMovieLoopingPlayback){
    [ dict setObject:bgmPath forKey:TYBGMPathSaveData ];
    } else if(bgmForceSave){
    [ dict setObject:bgmPath forKey:TYBGMPathSaveData ];
    [ dict setObject:[ NSNumber numberWithBool:true ] forKey:TYBGMNoLoopSaveData ];
    
    [ dict setObject:[ NSNumber numberWithInt:autoclickTimer ] forKey:TYAutoClickTimerSaveData ];
    
    return dict;
    
}

void TYMainController::decodeWithSaveData:()
{
    {
    id temp;
    
    if([ BGMView isPlaying ])
    [ BGMView stop:this ];
    if(bgmPath){
    [ bgmPath release ];
    bgmPath = nullptr;
    temp = [ aObject objectForKey:TYBGMPathSaveData ];
    if(temp){
    id temp2;
    temp2 = [ aObject objectForKey:TYBGMNoLoopSaveData ];
    [ this playSound:temp loop:(temp2) ? false : true forceSave:(temp2) ? true : false ];
    
    if(waveController){
    [ waveController release ];
    waveController = nullptr;
    temp = [ aObject objectForKey:TYWavePathSaveData ];
    if(temp){
    waveController = [ [ TYSoundController alloc ] initWithResource:temp loop:true ];
    [ waveController play ];
    
    temp = [ aObject objectForKey:TYAutoClickTimerSaveData ];
    if(temp){
    autoclickTimer = [ temp intValue ];
    } else {
    autoclickTimer = 0;
    
    
}

int TYMainController::autoclickTimer()
{
    {
    return autoclickTimer;
    
}

void TYMainController::setImage:()
{
    {
    [ MainView setImage:aImage ];
    [ MainView setNeedsDisplay:true ];
    
}

void TYMainController::setImage:()
{
    {
    [ MainView setImage:aImage ];
    if(isFullScreenMode){
    [ MainView setNeedsDisplayScalingRect:inRect ];
    } else {
    [ MainView setNeedsDisplayInRect:inRect ];
    
}

NSImage* TYMainController::image()
{
    {
    return [ MainView image ];
    
}

void TYMainController::directDrawImage:()
{
    {
    [ MainView directDrawImage:sourceImage inRect:inRect fromRect:fromRect ];
    
}

NSImage* TYMainController::makeImageFromMainView()
{
    {
    NSImage *image;
    NSBitmapImageRep *rep;
    
    [ MainView lockFocus ];
    rep = [ [ NSBitmapImageRep alloc ] initWithFocusedViewRect:[ MainView frame ] ];
    [ MainView unlockFocus ];
    if(!rep)
    return nullptr;
    [ rep setSize:TYVirtualScreenSize() ];
    
    image = [ [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ] autorelease ];
    [ image addRepresentation:rep ];
    return image;
    
}

void TYMainController::setNeedsDisplayMainView:()
{
    {
    [ MainView setNeedsDisplay:true ];
    
}

void TYMainController::setAcceptsMouseMovedEvents:()
{
    {
    //[ MainWindow setAcceptsMouseMovedEvents:flag ];
    
}

NSWindow* TYMainController::mainWindow()
{
    
}

void TYMainController::ty_savenumber:()
{
    {
    [ saveLoadController setNumber:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] ];
    
}

void TYMainController::ty_savefileexist:()
{
    {
    NSString *path,*filename;
    BOOL exist;
    
    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ] ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
    
    exist = [ [ NSFileManager defaultManager ] fileExistsAtPath:path ];
    
    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:QString::fromUtf8("mov"),[ argments objectAtIndex:1 ],[ NSNumber numberWithInt:(exist) ? 1 : 0 ],nullptr ] ];
    
}

void TYMainController::ty_savetime:()
{
    {
    NSDictionary *aDict;
    NSString *path,*filename;
    int dateValue[4];
    NSMutableArray *evalArg;
    NSCalendarDate *date;
    int i;
    
    filename = [ NSString stringWithFormat:SAVEDATA_NAME,[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
    
    aDict = [ NSUnarchiver unarchiveObjectWithFile:path ];
    if(!aDict){
    evalArg = [ NSMutableArray arrayWithObjects:@"",[ argments objectAtIndex:2 ],[ NSNumber numberWithInt:0 ],nullptr
    ];
    [ ScriptEngine ty_mov:evalArg ];
    } else {
    date = [ aDict objectForKey:TYMakeDateSaveData ];
    dateValue[0] = [ date monthOfYear ];
    dateValue[1] = [ date dayOfMonth ];
    dateValue[2] = [ date hourOfDay ];
    dateValue[3] = [ date minuteOfHour ];
    for(i=0;i < 4; i++){
    evalArg = [ NSMutableArray arrayWithObjects:@"",[ argments objectAtIndex:2+i ],
    [ NSNumber numberWithInt:dateValue[i] ],nullptr ];
    [ ScriptEngine ty_mov:evalArg ];
    
}

void TYMainController::ty_filelog:()
{
    {
    [ [ TYResourceServer sharedServer ] filelog:
    [ getNScrRootDirectory() stringByAppendingPathComponent:FILELOG_FILENAME ] ];
    
}

void TYMainController::ty_mp3:()
{
    {
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:false ];
    
}

void TYMainController::ty_mp3save:()
{
    {
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:true ];
    
}

void TYMainController::ty_mp3loop:()
{
    {
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true forceSave:false ];
    
}

void TYMainController::ty_mp3stop:()
{
    {
    [ this ty_playstop:argments ];
    
}

void TYMainController::ty_play:()
{
    {
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true forceSave:false ];
    
}

void TYMainController::ty_playonce:()
{
    {
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:false ];
    
}

void TYMainController::ty_bgm:()
{
    {
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true forceSave:false ];
    
}

void TYMainController::ty_bgmonce:()
{
    {
    [ this playSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false forceSave:false ];
    
}

void TYMainController::playSound:()
{
    {
    NSArray *components;
    NSMovie *movie;
    int trackNo;
    NSString *path;
    
    if(![ argment length ]){
    [ this ty_playstop:nullptr ];
    return;
    
    if(bgmPath)
    [ bgmPath autorelease ];
    bgmPath = [ argment retain ];
    bgmForceSave = save;
    
    if([ [ argment substringWithRange:NSMakeRange(0,1) ] isEqualToString:QString::fromUtf8("*") ]){
    // I[fBIgbN̉t
    trackNo = [ [ argment substringFromIndex:1 ] intValue ];
    components = [ audioSearchPath componentsSeparatedByString:QString::fromUtf8("*") ];
    path = [ NSString stringWithFormat:QString::fromUtf8("%@%02d%@"),[ components objectAtIndex:0 ],trackNo,[ components objectAtIndex:1 ] ];
    movie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:path ] byReference:true ];
    } else {
    NSData *data;
    NSString *filePath;
    //NSString *tempPath;
    
    if(filePath = [ [ TYResourceServer sharedServer ] getFilePath:bgmPath ]){
    movie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:filePath ] byReference:true ];
    } else {
    NSString *newTmpPath;
    newTmpPath = [ getNScrRootDirectory() stringByAppendingPathComponent:[ NSString stringWithFormat:QString::fromUtf8(".%@"),[ winPathToUnix(bgmPath) lastPathComponent ] ] ];
    if([ tmpPath isEqualToString:newTmpPath ]){
    [ BGMView gotoBeginning:nullptr ];
    [ BGMView start:nullptr ];
    return;
    [ [ NSFileManager defaultManager ] removeFileAtPath:tmpPath handler:nullptr ];
    [ tmpPath release ];
    tmpPath = newTmpPath;
    
    // ォNSMovie@ς蕪Ȃ̂ŁAfBXNɈxނƂɂB
    data = [ [ TYResourceServer sharedServer ] getData:winPathToUnix(bgmPath) ];
    if(data){
    [ tmpPath retain ];
    [ data writeToFile:tmpPath atomically:false ];
    movie = [ [ NSMovie alloc ] initWithURL:[ NSURL fileURLWithPath:tmpPath ] byReference:true ];
    // MP3t@CbyReferenace:NOȂ̂
    //[ [ NSFileManager defaultManager ] removeFileAtPath:tempPath handler:nullptr ];
    } else {
    tmpPath = nullptr;
    movie = nullptr;
    path = bgmPath;
    
    if(!movie){
    qtMovie = NULL;
    if(gMyTimer)
    [ gMyTimer invalidate ];
    gMyTimer = nullptr;
    [ BGMView stop:nullptr ];
    NSLog(QString::fromUtf8("can't play audio file = %@"),path);
    return;
    [ BGMView setMovie:movie ];
    if(aBool)
    [ BGMView setLoopMode:NSQTMovieLoopingPlayback ];
    else
    [ BGMView setLoopMode:NSQTMovieNormalPlayback ];
    [ BGMView setVolume:BGMVolume ];
    
    if (floor(NSAppKitVersionNumber) < NSAppKitVersionNumber10_2) {
    qtMovie = [ movie QTMovie ];
    gMyTimer = NSTimer->scheduledTimerWithTimeInterval(0.1		// interval, 0.1 seconds
    target:this
    selector:@selector(idleTimer:)		// call this method
    userInfo:nullptr
    repeats:true];
    [ BGMView start:nullptr ];
    NSLog2(QString::fromUtf8("playing=%d"),[ BGMView isPlaying ]);
    [ movie release ];
    
}

void TYMainController::ty_playstop:()
{
    {
    if([ BGMView isPlaying ])
    [ BGMView stop:this ];
    
    if(bgmPath)
    [ bgmPath release ];
    
    bgmPath=nullptr;
    
}

void TYMainController::idleTimer:()
{
    {
    MoviesTask(qtMovie,0);
    
    // ̌Quick Time API𒼐ڌĂяoƕsN̂ŕB
    // Apple͂ƂƂNSMovieView̃oOB
}

void TYMainController::ty_avi:()
{
    {
    [ this playMovie:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ]
    cancel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ] ];
    
}

void TYMainController::ty_mpegplay:()
{
    {
    [ this playMovie:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ]
    cancel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ] ];
    
}

void TYMainController::playMovie:()
{
    {
    NSString *filePath;
    Movie movie;
    
    if([ TYEnviroment boolForKey:TYEnablePlayMovieEnviroment ] == false)
    return;
    
    filePath = [ [ TYResourceServer sharedServer ] getFilePathMakeTemp:aPath ];
    if(!filePath)
    return;
    
    movieView = [ [ NSMovieView alloc ] initWithFrame:TYVirtualScreenRect() ];
    [ movieView setMovie:
    [ [ [ NSMovie alloc ] initWithURL:
    [ [ [ NSURL alloc ] initFileURLWithPath:filePath ] autorelease ]
    byReference:true ] autorelease ] ];
    [ movieView showController:false adjustingSize:false ];
    [ movieView setEditable:false ];
    [ movieView setVolume:[ BGMView volume ] ];
    [ movieView setFrame:TYVirtualScreenRect() ];
    movie = [ [ movieView movie ] QTMovie ];
    [ movieView setLoopMode:NSQTMovieNormalPlayback ];
    
    ctrlView = [ [ TYMovieControllerView alloc ] initWithFrame:TYVirtualScreenRect() ];
    [ ctrlView setController:this ];
    [ MainView addSubview:movieView ];
    [ movieView addSubview:ctrlView ];
    [ MainWindow makeFirstResponder:ctrlView ];
    
    [ movieView start:this ];
    [ this performSelector:@selector(endCheckMovie)
    withObject:nullptr
    afterDelay:GetMovieDuration(movie) / GetMovieTimeScale(movie) ];
    
    [ ScriptEngine setBreakRun:true ];
    
}

void TYMainController::endCheckMovie()
{
    {
    if([ movieView isPlaying ]) {
    [ this performSelector:@selector(endCheckMovie)
    withObject:nullptr
    afterDelay:0.1 ];
    } else {
    [ this endPlayMovie ];
    
}

void TYMainController::endPlayMovie()
{
    {
    if(!movieView) return;
    
    [ NSObject cancelPreviousPerformRequestsWithTarget:this
    selector:@selector(endCheckMovie) object:nullptr ];
    
    [ movieView stop:nullptr ];
    [ ctrlView removeFromSuperview ];
    [ movieView removeFromSuperview ];
    [ ctrlView autorelease ];
    [ movieView autorelease ];
    ctrlView = nullptr;
    movieView = nullptr;
    
    [ MainWindow makeFirstResponder:MainView ];
    if(isFullScreenMode==true)
    [ [ FullScrrenWindow contentView ] setNeedsDisplay:true ];
    [ ScriptEngine performSelector:@selector(runScript)  withObject:nullptr afterDelay:0 ];
    
}

void TYMainController::ty_v:()
{
    {
    [ this playWaveSound:[ NSString stringWithFormat:INSTANT_WAVE_PATH_FORMAT,[ argments objectAtIndex:1 ] ] loop:false ];
    
}

void TYMainController::ty_wave:()
{
    {
    [ this playWaveSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:false ];
    
}

void TYMainController::ty_waveloop:()
{
    {
    [ this playWaveSound:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] loop:true ];
    
}

void TYMainController::playWaveSound:()
{
    {
    if(waveController) {
    [ waveController stop ];
    // 10.3NSSoundThread Safeł͖oO悤Ȃ̂ŁAx点ĂB
    [ waveController performSelector:@selector(autorelease) withObject:nullptr afterDelay:15.0 ];
    waveController = [ [ TYSoundController alloc ] initWithResource:argment loop:aBool ];
    
    if(enable_automode && !aBool)
    [ waveController setPostingNotification:true ];
    [ waveController play ];
    
}

void TYMainController::ty_wavestop:()
{
    {
    [ waveController stop ];
    
}

void TYMainController::ty_dv:()
{
    {
    [ this playWaveChannel:0
    path:[ NSString stringWithFormat:INSTANT_WAVE_PATH_FORMAT,[ argments objectAtIndex:1 ] ]
    loop:false ];
    
}

void TYMainController::ty_dwave:()
{
    {
    [ this playWaveChannel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]
    path:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ]
    loop:false ];
    
}

void TYMainController::ty_dwaveloop:()
{
    {
    [ this playWaveChannel:[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]
    path:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ]
    loop:true ];
    
}

void TYMainController::playWaveChannel:()
{
    {
    int volume;
    
    NSAssert(((0 <= ch) && (ch < DIRECT_WAVE_MAX)),QString::fromUtf8("Direct Sound Channel Error"));
    
    switch(ch){
    case 0:
    case DIRECT_WAVE_REPLAY:
    volume = (100 +voiceVol) *TYSOUND_VOLUME_MAX /100;
    break;
    default:
    volume = (100 +seVol) *TYSOUND_VOLUME_MAX /100;
    
    
    if(*(directWaveController + ch)) {
    [ *(directWaveController + ch)stop ];
    // 10.3NSSoundThread Safeł͖oO悤Ȃ̂ŁAxꂹĂB
    [ *(directWaveController + ch) performSelector:@selector(release) withObject:nullptr afterDelay:15.0 ];
    
    *(directWaveController + ch) = [ [ TYSoundController alloc ] initWithResource:aPath
    loop:aBool
    volume:volume ];
    if((ch==0) && !aBool)
    [ *(directWaveController +ch) setPostingNotification:true ];
    
    if(ch==0)
    [ [ NSNotificationCenter defaultCenter ]
    postNotificationName:TYVoicePlayNotification
    object:aPath ];
    
    [ usingDirectWaveCannelSet addObject:[ NSNumber numberWithInt:ch ] ];
    
    [ *(directWaveController + ch) play ];
    
    
}

void TYMainController::ty_dwavestop:()
{
    {
    int ch = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    NSAssert(((0 <= ch) && (ch < DIRECT_WAVE_MAX)),QString::fromUtf8("Direct Sound Channel Error"));
    
    [ *(directWaveController + ch)stop ];
    
}

void TYMainController::ty_stop:()
{
    {
    NSEnumerator *enu;
    id temp;
    
    if([ BGMView isPlaying ])
    [ BGMView stop:this ];
    
    if(bgmPath)
    [ bgmPath release ];
    
    bgmPath=nullptr;
    
    [ waveController stop ];
    
    enu = [ usingDirectWaveCannelSet objectEnumerator ];
    while( temp = [ enu nextObject ]){
    [ directWaveController[ [ temp intValue ] ] stop ];
    
    // EChE^CgύX
}

void TYMainController::ty_caption:()
{
    {
    [ MainWindow setTitle:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    
    // o[WύX
}

void TYMainController::ty_versionstr:()
{
    {
    scriptVersionStr = [ NSString stringWithFormat:QString::fromUtf8("%@\n%@"),[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ],[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ] ];
    [ scriptVersionStr retain ];
    
}

void TYMainController::ty_click:()
{
    {
    [ ScriptEngine setBreakRun:true ];
    [ this setStatus:TYClickWaitStatus ];
    
}

void TYMainController::ty_autoclick:()
{
    {
    autoclickTimer = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    //[ StageManager setAutoclickTimer:autoclickTimer ];
    
}

void TYMainController::ty_wait:()
{
    {
    [ ScriptEngine setBreakRun:true ];
    [ this setStatus:TYTimeWaitStatus ];
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:
    [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] / 1000.0 ];
    
}

void TYMainController::ty_delay:()
{
    {
    [ ScriptEngine setBreakRun:true ];
    [ this setStatus:TYClickWaitStatus ];
    [ this performSelector:@selector(select_action) withObject:nullptr afterDelay:
    [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] / 1000.0 ];
    
}

void TYMainController::ty_spi:()
{
    {
    NSArray *argArray;
    NSString *arg;
    
    arg = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    argArray = [ arg componentsSeparatedByString:QString::fromUtf8("|") ];
    
    [ [ TYResourceServer sharedServer ] addSpi:[ argArray objectAtIndex:0 ] extension:[ argArray objectAtIndex:1 ] ];
    
}

void TYMainController::ty_soundpressplgin:()
{
    {
    NSArray *argArray;
    NSString *arg;
    
    arg = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    argArray = [ arg componentsSeparatedByString:QString::fromUtf8("|") ];
    
    [ [ TYResourceServer sharedServer ] addSoundPressPlugin:[ argArray objectAtIndex:0 ] extension:[ argArray objectAtIndex:1 ] ];
    
}

void TYMainController::ty_mode_ext:()
{
    {
    mode_ext=true;
    [ this setEnableAutomode:true ];
    
}

void TYMainController::setEnableAutomode:()
{
    {
    int i,n;
    NSMenu *menu;
    NSMenuItem *mItem=[ [ NSMenuItem alloc ] initWithTitle:NSLocalizedString(QString::fromUtf8("AutoMode..."),nullptr)
    action:NULL
    keyEquivalent:QString::fromUtf8("A") ];
    
    enable_automode=aBool;
    
    //[ TYSoundController setPostingNotification:true ];
    
    [ mItem setEnabled:true ];
    [ mItem setAction:@selector(openAutoMode:) ];
    [ mItem setTarget:this ];
    menu = [ NScrMenu submenu ];
    n = [ menu numberOfItems ];
    i = 0;
    while(1){
    if([ menu itemAtIndex:i ] == SkipMenu){
    [ menu insertItem:mItem atIndex:i ];
    break;
    i++;
    if(i>=n){
    [ menu insertItem:mItem atIndex:i ];
    break;
    /*
    [ ScriptEngine setBreakRun:true ];
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    */
    
    
    
}

void TYMainController::ty_automode_time:()
{
    {
    NSNumber *temp;
    
    if(!enable_automode)
    [ this setEnableAutomode:true ];
    
    if(!(temp = [ TYEnviroment objectForKey:TYAutomodeWaitTimeEnviroment ])) {
    temp = [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ];
    [ TYEnviroment setObject:[ NSNumber numberWithInt:[ temp intValue ] ] forKey:TYAutomodeWaitTimeEnviroment ];
    
}

void TYMainController::ty_defmp3vol:()
{
    {
    defBGMVol=[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] /100.0;
    
}

void TYMainController::ty_voicevol:()
{
    {
    // Ȃ100񂾂? łB
    voiceVol = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] -100;
    
}

void TYMainController::ty_defvoicevol:()
{
    {
    defVoiceVol=[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] /100.0;
    
}

void TYMainController::ty_sevol:()
{
    {
    seVol = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] -100;
    
}

void TYMainController::ty_defsevol:()
{
    {
    defSEVol=[ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] /100.0;
    
}

void TYMainController::ty_mp3vol:()
{
    {
    int volume;
    
    volume = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    
    BGMVolume = volume / 100.0;
    [ BGMView setVolume:volume / 100.0 ];
    
}

void TYMainController::ty_kidokuskip:()
{
    {
    if(![ TYEnviroment objectForKey:TYKidokumodeEnviroment ]) {
    [ TYEnviroment setObject:[ NSNumber numberWithBool:true ] forKey:TYKidokumodeEnviroment ];
    [ SkipMenu setTitle:NSLocalizedString(QString::fromUtf8("KidokuSkip"),nullptr) ];
    [ SkipMenu setAction:@selector(skipWhileKidoku:) ];
    [ ScriptEngine enableKidoku ];
    
}

void TYMainController::ty_kidokumode:()
{
    {
    [ TYEnviroment setObject:
    [ NSNumber numberWithBool:(([ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ]) ? true : false) ]
    forKey:TYKidokumodeEnviroment ];
    
}

void TYMainController::ty_reset:()
{
    {
    [ this resetGame:nullptr ];
    
}

void TYMainController::ty_menu_window:()
{
    {
    [ this windowMode:nullptr ];
    
}

void TYMainController::ty_menu_full:()
{
    {
    [ this fullScreenMode:nullptr ];
    
}

void TYMainController::ty_savename:()
{
    {
    [ saveLoadController setNames:[ NSArray arrayWithObjects:
    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ],
    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ],
    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:3 ] ],nullptr ] ];
    
}

void TYMainController::ty_systemcall:()
{
    {
    NSString *arg=[ [ argments objectAtIndex:1 ] lowercaseString ];
    
    if([ arg isEqualToString:QString::fromUtf8("load") ]){
    [ this enterSaveLoadMenu:1 ];
    } else if([ arg isEqualToString:QString::fromUtf8("save") ]){
    [ this enterSaveLoadMenu:0 ];
    } else if([ arg isEqualToString:QString::fromUtf8("skip") ]){
    id envObj;
    envObj = [ TYEnviroment objectForKey:TYKidokumodeEnviroment ];
    if(envObj && [ envObj boolValue ])
    [ this skipWhileKidoku:nullptr ];
    else
    [ this skipToSelection:nullptr ];
    } else if([ arg isEqualToString:QString::fromUtf8("windowerase") ]){
    [ this eraseTextWindowMode:nullptr ];
    } else if([ arg isEqualToString:QString::fromUtf8("lookback") ]){
    [ this enterLookback:nullptr ];
    } else if([ arg isEqualToString:QString::fromUtf8("rmenu") ]){
    [ this openRightclickMenu:nullptr ];
    } else if([ arg isEqualToString:QString::fromUtf8("reset") ]){
    [ this enterYesNoModeTitle:NSLocalizedString(QString::fromUtf8("May I reset?"),nullptr)
    yesAction:QString::fromUtf8("_reset")
    noAction:@"" ];
    } else if([ arg isEqualToString:QString::fromUtf8("resetdlg") ]){
    [ this resetGame:[ NSNull null ] ];
    } else if([ arg isEqualToString:QString::fromUtf8("_reset") ]){
    [ this resetGame:nullptr ];
    } else if([ arg length ] >= 7) {
    NSString *cmd = [ arg substringWithRange:NSMakeRange(0,6) ];
    NSString *nostr = [ arg substringFromIndex:6 ];
    NSArray *names = [ saveLoadController names ];
    NSString *bookmark;
    NSString *title;
    
    if([ cmd isEqualToString:QString::fromUtf8("_qload") ]){
    bookmark = [ [ names objectAtIndex:2 ] stringByAppendingString:
    TYWideCharDecimalStringWithString(nostr) ];
    title = [ NSString stringWithFormat:NSLocalizedString(QString::fromUtf8("May I Load?"),nullptr),bookmark ];
    [ this enterYesNoModeTitle:title
    yesAction:[ QString::fromUtf8("_eload") stringByAppendingString:nostr ]
    noAction:@"" ];
    } else if([ cmd isEqualToString:QString::fromUtf8("_qsave") ]){
    bookmark = [ [ names objectAtIndex:2 ] stringByAppendingString:
    TYWideCharDecimalStringWithString(nostr) ];
    title = [ NSString stringWithFormat:NSLocalizedString(QString::fromUtf8("May I Save?"),nullptr),bookmark ];
    [ this enterYesNoModeTitle:title
    yesAction:[ QString::fromUtf8("_esave") stringByAppendingString:nostr ]
    noAction:@"" ];
    } else if([ cmd isEqualToString:QString::fromUtf8("_eload") ]) {
    [ NSObject cancelPreviousPerformRequestsWithTarget:ScriptEngine
    selector:@selector(runScript)
    object:nullptr ];
    [ this loadLocalData:[ NSNumber numberWithInt:[ nostr intValue ] ] ];
    } else if([ cmd isEqualToString:QString::fromUtf8("_esave") ]) {
    [ NSObject cancelPreviousPerformRequestsWithTarget:ScriptEngine
    selector:@selector(runScript)
    object:nullptr ];
    [ this saveLocalData:[ NSNumber numberWithInt:[ nostr intValue ] ] ];
    
}

void TYMainController::enterYesNoModeTitle:()
{
    yesAction:(NSString*)yAction
    noAction:(NSString*)nAction
    {
    TYMenuModeView *aView;
    aView = [ [ TYYesNoMenuView alloc ] initWithFrame:TYVirtualScreenRect()
    controller:this
    attributes:[ StageManager textAttDict ]
    titleAndAction:
    [ NSMutableArray arrayWithObjects:
    title,
    yAction,
    nAction,nullptr ]
    layout:rightMenuLayout ];
    [ MainView addSubview:aView ];
    [ [ aView window ] makeFirstResponder:aView ];
    [ aView updatesTrackingRect ];
    [ this enterSystemMode ];
    
}

void TYMainController::ty_rmenu:()
{
    {
    id temp;
    NSEnumerator *enu;
    
    if(rightMenuItemArray)
    [ rightMenuItemArray release ];
    
    rightMenuItemArray = [ [ NSMutableArray alloc ] initWithCapacity:[ argments count ] -1 ];
    
    enu = [ argments objectEnumerator ];
    [ enu nextObject ];
    while(temp = [ enu nextObject ]){
    [ rightMenuItemArray addObject:[ ScriptEngine getStringOfArgment:temp ] ];
    temp = [ enu nextObject ];
    [ rightMenuItemArray addObject:temp ];
    
}

void TYMainController::ty_menusetwindow:()
{
    {
    NSSize fontSize,pitchSize;
    int shadow,bold;
    NSColor *color;
    
    fontSize.width = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    fontSize.height = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    pitchSize.width = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    pitchSize.height = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    bold = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ];
    shadow = [ [ ScriptEngine getValueOfArgment:[ argments objectAtIndex:6 ] ] intValue ];
    color = getTextWindowColorWithHTMLFormat([ ScriptEngine getStringOfArgment:[ argments objectAtIndex:7 ] ]);
    
    [ rightMenuLayout setObject:[ NSValue valueWithSize:fontSize ] forKey:TYRMenuFontSize ];
    [ rightMenuLayout setObject:[ NSValue valueWithSize:pitchSize ] forKey:TYRMenuFontPitchSize ];
    [ rightMenuLayout setObject:[ NSNumber numberWithBool:shadow ] forKey:TYRMenuShadowed ];
    [ rightMenuLayout setObject:[ NSNumber numberWithBool:bold ] forKey:TYRMenuBold ];
    [ rightMenuLayout setObject:color forKey:TYRMenuBGColor ];
    
}

void TYMainController::ty_menuselectcolor:()
{
    {
    NSColor *color;
    NSString* str;
    
    if(!rightMenuLayout)
    rightMenuLayout = [ [ NSMutableDictionary alloc ] initWithCapacity:8 ];
    
    str = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ];
    color = getColorWithHTMLFormat(str);
    [ rightMenuLayout setObject:color forKey:TYRMenuSelectColor ];
    
    str = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ];
    color = getColorWithHTMLFormat(str);
    [ rightMenuLayout setObject:color forKey:TYRMenuNoSelectColor ];
    
    str = [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:3 ] ];
    color = getColorWithHTMLFormat(str);
    [ rightMenuLayout setObject:color forKey:TYRMenuNoDataColor ];
    
}

void TYMainController::ty_lookbackcolor:()
{
    {
    lookbackColor = [ getColorWithHTMLFormat([ argments objectAtIndex:1 ]) retain ];
    
}

void TYMainController::ty_lookbackbutton:()
{
    {
    lookbackBtn = [ NSArray arrayWithObjects:
    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ],
    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:2 ] ],
    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:3 ] ],
    [ ScriptEngine getStringOfArgment:[ argments objectAtIndex:4 ] ],nullptr ];
    [ lookbackBtn retain ];
    
}

void TYMainController::ty_getmousepos:()
{
    {
    NSPoint btnClickPoint;
    NSPoint screenPoint;
    NSPoint windowPoint;
    NSPoint viewPoint;
    
    // 10.2.5AconvetPoint: fromView:niloOĂ(
    screenPoint = [ NSEvent mouseLocation ];
    windowPoint = [ [ MainView window ] frame ].origin;
    viewPoint = [ MainView frame ].origin;
    
    btnClickPoint = NSMakePoint(screenPoint.x -windowPoint.x -viewPoint.x,
    screenPoint.y -windowPoint.y -viewPoint.y);
    if(btnClickPoint.x < 0)
    btnClickPoint.x = 0;
    else if(btnClickPoint.x > VSCREEN_WIDTH)
    btnClickPoint.x = VSCREEN_WIDTH;
    
    if(btnClickPoint.y < 0)
    btnClickPoint.y = 0;
    else if(btnClickPoint.y > VSCREEN_HEIGHT)
    btnClickPoint.y = VSCREEN_HEIGHT;
    btnClickPoint.y = VSCREEN_HEIGHT -btnClickPoint.y;
    
    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:QString::fromUtf8("mov"),[ argments objectAtIndex:1 ],[ NSNumber numberWithInt:btnClickPoint.x ],nullptr ] ];
    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:QString::fromUtf8("mov"),[ argments objectAtIndex:2 ],[ NSNumber numberWithInt:btnClickPoint.y ],nullptr ] ];
    
}

void TYMainController::ty_exec_dll:()
{
    {
    [ [ TYResourceServer sharedServer ] executeBundle:[ ScriptEngine getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    [ ScriptEngine setBreakRun:true ];
    
}

void TYMainController::ty_getret:()
{
    {
    TYArgment *arg = [ argments objectAtIndex:1 ];
    
    if([ arg varType ] & TYDigitVarTypeMask) {
    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:QString::fromUtf8("mov"),arg,
    [ NSNumber argmentWithInt:[ [ TYCCSProxy proxy ] returnCode ] ],nullptr ] ];
    } else if([ arg varType ] ==  TYStringVarType) {
    [ ScriptEngine ty_mov:[ NSMutableArray arrayWithObjects:QString::fromUtf8("mov"),arg,
    [ [ TYCCSProxy proxy ] returnString ],nullptr ] ];
    
}

void TYMainController::setTrap:()
{
    {
    trapSelectAction = aBool;
    
}

void TYMainController::changeFont:()
{
    {
    [ StageManager changeFont:fontManager ];
    
}

IBAction TYMainController::changeTextSpeed:()
{
    {
    NSEnumerator *enu=[ [ SpeedMenu itemArray ] objectEnumerator ];
    id tmp;
    
    while((tmp = [ enu nextObject ])!=nullptr){
    [ tmp setState:NSOffState ];
    [ sender setState:NSOnState ];
    
    [ StageManager changeTextSpeed:[ sender tag ] ];
    
}

int TYMainController::selectedSpeedTag()
{
    {
    NSEnumerator *enu=[ [ SpeedMenu itemArray ] objectEnumerator ];
    id tmp;
    
    while((tmp = [ enu nextObject ])!=nullptr){
    if(tmp->state()==NSOnState){
    return [ tmp tag ];
    return -1;
    
}

IBAction TYMainController::skipToSelection:()
{
    {
    [ StageManager setSkipStatus:TYSelectionSkipMask ];
    
}

IBAction TYMainController::skipWhileKidoku:()
{
    {
    [ ScriptEngine setWatchKidoku:true ];
    [ StageManager setSkipStatus:TYKidokuSkipMask ];
    
}

IBAction TYMainController::versionDisp:()
{
    {
    NSString *title;
    title = NSLocalizedString(QString::fromUtf8("SCRIPT_VERSION"),nullptr);
    NSRunInformationalAlertPanel(title,scriptVersionStr,QString::fromUtf8("OK"),nullptr,nullptr);
}

IBAction TYMainController::openSaveDialog:()
{
    {
    if([ this isPossibleEnterSystemMode ]){
    [ this enterSaveLoadMenu:0 ];
    } else {
    NSBeep();
    
    
}

IBAction TYMainController::openLoadDialog:()
{
    {
    if([ this isPossibleEnterSystemMode ]){
    [ this enterSaveLoadMenu:1 ];
    } else {
    NSBeep();
    
}

void TYMainController::enterSaveLoadMenu:()
{
    {
    NSArray *dArray;
    NSArray *eArray;
    TYSaveLoadMenuView *aView;
    
    dArray = [ saveLoadController dateStrings:loadmode ];
    eArray = [ saveLoadController existsArray ];
    
    aView = [ [ TYSaveLoadMenuView alloc ] initWithFrame:TYVirtualScreenRect()
    controller:this
    layout:rightMenuLayout
    attributes:[ StageManager textAttDict ]
    dateStrArray:[ saveLoadController dateStrings:loadmode ]
    existsArray:[ saveLoadController existsArray ]
    doLoad:loadmode ];
    [ MainView addSubview:aView ];
    [ [ aView window ] makeFirstResponder:aView ];
    [ aView updatesTrackingRect ];
    [ this enterSystemMode ];
    
    /* obsolute
}

void TYMainController::openSaveLoadDialog:()
{
    {
    NSAutoreleasePool *aPool;
    NSDictionary* aDict;
    NSString *path,*filename;
    id aObj;
    int result;
    int i,num;
    
    if([ saveLoadController isLoaded ] == false){
    // LoadĂȂ΃Z[uf[^t@C
    num = [ saveLoadController number ];
    aPool = [ [ NSAutoreleasePool alloc ] init ];
    for(i=1; i <= num; i++){
    filename = [ NSString stringWithFormat:SAVEDATA_NAME,i ];
    path = [ getNScrRootDirectory() stringByAppendingPathComponent:filename ];
    aDict = [ NSUnarchiver unarchiveObjectWithFile:path ];
    if(aDict){
    aObj = [ aDict objectForKey:TYMakeDateSaveData ];
    if(aObj)
    [ saveLoadController setDate:aObj number:i ];
    [ aPool release ];
    
    [ saveLoadController setLoaded:true ];
    
    [ saveLoadController setLoadMode:loadmode ];
    [ NSBundle loadNibNamed:QString::fromUtf8("SaveLoadDialog") owner:saveLoadController ];
    
    if(loadmode){
    [ saveLoadController setTitle:QString::fromUtf8("LOAD") ];
    } else {
    [ saveLoadController setTitle:QString::fromUtf8("SAVE") ];
    
    result = [NSApplication->sharedApplication()
    runModalForWindow:[ saveLoadController window ] ];
    [ [ saveLoadController window ] close ];
    
    if(result==DIALOG_OK){
    if(loadmode){
    // load
    [ this loadLocalData:[ NSNumber numberWithInt:[ saveLoadController selectedRow ] +1 ] ];
    } else {
    [ this saveLocalData:[ NSNumber numberWithInt:[ saveLoadController selectedRow ] +1 ] ];
    */
    
}

IBAction TYMainController::openAudioPathWindow:()
{
    {
    if(!audioPathController){
    audioPathController = [ [ TYAudioPathController alloc ] init ];
    [ NSBundle loadNibNamed:QString::fromUtf8("AudioPath") owner:audioPathController ];
    [ audioPathController setDelegate:this ];
    
    [ audioPathController openWithPath:audioSearchPath defaultPath:[ TYEnviroment defaultObjectForKey:TYAudioFilePathEnviroment ] ];
    
}

IBAction TYMainController::showDebugInfo:()
{
    {
    TYGetDisplayInfo();
    NSRunInformationalAlertPanel(QString::fromUtf8("Debug Infomation"),[ NSString stringWithFormat:QString::fromUtf8("Line:%d"),[ ScriptEngine runLine ]+1 ], QString::fromUtf8("OK"), nullptr, nullptr);
    
    
}

void TYMainController::changeAudioPath:()
{
    {
    if(audioSearchPath)
    [ audioSearchPath release ];
    
    audioSearchPath = [ aPath retain ];
    [ TYEnviroment setObject:audioSearchPath forKey:TYAudioFilePathEnviroment ];
    
    [ audioPathController autorelease ];
    audioPathController = nullptr;
    
    // BGMtȂ瑦ɍĉt`FbN
    if(bgmPath){
    BOOL loop = ([ BGMView loopMode ]==NSQTMovieLoopingPlayback) ? true : false;
    if(loop || bgmForceSave){
    [ this playSound:bgmPath loop:loop forceSave:bgmForceSave ];
    
}

IBAction TYMainController::windowMode:()
{
    {
    NSRect mainFrame=[ MainView frame ];
    
    if(!isFullScreenMode)
    return;
    
    // VXe[h̕ύX͓ŝ
    if(isSystemMode){
    NSBeep();
    return;
    
    isFullScreenMode=false;
    
    TYEndFullScreen();
    
    [ [ MainView retain ] autorelease ];
    [ MainView removeFromSuperview ];
    [ [ MainWindow contentView ] addSubview:MainView ];
    mainFrame.origin.x = 0;
    mainFrame.origin.y = 0;
    mainFrame.size.width = VSCREEN_WIDTH;
    mainFrame.size.height = VSCREEN_HEIGHT;
    [ MainView setScaling:1.0 ];
    [ MainView setFrame:mainFrame ];
    
    [ MainWindow makeFirstResponder:MainView ];
    [ FullScrrenWindow setAcceptsMouseMovedEvents:false ];
    [ MainWindow setAcceptsMouseMovedEvents:true ];
    [ FullScrrenWindow orderOut:this ];
    [ MainWindow makeKeyAndOrderFront:this ];
    
    if([ TYEnviroment boolForKey:TYHideOtherFullScreenEnviroment ]) {
    [ NSApp unhideAllApplications:nullptr ];
    
}

IBAction TYMainController::fullScreenMode:()
{
    {
    #ifndef DEBUG
    NSRect screenRect;
    NSRect mainFrame=[ MainView frame ];
    NSSize fullScreenSize;
    
    if(isFullScreenMode)
    return;
    
    // VXe[h̕ύX͓ŝ
    if(isSystemMode){
    NSBeep();
    return;
    
    if([ TYEnviroment boolForKey:TYDisplayResizeAtFullScreenEnviroment ]) {
    if([ TYEnviroment boolForKey:TYHideOtherFullScreenEnviroment ]) {
    [ NSApp hideOtherApplications:nullptr ];
    fullScreenSize = TYStartFullScreen(VSCREEN_WIDTH,VSCREEN_HEIGHT);
    } else
    fullScreenSize = NSZeroSize;
    
    screenRect = [ [ FullScrrenWindow screen ] frame ];
    if(!NSEqualSizes(fullScreenSize,NSZeroSize)) {
    screenRect = NSMakeRect(0,
    NSHeight(screenRect) -fullScreenSize.height,
    fullScreenSize.width,
    fullScreenSize.height);
    
    [ [ MainView retain ] autorelease ];
    [ MainView removeFromSuperview ];
    [ [ FullScrrenWindow contentView ] addSubview:MainView ];
    {
    mainFrame.origin.x = (screenRect.size.width -mainFrame.size.width) /2;
    mainFrame.origin.y = (screenRect.size.height -mainFrame.size.height) /2;
    [ MainView setFrame:mainFrame ];
    
    /*
    [ [ BGMView retain ] autorelease ];
    [ BGMView removeFromSuperview ];
    [ [ MainWindow contentView ] addSubview:BGMView ];
    */
    
    [ FullScrrenWindow setFrame:screenRect display:true ];
    
    //[ MainWindow orderOut:this ];
    //[ MainView removeFromSuperview ];
    [ FullScrrenWindow makeFirstResponder:MainView ];
    [ FullScrrenWindow setLevelToFront ];
    [ FullScrrenWindow makeKeyAndOrderFront:this ];
    [ MainWindow setAcceptsMouseMovedEvents:false ];
    [ FullScrrenWindow setAcceptsMouseMovedEvents:true ];
    
    isFullScreenMode = true;
    #endif
    
}

void TYMainController::didChangeKeyWindow:()
{
    {
    if(isFullScreenMode){
    if([ notification object ] != FullScrrenWindow){
    [ FullScrrenWindow setLevelToNormal ];
    } else {
    [ FullScrrenWindow setLevelToFront ];
    
}

IBAction TYMainController::openBGMVolumeDialog:()
{
    {
    if(!volumeController){
    float bV;
    id temp;
    bV = (temp = [ TYEnviroment objectForKey:TYBGMVolumeEnviroment ]) ? [ temp floatValue ] : defBGMVol;
    
    if(!mode_ext) {
    volumeController = [ [ TYBGMVolumeController alloc ] initWithBGMVolume:bV ];
    } else {
    float vV,sV;
    vV = (temp = [ TYEnviroment objectForKey:TYVoiceVolumeEnviroment ]) ? [ temp floatValue ] : defVoiceVol;
    sV = (temp = [ TYEnviroment objectForKey:TYSEVolumeEnviroment ]) ? [ temp floatValue ] : defSEVol;
    
    volumeController = [ [ TYExtVolumeController alloc ]initWithDefaultBGMVolume:defBGMVol
    bgmVolume:bV
    defaultVoiceVolume:defVoiceVol
    voiceVolume:vV
    defaultSEVolume:defSEVol
    seVolume:sV ];
    
    //[ [ (mode_ext) ? TYBGMVolumeController : TYExtVolumeContoller alloc ] init ];
    //[ NSBundle loadNibNamed:QString::fromUtf8("BGMVolume") owner:this ];
    [ volumeController setDelegate:this ];
    [ volumeController showDialog ];
    [ this closeBGMVolumeDialog:volumeController ];
    
    //[ VolumeSlider setFloatValue:[ BGMView volume ] ];
    
    //[NSApplication->sharedApplication() runModalForWindow:[ VolumeSlider window ] ];
    
}

IBAction TYMainController::preference:()
{
    {
    [ TYPreferencePanelController showDialog ];
    
}

void TYMainController::changeBGMVolume:()
{
    {
    float volume = [ sender floatValue ];
    
    BGMVolume = volume;
    [ BGMView setVolume:volume ];
    
}

void TYMainController::closeBGMVolumeDialog:()
{
    {
    [ TYEnviroment setObject:[ NSNumber numberWithFloat:BGMVolume ]
    forKey:TYBGMVolumeEnviroment ];
    if(mode_ext){
    [ TYEnviroment setObject:[ NSNumber numberWithFloat:[ volumeController voiceVolume ] ]
    forKey:TYVoiceVolumeEnviroment ];
    voiceVol = [ volumeController voiceVolume ] *100 -100;
    
    [ TYEnviroment setObject:[ NSNumber numberWithFloat:[ volumeController seVolume ] ]
    forKey:TYSEVolumeEnviroment ];
    seVol = [ volumeController seVolume ] *100 -100;
    
}

IBAction TYMainController::openAutoMode:()
{
    {
    static TYAutoModeController *autoDialog;
    if(!autoDialog)
    autoDialog=[ [ TYAutoModeController dialog ] retain ];
    
    if([ TYEnviroment objectForKey:TYAutomodeWaitTimeEnviroment ] == nullptr) {
    [ TYEnviroment setObject:[ NSNumber numberWithInt:0 ] forKey:TYAutomodeWaitTimeEnviroment ];
    
    if([ autoDialog runModalTextSpeed:[ StageManager userTextSpeed ]
    waitValue:[ [ TYEnviroment objectForKey:TYAutomodeWaitTimeEnviroment ] intValue ]
    waitType:[ [ TYEnviroment objectForKey:TYAutomodeWaitTypeEnviroment ] intValue ] ]
    == NSOKButton){
    [ TYEnviroment setObject:[ NSNumber numberWithInt:[ autoDialog waitNum ] ] forKey:TYAutomodeWaitTimeEnviroment ];
    [ TYEnviroment setObject:[ NSNumber numberWithInt:[ autoDialog waitType ] ] forKey:TYAutomodeWaitTypeEnviroment ];
    [ StageManager setAutoMode:[ autoDialog textSpeed ]
    waitType:[ autoDialog waitType ]
    wait:[ autoDialog waitNum ] ];
    
}

IBAction TYMainController::eraseTextWindowMode:()
{
    {
    TYEraseModeView *aView;
    
    if(sender && ![ this isPossibleEnterSystemMode ]){
    NSBeep();
    return;
    
    aView = [ [ TYEraseModeView alloc ] initWithFrame:TYVirtualScreenRect() controller:this ];
    [ aView autorelease ];
    [ MainView addSubview:aView ];
    [ [ aView window ] makeFirstResponder:aView ];
    [ this enterSystemMode ];
    
}

IBAction TYMainController::openRightclickMenu:()
{
    {
    if(sender && ![ this isPossibleEnterSystemMode ]){
    NSBeep();
    return;
    
    if(!menuModeView){
    menuModeView = [ [ TYRootMenuView alloc ] initWithFrame:TYVirtualScreenRect()
    controller:this
    attributes:[ StageManager textAttDict ]
    menuItems:rightMenuItemArray
    layout:rightMenuLayout ];
    
    [ MainView addSubview:menuModeView ];
    [ [ menuModeView window ] makeFirstResponder:menuModeView ];
    [ menuModeView updatesTrackingRect ];
    
    [ this enterSystemMode ];
    
}

IBAction TYMainController::enterLookback:()
{
    {
    TYLookbackView *aView;
    NSMutableDictionary *aDict;
    NSArray *queue;
    TYCellImage *img1,*img2;
    
    if(sender && ![ this isPossibleEnterSystemMode ]){
    NSBeep();
    return;
    queue = [ StageManager lookbackQueue ];
    if(![ queue count ])
    return;
    
    // {^摜
    {
    TYResourceServer *server = [ TYResourceServer sharedServer ];
    NSImage *uoncur,*uoffcur,*doncur,*doffcur;
    
    if(!lookbackBtn) {
    lookbackBtn = [ NSArray arrayWithObjects:QString::fromUtf8("uoncur.bmp"),
    QString::fromUtf8("uoffcur.bmp"),
    QString::fromUtf8("doncur.bmp"),
    QString::fromUtf8("doffcur.bmp"),nullptr ];
    [ lookbackBtn retain ];
    
    uoncur = [ server getImage:[ lookbackBtn objectAtIndex:1 ] transMode:true ];
    uoffcur = [ server getImage:[ lookbackBtn objectAtIndex:0 ] transMode:true ];
    
    doncur = [ server getImage:[ lookbackBtn objectAtIndex:3 ] transMode:true ];
    doffcur = [ server getImage:[ lookbackBtn objectAtIndex:2 ] transMode:true ];
    
    if(uoncur && uoffcur)
    img1 = [ [ TYCellImage alloc ] initWithImages:
    [ NSArray arrayWithObjects:uoncur,uoffcur,nullptr ] ];
    else
    img1 = nullptr;
    
    if(doncur && doffcur)
    img2 = [ [ TYCellImage alloc ] initWithImages:
    [ NSArray arrayWithObjects:doncur,doffcur,nullptr ] ];
    else
    img2 = nullptr;
    
    aDict = [ [ [ StageManager textAttDict ] mutableCopy ] autorelease ];
    if(lookbackColor)
    [ aDict setObject:lookbackColor forKey:NSForegroundColorAttributeName ];
    aView = [ [ TYLookbackView alloc ] initWithFrame:TYVirtualScreenRect()
    controller:this
    attributes:aDict
    layout:rightMenuLayout
    buffer:queue
    ubutton:img1
    dbutton:img2 ];
    [ aView autorelease ];
    
    [ MainView addSubview:aView ];
    [ aView updatesTrackingRect ];
    [ [ aView window ] makeFirstResponder:aView ];
    
    [ this enterSystemMode ];
    
    
}

IBAction TYMainController::resetGame:()
{
    {
    if(sender){
    if(![ sender respondsToSelector:@selector(tag:) ]) {
    if(NSRunAlertPanel(NSLocalizedString(QString::fromUtf8("Reset Game"),nullptr),
    NSLocalizedString(QString::fromUtf8("May I reset?"),nullptr),
    QString::fromUtf8("OK"),
    nullptr,
    QString::fromUtf8("Cancel")) == NSAlertOtherReturn){
    return ;
    } else if(![ this isPossibleEnterSystemMode ]){
    // j[Ă΂ꂽꍇŁAJڂłȂB
    NSBeep();
    return;
    } else {
    [ this ty_systemcall:[ NSArray arrayWithObjects:QString::fromUtf8("systemcall"),QString::fromUtf8("reset"),nullptr ] ];
    return ;
    
    if([ this status ] == TYScriptRunningStatus){
    [ ScriptEngine setBreakRun:true ];
    
    [ this setStatus:TYScriptRunningStatus ];
    [ ScriptEngine performSelector:@selector(runScript) withObject:nullptr afterDelay:0 ];
    
    
    [ BGMView stop:this ];
    [ bgmPath release ];
    bgmPath=nullptr;
    
    [ waveController release ];
    waveController=nullptr;
    
    autoclickTimer=0;
    
    [ StageManager resetGame ];
    [ ScriptEngine resetGame ];
    
}

IBAction TYMainController::forceResume:()
{
    {
    [ ScriptEngine runScript ];
    
}

void TYMainController::select_action()
{
    {
    if(trapSelectAction && TYStatus != TYPrinting)
    [ ScriptEngine fireOfTrap ];
    
    switch (TYStatus) {
    case TYClickWaitStatus:
    [ NSObject cancelPreviousPerformRequestsWithTarget:this selector:@selector(select_action) object:nullptr ];
    [ ScriptEngine runScript ];
    break;
    case TYPrinting:
    [ StageManager select_action ];
    break;
    case TYButtonWaitStatus:
    //[ MainWindow setAcceptsMouseMovedEvents:false ];
    
    [ StageManager select_action ];
    break;
    case TYSelectStatus:
    [ StageManager select_action ];
    default : break;
    
}

IBAction TYMainController::cancel_action:()
{
    {
    switch (TYStatus) {
    case TYButtonWaitStatus:
    [ StageManager cancel_action:sender ];
    break;
    case TYSelectStatus:
    [ this openRightclickMenu:nullptr ];
    break;
    case TYScriptRunningStatus:
    case TYClickWaitStatus:
    break;
    default:
    [ StageManager cancel_action:sender ];
    
}

void TYMainController::up_action()
{
    {
    switch (TYStatus) {
    case TYButtonWaitStatus:
    case TYSelectStatus:
    case TYPrinting:
    [ StageManager up_action ];
    break;
    default : break;
    
}

void TYMainController::down_action()
{
    {
    switch (TYStatus) {
    case TYButtonWaitStatus:
    case TYSelectStatus:
    [ StageManager down_action ];
    break;
    default : break;
    
}

void TYMainController::move_mouse:()
{
    {
    switch (TYStatus){
    case TYButtonWaitStatus:
    case TYSelectStatus:
    [ StageManager move_mouse:point ];
    break;
    default:break;
    
}

void TYMainController::other_action:()
{
    {
    switch (TYStatus){
    case TYButtonWaitStatus:
    [ StageManager other_action:code ];
    break;
    default:break;
    
}

void TYMainController::enterSystemMode()
{
    {
    isSystemMode = true;
    
    switch (TYStatus){
    case TYPrinting:
    [ StageManager enterSystemMode ];
    break;
    case TYScriptRunningStatus:
    [ ScriptEngine setBreakRun:true ];
    [ NSObject cancelPreviousPerformRequestsWithTarget:ScriptEngine
    selector:@selector(runScript)
    object:nullptr ];
    break;
    default:break;
    [ MainView setImage:[ StageManager visualLayer ] ];
    
}

void TYMainController::exitSystemModeResumeStatus:()
{
    {
    switch (TYStatus & (TYRmodeStatusMask -1)){
    case TYPrinting:
    case TYSelectStatus:
    [ StageManager exitSystemModeResumeStatus:aBool ];
    break;
    case TYScriptRunningStatus:
    [ ScriptEngine performSelector:@selector(runScript)
    withObject:nullptr
    afterDelay:0.1 ];
    break;
    default:break;
    
    isSystemMode = false;
    
}

bool TYMainController::isPossibleEnterSystemMode()
{
    {
    // [U̗vɂăVXe[hֈڍs\ȏԂԂB
    if(isSystemMode)
    return false;
    
    switch (TYStatus){
    case TYPrinting:
    return [ StageManager isPossibleEnterSystemMode ];
    case TYSelectStatus:
    return true;
    default:
    return false;
    
    
    
}

