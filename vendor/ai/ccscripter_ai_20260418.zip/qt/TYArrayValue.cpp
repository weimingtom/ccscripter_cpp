#include "TYArrayValue.h"

// Converted from Objective-C

QObject* TYArrayValue::initWithID:()
{
    {
    [ super init ];
    
    idNo = aInt;
    limitArray = [ aArray retain ];
    
    // データ格納領域確保
    {
    int size = 1;
    NSEnumerator *enu = [ limitArray objectEnumerator ];
    id tmp;
    
    while(tmp = [ enu nextObject ]){
    size *= [ tmp intValue ];
    
    data = [ [ NSMutableData alloc ] initWithLength:size * sizeof(int) ];
    
    dataPtr = [ data mutableBytes ];
    lastLimit = [ [ limitArray lastObject ] intValue ];
    
    return this;
    
}

void TYArrayValue::setNum:()
{
    {
    NSEnumerator *enuI,*enuA;
    int address;
    
    NSAssert(([ limitArray count ]==[ aArray count ]),QString::fromUtf8("Bad Address of Array Value"));
    
    enuI = [ limitArray reverseObjectEnumerator ];
    enuA = [ aArray reverseObjectEnumerator ];
    
    address = get_address(0,enuI,enuA);
    
    *(dataPtr +address) = [ num intValue ];
    
}

void TYArrayValue::setNumbers:()
{
    {
    NSEnumerator *enuI,*enuA;
    int address,prLastLimit;
    
    NSAssert(([ limitArray count ]==([ aArray count ]+1)),QString::fromUtf8("Bad Address of Array Value"));
    
    prLastLimit = [ [ limitArray lastObject ] intValue ];
    
    NSAssert((lastLimit == [ numbers count ]),QString::fromUtf8("No Match Argments Number Of Elements"));
    
    enuI = [ limitArray reverseObjectEnumerator ];
    enuA = [ aArray reverseObjectEnumerator ];
    
    address = get_address([ [ enuI nextObject ] intValue ],enuI,enuA);
    
    // データ代入処理
    {
    NSEnumerator *enuN=[ numbers objectEnumerator ];
    int *ptr;
    id tmp;
    
    ptr = dataPtr +address;
    
    while(tmp = [ enuN nextObject ]){
    *ptr = [ tmp intValue ];
    ptr++;
    
    
}

NSNumber* TYArrayValue::getNumOfAddress:()
{
    {
    NSEnumerator *enuI,*enuA;
    int address;
    
    NSAssert(([ limitArray count ]==[ aArray count ]),QString::fromUtf8("Bad Address of Array Value"));
    
    enuI = [ limitArray reverseObjectEnumerator ];
    enuA = [ aArray reverseObjectEnumerator ];
    
    address = get_address(0,enuI,enuA);
    
    return [ NSNumber numberWithInt:*(dataPtr +address) ];
    
    // ----------------------------------------------------------------------------------------
    // NSCoding
    // ----------------------------------------------------------------------------------------
    
}

QObject* TYArrayValue::initWithCoder:()
{
    {
    super->init();
    
    aDecoder->decodeValueOfObjCType(@encode(int) at:&idNo ];
    limitArray = [ aDecoder->decodeObject() retain ];
    data = [ [ aDecoder decodeObject ] retain ];
    dataPtr = [ data mutableBytes ];
    lastLimit = [ [ limitArray lastObject ] intValue ];
    
    return this;
    
}

void TYArrayValue::encodeWithCoder:()
{
    {
    aCoder->encodeValueOfObjCType(@encode(int) at:&idNo ];
    aCoder->encodeObject(limitArray ];
    aCoder->encodeObject(data ];
    
}

void TYArrayValue::dealloc()
{
    {
    limitArray->release();
    data->release();
    super->dealloc();
    
    
}

