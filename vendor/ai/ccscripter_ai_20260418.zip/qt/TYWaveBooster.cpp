#include "TYWaveBooster.h"

// Converted from Objective-C

