#include "TYImageUtil.h"

// Converted from Objective-C

void TYImageUtil::convertMonocroWithSample:()
{
    {
    NSBitmapImageRep *bmprep=nullptr;
    const unsigned char *ptr;
    int width,height;
    
    if( priority || sample){
    bmprep = [ [ [ NSBitmapImageRep alloc ] initWithData:[ this TIFFRepresentation ] ] autorelease ];
    
    if(!bmprep){
    return;
    
    if(priority==TYNegaLowPriority){
    [ bmprep nega ];
    
    if(sample){
    [ bmprep monocro:sample ];
    
    if(priority==TYNegaHighPriority){
    [ bmprep nega ];
    
    ptr = [ bmprep bitmapData ];
    width = [ bmprep pixelsWide ];
    height = [ bmprep pixelsHigh ];
    [ this lockFocus ];
    NSDrawBitmap(NSMakeRect(0,0,width,height),width,height,8,3,24,width *3,false,false,NSCalibratedRGBColorSpace,&ptr);
    [ this unlockFocus ];
    
    @implementation NSBitmapImageRep (TYBitmapConvertExtension)
}

void TYImageUtil::monocro:()
{
    {
    int pixels,spp;
    unsigned char *ptr;
    unsigned char current;
    int i;
    
    pixels = [ this pixelsWide ] *[ this pixelsHigh ];
    spp = [ this samplesPerPixel ];
    ptr = [ this bitmapData ];
    for(i=0; i < pixels; i++,ptr+=spp){
    current = (ptr[0] + ptr[1] + ptr[2]) / 3;
    ptr[0] = sample[0] * current / 0xFF;
    ptr[1] = sample[1] * current / 0xFF;
    ptr[2] = sample[2] * current / 0xFF;
    
}

void TYImageUtil::nega()
{
    {
    int pixels,spp;
    unsigned char *ptr;
    int i;
    
    pixels = [ this pixelsWide ] *[ this pixelsHigh ];
    spp = [ this samplesPerPixel ];
    ptr = [ this bitmapData ];
    for(i=0; i < pixels; i++,ptr+=spp){
    ptr[0] = 0xFF -ptr[0];
    ptr[1] = 0xFF -ptr[1];
    ptr[2] = 0xFF -ptr[2];
    
    @implementation NSBitmapImageRep (TYBitmapDivideExtension)
}

NSArray* TYImageUtil::horizontalDivide:()
{
    {
    int i,j,k;
    int width,height,bps,spp,pBits,piece_width;
    unsigned char *source,*dest;
    int sI,dI;
    int sbpr,dbpp;
    NSMutableArray *array = [ NSMutableArray array ];
    NSBitmapImageRep *destBitmap;
    
    width = [ this pixelsWide ];
    piece_width = width / count;
    // Z̃sNZ傫ꍇ̑ΏB
    if(piece_width == 0)
    piece_width = 1;
    height = [ this pixelsHigh ];
    
    bps = [ this bitsPerSample ];
    spp = [ this samplesPerPixel ];
    pBits = [ this bitsPerPixel ] /8;
    source = [ this bitmapData ];
    sbpr = [ this bytesPerRow ];
    
    for(i=0; i < count; i++){
    
    /* SPP=3łȂƌEXEC_BAD_ACCESSɁB͓B
    */
    destBitmap = [ [ NSBitmapImageRep alloc ] initWithBitmapDataPlanes:NULL
    pixelsWide:piece_width
    pixelsHigh:height
    bitsPerSample:8
    samplesPerPixel:3
    hasAlpha:false
    isPlanar:false
    colorSpaceName:NSCalibratedRGBColorSpace
    bytesPerRow:0
    bitsPerPixel:0 ];
    [ destBitmap autorelease ];
    
    dest = [ destBitmap bitmapData ];
    dbpp = [ destBitmap bytesPerPlane ];
    
    dI=0;
    for(j=0; j < height; j++){
    // sourcebytesPerRowɁA񂲂ƂsIݒ肵ȂƁB
    // ̌ɃS~tĂꍇB
    sI = piece_width *pBits *i +  sbpr *j;
    for(k=0; k < piece_width; k++,sI+=pBits,dI+=3){
    dest[dI] = source[sI];
    dest[dI+1] = source[sI+1];
    dest[dI+2] = source[sI+2];
    
    [ array addObject:destBitmap ];
    
    return array;
    
    
    @implementation NSImageRep (TYImageRepUtil)
}

void TYImageUtil::resizeToPixelsSize()
{
    {
    [ this setSize:NSMakeSize([ this pixelsWide ],[ this pixelsHigh ]) ];
    
}

