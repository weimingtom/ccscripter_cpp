#include "TYExtraButtonManager.h"

// Converted from Objective-C

QObject* TYExtraButtonManager::initWithStageManager:()
{
    {
    [ super initWithStageManager:manager ];
    
    sourceImage = [ sImage retain ];
    
    return this;
    
}

void TYExtraButtonManager::addButton:()
{
    {
    NSImage *selImage;
    int w,h,sx,sy;
    NSSize srcSize;
    NSRect rect;
    
    isOverlayButton = true;
    
    w = [ width intValue ];
    h = [ height intValue ];
    sx = [ selx intValue ];
    sy = [ sely intValue ];
    rect = NSMakeRect([ x intValue ],VSCREEN_HEIGHT -[ y intValue ] -h,w,h);
    
    // IԂ̃C[W쐬
    selImage = [ [ [ NSImage alloc ] initWithSize:NSMakeSize(w,h) ] autorelease ];
    srcSize = [ sourceImage size ];
    [ selImage lockFocus ];
    [ sourceImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(sx,srcSize.height -h -sy,w,h) operation:NSCompositeSourceOver ];
    
    [ selImage unlockFocus ];
    
    // {^`̒ǉ
    [ this addSelection:[ [ [ TYButton alloc ] initWithID:no
    selectedImage:selImage rect:rect ] autorelease ]
    rect:rect ];
    
}

void TYExtraButtonManager::addSpriteButton:()
{
    {
    NSRect rect;
    
    isSpriteButton = true;
    
    // XvCgrect擾
    rect = [ stageManager rectOfSprite:[ sNo intValue ] ];
    
    if(NSEqualRects(rect,NSZeroRect))
    return;
    
    // {^`̒ǉ
    [ this addSelection:[ [ [ TYSpriteButton alloc ] initWithID:no
    spriteNo:sNo
    appendAction:aString ] autorelease ]
    rect:rect ];
    
    
}

void TYExtraButtonManager::addCselButton:()
{
    {
    NSRect rect;
    
    isCustomSel = true;
    
    // |Cg̍WMacɍ킹ĕϊB
    rect.size = [ (NSImage*)image size ];
    aPoint.y = VSCREEN_HEIGHT -aPoint.y - rect.size.height;
    rect.origin = aPoint;
    
    [ this addSelection:[ [ [ TYCselButton alloc ] initWithID:no
    selctionNo:[ sNo intValue ]
    image:image
    point:aPoint ] autorelease ]
    rect:rect ];
    
}

void TYExtraButtonManager::setNoSelectAction:()
{
    {
    noSelectAction = [ aStr retain ];
    
}

void TYExtraButtonManager::initialButtonImage()
{
    {
    // {^[hJnÓA{^摜̏
    NSEnumerator *enm;
    id temp;
    
    // 摜{^Aobt@ĂȂ΁ASẴ{^`
    if((isCustomSel || isOverlayButton) && beforeSelection==TYButtonUnInitialize){
    [ drawBuffer lockFocus ];
    enm = [ btnArray objectEnumerator ];
    while( (temp = [ enm nextObject ]) != nullptr){
    if([ temp respondsToSelector:@selector(drawWithSelect:) ])
    [ temp drawWithSelect:false ];
    [ drawBuffer unlockFocus ];
    // XvCg΃ItXN[`AȂΒڕ`
    /*
    if(!isSpriteButton){
    [ stageManager updateStageOnlyButton ];
    } else {
    [ stageManager updateStage ];
    */
    [ stageManager updateStage ];
    
    beforeSelection = TYButtonNoSelected;
    
}

bool TYExtraButtonManager::changeSelection:()
{
    {
    id exitBtn , enterBtn;
    BOOL exitIsOverlay,enterIsOverlay;
    
    if(beforeSelection==index){
    return false;
    
    exitBtn = (beforeSelection) ? [ btnArray objectAtIndex:(beforeSelection -1) ] : nullptr;
    enterBtn = (index) ? [ btnArray objectAtIndex:(index -1) ]: nullptr;
    
    // I[o[C{^(XvCg{^)tO
    exitIsOverlay = ([ exitBtn isMemberOfClass:[ TYSpriteButton class ] ]) ? false : true;
    enterIsOverlay = ([ enterBtn isMemberOfClass:[ TYSpriteButton class ] ]) ? false : true;
    
    if(isCustomSel & (exitIsOverlay || enterIsOverlay)){
    // I܂܂ꍇ͑SĂ̑Iƃ{^`B
    TYButton *temp;
    NSEnumerator *enu = [ btnArray objectEnumerator ];
    
    [ drawBuffer lockFocus ];
    [ [ NSColor clearColor ] set ];
    NSRectFillUsingOperation(TYVirtualScreenRect(),NSCompositeClear);
    {
    while(temp = [ enu nextObject ]){
    if([ temp respondsToSelector:@selector(drawWithSelect:) ]){
    [ temp drawWithSelect:(temp == enterBtn) ? true : false ];
    [ drawBuffer unlockFocus ];
    
    } else if(exitIsOverlay || enterIsOverlay){
    [ drawBuffer lockFocus ];
    {
    // OIԂ{^IԂŕ`
    if(exitBtn && exitIsOverlay){
    [ exitBtn drawWithSelect:false ];
    
    // Iꂽ{^IԂŕ`
    if(enterBtn && enterIsOverlay){
    [ enterBtn drawWithSelect:true ];
    [ drawBuffer unlockFocus ];
    
    if(exitIsOverlay && enterIsOverlay){
    [ stageManager updateStageOnlyButton ];
    } else {
    if(exitBtn && !exitIsOverlay){
    [ stageManager setSprite:[ exitBtn spriteNo ] cell:0 ];
    if(!enterBtn){
    if(noSelectAction)
    [ stageManager ty_spstr:[ NSMutableArray arrayWithObjects:QString::fromUtf8("spstr"),noSelectAction,nullptr ] ];
    
    if(enterBtn && !enterIsOverlay){
    NSString *str;
    [ stageManager setSprite:[ enterBtn spriteNo ] cell:1 ];
    str = [ enterBtn appendString ];
    if(str)
    [ stageManager ty_spstr:[ NSMutableArray arrayWithObjects:QString::fromUtf8("spstr"),str,nullptr ] ];
    
    
    [ stageManager updateStage ];
    
    //[ drawBuffer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    beforeSelection = index;
    
    return true;
    
}

int TYExtraButtonManager::selectedButtonID()
{
    {
    if(beforeSelection) {
    return [ [ [ btnArray objectAtIndex:(beforeSelection -1) ] idNo ] intValue ];
    } else {
    return 0;
    
}

NSImage* TYExtraButtonManager::sourceImage()
{
    
}

void TYExtraButtonManager::clear()
{
    {
    [ super clear ];
    
    [ noSelectAction release ];
    noSelectAction = nullptr;
    isOverlayButton = false;
    isSpriteButton = false;
    isCustomSel = false;
    
}

void TYExtraButtonManager::dealloc()
{
    {
    sourceImage->release();
    noSelectAction->release();
    super->dealloc();
    
    
    
    
    @implementation TYButton
    
}

QObject* TYExtraButtonManager::initWithID:()
{
    {
    this = [ super init ];
    
    idno = [ no retain ];
    selectedImage = selImage;
    [ selectedImage retain ];
    drawRect = aRect;
    
    return this;
    
}

void TYExtraButtonManager::drawWithSelect:()
{
    {
    // gRectNAĂ`
    [ [ NSColor whiteColor ] set ];
    NSRectFillUsingOperation(drawRect,NSCompositeClear);
    /*
    [ [ NSColor clearColor ] set ];
    [ NSBezierPath fillRect:drawRect ];
    */
    
    if(aBool){
    [ selectedImage compositeToPoint:drawRect.origin operation:NSCompositeSourceOver ];
    
}

NSRect* TYExtraButtonManager::boundingRect()
{
    {
    return &drawRect;
    
}

NSNumber* TYExtraButtonManager::idNo()
{
    {
    return idno;
    
}

NSString* TYExtraButtonManager::description()
{
    {
    return [ NSString stringWithFormat:QString::fromUtf8("ID=%@,Rect=%@,selectedImage=%@"),
    idno,NSStringFromRect(drawRect),selectedImage ];
    
}

void TYExtraButtonManager::dealloc()
{
    {
    [ idno release ];
    [ selectedImage release ];
    
    super->dealloc();
    
    
    @implementation TYSpriteButton
}

QObject* TYExtraButtonManager::initWithID:()
{
    {
    this = [ super init ];
    
    idno = [ no retain ];
    spriteNo = [ sNo retain ];
    appendAction = [ string retain ];
    
    return this;
    
}

NSNumber* TYExtraButtonManager::idNo()
{
    {
    return idno;
    
}

int TYExtraButtonManager::spriteNo()
{
    {
    return [ spriteNo intValue ];
    
}

NSString* TYExtraButtonManager::appendString()
{
    {
    return appendAction;
    
}

void TYExtraButtonManager::dealloc()
{
    {
    idno->release();
    spriteNo->release();
    appendAction->release();
    super->dealloc();
    
    
    @implementation TYCselButton
    
}

QObject* TYExtraButtonManager::initWithID:()
{
    {
    [ super init ];
    
    idno = [ no retain ];
    selNo = sNo;
    strImage = [ image retain ];
    drawPoint = aPoint;
    
    return this;
    
}

void TYExtraButtonManager::drawWithSelect:()
{
    {
    [ strImage changeCell:aBool ];
    [ (NSImage*)strImage compositeToPoint:drawPoint operation:NSCompositeSourceOver ];
    
}

int TYExtraButtonManager::cselNo()
{
    
}

void TYExtraButtonManager::dealloc()
{
    {
    idno->release();
    strImage->release();
    super->dealloc();
    
    
}

