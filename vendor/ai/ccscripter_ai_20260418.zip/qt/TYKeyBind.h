#ifndef TYKEYBIND_H
#define TYKEYBIND_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // TYKEYBIND_H
