#ifndef TYBITOPERATOR_H
#define TYBITOPERATOR_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYBitOperator : public QObject
{
    Q_OBJECT
public:
    QObject* initWithFileHandle:();
    int get();
    unsigned int getWithLength:();
};

#endif // TYBITOPERATOR_H
