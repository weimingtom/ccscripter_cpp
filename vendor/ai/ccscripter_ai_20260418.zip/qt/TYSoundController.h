#ifndef TYSOUNDCONTROLLER_H
#define TYSOUNDCONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYSoundController : public QObject
{
    Q_OBJECT
public:
    QObject* initWithResource:();
    QObject* initWithResource:();
    void setSound:(void value);
    void play();
    void stop();
    void setPostingNotification:(void value);
    NSString* soundPathIfNeedPlayingAtLoad();
    void sound:();
};

#endif // TYSOUNDCONTROLLER_H
