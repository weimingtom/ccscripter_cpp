#ifndef TYWAVE2AIFF_H
#define TYWAVE2AIFF_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // TYWAVE2AIFF_H
