#include "TYScriptEngine.h"

// Converted from Objective-C

QObject* TYScriptEngine::initWithContentsOfFile:()
{
    {
    NSFileManager *fileManager;
    NSMutableData *ScriptData;
    NSString *truePath;
    NSData *addData;
    NSArray *filesArray;
    unsigned char* encodedCharptr;
    unsigned scriptLength;
    const unsigned char *stringSourceptr;
    int	i;
    enum { mode_multi,mode_single } scriptMode=mode_single;
    id arp;
    
    this = [ super init ];
    
    // pathtH_ăXNvgt@CB
    // 0.txt~TAꂪȂnscript.datTB
    fileManager = [ NSFileManager defaultManager ];
    filesArray = [ fileManager directoryContentsAtPath:path ];
    for(i = 0; i < [ filesArray count ]; i++ ){
    if( [ [ filesArray objectAtIndex:i ] isEqualToString:QString::fromUtf8("0.txt") ]){
    scriptMode=mode_multi;
    break;
    
    if(scriptMode==mode_single){
    truePath = [ [ NSString stringWithString:path ] stringByAppendingPathComponent:QString::fromUtf8("nscript.dat") ];
    
    // ÍꂽXNvgoCî܂ܓǂݍ
    ScriptData = [ [ NSMutableData alloc ] initWithContentsOfFile:truePath ]; // svɂȂ_őɃ[X
    if( ScriptData == nullptr){
    NSLog(QString::fromUtf8("Script File is not Found"));
    return nullptr;
    
    encodedCharptr = [ ScriptData mutableBytes ];
    
    // ϊpobt@[̈̊m
    scriptLength = [ ScriptData length ];
    
    // eoCg132ɂXORŕϊ
    for( i=0; i < scriptLength; i++,encodedCharptr++){
    *encodedCharptr = (*encodedCharptr) ^ 132;
    stringSourceptr = [ ScriptData bytes ];
    
    } else {
    // ÍĂȂeLXgt@C 0.txt~ǂݍ݁AAĂB
    i=0;
    
    ScriptData = [ [ NSMutableData alloc ] initWithCapacity:1 ]; // svɂȂ_őɃ[X
    arp = [ [ NSAutoreleasePool alloc ] init ];
    
    while(1){
    addData = [ [ [ NSData alloc ] initWithContentsOfFile:
    [ path stringByAppendingPathComponent:
    [ NSString stringWithFormat:QString::fromUtf8("%d.txt"),i ] ] ] autorelease ];
    if(addData){
    [ ScriptData appendData:addData ];
    [ ScriptData appendData:[ NSData dataWithBytes:"\r\n" length:2 ] ];
    } else {
    break;
    i++;
    scriptLength = [ ScriptData length ];
    stringSourceptr = [ ScriptData bytes ];
    [ arp release ];
    
    // sR[h̔ʂsB
    // MEMO:ÍĂȂꍇłȂXNvgt@CɕĂƁAsR[hCR+LFB
    for(i =0 ; i < scriptLength ; i++){
    if (stringSourceptr[i] == '\n'){
    strcpy(newLineCode,newLineCodeUnix);
    break;
    } else if (stringSourceptr[i] == '\r'){
    if(stringSourceptr[i+1] == '\n'){
    strcpy(newLineCode,newLineCodeWin);
    break;
    } else {
    strcpy(newLineCode,newLineCodeMac);
    
    // ϊoCgf[^NSString̐AэsPʂł̔zւ̊i[sB
    // encoding"Japanese(Win,DOS)"w肷B
    // MEMO:_Ńx}bv쐬KvBd`΃G[ɂ邱ƁB
    {
    NSString *str;
    str = [ [ [ NSString alloc ] initWithData:ScriptData encoding:NSShiftJISStringEncoding ] autorelease ];
    [ ScriptData release ];
    ScriptArray = [ str componentsSeparatedByString:[ NSString stringWithCSJISString:newLineCode ] ];
    [ ScriptArray retain ];
    //[ str release ]; //releaseƗBArrayɂ͎QƂi[ĂȂƂƁH
    
    // x쐬
    {
    NSCharacterSet *cset=[ NSCharacterSet varNameCharacterSet ];
    NSEnumerator *enu=[ ScriptArray objectEnumerator ];
    int line=0;
    NSString *buff;
    id tmp;
    NSScanner *scanner;
    
    labelDict = [ [ NSMutableDictionary alloc ] initWithCapacity:[ ScriptArray count ] /512 ];
    
    while(tmp = [ enu nextObject ]){
    scanner = [ NSScanner scannerWithString:tmp ];
    
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
    intoString:nullptr ];
    if([ scanner scanString:QString::fromUtf8("*") intoString:nullptr ]){ // s̑Oɋ󔒂Ăv
    [ scanner scanCharactersFromSet:cset
    intoString:&buff ];
    [ labelDict setObject:[ NSNumber numberWithInt:line ]
    forKey:[ QString::fromUtf8("*") stringByAppendingString:[ buff lowercaseString ] ] ];
    
    line++;
    
    
    // ̑̃CX^Xϐ̏
    numAliases = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    strAliases = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    scripterValues = [ [ TYScripterValues ScripterValues ] retain ];
    multiLineCmdStringSet = [ [ NSSet alloc ] initWithObjects:MULTILINE_CMD_STRINGS,nullptr ];
    returnStack = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    timerStartDate = [ [ NSDate alloc ] init ];
    loopStack = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    textgosubPointIndex = -1;
    undefinedComSet = [ [ NSMutableSet set ] retain ];
    
    // O[oϐ̃[hOvalue錾̃`FbN
    {
    int value = [ this scanGlobalValue ];
    if (value > 0) {
    NSLog(QString::fromUtf8("change global ID bottom = %d"),value);
    [ TYScripterValues setMinGlobalNo:value ];
    
    // O[oϐ͊Jnɂ炩߃[hB
    [ scripterValues loadGlobalValues:
    [ getNScrRootDirectory() stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    
    // Jnʒu
    [ this labeljump:QString::fromUtf8("*define") ];
    
    // ̎ݒ
    {
    NSCalendarDate *cDate=[ NSCalendarDate calendarDate ];
    unsigned int seed= ([ cDate hourOfDay ] *60 +[ cDate minuteOfHour ]) *60 +[ cDate secondOfMinute ];
    srandom(seed);
    // sharedɊi[
    sharedEngine = this;
    
    return this;
    
}

bool TYScriptEngine::isModeSVGA()
{
    {
    NSScanner *scanner;
    
    scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:0 ] ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
    intoString:NULL ];
    return [ scanner scanString:QString::fromUtf8(";mode800") intoString:NULL ];
    
    
}

int TYScriptEngine::scanGlobalValue()
{
    {
    NSScanner *scanner;
    NSString *strBuf;
    
    scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:0 ] ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
    intoString:NULL ];
    scanner->scanUpToString(QString::fromUtf8("value") intoString:NULL ];
    if ([ scanner isAtEnd ] == true) {
    return 0;
    } else {
    [ scanner scanString:QString::fromUtf8("value") intoString:NULL ];
    if ([ scanner scanCharactersFromSet:[ NSCharacterSet decimalDigitCharacterSet ]
    intoString:&strBuf ] == true) {
    return [ strBuf intValue ];
    
    return 0;
    
}

QObject* TYScriptEngine::encodeWithSaveData()
{
    {
    NSDictionary *aDict;
    NSData *valueData;
    NSValue *pointValue;
    //TYScriptPoint point;
    
    
    valueData = [ scripterValues encodeWithSaveData ];
    
    /*
    {
    aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,nullptr ];
    
    return aDict;
    */
    
    
    //point = TYMakeScriptPoint(runLine,runColumn);
    // ĨNbN҂̊ԂɌĂ΂ꂽ̂ł΁AYsij̏𕜋Aɂ蒼Kv̂ŁB
    if([ (TYMainController*)controller status ]==TYSelectStatus){
    if(savePoint.column == 0){
    savePoint.line--;
    } else if([ (TYMainController*)controller status ]==TYScriptRunningStatus){
    // XNvgȂĊJɎ̃JɐiłKvB
    savePoint.column++;
    pointValue = [ NSValue valueWithBytes:&savePoint objCType:@encode(TYScriptPoint) ];
    
    if(textgosubPointIndex == -1){
    aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,
    pointValue,TYScriptPointSaveData,
    returnStack,TYReturnStackSaveData,nullptr ];
    } else {
    aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,
    pointValue,TYScriptPointSaveData,
    returnStack,TYReturnStackSaveData,
    [ NSNumber numberWithInt:textgosubPointIndex ] , TYTextgosubIndexSaveData ,nullptr ];
    
    return aDict;
    
    
}

void TYScriptEngine::decodeWithSaveData:()
{
    {
    id tmp;
    TYScriptPoint point;
    
    [ scripterValues decodeWithSaveData:[ aObject objectForKey:TYLocalValuesSaveData ] ];
    
    tmp = [ aObject objectForKey:TYReturnStackSaveData ];
    if(tmp){
    if(returnStack)
    [ returnStack release ];
    returnStack = [ tmp retain ];
    
    tmp = [ aObject objectForKey:TYScriptPointSaveData ];
    if(tmp){
    [ tmp getValue:&point ];
    
    runLine=point.line;
    runColumn=point.column;
    
    
    tmp = [ aObject objectForKey:TYTextgosubIndexSaveData ];
    if(tmp){
    textgosubPointIndex = [ tmp intValue ];
    } else {
    textgosubPointIndex = -1;
    
}

void TYScriptEngine::resetGame()
{
    {
    [ scripterValues resetGame ];
    
    [ returnStack release ];
    returnStack = [ [ NSMutableArray arrayWithCapacity:1 ] retain ];
    
    textgosubPointIndex = -1;
    
    [ this labeljump:QString::fromUtf8("*start") ];
    
}

void TYScriptEngine::setController:()
{
    {
    controller = cont;
    stageManager = manager;
    
    // NScripts܂BXNvg߂AR}h烁\bh𐶐ċN܂B
}

void TYScriptEngine::runScript()
{
    {
    NSString *currentString;
    const char *startptr;
    char *currentchars;
    char command[MAX_LINE_LENGTH];
    NSMutableArray *cmdArray;
    int j;
    BOOL conditionResult;
    
    breakRun = false;
    
    [ controller setStatus:TYScriptRunningStatus ];
    // Cxg҂Kv܂ŁA𑱂܂B
    while(1){
    // trap̕ߑ`FbN
    if(labelWithTrap && fireOfTrap){
    [ labelWithTrap autorelease ];
    [ this labeljump:labelWithTrap ];
    [ controller setTrap:false ];
    fireOfTrap=false;
    labelWithTrap=nullptr;
    
    // ̏łȂ΍si߂
    if( runColumn == 0){
    runLine++;
    //NSLog2(QString::fromUtf8("%d"),runLine);
    currentString = [ ScriptArray objectAtIndex:runLine ];
    [ currentData release ];
    currentData = [ currentString getCSJISData ];
    [ currentData retain ];
    currentchars = [ currentData mutableBytes ];
    // obt@I[o[t[΍
    if([ currentData length ] > MAX_LINE_LENGTH){
    NSLog(QString::fromUtf8("too long line. omit data over %d"),MAX_LINE_LENGTH);
    currentchars[MAX_LINE_LENGTH -1] = '\0';
    startptr = currentchars;
    // ̏ȂJnʒu܂ł炷
    if(runColumn){
    if(slideColumn(&currentchars,runColumn)){
    // sɃVtg
    runLine++; runColumn=0;
    currentString = [ ScriptArray objectAtIndex:runLine ];
    [ currentData release ];
    currentData = [ currentString getCSJISData ];
    [ currentData retain ];
    currentchars = [ currentData mutableBytes ];
    startptr = currentchars;
    savePoint.line=runLine;
    savePoint.column=runColumn;
    
    TYParserSetCString(currentchars);
    yyparse();
    
    /*
    // 擪Xy[X̓ǂݔ΂
    while((*currentchars)&&(isspace(*currentchars))){
    currentchars++;
    
    // xȂ烉xOǉA
    if(currentchars[0]=='*'){
    if(labelLog)
    [ labelLog addLog:[ NSString stringWithCSJISString:currentchars ] ];
    runColumn=0;
    continue;
    // RgAsȂ玟
    if( (strchr(";*~",currentchars[0]))||(currentchars[0]=='\0') ){
    runColumn=0;
    continue;
    
    if (isalpha(*currentchars)) {
    // ߕ
    
    // `NɔzɊi[
    cmdArray = [ NSMutableArray array ];
    
    // R}h̎擾BR}hI܂œǂݍ݁B
    for(j=0; myisalnum(*currentchars); currentchars++,j++){
    command[j] = *currentchars;
    command[j] = '\0';
    [ cmdArray addObject:[ [ NSString stringWithCSJISString:command ] lowercaseString ] ];
    
    // ʏ̖ߕifnōu߂Ⴄ̂ŕ
    if( strncmp(command,"for",3)==0 ){
    [ this registLoop:currentchars ];
    continue;
    } else if( (strncmp(command,"if",2)!=0)&&(strncmp(command,"notif",5)!=0) ){
    [ this splitArgNormal:currentchars Array:cmdArray ]; // ʏ̈
    } else {
    if(strncmp(command,"if",2)==0){
    conditionResult = [ this splitArgCondition:&currentchars trueflg:true ]; // if
    } else {
    conditionResult = [ this splitArgCondition:&currentchars trueflg:false ]; // notif
    
    if(conditionResult==false){
    runColumn=0;
    continue;
    } else {
    // 擪Xy[X̓ǂݔ΂
    while((*currentchars)&&(*currentchars==' ')){
    currentchars++;
    // `NɔzɊi[
    cmdArray = [ NSMutableArray array ];
    
    // R}h̎擾B
    for(j=0; (*currentchars)&&(myisalnum(*currentchars)); currentchars++,j++){
    command[j] = *currentchars;
    command[j] = '\0';
    if( strncmp(command,"for",3)==0 ){
    [ this registLoop:currentchars ];
    continue;
    [ cmdArray addObject:[ [ NSString stringWithCSJISString:command ] lowercaseString ] ];
    [ this splitArgNormal:currentchars Array:cmdArray ];
    
    // XNvgsB
    if(![ this eval:cmdArray ]){
    NSLog(QString::fromUtf8("Undefined script '%@' at LINE %d\n"),[ cmdArray objectAtIndex:0 ],runLine+1);
    } else if (*currentchars==':') {
    runColumn++;
    } else {
    // \̎
    NSString* printString;
    
    if(currentchars==startptr){
    printString = [ ScriptArray objectAtIndex:runLine ];
    } else {
    printString = [ NSString stringWithCSJISString:currentchars ];
    while(*currentchars &&(*currentchars !=':'))
    currentchars++;
    if(!currentchars){
    runColumn=0;
    } else {
    runColumn++;
    // ǃXLbvgp̃`FbN
    if(kidokuptr){
    if(isWatchKidoku){
    //NSLog(QString::fromUtf8("runLine=%d,kidokuchr=%d,bit = %d"),runLine,*(kidokuptr+(runLine>>3)),getbit(kidokuptr,runLine));
    if(!(*(kidokuptr+(runLine>>3)) & (1 << (runLine & 0x7)))){
    [ stageManager setSkipStatus:TYNoSkip ];
    isWatchKidoku=false;
    *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
    //NSLog(QString::fromUtf8("runLine=%d,kidokuchr=%d,bit = %d"),runLine,*(kidokuptr+(runLine>>3)),getbit(kidokuptr,runLine));
    } else {
    *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
    //                 NSLog(QString::fromUtf8("bit = %d"),getbit(kidokuptr,runLine));
    [ stageManager textPrint:printString ];
    */
    
    if(breakRun) {
    break;
    
}

void TYScriptEngine::ty__print:()
{
    {
    NSString *aStr = [ argments objectAtIndex:1 ];
    
    // ǃXLbvgp̃`FbN
    if(kidokuptr){
    if(isWatchKidoku){
    if(!(*(kidokuptr+(runLine>>3)) & (1 << (runLine & 0x7)))){
    [ stageManager setSkipStatus:TYNoSkip ];
    isWatchKidoku=false;
    *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
    } else {
    *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
    
    [ stageManager textPrint:aStr ];
    
}

bool TYScriptEngine::eval:()
{
    {
    SEL cmdSEL;
    
    // R}hZN^𐶐ivtBbNX"ty_"t^B\bh̏Փ˖h~j
    // NScriptł͑召̋ʂȂB
    cmdSEL = NSSelectorFromString([ [ NSString stringWithFormat:QString::fromUtf8("ty_%@:"),[ argments objectAtIndex:0] ] lowercaseString ]);
    NSLog2(QString::fromUtf8("[%5d]%@"),runLine+1,NSStringFromSelector(cmdSEL));
    
    // ZN^gĂ邩ǂ`FbNB
    if( [ this respondsToSelector:cmdSEL ]){
    // ZN^R[BقƂ͗ÕnhÔˁ`
    [ this performSelector:cmdSEL withObject:argments ];
    } else if ([ stageManager respondsToSelector:cmdSEL ]){
    [ stageManager performSelector:cmdSEL withObject:argments ];
    } else if ([ controller respondsToSelector:cmdSEL ]){
    [ controller performSelector:cmdSEL withObject:argments ];
    } else {
    // vXXXX:dvXXXX:ւ̑Ή
    NSScanner *scanner=[ NSScanner scannerWithString:[ argments objectAtIndex:0 ] ];
    NSString *cmdStr,*numStr;
    
    if([ scanner scanString:QString::fromUtf8("dv") intoString:&cmdStr ] ||
    [ scanner scanString:QString::fromUtf8("v") intoString:&cmdStr ]){
    [ scanner scanCharactersFromSet:[ NSCharacterSet decimalDigitCharacterSet ]
    intoString:&numStr ];
    [ controller performSelector:NSSelectorFromString([ [ NSString stringWithFormat:QString::fromUtf8("ty_%@:"),cmdStr ] lowercaseString ])
    withObject:[ NSMutableArray arrayWithObjects:cmdStr,numStr,nullptr ] ];
    } else {
    if ([ undefinedComSet containsObject:[ argments objectAtIndex:0 ] ] == false) {
    NSLog(QString::fromUtf8("Undefined script '%@' at LINE %d\n"),[ argments objectAtIndex:0 ],runLine+1);
    [ undefinedComSet addObject:[ argments objectAtIndex:0 ] ];
    return false;
    
    return true;
    
}

bool TYScriptEngine::breakRun()
{
    {
    return breakRun;
    
}

void TYScriptEngine::setBreakRun:()
{
    {
    breakRun = aFlag;
    
}

void TYScriptEngine::lineEnd()
{
    {
    //runColumn++;
    
    // 𕪊āAarrayɊi[
}

int TYScriptEngine::splitArgNormal:()
{
    {
    char * buffer=currentchars;
    char command[MAX_LINE_LENGTH];
    int context; // _~[̒l
    BOOL multiLinePossible=true;
    
    // ƂȂȂ܂Ń[v
    space_skip(&buffer);
    context = get_item(&buffer,command);
    
    while(context!=TYNoArgContext){
    [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
    space_skip(&buffer);
    context = get_item(&buffer,command);
    if(context==TYSeparaterArgContext){
    space_skip(&buffer);
    context = get_item(&buffer,command);
    } else {
    multiLinePossible=false;
    break;
    
    // ̃CNg`FbNBłȂΕsT|[gR}h`FbN
    if(*buffer==':'){
    runColumn++;
    } else {
    if(multiLinePossible && [ this isMultLineSupport:[ cmdArray objectAtIndex:0 ] ]){
    [ this splitArgNormal:[ this nextLine ] Array:cmdArray ];
    } else {
    runColumn=0;
    
    return 0;
    
    /*
    int i=0,j=0;
    char command[256];
    enum { aas_SpaceSkip,aas_CommaSkip,aas_GetArg,aas_GetArgStr } argAnalyzerStat;
    BOOL chained=false;
    
    argAnalyzerStat = aas_SpaceSkip;
    while(currentchars[i]){
    switch (argAnalyzerStat) {
    case aas_SpaceSkip:	// ̈n܂܂ł̃Xy[X΂܂B
    if(!isspace(currentchars[i])){
    if(currentchars[i] == ':'){ // ߕ̘Aq
    runColumn++;
    chained=true;
    break;
    
    j=0;
    command[j] = currentchars[i];
    j++;
    if(currentchars[i] == '"'){
    argAnalyzerStat = aas_GetArgStr;
    } else {
    argAnalyzerStat = aas_GetArg;
    i++;
    break;
    
    case aas_GetArgStr: // 萔擾܂B
    command[j] = currentchars[i];
    j++;
    if(currentchars[i] == '"'){
    argAnalyzerStat = aas_CommaSkip;
    //@𐶐
    command[j] = '\0';
    [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
    i++;
    break;
    
    case aas_GetArg: // ȊÖ擾܂B
    if( (currentchars[i] != ',')&&(!isspace(currentchars[i]))&&(currentchars[i] != ':') ){
    command[j] = currentchars[i];
    j++;
    i++;
    } else {
    argAnalyzerStat = aas_CommaSkip;
    // 𐶐
    command[j] = '\0';
    [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
    if(currentchars[i] == ':' ){ // Awq
    runColumn++;
    chained=true;
    break;
    break;
    
    case aas_CommaSkip: // ؂̃J}܂Ŕ΂܂B
    if(currentchars[i] == ','){
    argAnalyzerStat = aas_SpaceSkip;
    } else if(currentchars[i] == ':' ) {
    runColumn++;
    chained=true;
    break;
    } else if(!isspace(currentchars[i])) {
    // J}̂Ȃsȍ\
    //[ NSException raise:QString::fromUtf8("TYNScriptSyntaxError") format:QString::fromUtf8("lack comma") ];
    // ̃R}hňȂꍇ̂݃G[f̂ŁAł̓G[ƂȂB
    i++;
    break;
    
    default:
    NSLog(QString::fromUtf8("Show Debbuger!\n"));
    return -1;
    
    // AqāAAi[Ă
    if(chained){
    break;
    
    // ̐rŃuCNĂ
    if(argAnalyzerStat == aas_GetArg){
    command[j] = '\0';
    [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
    } else if(argAnalyzerStat == aas_SpaceSkip){
    // Qڈȍ~̈TrŃuCNĂ
    if([ this isMultLineSupport:[ cmdArray objectAtIndex:0 ] ]){
    [ this splitArgNormal:[ this nextLine ] Array:cmdArray ];
    
    if(!chained){
    runColumn=0;
    
    return 0;
    */
    
    // R}hsɓnLqĂ邩ǂԂ
}

bool TYScriptEngine::isMultLineSupport:()
{
    {
    return [ multiLineCmdStringSet containsObject:command ];
    
    // ̍s֏i߁AXNvgoB
}

char* TYScriptEngine::nextLine()
{
    {
    runLine++;
    [ currentData release ];
    currentData = [ [ ScriptArray objectAtIndex:runLine ] getCSJISData ];
    [ currentData retain ];
    return (unsigned char*)[ currentData mutableBytes ];
    
    // for[v̓o^
    /*
}

void TYScriptEngine::registLoop:()
{
    {
    char buffer[256];
    int context;
    id targetNo;
    int initValue;
    int limit;
    int step;
    NSString *var;
    TYLoopStruct loop;
    
    // oChϐԍ擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYIntergerArgContext&& buffer[0] == '%'),
    TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    targetNo = [ this getIdNoOfArgment:var ];
    // Zq=̃`FbN
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYOperandArgContext && strcmp(buffer,"=")==0),
    TYNScriptSyntaxErrorException);
    // l擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYIntergerArgContext || context==TYUndefinedArgContext),
    TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    initValue = [ [ this getValueOfArgment:var ] intValue ];
    // to`FbN
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYUndefinedArgContext),TYNScriptSyntaxErrorException);
    // Eo̒l擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYUndefinedArgContext || context==TYIntergerArgContext),
    TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    limit = [ [ this getValueOfArgment:var ] intValue ];
    // step̑݃`FbN
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    if(context==TYNoArgContext){
    step=1;
    } else {
    NSAssert((context==TYUndefinedArgContext && (strcmp(buffer,"step")==0)),
    TYNScriptSyntaxErrorException);
    // stepl̎擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYUndefinedArgContext || context==TYIntergerArgContext),
    TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    step = [ [ this getValueOfArgment:var ] intValue ];
    
    // ϐɏlZbg
    [ scripterValues setIntValue:targetNo object:[ NSNumber numberWithInt:initValue ] ];
    
    // lɃ[v̒Eo𖞂Ăꍇ
    if(step > 0){
    if(initValue > limit){
    [ this jumpToLoopEnd ];// nextɃWv?
    return;
    } else if(step < 0){
    if(initValue < limit){
    [ this jumpToLoopEnd ];// nextɃWv?
    return;
    
    // loopIuWFNg쐬BX^bNɐςށB
    loop = TYMakeLoopStruct(TYMakeScriptPoint(runLine,runColumn),targetNo,limit,step);
    [ loopStack addObject:[ [ [ TYLoopValue alloc ] initWithStruct:loop ] autorelease ] ];
    
    runColumn++;
    */
    
}

void TYScriptEngine::registLoopTargetID:()
{
    {
    TYLoopStruct loop;
    
    NSLog2(QString::fromUtf8("push for stack at %d"),runLine);
    // ϐɏlZbg
    [ scripterValues setIntValue:varID object:[ initVal intNumber ] ];
    
    // MEMO:lɃ[v̒Eo𖞂Ăꍇ̑ΏKv?
    
    // loopIuWFNg쐬BX^bNɐςށB
    loop = TYMakeLoopStruct(TYMakeScriptPoint(runLine,runColumn),varID,[ limitVal intValue ],[ stepVal intValue ]);
    [ loopStack addObject:[ [ [ TYLoopValue alloc ] initWithStruct:loop ] autorelease ] ];
    
    
    static int chkNext(char**,int);
    
    static int chkNext(char** ptr,int stColumn)
    {
    int column;
    int result=-1;
    
    for(column=stColumn; !slideColumn(ptr,column); column++){
    space_skip(ptr);
    if(strncmp("next",*ptr,4)==0){
    result = column;
    break;
    
    return result;
    
    // next܂ŃWv܂B
}

void TYScriptEngine::jumpToLoopEnd()
{
    {
    char *ptr;
    int column=runColumn +1;
    // oCiBE|bg̘AnextɂΉB
    while(1) {
    ptr = (char*)[ [ ScriptArray objectAtIndex:runLine ] cSJISString ];
    column=chkNext(&ptr,column);
    if(column >= 0){
    runColumn = column +1;
    break;
    } else {
    runLine++;
    column=0;
    
    // if n\̉߂ƏB
}

int TYScriptEngine::splitArgCondition:()
{
    {
    int k,count;
    NSMutableArray *conditions;
    char buffer[MAX_LINE_LENGTH];
    char sentence[MAX_LINE_LENGTH];
    int context=TYChainArgContext;
    BOOL judgeResult;
    
    conditions = [ NSMutableArray array ];
    
    while(context==TYChainArgContext){
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    strcpy(sentence,buffer);
    if(context==TYIntergerArgContext){
    // ӊmBĉZqƉEӂ擾
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    if(context != TYOperandArgContext){
    NSLog(QString::fromUtf8("invalid argment [%s]. it needs operand here"),buffer);
    return false;
    strcat(sentence,buffer);
    
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    if((context != TYIntergerArgContext )&&(context != TYUndefinedArgContext)){
    NSLog(QString::fromUtf8("invalid argment [%s]. it needs interger here"),buffer);
    return false;
    strcat(sentence,buffer);
    [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];
    
    } else if(context==TYStringArgContext) {
    // ӊmBĉZqƉEӂ擾
    [ conditions addObject:QString::fromUtf8("string") ];
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    if(context != TYOperandArgContext){
    NSLog(QString::fromUtf8("invalid argment [%s]. it needs operand here"),buffer);
    return false;
    strcat(sentence,buffer);
    
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    if((context != TYStringArgContext )&&(context != TYUndefinedArgContext)){
    NSLog(QString::fromUtf8("invalid argment [%s]. it needs string here"),buffer);
    return false;
    strcat(sentence,buffer);
    [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];
    } else if(context==TYUndefinedArgContext){
    if((strcmp(buffer,"fchk")==0)||(strcmp(buffer,"lchk")==0)){
    [ conditions addObject:[ NSString stringWithCSJISString:buffer ] ];
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    if((context==TYStringArgContext)||(context==TYUndefinedArgContext)){
    [ conditions addObject:[ NSString stringWithCSJISString:buffer ] ];
    } else {
    NSLog(QString::fromUtf8("invalid argment [%s]. it needs string here"),buffer);
    return false;
    } else {
    // Ƃ肠ӂƂ݂ȂBĉZqƉEӂ擾BăXgOƂĂG[ȂłǂˁB
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    if(context != TYOperandArgContext){
    NSLog(QString::fromUtf8("invalid argment [%s]. it needs operand here"),buffer);
    return false;
    strcat(sentence,buffer);
    
    space_skip(currentcharsptr);
    context = get_item(currentcharsptr,buffer);
    if(context != TYOperandArgContext){
    NSLog(QString::fromUtf8("invalid argment [%s]. it needs interger here"),buffer);
    return false;
    strcat(sentence,buffer);
    [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];
    
    } else {
    NSLog(QString::fromUtf8("invalid argment [%s].it needs interger or \")fchk\" or \"lchk\" here",buffer);
    return false;
    
    space_skip(currentcharsptr);
    if(**currentcharsptr=='&'){
    context = get_item(currentcharsptr,buffer);
    } else {
    break;
    
    // ̐^U𔻒Btrueflg=truêƂSĐ^ȂsAtrueflg=falsêƂASċUȂs
    for(k = 0,count=[ conditions count ]; k < count ; k++){
    if([ [ conditions objectAtIndex:k ] isEqualToString:QString::fromUtf8("fchk") ]){
    k++;
    judgeResult = [ this judgefchk:[ conditions objectAtIndex:k ] ];
    } else if([ [ conditions objectAtIndex:k ] isEqualToString:QString::fromUtf8("lchk") ]){
    k++;
    judgeResult = [ labelLog isRead:[ this getStringOfArgment:[ conditions objectAtIndex:k ] ] ];
    } else if([ [ conditions objectAtIndex:k ] isEqualToString:QString::fromUtf8("string") ]){
    k++;
    judgeResult = [ this judgeCondition:[ conditions objectAtIndex:k ] string:true ];
    } else {
    judgeResult = [ this judgeCondition:[ conditions objectAtIndex:k ] string:false ];
    
    if(judgeResult != trueflg){
    return false; // sȂƂ甲B
    
    return true;
    
    // ̉摜i^O܂ށjǂݍ܂ꂽǂԂB
}

bool TYScriptEngine::judgefchk:()
{
    {
    return [ [ TYResourceServer sharedServer ] fchk:[ this getStringOfArgment:file ] ];
    
}

bool TYScriptEngine::judgelchk:()
{
    {
    return [ labelLog isRead:[ this getStringOfArgment:label ] ];
    
}

void TYScriptEngine::addLabelLog:()
{
    {
    if(labelLog)
    [ labelLog addLog:string ];
    
}

bool TYScriptEngine::judgeCondition:()
{
    {
    char valueString1[MAX_LINE_LENGTH];
    char valueString2[MAX_LINE_LENGTH];
    char cond[3];
    const char *conditionchars;
    int value1,value2;
    const char *operandchars = "!<>=";
    int i,j;
    
    conditionchars = [ condition cSJISString ];
    
    // ӂ̎擾
    for(i=0,j=0; (conditionchars[i])&&(strchr(operandchars,conditionchars[i]) == NULL) ; i++,j++ ){
    valueString1[j] = conditionchars[i];
    valueString1[j] = '\0';
    
    // Zq̎擾
    for( j=0; (conditionchars[i])&&(strchr(operandchars,conditionchars[i]) != NULL) ; i++,j++ ){
    cond[j] = conditionchars[i];
    cond[j] = '\0';
    
    // Eӂ̎擾
    for(j=0; (conditionchars[i]) ; i++,j++ ){
    valueString2[j] = conditionchars[i];
    valueString2[j] = '\0';
    
    if(aBool){
    NSString *string1,*string2;
    // ̏ꍇ̏
    string1 = [ this getStringOfArgment:[ NSString stringWithCSJISString:valueString1 ] ];
    string2 = [ this getStringOfArgment:[ NSString stringWithCSJISString:valueString2 ] ];
    
    //
    if( (strcmp(cond,"==")==0)||(strcmp(cond,"=")==0) ){ //
    return [ string1 isEqualToString:string2 ];
    } else if ( (strcmp(cond,"!=")==0)||(strcmp(cond,"<>")==0) ) { //
    return ![ string1 isEqualToString:string2 ];
    } else if (strcmp(cond,">")==0) { // ӁE
    return ([ string1 compare:string2 ] == NSOrderedDescending);
    } else if (strcmp(cond,"<")==0) { // ӁE
    return ([ string1 compare:string2 ] == NSOrderedAscending);
    } else if (strcmp(cond,">=")==0) { // ӁE
    return  ([ string1 compare:string2 ] >= NSOrderedSame);
    } else if (strcmp(cond,"<=")==0) { // ӁE
    return ([ string1 compare:string2 ] <= NSOrderedSame);
    } else {
    NSLog(QString::fromUtf8("It's illegal operand![%s]"),conditionchars);
    return -1;
    } else {
    // l̏ꍇ̏
    value1 = [ [ this getValueOfArgment:[ NSString stringWithCSJISString:valueString1 ] ] intValue];
    value2 = [ [ this getValueOfArgment:[ NSString stringWithCSJISString:valueString2 ] ] intValue];
    
    //
    if( (strcmp(cond,"==")==0)||(strcmp(cond,"=")==0) ){ //
    return (value1 == value2);
    } else if ( (strcmp(cond,"!=")==0)||(strcmp(cond,"<>")==0) ) { //
    return (value1 != value2);
    } else if (strcmp(cond,">")==0) { // ӁE
    return (value1 > value2);
    } else if (strcmp(cond,"<")==0) { // ӁE
    return (value1 < value2);
    } else if (strcmp(cond,">=")==0) { // ӁE
    return (value1 >= value2);
    } else if (strcmp(cond,"<=")==0) { // ӁE
    return (value1 <= value2);
    } else {
    NSLog(QString::fromUtf8("It's illegal operand![%s]"),conditionchars);
    return -1;
    
}

void TYScriptEngine::jump:()
{
    {
    runLine = target;
    runColumn = 0;
    
    // w肳ꂽxTɈړ
}

void TYScriptEngine::labeljump:()
{
    {
    id tmp;
    
    if(tmp = [ labelDict objectForKey:[ label lowercaseString ] ]){
    // xOɒǉ
    [ labelLog addLog:label ];
    runLine = [ tmp intValue ];
    runColumn =0;
    return;
    } else {
    NSLog(QString::fromUtf8("Not Found Label:%@"),label);
    [ NSException raise:QString::fromUtf8("TYNScriptRuntimeError") format:QString::fromUtf8("Not Found Label:%@"),label ];
    
    /*
    [ this labeljump:label fromLine:0 reverse:false ];
    return;
    */
    /*
    NSString *search_label;
    unsigned line;
    unsigned length;
    
    search_label = [ NSString stringWithFormat:QString::fromUtf8("%@"),label ];
    length = [ ScriptArray count ];
    for(line=0; line < length; line++){
    if(![ ScriptArray objectAtIndex:line]){
    continue;
    if([ search_label isEqualToString:[ ScriptArray objectAtIndex:line] ]){ // s̑Oɋ󔒂肷Ƃ܂
    runLine = line;
    runColumn = 0;
    return;
    
    NSLog(QString::fromUtf8("Not Found Label:%@"),label);
    [ NSException raise:QString::fromUtf8("TYNScriptRuntimeError") format:QString::fromUtf8("Not Found Label:%@"),label ];
    
    return;
    */
    
}

void TYScriptEngine::labeljump:()
{
    {
    unsigned l;
    unsigned length;
    NSScanner *scanner;
    NSString *str;
    
    if(labelLog)
    [ labelLog addLog:label ];
    
    if(aBool==false){
    length = [ ScriptArray count ];
    
    for(l=line; l < length; l++){
    str = [ ScriptArray objectAtIndex:l];
    if(![ str length ]){
    continue;
    scanner = [ NSScanner scannerWithString:str ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
    intoString:nullptr ];
    
    if([ scanner scanString:label intoString:nullptr ]){ // s̑Oɋ󔒂Ăv
    if([ scanner isAtEnd ] ||
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
    intoString:nullptr ]){
    
    runLine = l;
    runColumn = 0;
    return;
    } else {
    for(l=line; l >= 0; l--){
    if(![ ScriptArray objectAtIndex:l]){
    continue;
    scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:l] ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
    intoString:nullptr ];
    if([ scanner scanString:label intoString:nullptr ]){ // s̑Oɋ󔒂Ăv
    if([ scanner isAtEnd ] ||
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
    intoString:nullptr ]){
    
    runLine = l;
    
    runColumn = 0;
    
    return;
    
    NSLog(QString::fromUtf8("Not Found Label:%@"),label);
    [ NSException raise:QString::fromUtf8("TYNScriptRuntimeError") format:QString::fromUtf8("Not Found Label:%@"),label ];
    
    return;
    
    // 琔lIuWFNgoBMEMO:ϐɂċAIȎQƂ\ɂȂ΂ȂȂ
}

QObject* TYScriptEngine::getValueOfArgment:()
{
    {
    /*
    NSString *firstCharStr;
    int scanValue;
    NSNumber *resultForAlias;
    */
    
    return [ argment intNumber ];
    /*
    firstCharStr = [ argment substringWithRange:NSMakeRange(0,1) ];
    // 1ڂɂĕ
    if([ firstCharStr isEqualToString:QString::fromUtf8("%") ]) {
    // ϐ̏ꍇAIndex̎wċAŕ]
    return [ scripterValues getIntValue:[ this getValueOfArgment:[ argment substringFromIndex:1 ] ] ];
    } else if([ firstCharStr isEqualToString:QString::fromUtf8("?") ]){
    // zϐꍇ
    return [ scripterValues getIntValue:[ this getArrayIdOfArgment:argment ] ];
    
    if([ [ NSScanner scannerWithString:argment ] scanInt:&scanValue ]){
    // 萔̏ꍇ
    return [ NSNumber numberWithInt:scanValue ];
    } else {
    // GCAXH
    resultForAlias = [ numAliases objectForKey:[ argment lowercaseString ] ];
    if(resultForAlias){
    return resultForAlias;
    } else {
    // O
    goto ANALYZE_ERROR;
    //[ NSException raise:QString::fromUtf8("TYNScriptRuntimeError") format:QString::fromUtf8("Illegal Value Index:%@"),argment ];
    //return [ NSNumber numberWithInt:0 ];
    
    ANALYZE_ERROR:
    NSLog(QString::fromUtf8("Not Get Interger Value from [%@]\n"),argment);
    return [ NSNumber numberWithInt:0 ];
    */
    
    // 當IuWFNgoB
}

QObject* TYScriptEngine::getStringOfArgment:()
{
    {
    /*
    NSString *firstCharStr;
    NSString *scanStr;
    NSString *resultForAlias;
    */
    return [ argment stringObj ];
    /*
    // 1ڂɂĕ
    firstCharStr = [ argment substringWithRange:NSMakeRange(0,1) ];
    if( [ firstCharStr isEqualToString:QString::fromUtf8("\")" ]){
    // 萔̏ꍇ
    // 擪Ɩ'"'폜̂܂ܕԂB
    if([ [ NSScanner scannerWithString:[ argment substringFromIndex:1 ] ] scanUpToString:
    QString::fromUtf8("\")" intoString:&scanStr ]){
    return scanStr;
    } else {
    return @"";
    //NSLog(QString::fromUtf8("get constant String %@ from %@"),scanStr,argment );
    //return (scanStr) ? scanStr : @"";
    } else if( [ firstCharStr isEqualToString:QString::fromUtf8("$") ]) {
    // ϐ̃CfbNXċAIɎ擾
    return [ scripterValues getStringValue:[ this getValueOfArgment:
    [ argment substringFromIndex:1 ] ] ];
    } else if( [ firstCharStr isEqualToString:QString::fromUtf8("(") ]) {
    NSScanner *scanner=[ NSScanner scannerWithString:argment ];
    NSString *fileName,*trueStr,*falseStr;
    
    NSLog2(QString::fromUtf8("%@"),argment);
    [ scanner setScanLocation:1 ];
    [ scanner scanUpToString:QString::fromUtf8(")") intoString:&fileName ];
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
    intoString:nullptr ];
    if([ [ argment substringWithRange:NSMakeRange([ scanner scanLocation ],1) ] isEqualToString:QString::fromUtf8("\")" ]) {
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    [ scanner scanUpToString:QString::fromUtf8("\")" intoString:&trueStr ];
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    } else {
    [ scanner scanUpToCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
    intoString:&trueStr ];
    
    if([ [ TYResourceServer sharedServer ] fchk:[ this getStringOfArgment:fileName ] ]){
    NSLog2(QString::fromUtf8("fileName=%@[%@],TRUE\n,result=%@[%@]"),fileName,[ this getStringOfArgment:fileName ],
    trueStr,[ this getStringOfArgment:trueStr ]);
    return [ this getStringOfArgment:trueStr ];
    } else {
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
    intoString:nullptr ];
    
    if([ [ argment substringWithRange:NSMakeRange([ scanner scanLocation ],1) ] isEqualToString:QString::fromUtf8("\")" ]) {
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    [ scanner scanUpToString:QString::fromUtf8("\")" intoString:&falseStr ];
    } else {
    [ scanner scanUpToCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
    intoString:&falseStr ];
    NSLog2(QString::fromUtf8("fileName=%@[%@],FALSE\n,result=%@[%@]"),fileName,[ this getStringOfArgment:fileName ],
    falseStr,[ this getStringOfArgment:falseStr ]);
    
    return [ this getStringOfArgment:falseStr ];
    
    
    
    } else {
    // GCAX̏ꍇ
    resultForAlias = [ strAliases objectForKey:[ argment lowercaseString ] ];
    if(resultForAlias){
    return resultForAlias;
    } else {
    return argment; // GCAXɓo^ĂȂΕ̂܂ܕԂA񃉃xWJ΍
    //goto ANALYZE_ERROR;
    */
    
    /*
    ANALYZE_ERROR:
    NSLog(QString::fromUtf8("Not Get String Value from [%@]\n"),argment);
    return nullptr;
    */
    
    
}

QObject* TYScriptEngine::getIdNoOfArgment:()
{
    {
    return [ argment varID ];
    /*
    if([ argment length ] &&
    ([ [ argment substringWithRange:NSMakeRange(0,1) ] isEqualToString:QString::fromUtf8("?") ])){
    // z^
    return [ this getArrayIdOfArgment:argment ];
    } else {
    return [ this getValueOfArgment:[ argment substringFromIndex:1 ] ];
    */
    
}

QObject* TYScriptEngine::getArrayIdOfArgment:()
{
    {
    return [ argment varID ];
    /*
    // zϐ̎w擾B
    NSMutableArray *aArray = [ NSMutableArray array ];
    NSScanner *scanner;
    NSString *bufStr;
    NSString *stopString = QString::fromUtf8("[");
    
    scanner = [ NSScanner scannerWithString:[ argment substringFromIndex:1 ] ];
    
    while([ scanner scanUpToString:stopString intoString:&bufStr ]){
    // ϐWJĊi[
    [ aArray addObject:[ this getValueOfArgment:bufStr ] ];
    
    [ scanner setScanLocation:[ scanner scanLocation ]+1 ];
    [ scanner scanString:QString::fromUtf8("[") intoString:nullptr ];
    stopString = QString::fromUtf8("]");
    
    return aArray;
    */
    
    // GtFNgԍԂB́ATYEffecter-1Ԃɓo^A-1ԂB
}

QObject* TYScriptEngine::getEffectNoOfArgments:()
{
    {
    int count;
    
    count = [ argments count ];
    
    if(count == 1){
    return [ this getValueOfArgment:[ argments objectAtIndex:0 ] ];
    } else {
    [ argments insertObject:[ NSNull null ] atIndex:0 ];
    [ argments insertObject:[ NSNumber numberWithInt:-1 ] atIndex:1 ];
    [ stageManager performSelector:@selector(ty_effect:) withObject:argments ];
    return [ NSNumber numberWithInt:-1 ];
    
}

QObject* TYScriptEngine::intNumberWithVarID:()
{
    {
    return [ scripterValues getIntValue:varID ];
    
}

QObject* TYScriptEngine::stringValueWithVarID:()
{
    {
    return [ scripterValues getStringValue:varID ];
    
}

QObject* TYScriptEngine::intNumberWithAlias:()
{
    {
    return [ numAliases objectForKey:aStr ];
    
}

QObject* TYScriptEngine::stringValueWithAlias:()
{
    {
    return [ strAliases objectForKey:aStr ];
    
    // 񒆂̕ϐWJԂB
}

NSString* TYScriptEngine::stringOfReplaceVars:()
{
    {
    NSCharacterSet *varHeaderSet = [ NSCharacterSet characterSetWithCharactersInString:QString::fromUtf8("$%") ];
    NSString *replaceStr,*str=nullptr,*symbol;
    NSScanner *scanner;
    NSMutableArray *array;
    
    scanner = [ NSScanner scannerWithString:aString ];
    [ scanner scanUpToCharactersFromSet:varHeaderSet intoString:&str ];
    if([ scanner isAtEnd ]==false){
    array = [ NSMutableArray arrayWithCapacity:1 ];
    while(1){
    if(str)
    [ array addObject:str ];
    symbol = [ [ scanner string ] substringWithRange:NSMakeRange([ scanner scanLocation ],1) ];
    [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet varNameCharacterSet ] intoString:&str ];
    if([ symbol isEqualToString:QString::fromUtf8("$") ]){
    [ array addObject:[ this getStringOfArgment:
    [ TYStringVarArgment argmentWithVarID:
    [ NSNumber numberWithInt:[ str intValue ] ] ] ] ];
    } else if([ symbol isEqualToString:QString::fromUtf8("%") ]){
    NSNumber *number;
    number = [ this getValueOfArgment:
    [ TYIntVarArgment argmentWithVarID:
    [ NSNumber numberWithInt:[ str intValue ] ] ] ];
    [ array addObject:[ number stringValue ] ];
    
    str = nullptr;
    [ scanner scanUpToCharactersFromSet:varHeaderSet intoString:&str ];
    if([ scanner isAtEnd ])
    break;
    if(str)
    [ array addObject:str ];
    
    replaceStr = [ array componentsJoinedByString:@"" ];
    } else {
    replaceStr = aString;
    
    return replaceStr;
    
}

void TYScriptEngine::saveExternalData()
{
    {
    if(globalOn){
    [ scripterValues saveGlobalValues:[ getNScrRootDirectory()
    stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    
    if(labelLog)
    [ labelLog writeToFile:[ getNScrRootDirectory() stringByAppendingPathComponent:LABELLOG_FILENAME ] ];
    
    if(kidokuData)
    [ kidokuData writeToFile:[ getNScrRootDirectory() stringByAppendingPathComponent:KIDOKU_FILENAME ] atomically:true ];
    
    #if YYDEBUG == 1
    extern int yydebug;
}

void TYScriptEngine::ty__yydebug:()
{
    {
    yydebug = [ [ argments objectAtIndex:1 ] intValue ];
    #endif
    
}

void TYScriptEngine::ty__log:()
{
    {
    TYArgment *arg;
    
    arg = [ argments objectAtIndex:1 ];
    switch([ arg argType ]) {
    case TYDigitArgType:
    case TYIntVarArgType:
    NSLog(QString::fromUtf8("log it's number,[%d]"),[ arg intValue ]);
    break;
    case TYConstStringArgType:
    case TYStringVarArgType:
    case TYFchkArgType:
    NSLog(QString::fromUtf8("log it's string,[%@]"),[ arg stringObj ]);
    break;
    case TYAliasArgType:
    NSLog(QString::fromUtf8("log it's alias,name[%@],string[%@],number[%@]"),arg->rawString(),arg->stringObj(),arg->intNumber());
    
    
}

void TYScriptEngine::ty_globalon:()
{
    {
    // O[oϐ[hAIɕۑ悤ɂB
    
    /*aData = [ NSMutableData dataWithContentsOfFile:
    [ getAppDirectory() stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    */
    
    
    // MEMO:݌̃`FbN
    {
    globalOn = true;
    
    
    /*
}

void TYScriptEngine::saveGlobal()
{
    {
    if(globalOn){
    [ scripterValues saveGlobalValues:[ getAppDirectory()
    stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    */
    
    
    /*
}

void TYScriptEngine::saveLabelLog()
{
    {
    if(labelLog)
    [ labelLog writeToFile:[ getAppDirectory() stringByAppendingPathComponent:LABELLOG_FILENAME ] ];
    */
    
}

int TYScriptEngine::runLine()
{
    {
    return runLine;
    
}

void TYScriptEngine::moveRunLine:()
{
    {
    runLine += aInt;
    
}

void TYScriptEngine::incRunColumn()
{
    {
    runColumn++;
    
}

void TYScriptEngine::resetRunColumn()
{
    {
    runColumn=0;
    
}

void TYScriptEngine::ty_labellog:()
{
    {
    labelLog = [ [ TYFileLog alloc ] initWithContentsOfFile:[ getNScrRootDirectory()  	stringByAppendingPathComponent:LABELLOG_FILENAME ] ];
    
    
}

void TYScriptEngine::ty_getversion:()
{
    {
    NSNumber *verNum;
    id idno;
    verNum = [ TYEnviroment objectForKey:QString::fromUtf8("NScripterVersion") ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    [ scripterValues setIntValue:idno object:verNum ];
    
    // zϐ̐錾
}

void TYScriptEngine::ty_dim:()
{
    {
    id idno;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    [ scripterValues defineArrayValue:idno ];
    
}

void TYScriptEngine::ty_movl:()
{
    {
    id idno;
    NSEnumerator *enu;
    NSMutableArray *array = [ NSMutableArray array ];
    id tmp;
    
    enu = [ argments objectEnumerator ];
    [ enu nextObject ];
    
    idno = [ this getArrayIdOfArgment:[ enu nextObject ] ];
    
    while(tmp = [ enu nextObject ]){
    [ array addObject:[ this getValueOfArgment:tmp ] ];
    
    [ scripterValues setArrayLine:idno values:array ];
    
    
    //  ϐɑ
}

void TYScriptEngine::ty_mov:()
{
    {
    TYVarType type;
    id arg;
    id idno;
    
    type = [ [ argments objectAtIndex:1 ] varType ];
    
    // ϐID擾
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    if(type == TYStringVarType){
    arg = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
    [ scripterValues setStringValue:idno object:arg ];
    } else if(type & TYDigitVarTypeMask) {
    arg = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
    [ scripterValues setIntValue:idno object:arg ];
    
}

void TYScriptEngine::ty_mov3:()
{
    {
    [ this movRepeat:3 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::ty_mov4:()
{
    {
    [ this movRepeat:4 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::ty_mov5:()
{
    {
    [ this movRepeat:5 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::ty_mov6:()
{
    {
    [ this movRepeat:6 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::ty_mov7:()
{
    {
    [ this movRepeat:7 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::ty_mov8:()
{
    {
    [ this movRepeat:8 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::ty_mov9:()
{
    {
    [ this movRepeat:9 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::ty_mov10:()
{
    {
    [ this movRepeat:10 argments:(NSMutableArray*)argments ];
    
}

void TYScriptEngine::movRepeat:()
{
    {
    TYVarType type;
    int i;
    int intId;
    NSEnumerator *enm;
    id temp;
    
    enm = [ argments objectEnumerator ];
    [ enm nextObject ];
    
    temp = [ enm nextObject ];
    type = [ temp varType ];
    intId = [ [ this getIdNoOfArgment:temp ] intValue ];
    
    if(type & TYDigitVarTypeMask){
    for(i=0; i < repeat_times; i++,intId++){
    [ scripterValues setIntValue:[ NSNumber numberWithInt:intId ] object:[ this getValueOfArgment:[ enm nextObject ] ] ];
    } else if(type == TYStringVarType) {
    for(i=0; i < repeat_times; i++,intId++){
    [ scripterValues setStringValue:[ NSNumber numberWithInt:intId ] object:[ this getStringOfArgment:[ enm nextObject ] ] ];
    } else {
    NSLog(QString::fromUtf8("movX,error of arg 1,invalid context"));
    
}

void TYScriptEngine::ty_intlimit:()
{
    {
    [ scripterValues setIntLimitID:[ this getValueOfArgment:[ argments objectAtIndex:1 ] ]
    low:[ this getValueOfArgment:[ argments objectAtIndex:2 ] ] 				      high:[ this getValueOfArgment:[ argments objectAtIndex:3 ] ] ];
    
    // ϐ̃CNg
}

void TYScriptEngine::ty_inc:()
{
    {
    id idno;
    NSNumber *number;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] +1 ];
    [ scripterValues setIntValue:idno object:number ];
    
    // ϐ̃fNg
}

void TYScriptEngine::ty_dec:()
{
    {
    id idno;
    NSNumber *number;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] -1 ];
    [ scripterValues setIntValue:idno object:number ];
    
    
    // ϐ̑Z ȂA
}

void TYScriptEngine::ty_add:()
{
    {
    id idno;
    NSNumber *number;
    NSNumber *argnum;
    NSString *string;
    NSString *argstr;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    if( [ [ argments objectAtIndex:1 ] varType ] == TYStringVarType ){
    argstr = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
    string = [ scripterValues getStringValue:idno ];
    string = [ NSString stringWithFormat:QString::fromUtf8("%@%@"),string,argstr ];
    [ scripterValues setStringValue:idno object:string ];
    } else {
    argnum = [ this getValueOfArgment:argments->objectAtIndex(2 ] ];
    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] +[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
    
    return ;
    
    // ϐ̈Z
}

void TYScriptEngine::ty_sub:()
{
    {
    id idno;
    NSNumber *number;
    NSNumber *argnum;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
    
    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] -[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
    
}

void TYScriptEngine::ty_mul:()
{
    {
    id idno;
    NSNumber *number;
    NSNumber *argnum;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
    
    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] *[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
    
}

void TYScriptEngine::ty_div:()
{
    {
    id idno;
    NSNumber *number;
    NSNumber *argnum;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
    
    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] /[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
    
}

void TYScriptEngine::ty_mod:()
{
    {
    id idno;
    NSNumber *number;
    NSNumber *argnum;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
    
    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] % [ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
    
}

void TYScriptEngine::ty_cmp:()
{
    {
    id idno;
    int result;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    result = [ (NSString*)[ this getStringOfArgment:[ argments objectAtIndex:2 ] ] compare:
    [ this getStringOfArgment:[ argments objectAtIndex:3 ] ] ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];
    
    
}

void TYScriptEngine::ty_atoi:()
{
    {
    id idno;
    NSString *str;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    str = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
    
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:[ str intValue ] ] ];
    
}

void TYScriptEngine::ty_itoa:()
{
    {
    id idno;
    int value;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    value = [ [ this getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    
    [ scripterValues setStringValue:idno object:[ NSString stringWithFormat:QString::fromUtf8("%d"),value ] ];
    
}

void TYScriptEngine::ty_len:()
{
    {
    id idno;
    unsigned length;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    length = [ [ this getStringOfArgment:[ argments objectAtIndex:2 ] ] cSJISStringLength ];
    
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:length ] ];
    
}

void TYScriptEngine::ty_mid:()
{
    {
    id idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    NSString *inStr = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
    int offset = [ [ this getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    int length = [ [ this getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    
    [ scripterValues setStringValue:idno object:[ inStr substringSJISRange:NSMakeRange(offset,length) ] ];
    
}

void TYScriptEngine::ty_splitstring:()
{
    {
    NSString *scrStr;
    NSString *tmpStr;
    NSEnumerator *argEnu,*scrEnu;
    
    argEnu = [ argments objectEnumerator ];
    [ argEnu nextObject ];
    scrStr = [ [ argEnu nextObject ] stringObj ];
    scrEnu = [ [ scrStr componentsSeparatedByString:[ [ argEnu nextObject ] stringObj ] ] objectEnumerator ];
    while(tmpStr = [ scrEnu nextObject ]) {
    [ this ty_mov:[ NSMutableArray arrayWithObjects:QString::fromUtf8("mov"),
    [ argEnu nextObject ],
    [ TYConstStringArgment argmentWithString:tmpStr ],nullptr ]  ];
    
}

void TYScriptEngine::ty_rnd:()
{
    {
    id idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    int max = [ [ this getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    int result;
    
    result = TYRandom(0,max -1);
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];
    
}

void TYScriptEngine::ty_rnd2:()
{
    {
    int min,max,result;
    id idno;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    min = [ [ this getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    max = [ [ this getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    
    result = TYRandom(min,max);
    
    //NSLog(QString::fromUtf8("random,min=%d,max=%d,result=%d"),min,max,result);
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];
    
}

void TYScriptEngine::ty_date:()
{
    {
    NSCalendarDate *cDate;
    id idno;
    int d;
    
    cDate = [ NSCalendarDate calendarDate ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    d = [ cDate yearOfCommonEra ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    d = [ cDate monthOfYear ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:3 ] ];
    d = [ cDate dayOfMonth ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    
}

void TYScriptEngine::ty_time:()
{
    {
    NSCalendarDate *cDate;
    id idno;
    int d;
    
    cDate = [ NSCalendarDate calendarDate ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    d = [ cDate hourOfDay ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    d = [ cDate minuteOfHour ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:3 ] ];
    d = [ cDate secondOfMinute ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    
    // GCAX̓o^
}

void TYScriptEngine::ty_stralias:()
{
    {
    [ strAliases setObject: [ this getStringOfArgment:[ argments objectAtIndex:2 ] ]
    forKey:[ [ argments objectAtIndex:1 ] lowercaseString ] ];
    return;
    
    // GCAX̓o^
}

void TYScriptEngine::ty_numalias:()
{
    {
    [ numAliases setObject:[ this getValueOfArgment:[ argments objectAtIndex:2 ] ]
    forKey:[ [ argments objectAtIndex:1 ] lowercaseString ] ];
    return;
    
    // A[JCoo^
}

void TYScriptEngine::ty_arc:()
{
    {
    [ [ TYResourceServer sharedServer ] addArchiver:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    
    // NSAA[JCuǂ
}

void TYScriptEngine::ty_nsa:()
{
    {
    int i;
    NSString *dir = ( nsaDir ) ? nsaDir : @"";
    
    [ [ TYResourceServer sharedServer ] addArchiver:
    [ dir stringByAppendingPathComponent:[ NSString stringWithFormat:DEFALUT_NSA_ARCHIVE,@"" ] ] ];
    
    for(i=1;i<=9;i++){
    [ [ TYResourceServer sharedServer ] addArchiver:
    [ dir stringByAppendingPathComponent:[ NSString stringWithFormat:DEFALUT_NSA_ARCHIVE,[ NSString stringWithFormat:QString::fromUtf8("%d"),i ] ] ] ];
    
    
}

void TYScriptEngine::ty_nsadir:()
{
    {
    nsaDir = [ [ this getStringOfArgment:[ argments objectAtIndex:1 ] ] retain ];
    
}

void TYScriptEngine::ty_ns2:()
{
    {
    [ TYNsaArchiver setMode:TY2TypeNsaFileMode ];
    [ this ty_nsa:nullptr ];
    
}

void TYScriptEngine::ty_ns3:()
{
    {
    [ TYNsaArchiver setMode:TY3TypeNsaFileMode ];
    [ this ty_nsa:nullptr ];
    
    // EChE^Cg̕ύX
    /*-(void)ty_caption:(NSMutableArray *)argments
    {
    [ controller ty_caption:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    return;
    }*/
    
    
    // GtFNgo^
    /*-(void)ty_effect:(NSMutableArray *)argments
    {
    int count;
    NSNumber *effectNo=nullptr,*effectType=nullptr,*time=nullptr;
    NSString *path=nullptr;
    
    count = [ argments count ];
    
    switch(count){
    case 5:
    path = [ this getStringOfArgment:[ argments objectAtIndex:4 ] ];
    case 4:
    time = [ this getValueOfArgment:[ argments objectAtIndex:3 ] ];
    case 3:
    effectType = [ this getValueOfArgment:[ argments objectAtIndex:2 ] ];
    effectNo = [ this getValueOfArgment:[ argments objectAtIndex:1 ] ];
    
    [ [ stageManager effecter ] setEffectNo:[ effectNo intValue ]
    type:[ effectType intValue ]
    time:[ time intValue ]
    path:path ];
    
    }*/
    
    /*-(void)ty_bg:(NSMutableArray *)argments
    {
    NSNumber *effNo;
    
    effNo = [ this getEffectNoOfArgments:[ NSMutableArray arrayWithArray:
    [ argments subarrayWithRange:NSMakeRange(2,[ argments count]-2) ] ] ];
    
    [ stageManager ty_bg:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] effectNo:[ effNo intValue ] ];
    }*/
    
    /*-(void)ty_click:(NSMutableArray *)argments
    {
    [ this setBreakRun:true ];
    [ controller ty_click ];
    }*/
    
    
    /*-(void)ty_wait:(NSMutableArray *)argments
    {
    [ this setBreakRun:true ];
    [ controller setStatus:TYTimeWaitStatus ];
    [ this performSelector:@selector(runScript) withObject:nullptr afterDelay:
    [ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] / 10 ];
    }*/
    
}

void TYScriptEngine::ty_jumpf:()
{
    {
    [ this labeljump:QString::fromUtf8("~") fromLine:runLine reverse:false ];
    
}

void TYScriptEngine::ty_jumpb:()
{
    {
    [ this labeljump:QString::fromUtf8("~") fromLine:runLine reverse:true ];
    
}

void TYScriptEngine::ty_goto:()
{
    {
    [ this labeljump:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    
}

void TYScriptEngine::ty_gosub:()
{
    {
    TYScriptPoint sPoint;
    sPoint = TYMakeScriptPoint(runLine,runColumn);
    [ returnStack addObject:[ NSValue valueWithBytes:&sPoint objCType:@encode(TYScriptPoint) ] ];
    [ this labeljump:[ this getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    
}

void TYScriptEngine::ty_return:()
{
    {
    TYScriptPoint sPoint;
    [ [ returnStack lastObject ] getValue:&sPoint ];
    [ this jump:sPoint.line ];
    runColumn = sPoint.column;
    [ returnStack removeLastObject ];
    
    // VXeJX^}CYAtextgosubŌĂ΂ꂽƂ납ԂȂ
    if((textgosubPointIndex > -1) &&
    (textgosubPointIndex == [ returnStack count ])){
    [ this setBreakRun:true ];
    [ stageManager resumePrinting ];
    textgosubPointIndex = -1;
    
}

void TYScriptEngine::ty_tablegoto:()
{
    {
    int num=[ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    [ this ty_goto:[ NSMutableArray arrayWithObjects:QString::fromUtf8("goto"),[ argments objectAtIndex:2+num ],nullptr ] ];
    
}

void TYScriptEngine::ty_skip:()
{
    {
    int step = [ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    if(step)
    runLine += step -1;
    
}

void TYScriptEngine::ty_next:()
{
    {
    TYLoopStruct loop;
    int now;
    
    NSAssert(([ loopStack count ] > 0),QString::fromUtf8("do next,but no loop stack"));
    [ [ loopStack lastObject ] getValue:&loop ];
    
    now=[ [ scripterValues getIntValue:loop.varNo ] intValue ]+loop.step;
    [ scripterValues setIntValue:loop.varNo object:[ NSNumber numberWithInt:now ] ];
    
    if((loop.step>0 && now>loop.limit) || (loop.step<0 && now<loop.limit)){
    NSLog2(QString::fromUtf8("remove for stack"));
    [ loopStack removeLastObject ];
    } else {
    runLine=loop.point.line;
    runColumn=loop.point.column;
    if(runColumn==0)
    runColumn++;
    
}

void TYScriptEngine::ty_break:()
{
    {
    NSLog2(QString::fromUtf8("remove for stack"));
    [ loopStack removeLastObject ];
    if([ argments count ] >= 2) {
    [ this ty_goto:argments ];
    } else
    [ this jumpToLoopEnd ];
    
}

void TYScriptEngine::ty_game:()
{
    {
    [ this labeljump:QString::fromUtf8("*start") ];
    
}

void TYScriptEngine::ty_resettimer:()
{
    {
    [ timerStartDate release ];
    timerStartDate = [ [ NSDate alloc ] init ];
    
}

void TYScriptEngine::ty_waittimer:()
{
    {
    int timerValue;
    NSTimeInterval interval=[ timerStartDate timeIntervalSinceNow ];
    NSTimeInterval delay;
    
    timerValue = [ [ this getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    
    delay = timerValue / 1000.0 +interval;
    if(delay < 0)
    delay = 0;
    
    [ this setBreakRun:true ];
    
    [ this performSelector:@selector(runScript) withObject:nullptr afterDelay:
    timerValue / 1000.0 +[ timerStartDate timeIntervalSinceNow ] ];
    
}

void TYScriptEngine::ty_gettimer:()
{
    {
    id idno;
    NSNumber *number;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    number = [ NSNumber numberWithInt:-[ timerStartDate timeIntervalSinceNow ] *1000 ];
    [ scripterValues setIntValue:idno object:number ];
    
}

void TYScriptEngine::ty_loadgame:()
{
    {
    NSNumber *number;
    
    number = [ this getValueOfArgment:[ argments objectAtIndex:1 ] ];
    
    [ controller loadLocalData:number ];
    
}

void TYScriptEngine::ty_savegame:()
{
    {
    NSNumber *number;
    
    number = [ this getValueOfArgment:[ argments objectAtIndex:1 ] ];
    
    [ controller saveLocalData:number ];
    
    // vȌI
}

void TYScriptEngine::ty_end:()
{
    {
    // ݒ̃Z[u
    // O[oϐ̃Z[u
    [ NSApp terminate:this ];
    
}

void TYScriptEngine::ty_inputstr:()
{
    {
    id idno;
    TYInputStrController *input;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    input = [ TYInputStrController dialog ];
    [ input runModalCaption:[ this getStringOfArgment:[ argments objectAtIndex:2 ] ]
    length:[ [ this getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ]
    notAscii:[ [ this getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ] ];
    
    [ scripterValues setStringValue:idno object:[ input string ] ];
    
    
}

void TYScriptEngine::ty_input:()
{
    {
    id idno;
    TYInputStrController *input;
    
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    input = [ TYInputStrController dialog ];
    [ input runModalCaption:[ this getStringOfArgment:[ argments objectAtIndex:2 ] ]
    defaultStr:[ this getStringOfArgment:[ argments objectAtIndex:3 ] ]
    length:[ [ this getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ]
    notAscii:[ [ this getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ] ];
    
    [ scripterValues setStringValue:idno object:[ input string ] ];
    
    
}

void TYScriptEngine::ty_mesbox:()
{
    {
    NSRunInformationalAlertPanel([ this getStringOfArgment:[ argments objectAtIndex:2 ] ],[ this getStringOfArgment:[ argments objectAtIndex:1 ] ],QString::fromUtf8("OK"),nullptr,nullptr);
    
    
}

void TYScriptEngine::ty_getreg:()
{
    {
    NSDictionary *aDict=[ NSDictionary dictionaryWithContentsOfFile:[ getNScrRootDirectory() stringByAppendingPathComponent:REGISTRY_NAME ] ];
    NSString *key;
    NSString *name;
    NSString *value;
    NSDictionary *keyDict;
    id idno;
    
    key = [ this getStringOfArgment:[ argments objectAtIndex:2 ] ];
    name = [ this getStringOfArgment:[ argments objectAtIndex:3 ] ];
    
    if((aDict)&&(keyDict = [ aDict objectForKey:key ])){
    value = [ keyDict objectForKey:name ];
    idno = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    [ scripterValues setStringValue:idno object:value ];
    
    
}

void TYScriptEngine::ty_getcursorpos:()
{
    {
    NSPoint point;
    id varX,varY;
    
    varX = [ this getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    varY = [ this getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    
    point = [ stageManager drawPoint ];
    [ scripterValues setIntValue:varX object:[ NSNumber numberWithInt:point.x ] ];
    [ scripterValues setIntValue:varY object:[ NSNumber numberWithInt:VSCREEN_HEIGHT -point.y ] ];
    
}

void TYScriptEngine::ty_lr_trap:()
{
    {
    [ this ty_trap:argments ];
    
}

void TYScriptEngine::ty_trap:()
{
    {
    NSString *arg=[ argments objectAtIndex:1 ];
    NSString *carg = [ this getStringOfArgment:arg ];
    
    if([ arg compare:QString::fromUtf8("off") options:NSCaseInsensitiveSearch ]==NSOrderedSame){
    if(labelWithTrap)
    [ labelWithTrap release ];
    labelWithTrap=nullptr;
    fireOfTrap = false;
    [ controller setTrap:false ];
    } else if([ arg compare:QString::fromUtf8("stop") options:NSCaseInsensitiveSearch ]==NSOrderedSame){
    fireOfTrap = false;
    [ controller setTrap:false ];
    } else if([ arg compare:QString::fromUtf8("resume") options:NSCaseInsensitiveSearch ]==NSOrderedSame){
    fireOfTrap = false;
    [ controller setTrap:true ];
    } else {
    labelWithTrap=[ carg retain ];
    fireOfTrap = false;
    [ controller setTrap:true ];
    
}

void TYScriptEngine::fireOfTrap()
{
    {
    if(labelWithTrap)
    fireOfTrap=true;
    
}

void TYScriptEngine::fireOfTextgosub:()
{
    {
    TYScriptPoint point;
    point = TYMakeScriptPoint(runLine,runColumn);
    [ this ty_gosub:[ NSMutableArray arrayWithObjects:QString::fromUtf8("gosub"),aLabel,nullptr ] ];
    textgosubPointIndex = [ returnStack count ] -1;
    [ this runScript ];
    
}

void TYScriptEngine::enableKidoku()
{
    {
    kidokuData=[ [ NSMutableData alloc ] initWithContentsOfFile:
    [ getNScrRootDirectory() stringByAppendingPathComponent:KIDOKU_FILENAME ] ];
    if(!kidokuData){
    kidokuData = [ [ NSMutableData alloc ] initWithLength:[ ScriptArray count ] / 8 +1 ];
    } else {
    if([ kidokuData length ] < [ ScriptArray count ] / 8 +1){
    [ kidokuData setLength:[ ScriptArray count ] / 8 +1 ];
    
    kidokuptr = (unsigned char*)[ kidokuData mutableBytes ];
    
}

void TYScriptEngine::setWatchKidoku:()
{
    {
    isWatchKidoku = aBool;
    
    
}

