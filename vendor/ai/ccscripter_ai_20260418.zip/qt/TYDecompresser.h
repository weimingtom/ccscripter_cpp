#ifndef TYDECOMPRESSER_H
#define TYDECOMPRESSER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYDecompresser : public QObject
{
    Q_OBJECT
public:
    NSData* decodeDataWithFileHandle:();
    NSBitmapImageRep* decodeBitmapWithFileHandle:();
};

#endif // TYDECOMPRESSER_H
