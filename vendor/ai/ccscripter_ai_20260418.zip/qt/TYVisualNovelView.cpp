#include "TYVisualNovelView.h"

// Converted from Objective-C

void TYVisualNovelView::setMouseDownSelector:()
{
    {
    TYMouseDownSelector = aSelector;
    */
    
    /*
}

QObject* TYVisualNovelView::initWithFrame:()
{
    {
    [ super initWithFrame:frameRect ];
    return this;
    */
    
}

void TYVisualNovelView::drawRect:()
{
    {
    if(directDraw){
    if(NSEqualRects(rect,directInRect)){
    [ directDrawImage drawInRect:directInRect fromRect:directFromRect operation:NSCompositeCopy fraction:1.0 ];
    directDraw=false;
    [ directDrawImage release ];
    return;
    
    if(isScale){
    if(sourceImage){
    NSRect fRect=rect;
    RECT_DIV(fRect,scale);
    [ sourceImage drawInRect:rect fromRect:fRect operation:NSCompositeCopy fraction:1.0 ];
    //[ sourceImage compositeToPoint:rect.origin fromRect:rect operation:NSCompositeCopy ];
    } else {
    [ [ NSColor blackColor ] set ];
    NSRectFill(rect);
    } else {
    if(sourceImage){
    [ sourceImage compositeToPoint:rect.origin fromRect:rect operation:NSCompositeCopy ];
    } else {
    [ [ NSColor blackColor ] set ];
    NSRectFill(rect);
    
    if(directDraw){
    [ directDrawImage drawInRect:directInRect fromRect:directFromRect operation:NSCompositeCopy fraction:1.0 ];
    directDraw=false;
    [ directDrawImage release ];
    
    
}

bool TYVisualNovelView::isOpaque()
{
    {
    return true;
    
    /*
}

bool TYVisualNovelView::isFlipped()
{
    {
    return true;
    */
    
}

NSImage* TYVisualNovelView::image()
{
    {
    return sourceImage;
    
}

void TYVisualNovelView::setImage:()
{
    {
    [ sourceImage autorelease ];
    sourceImage = image;
    [ sourceImage retain ];
    
}

void TYVisualNovelView::directDrawImage:()
{
    {
    /*
    [ this lockFocus ];
    [ image drawInRect:inRect fromRect:fromRect operation:NSCompositeCopy fraction:1.0 ];
    [ this unlockFocus ];
    
    [ [ NSGraphicsContext graphicsContextWithWindow:[ this window ] ] flushGraphics ];
    return ;
    */
    
    directDraw=true;
    directDrawImage = [ image retain ];
    if(isScale){
    RECT_MUL(inRect,scale);
    directInRect = inRect;
    directFromRect = fromRect;
    [ this setNeedsDisplayInRect:directInRect ];
    //[ this display ];
    
}

void TYVisualNovelView::setTarget:()
{
    {
    target = aTarget;
    
}

void TYVisualNovelView::setScaling:()
{
    {
    isScale = (s != 1.0) ? true : false;
    
    scale = s;
}

float TYVisualNovelView::scale()
{
    
}

void TYVisualNovelView::setNeedsDisplayScalingRect:()
{
    {
    if(isScale){
    RECT_MUL(sRect,scale);
    [ super setNeedsDisplayInRect:sRect ];
    
}

void TYVisualNovelView::mouseDown:()
{
    {
    if([ theEvent modifierFlags ] & NSControlKeyMask){
    [ target cancel_action:this ];
    } else {
    [ target select_action ];
    
}

void TYVisualNovelView::rightMouseDown:()
{
    {
    [ target cancel_action:this ];
    
}

void TYVisualNovelView::keyDown:()
{
    {
    [ NSCursor setHiddenUntilMouseMoves:true ];
    [ target performSelector:TYSelectorForKeycode([ theEvent keyCode ]) withObject:nullptr ];
}

void TYVisualNovelView::mouseMoved:()
{
    {
    if(isScale){
    NSPoint point=[ this convertPoint:[ theEvent locationInWindow ] fromView:nullptr ];
    POINT_DIV(point,scale);
    [ target move_mouse:point ];
    } else {
    [ target move_mouse:[ this convertPoint:[ theEvent locationInWindow ] fromView:nullptr ] ];
    
}

void TYVisualNovelView::scrollWheel:()
{
    {
    if([ theEvent deltaY ] > 0.0){
    [ target up_action ];
    } else {
    [ target down_action ];
    
}

bool TYVisualNovelView::acceptsFirstResponder()
{
    {
    return true;
    
    
}

