#ifndef TYSTAGEMANAGER_H
#define TYSTAGEMANAGER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYStageManager : public QObject
{
    Q_OBJECT
public:
    void setController:(void value);
    void enterSystemMode();
    void exitSystemModeResumeStatus:();
    bool isPossibleEnterSystemMode();
    void loadTextWindow:();
    void loadBGImage:();
    void addSprite:();
    void startSelect:();
    void updateStage();
    void updateStageOnlyButton();
    NSImage* visualLayer();
    NSImage* compositeLayer();
    void changeVisualLayer:();
    void flushNovelLayer();
    void startEraseTextWindow:();
    void setNextPerformSelector:(void value);
    NSArray* lookbackQueue();
    void addTextQueue:();
    void textPrint:();
    void drawTextWindow();
    NSRect textWindowRect();
    void drawChar:();
    void drawAttStr:();
    NSPoint drawPoint();
    void setSkipStatus:(void value);
    int skipStatus();
    void setClickWait:(void value);
    void rectOfColumnRange:();
    void ty_bg:();
    void resetGame();
    int status();
    void setStatus:(void value);
    void printing();
    void resumePrinting();
    void automode_select_action();
    void ty_select:();
    void ty_spstr:();
    void ty_textclear:();
    void ty_lookbackflush:();
    void setTextWindow:(void value);
    void makeAttributeDict();
    NSDictionary* textAttDict();
    int textFontWidth();
    int textFontHeight();
    int textPitchx();
    bool isShadow();
    void changeFont:();
    void changeTextSpeed:();
    void setAutoMode:(void value);
    int userTextSpeed();
    void startButtonWait:();
    void changeSelectedButton:();
    void responseButton:();
    void changeSelection:();
    void responseSelection();
    void makeCselImage();
    NSRect rectOfSprite:();
    void setSprite:(void value);
    void setSprite:(void value);
    void changeEffectionImage:();
    void effectFinished();
    void updateSprites:();
    void startWaveSound:();
    void stopWaveSound:();
};

#endif // TYSTAGEMANAGER_H
