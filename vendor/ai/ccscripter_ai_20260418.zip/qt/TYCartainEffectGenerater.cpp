#include "TYCartainEffectGenerater.h"

// Converted from Objective-C

QObject* TYCartainEffectGenerater::initWithBeforeImage:()
{
    {
    TYEffectDefinition effdef;
    
    this = [ super init ];
    
    [ effect getValue:&effdef ];
    switch(effdef.type){
    case TYEffectTopCartain:
    reverse = true;
    break;
    case TYEffectRightCartain:
    reverse = true;
    case TYEffectLeftCartain:
    horizontal = true;
    break;
    default:
    break;
    
    if(horizontal) {
    numberOfColumn = VSCREEN_WIDTH / PIXEL_OF_COLUMN;
    phaseMAX = PIXEL_OF_COLUMN +numberOfColumn -1;
    pointMAX = VSCREEN_WIDTH;
    remainder = VSCREEN_WIDTH % PIXEL_OF_COLUMN;
    } else {
    numberOfColumn = VSCREEN_HEIGHT / PIXEL_OF_COLUMN;
    phaseMAX = PIXEL_OF_COLUMN +numberOfColumn -1;
    pointMAX = VSCREEN_HEIGHT;
    phaseInterval = effdef.time / 1000.0 / phaseMAX;
    time = effdef.time;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    afterImage = [ atImage copyWithZone:[ atImage zone ] ];
    nowImage = [ befImage copyWithZone:[ befImage zone ] ];
    
    startDate = [ [ NSDate alloc ] init ];
    
    return this;
    
    } // override
    
}

void TYCartainEffectGenerater::drawEffect()
{
    {
    int x,y,w,h;
    int phase,movePhase,currentPhase;
    int i,loc,*mp;
    
    // oߎԂtFCYPʂŎ擾
    phase =  (-[ startDate timeIntervalSinceNow ] *1000) / time *phaseMAX;
    if(phase >= phaseMAX){
    [ this changeEffectionImage:afterImage ];
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    return;
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:phaseInterval ];
    
    movePhase = phase -beforePhase;
    // ܂A肦ȂƂ͎vB
    if(movePhase==0){
    return;
    
    if(horizontal){
    w = 1;
    h = VSCREEN_HEIGHT;
    y = 0;
    mp = &x;
    } else {
    w = VSCREEN_WIDTH;
    h = 1;
    x = 0;
    mp = &y;
    
    [ nowImage lockFocus ];
    for(currentPhase=beforePhase+1; currentPhase <= phase; currentPhase++){
    for(i=0,loc=currentPhase -1; i < numberOfColumn; i++,loc--){
    if((loc >= 0)&&(loc < PIXEL_OF_COLUMN)){
    *mp = (reverse) ? pointMAX -PIXEL_OF_COLUMN *i -loc -1 : PIXEL_OF_COLUMN *i +loc;
    [ afterImage compositeToPoint:NSMakePoint(x,y) fromRect:NSMakeRect(x,y,w,h) operation:NSCompositeCopy ];
    // ]肪΂̏
    if(remainder){
    if((loc >= 0)&&(loc < remainder)){
    *mp = (reverse) ? pointMAX -PIXEL_OF_COLUMN *i -loc -1 : PIXEL_OF_COLUMN *i +loc;
    [ afterImage compositeToPoint:NSMakePoint(x,y) fromRect:NSMakeRect(x,y,w,h) operation:NSCompositeCopy ];
    [ nowImage unlockFocus ];
    
    [ this changeEffectionImage:nowImage ];
    
    beforePhase = phase;
    
    return ;
    } // override
    
}

void TYCartainEffectGenerater::dealloc()
{
    {
    [ startDate release ];
    super->dealloc();
    
}

