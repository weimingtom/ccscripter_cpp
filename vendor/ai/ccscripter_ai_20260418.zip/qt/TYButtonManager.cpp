#include "TYButtonManager.h"

// Converted from Objective-C

QObject* TYButtonManager::initWithImage:()
{
    {
    this = [ super init ];
    
    // C[W̕ێ
    sourceImage = srcImage;
    [ sourceImage retain ];
    
    // CX^X̊m
    btnArray = [ [ NSMutableArray alloc ] initWithCapacity:1 ];
    
    drawBuffer = [ [ NSImage alloc ] initWithSize:TYVirtualScreenSize() ];
    
    beforeSelection = TYButtonUnInitialize;
    
    rectMap = [ [ NSMutableData dataWithLength:VSCREEN_WIDTH *VSCREEN_HEIGHT ] retain ];
    
    return this;
    
}

NSImage* TYButtonManager::image()
{
    {
    return sourceImage;
    
}

void TYButtonManager::addButton:()
{
    {
    NSImage *unselImage,*selImage;
    int w,h,sx,sy,i,j;
    NSSize srcSize;
    NSRect rect;
    unsigned char *map,*ptr;
    int index;
    
    w = [ width intValue ];
    h = [ height intValue ];
    sx = [ selx intValue ];
    sy = [ sely intValue ];
    rect = NSMakeRect([ x intValue ],VSCREEN_HEIGHT -[ y intValue ] -h,w,h);
    
    // IԂ̃C[W쐬
    unselImage = [ [ [ NSImage alloc ] initWithSize:NSMakeSize(w,h) ] autorelease ];
    
    // IԂ̃C[W쐬
    selImage = [ [ [ NSImage alloc ] initWithSize:NSMakeSize(w,h) ] autorelease ];
    srcSize = [ sourceImage size ];
    [ selImage lockFocus ];
    [ sourceImage compositeToPoint:NSZeroPoint fromRect:NSMakeRect(sx,srcSize.height -h -sy,w,h) operation:NSCompositeSourceOver ];
    
    [ selImage unlockFocus ];
    
    // {^`̒ǉ
    [ btnArray addObject:[ [ [ TYButton alloc ] initWithID:no image:unselImage selectedImage:selImage rect:rect ] autorelease ] ];
    
    // }EXp̃rbg}bv`
    map = (unsigned char*)[ rectMap mutableBytes ];
    index = [ btnArray count ];
    for(i = 0; i < rect.size.height; i++){
    ptr = map +(int)rect.origin.x +( (int)rect.origin.y +i) *VSCREEN_WIDTH;
    for(j = 0; j < rect.size.width; j++,ptr++){
    *ptr = index;
    
}

NSData* TYButtonManager::rectMap()
{
    {
    return rectMap;
    
}

void TYButtonManager::initialButtonImage()
{
    {
    // {^[hJnÓA{^摜̏
    NSEnumerator *enm;
    id temp;
    
    // ĂȂ΁ASẴ{^`
    if(beforeSelection==TYButtonUnInitialize){
    enm = [ btnArray objectEnumerator ];
    while( (temp = [ enm nextObject ]) != nullptr){
    [ temp drawWithSelect:false ];
    beforeSelection = TYButtonNoSelected;
    return;
    
    
}

int TYButtonManager::selectedButtonID()
{
    {
    if(beforeSelection) {
    return [ [ [ btnArray objectAtIndex:(beforeSelection -1) ] idNo ] intValue ];
    } else {
    return 0;
    
}

int TYButtonManager::incToIndex()
{
    {
    int nowSelection,count;
    
    count = [ btnArray count ];
    
    if(!count){
    return 0;
    
    nowSelection = beforeSelection +1;
    if(nowSelection > count ){
    return 1;
    } else {
    return nowSelection;
    
    
}

int TYButtonManager::decToIndex()
{
    {
    int nowSelection,count;
    
    count = [ btnArray count ];
    
    if(!count){
    return 0;
    
    nowSelection = beforeSelection -1;
    if(nowSelection <= 0){
    return count;
    } else {
    return nowSelection;
    
}

void TYButtonManager::drawWithSelection:()
{
    {
    [ drawBuffer lockFocus ];
    {
    // OIԂ{^IԂŕ`
    if(beforeSelection){
    [ [ btnArray objectAtIndex:(beforeSelection -1) ] drawWithSelect:false ];
    
    // Iꂽ{^IԂŕ`
    if(status){
    [ [ btnArray objectAtIndex:(status -1) ] drawWithSelect:true ];
    [ drawBuffer unlockFocus ];
    
    [ drawBuffer compositeToPoint:NSZeroPoint operation:NSCompositeSourceOver ];
    beforeSelection = status;
    
}

NSString* TYButtonManager::description()
{
    {
    return [ btnArray description ];
    
}

void TYButtonManager::dealloc()
{
    {
    [ sourceImage release ];
    [ btnArray release ];
    [ drawBuffer release ];
    [ rectMap release ];
    
    super->dealloc();
    
    
    @implementation TYButton
}

QObject* TYButtonManager::initWithID:()
{
    {
    this = [ super init ];
    
    idno = [ no retain ];
    unselectedImage = unselImage;
    [ unselectedImage retain ];
    selectedImage = selImage;
    [ selectedImage retain ];
    drawRect = aRect;
    
    return this;
    
}

void TYButtonManager::drawWithSelect:()
{
    {
    NSImage *drawImage;
    
    // gRectNAĂ`
    [ [ NSColor blackColor ] set ];
    NSRectFillUsingOperation(drawRect,NSCompositeClear);
    /*
    [ [ NSColor clearColor ] set ];
    [ NSBezierPath fillRect:drawRect ];
    */
    
    drawImage = (aBool) ? selectedImage : unselectedImage ;
    [ drawImage compositeToPoint:drawRect.origin operation:NSCompositeSourceOver ];
    
}

NSRect* TYButtonManager::boundingRect()
{
    {
    return &drawRect;
    
}

NSNumber* TYButtonManager::idNo()
{
    {
    return idno;
    
}

NSString* TYButtonManager::description()
{
    {
    return [ NSString stringWithFormat:QString::fromUtf8("ID=%@,Rect=%@,unselImage=%@,selectedImage=%@"),
    idno,NSStringFromRect(drawRect),unselectedImage,selectedImage ];
    
}

void TYButtonManager::dealloc()
{
    {
    [ idno release ];
    [ unselectedImage release ];
    [ selectedImage release ];
    
    super->dealloc();
    
}

QObject* TYButtonManager::copyWithZone:()
{
    {
    id tempcopy = [ [ [ this class ] allocWithZone:zone ] init ];
    
    // 󂢃Rs[łȁH
    tempcopy->idno = [ idno retain ];
    tempcopy->unselectedImage = [ unselectedImage retain ];
    tempcopy->selectedImage = [ selectedImage retain ];
    tempcopy->drawRect = drawRect;
    
    return tempcopy;
    
}

bool TYButtonManager::isOverlay()
{
    {
    return false;
    
    
}

