#ifndef TYSCRIPTSTREAM_H
#define TYSCRIPTSTREAM_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYScriptStream : public QObject
{
    Q_OBJECT
public:
    QObject* initWithData:();
    void addNewLine:();
    void addLabel:();
    QObject* objectAtIndex:();
    char* cStringAtIndex:();
    NSDictionary* labelDict();
};

#endif // TYSCRIPTSTREAM_H
