#include "TYArrayVarArgment.h"

// Converted from Objective-C

QObject* TYArrayVarArgment::initWithVarID:()
{
    {
    NSEnumerator *enu;
    id temp;
    
    this = [ super init ];
    
    varID = [ [ NSMutableArray arrayWithCapacity:[ aArray count ]+1 ] retain ];
    
    [ varID addObject:[ aObj intNumber ] ];
    enu = [ aArray objectEnumerator ];
    while(temp = [ enu nextObject ]){
    [ varID addObject:[ temp intNumber ] ];
    
    return this;
    
    // override
}

TYVarType TYArrayVarArgment::varType()
{
    {
    return TYArrayVarType;
    
    //-(TYArgType)argType
    
    
}

