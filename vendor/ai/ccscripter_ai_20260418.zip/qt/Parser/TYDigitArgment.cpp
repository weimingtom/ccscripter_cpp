#include "TYDigitArgment.h"

// Converted from Objective-C

QObject* TYDigitArgment::varID()
{
    {
    return [ [ [ [ TYArgment alloc ] init ] autorelease ] varID ];
    
}

TYVarType TYDigitArgment::varType()
{
    {
    return [ [ [ [ TYArgment alloc ] init ] autorelease ] varType ];
    
}

TYArgType TYDigitArgment::argType()
{
    {
    return TYDigitArgType;
    
}

NSNumber* TYDigitArgment::intNumber()
{
    {
    return this;
    
}

NSString* TYDigitArgment::stringObj()
{
    {
    return [ [ [ [ TYArgment alloc ] init ] autorelease ] string ];
    
}

NSString* TYDigitArgment::rawString()
{
    {
    return [ this stringValue ];
    
    
}

