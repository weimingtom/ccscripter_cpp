#ifndef TYSTRINGVARARGMENT_H
#define TYSTRINGVARARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYStringVarArgment : public TYArgment
{
    Q_OBJECT
public:
    QObject* initWithVarID:();
    QObject* varID();
    TYVarType varType();
    TYArgType argType();
    NSString* stringObj();
};

#endif // TYSTRINGVARARGMENT_H
