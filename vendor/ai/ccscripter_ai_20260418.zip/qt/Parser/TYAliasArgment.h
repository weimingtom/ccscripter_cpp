#ifndef TYALIASARGMENT_H
#define TYALIASARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class NSString : public QWidget
{
    Q_OBJECT
public:
    QObject* varID();
    TYVarType varType();
    TYArgType argType();
    NSNumber* intNumber();
    NSString* stringObj();
    NSString* rawString();
};

#endif // TYALIASARGMENT_H
