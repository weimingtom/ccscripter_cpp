#ifndef TYINTVARARGMENT_H
#define TYINTVARARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYIntVarArgment : public TYArgment
{
    Q_OBJECT
public:
    QObject* initWithVarID:();
    QObject* varID();
    TYVarType varType();
    TYArgType argType();
    NSNumber* intNumber();
};

#endif // TYINTVARARGMENT_H
