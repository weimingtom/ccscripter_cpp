#ifndef TYFCHKSTRINGARGMENT_H
#define TYFCHKSTRINGARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYFchkStringArgment : public QObject
{
    Q_OBJECT
public:
    QObject* initWithFileName:();
    TYArgType argType();
    NSString* stringObj();
};

#endif // TYFCHKSTRINGARGMENT_H
