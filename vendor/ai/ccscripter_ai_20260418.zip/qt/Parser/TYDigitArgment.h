#ifndef TYDIGITARGMENT_H
#define TYDIGITARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class NSNumber : public QWidget
{
    Q_OBJECT
public:
    QObject* varID();
    TYVarType varType();
    TYArgType argType();
    NSNumber* intNumber();
    NSString* stringObj();
    NSString* rawString();
};

#endif // TYDIGITARGMENT_H
