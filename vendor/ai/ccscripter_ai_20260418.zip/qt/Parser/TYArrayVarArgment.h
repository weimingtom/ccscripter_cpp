#ifndef TYARRAYVARARGMENT_H
#define TYARRAYVARARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYArrayVarArgment : public TYIntVarArgment
{
    Q_OBJECT
public:
    QObject* initWithVarID:();
    TYVarType varType();
    TYArgType argType();
};

#endif // TYARRAYVARARGMENT_H
