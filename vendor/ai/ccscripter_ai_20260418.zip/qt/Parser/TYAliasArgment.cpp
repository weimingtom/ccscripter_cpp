#include "TYAliasArgment.h"

// Converted from Objective-C

QObject* TYAliasArgment::varID()
{
    {
    return [ [ [ [ TYArgment alloc ] init ] autorelease ] varID ];
    
}

TYVarType TYAliasArgment::varType()
{
    {
    return [ [ [ [ TYArgment alloc ] init ] autorelease ] varType ];
    
}

TYArgType TYAliasArgment::argType()
{
    {
    return TYAliasArgType;
    
}

NSNumber* TYAliasArgment::intNumber()
{
    {
    return [ [ TYScriptEngine sharedEngine ] intNumberWithAlias:this ];
    
}

NSString* TYAliasArgment::stringObj()
{
    {
    id result;
    result = [ [ TYScriptEngine sharedEngine ] stringValueWithAlias:this ];
    
    if(result){
    return result;
    } else {
    return this;
    
}

NSString* TYAliasArgment::rawString()
{
    {
    return this;
    
    
}

