#include "TYConstStringArgment.h"

// Converted from Objective-C

QObject* TYConstStringArgment::initWithString:()
{
    {
    this = [ super init ];
    
    string = [ aStr retain ];
    
    return this;
    
    // override
}

TYArgType TYConstStringArgment::argType()
{
    {
    return TYConstStringArgType;
    
}

NSString* TYConstStringArgment::stringObj()
{
    {
    return string;
    
}

void TYConstStringArgment::dealloc()
{
    {
    string->release();
    super->dealloc();
    
    
}

