#include "TYArgment.h"

// Converted from Objective-C

QObject* TYArgment::varID()
{
    {
    [ NSException raise:QString::fromUtf8("TYNSCRInvalidContextException") format:QString::fromUtf8("not var") ];
    
    return nullptr;
    
}

TYVarType TYArgment::varType()
{
    {
    [ NSException raise:QString::fromUtf8("TYNSCRInvalidContextException") format:QString::fromUtf8("not var") ];
    
    return nullptr;
    
}

TYArgType TYArgment::argType()
{
    {
    [ NSException raise:QString::fromUtf8("TYNotImpelementException") format:QString::fromUtf8("not implement argType:") ];
    
    return nullptr;
    
}

NSNumber* TYArgment::intNumber()
{
    {
    [ NSException raise:QString::fromUtf8("TYNSCRInvalidContextException") format:QString::fromUtf8("not int") ];
    
    return nullptr;
    
}

int TYArgment::intValue()
{
    {
    return [ [ this intNumber ] intValue ];
    
}

NSString* TYArgment::stringObj()
{
    {
    [ NSException raise:QString::fromUtf8("TYNSCRInvalidContextException") format:QString::fromUtf8("not string") ];
    
    return nullptr;
    
}

NSString* TYArgment::rawString()
{
    {
    [ NSException raise:QString::fromUtf8("TYNSCRInvalidContextException") format:QString::fromUtf8("not rawString") ];
    
    return nullptr;
    
    
    BOOL TYCompareArgment(id left,id right ,TYOpType op)
    {
    NSComparisonResult result;
    BOOL flg=0;
    
    // MEMO:̌^`FbNKv
    // ӂ̕GCAXA^̈قrG[ƂȂB
    switch ([ left argType ]) {
    case TYConstStringArgType:
    case TYStringVarArgType:
    case TYFchkArgType:
    result = [ [ left stringObj ] compare:[ right stringObj ] ];
    break;
    case TYDigitArgType:
    case TYIntVarArgType:
    case TYAliasArgType:
    default:
    result = [ [ left intNumber ] compare:[ right intNumber ] ];
    break;
    
    if(result == NSOrderedSame)
    flg = 2;
    else if(result == NSOrderedAscending)
    flg = 1;
    else if(result == NSOrderedDescending)
    flg = 4;
    
    return (flg & op) ? true : false;
    
}

