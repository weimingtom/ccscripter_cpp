#include "TYStringVarArgment.h"

// Converted from Objective-C

QObject* TYStringVarArgment::initWithVarID:()
{
    {
    this = [ super init ];
    
    varID = [ aObj retain ];
    
    return this;
    
    // override
}

QObject* TYStringVarArgment::varID()
{
    {
    return [ varID intNumber ];
    
}

TYVarType TYStringVarArgment::varType()
{
    {
    return TYStringVarType;
    
}

TYArgType TYStringVarArgment::argType()
{
    {
    return TYStringVarArgType;
    
}

NSString* TYStringVarArgment::stringObj()
{
    {
    return [ [ TYScriptEngine sharedEngine ] stringValueWithVarID:[ this varID ] ];
    
}

void TYStringVarArgment::dealloc()
{
    {
    varID->release();
    super->dealloc();
    
    
}

