#ifndef TYCONSTSTRINGARGMENT_H
#define TYCONSTSTRINGARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYConstStringArgment : public TYArgment
{
    Q_OBJECT
public:
    QObject* initWithString:();
    TYArgType argType();
    NSString* stringObj();
};

#endif // TYCONSTSTRINGARGMENT_H
