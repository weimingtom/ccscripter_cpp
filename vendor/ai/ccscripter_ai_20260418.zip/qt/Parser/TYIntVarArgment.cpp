#include "TYIntVarArgment.h"

// Converted from Objective-C

QObject* TYIntVarArgment::initWithVarID:()
{
    {
    this = [ super init ];
    
    varID = [ [ aObj intNumber ] retain ];
    
    return this;
    
    // override
}

QObject* TYIntVarArgment::varID()
{
    {
    return varID;
    
}

TYVarType TYIntVarArgment::varType()
{
    {
    return TYIntVarType;
    
}

TYArgType TYIntVarArgment::argType()
{
    {
    return TYIntVarArgType;
    
}

NSNumber* TYIntVarArgment::intNumber()
{
    {
    return [ [ TYScriptEngine sharedEngine ] intNumberWithVarID:[ this varID ] ];
    
}

void TYIntVarArgment::dealloc()
{
    {
    varID->release();
    super->dealloc();
    
    
}

