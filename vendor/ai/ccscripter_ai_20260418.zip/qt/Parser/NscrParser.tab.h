#ifndef NSCRPARSER.TAB_H
#define NSCRPARSER.TAB_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // NSCRPARSER.TAB_H
