#include "TYFchkStringArgment.h"

// Converted from Objective-C

QObject* TYFchkStringArgment::initWithFileName:()
{
    {
    this = [ super init ];
    
    fileName = [ fileArg retain ];
    trueValue = [ trueArg retain ];
    falseValue = [ falseArg retain ];
    
    return this;
    
}

TYArgType TYFchkStringArgment::argType()
{
    {
    return TYFchkArgType;
    
}

NSString* TYFchkStringArgment::stringObj()
{
    {
    if([ [ TYScriptEngine sharedEngine ] judgefchk:[ fileName stringObj ] ])
    return [ trueValue stringObj ];
    else
    return [ falseValue stringObj ];
    
}

void TYFchkStringArgment::dealloc()
{
    {
    fileName->release();
    trueValue->release();
    falseValue->release();
    super->dealloc();
    
    
}

