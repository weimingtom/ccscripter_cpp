#ifndef TYARGMENT_H
#define TYARGMENT_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYArgment : public QObject
{
    Q_OBJECT
public:
    QObject* varID();
    TYVarType varType();
    TYArgType argType();
    NSNumber* intNumber();
    NSString* stringObj();
    NSString* rawString();
    int intValue();
};

#endif // TYARGMENT_H
