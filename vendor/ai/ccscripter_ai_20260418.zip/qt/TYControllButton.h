#ifndef TYCONTROLLBUTTON_H
#define TYCONTROLLBUTTON_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYControllButton : public NSControl
{
    Q_OBJECT
public:
    QObject* initWithFrame:();
    TYCellImage* cellImage();
    void changeCell:();
};

#endif // TYCONTROLLBUTTON_H
