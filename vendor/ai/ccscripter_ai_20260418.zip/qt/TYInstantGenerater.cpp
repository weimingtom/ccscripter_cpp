#include "TYInstantGenerater.h"

// Converted from Objective-C

QObject* TYInstantGenerater::initWithBeforeImage:()
{
    {
    this = [ super init ];
    
    nowImage = [ atImage copyWithZone:[ atImage zone ] ];
    /*
    if(nowImage)
    [ nowImage retain ];
    */
    
    [ this performSelector:@selector(drawEffect) withObject:nullptr afterDelay:0 ];
    
    return this;
    
}

void TYInstantGenerater::drawEffect()
{
    {
    [ this changeEffectionImage:nowImage ];
    [ this performSelector:@selector(effectFinished) withObject:nullptr afterDelay:0 ];
    
    
}

