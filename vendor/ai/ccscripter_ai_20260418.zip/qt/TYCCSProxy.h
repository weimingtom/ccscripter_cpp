#ifndef TYCCSPROXY_H
#define TYCCSPROXY_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYCCSProxy : public QObject
{
    Q_OBJECT
public:
};

#endif // TYCCSPROXY_H
