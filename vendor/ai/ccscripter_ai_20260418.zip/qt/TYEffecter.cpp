#include "TYEffecter.h"

// Converted from Objective-C

QObject* TYEffecter::init()
{
    {
    this = [ super init ];
    
    // 0ԂLbV̂݁APԁA-2(windoweffect)uԕ\ŗ\񂵂Ă
    ty_effectDict = [ [ NSMutableDictionary alloc ] initWithObjectsAndKeys:
    [ TYEffectRegister effectRegisterType:TYEffectInstant time:0 path:nullptr ],
    [ NSNumber numberWithInt:-2 ],
    [ TYEffectRegister effectRegisterType:TYEffectCached time:0 path:nullptr ],
    [ NSNumber numberWithInt:0 ],
    [ TYEffectRegister effectRegisterType:TYEffectInstant time:0 path:nullptr ],
    [ NSNumber numberWithInt:1 ],
    nullptr ];
    
    return this;
    
}

void TYEffecter::setBeforeImage:()
{
    {
    if(beforeImage)
    [ beforeImage autorelease ];
    beforeImage = [ aImage copy ];
}

NSImage* TYEffecter::beforeImage()
{
    {
    return beforeImage;
    
}

void TYEffecter::setEffectNo:()
{
    {
    TYEffectRegister *tmp;
    
    // `FbN͂߂ǂ̂ŏȗ
    
    tmp = [ TYEffectRegister effectRegisterType:effectType time:time path:path ];
    
    if(!tmp){
    return ;
    
    [ ty_effectDict setObject:tmp forKey:[ NSNumber numberWithInt:effectNo ] ];
    
    return ;
    
}

bool TYEffecter::startEffect:()
{
    {
    TYEffectRegister *reg;
    int type;
    BOOL endFlg;
    
    reg = [ ty_effectDict objectForKey:[ NSNumber numberWithInt:effectNo ] ];
    
    type = [ reg getType ];
    
    // ItXN[XV݂̂Ȃ疳ďI
    if(type == TYEffectCached){
    return true;
    
    [ afterImage autorelease ];
    afterImage = [ newImage copyWithZone:NULL ];
    //[ afterImage retain ];
    
    
    switch(type){
    case TYEffectInstant:
    [ beforeImage autorelease ];
    beforeImage = afterImage;
    [ beforeImage retain ];
    if(nowImage)
    [ nowImage autorelease ];
    nowImage = beforeImage;
    [ nowImage retain ];
    endFlg = true;
    break;
    default:
    // obt@̈̊m
    if(nowImage)
    [ nowImage autorelease ];
    nowImage = [ beforeImage copyWithZone:[ beforeImage zone ] ];
    // ݎ擾
    if(startDate)
    [ startDate autorelease ];
    startDate =  [ [ NSDate date ] retain ];
    
    // is󋵂̏
    beforeParsentage = 0;
    
    nowEffect = reg;
    endFlg = false;
    
    return endFlg;
    
}

bool TYEffecter::getEffectionImage:()
{
    {
    NSTimeInterval parsentage;
    
    // ڂ̊擾
    parsentage = [ startDate timeIntervalSinceNow ] * -1 / ( [ nowEffect getTime ] / 1000.0 );
    
    if(parsentage >= 1 ){
    *drawImage = afterImage;
    [ beforeImage autorelease ];
    beforeImage = afterImage;
    [ beforeImage retain ];
    
    return true;
    
    [ nowImage lockFocus ];
    
    // GtFNgʂ̍쐬
    switch([ nowEffect getType ]){
    case TYEffectCrossFadeWithPixel:
    default:
    //[ beforeImage compositeToPoint:NSZeroPoint operation:NSCompositeCopy ];
    [ afterImage dissolveToPoint:NSZeroPoint fraction:(parsentage -beforeParsentage)];
    break;
    
    [ nowImage unlockFocus ];
    
    beforeParsentage = parsentage;
    *drawImage = nowImage;
    
    return false;
    
    
}

NSString* TYEffecter::description()
{
    {
    return [ ty_effectDict description ];
    
}

void TYEffecter::dealloc()
{
    {
    [ ty_effectDict release ];
    
    [ super dealloc ];
    
    // ȉAGtFNgf[^IuWFNg̎
    @implementation TYEffectRegister
    +(id)effectRegisterType:(int)type time:(int)time path:(NSString*)path
    {
    return [ [ [ [ this class ] alloc ] initWithType:type time:time path:path ] autorelease ];
    
}

QObject* TYEffecter::initWithType:()
{
    {
    this = [ super init ];
    
    ty_effectType = type;
    ty_time = time;
    if(path)
    ty_path = [ [ NSString stringWithString:path ] retain ];
    
    return this;
    
}

int TYEffecter::getType()
{
    {
    return ty_effectType;
    
}

int TYEffecter::getTime()
{
    {
    return ty_time;
    
}

NSString* TYEffecter::getPath()
{
    {
    return ty_path;
    
}

NSString* TYEffecter::description()
{
    {
    return [ NSString stringWithFormat:QString::fromUtf8("type:%d time:%d path:%@"),ty_effectType,ty_time,ty_path ];
    
}

void TYEffecter::dealloc()
{
    {
    [ ty_path release ];
    [ super dealloc ];
    
    @implementation TYEffectDefinitionValue
    +(id)valueWithEffectDefinition:(TYEffectDefinition)aDefinition
    {
    return [ [ [ [ this class ] alloc ] initWithEffectDefinition:aDefinition ] autorelease ];
    
}

QObject* TYEffecter::initWithEffectDefinition:()
{
    {
    this = [ super init ];
    
    if(aDefinition.path)
    [ aDefinition.path retain ];
    
    value = [ [ NSValue alloc ] initWithBytes:&aDefinition objCType:@encode(TYEffectDefinition) ];
    
    return this;
    
}

void TYEffecter::getValue:()
{
    {
    [ value getValue:buffer ];
    
}

void TYEffecter::dealloc()
{
    {
    TYEffectDefinition aDefinition;
    
    [ value getValue:&aDefinition ];
    
    if(aDefinition.path)
    [ aDefinition.path release];
    
    [ value release ];
    
    super->dealloc();
    
}

