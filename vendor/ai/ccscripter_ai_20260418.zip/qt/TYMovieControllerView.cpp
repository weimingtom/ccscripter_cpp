#include "TYMovieControllerView.h"

// Converted from Objective-C

void TYMovieControllerView::setController:()
{
    {
    controller = aObj;
    
}

bool TYMovieControllerView::acceptsFirstResponder()
{
    {
    return true;
    
}

void TYMovieControllerView::mouseDown:()
{
    {
    [ controller endPlayMovie ];
    
}

void TYMovieControllerView::keyDown:()
{
    {
    [ controller endPlayMovie ];
    
}

void TYMovieControllerView::drawRect:()
{
    {
    
}

