#ifndef TYQTMPCONTROLLER_H
#define TYQTMPCONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYQTMPController : public QObject
{
    Q_OBJECT
public:
};

#endif // TYQTMPCONTROLLER_H
