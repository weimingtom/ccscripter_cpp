#ifndef TYARCHIVER_H
#define TYARCHIVER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYArchiver : public QObject
{
    Q_OBJECT
public:
    QObject* initWithContentsOfFile:();
    NSFileHandle* fileHandleWithPath:();
    NSData* unArchivedFile:();
};

#endif // TYARCHIVER_H
