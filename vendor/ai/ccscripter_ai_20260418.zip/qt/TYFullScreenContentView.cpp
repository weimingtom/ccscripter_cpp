#include "TYFullScreenContentView.h"

// Converted from Objective-C

void TYFullScreenContentView::drawRect:()
{
    {
    [ [ NSColor blackColor ] set ];
    NSRectFill(rect);
    
    
}

