#include "TYAnimationCellImage.h"

// Converted from Objective-C

QObject* TYAnimationCellImage::initWithImages:()
{
    {
    //NSLog2(QString::fromUtf8("animeImage source=\n%@"),aArray);
    this = [ super initWithImages:aArray ];
    
    // Ajw蔻
    mode = [ [ aDict objectForKey:TYAnimationModeInfo ] intValue ];
    
    // ^C}쐬
    if(mode!=TYAnimationNoPlay){
    interval = [ [ aDict objectForKey:TYAnimationIntervalInfo ] retain ];
    
    return this;
    
}

void TYAnimationCellImage::setDelegate:()
{
    {
    delegate = aObject;
    
}

void TYAnimationCellImage::changingCell()
{
    {
    if(!isPlaying)
    return;
    
    switch(mode){
    case TYAnimationLoopingPlayback:
    if([ this currentCell ] +1 >= [ this cells ]){
    [ this changeCell:0 ];
    } else {
    [ this changeCell:[ this currentCell ]+1 ];
    [ this setNextTimer ];
    break;
    case TYAnimationNormalPlayback:
    
    if([ this currentCell ]+1==[ this cells ]){
    [ this stop ];
    } else {
    [ this changeCell:[ this currentCell ]+1 ];
    [ this setNextTimer ];
    break;
    case TYAnimationLoopingBackAndForthPlayback:
    if(!back){
    if([ this currentCell ]+1 == [ this cells ]-1){
    back=true;
    [ this changeCell:[ this currentCell ]+1 ];
    } else {
    if([ this currentCell ]==1){
    back=false;
    [ this changeCell:[ this currentCell ]-1 ];
    [ this setNextTimer ];
    break;
    default:
    break;
    
    /*
    if([ this currentCell ] +1 > [ this cells ]){
    [ this changeCell:0 ];
    } else {
    [ this changeCell:[ this currentCell ]+1 ];
    */
    
    [ this didChangeCell:this ];
    
    // implemantation for delegate
}

void TYAnimationCellImage::didChangeCell:()
{
    {
    if([ delegate respondsToSelector:@selector(didChangeCell:) ]){
    [ delegate didChangeCell:this ];
    
    // animation operate
}

void TYAnimationCellImage::play()
{
    {
    if(mode==TYAnimationNoPlay)
    return;
    
    back=false;
    [ this changeCell:0 ];
    [ this resume ];
}

bool TYAnimationCellImage::isPlaying()
{
    {
    return isPlaying;
    
}

void TYAnimationCellImage::stop()
{
    {
    // ^C}Xgbv
    isPlaying = false;
}

void TYAnimationCellImage::resume()
{
    {
    
    if(mode==TYAnimationNoPlay)
    return;
    isPlaying=true;
    
    [ this setNextTimer ];
    
}

void TYAnimationCellImage::setNextTimer()
{
    {
    int delay;
    
    // ^C}N
    if([ interval respondsToSelector:@selector(intValue) ]){
    delay = [ interval intValue ];
    } else {
    delay = [ [ interval objectAtIndex:[ this currentCell ] ] intValue ];
    
    [ this performSelector:@selector(changingCell) withObject:nullptr afterDelay:delay /1000.0 ];
    
}

bool TYAnimationCellImage::isAnimate()
{
    
}

void TYAnimationCellImage::dealloc()
{
    {
    [ NSObject cancelPreviousPerformRequestsWithTarget:this selector:@selector(changingCell) object:nullptr ];
    interval->release();
    super->dealloc();
    
    
}

