#ifndef TYWAVEBOOSTER_H
#define TYWAVEBOOSTER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // TYWAVEBOOSTER_H
