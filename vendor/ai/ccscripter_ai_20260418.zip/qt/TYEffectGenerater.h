#ifndef TYEFFECTGENERATER_H
#define TYEFFECTGENERATER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYEffectGenerater : public QObject
{
    Q_OBJECT
public:
    QObject* initWithBeforeImage:();
    QObject* initWithImage:();
    void setDelegate:(void value);
    void changeEffectionImage:();
    void effectFinished();
    void drawEffect();
};

#endif // TYEFFECTGENERATER_H
