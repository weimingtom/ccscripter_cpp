#include "TYMarDLGPlugin.h"

// Converted from Objective-C

void TYMarDLGPlugin::execPlugin:()
{
    {
    NSEnumerator *enu;
    int result;
    
    enu = [ [ aStr componentsSeparatedByString:QString::fromUtf8("/") ] objectEnumerator ];
    
    
    if(loaded == false) {
    loaded = [ [ NSBundle bundleForClass:[ this class ] ]
    loadNibFile:QString::fromUtf8("Sis3qDialog")
    externalNameTable:[ NSDictionary dictionaryWithObject:this forKey:QString::fromUtf8("NSOwner") ]
    withZone:NULL ];
    
    [ FirstName setStringValue:[ enu nextObject ] ];
    [ SecondName setStringValue:[ enu nextObject ] ];
    [ KanaName setStringValue:[ enu nextObject ] ];
    [ NickName setStringValue:[ enu nextObject ] ];
    
    result = [ NSApp runModalForWindow:[ FirstName window ] ];
    [ [ FirstName window ] orderOut:this ];
    
    switch(result) {
    case NSOKButton:
    [ ccsProxy setRetunCode:1 string:
    [ [ NSArray arrayWithObjects:[ FirstName stringValue ],
    [ SecondName stringValue ],
    [ KanaName stringValue ],
    [ NickName stringValue ],nullptr ] componentsJoinedByString:QString::fromUtf8("/") ] ];
    break;
    default:
    [ ccsProxy setRetunCode:0 string:aStr ];
    break;
    
}

IBAction TYMarDLGPlugin::dialogOK:()
{
    {
    [ NSApp stopModalWithCode:NSOKButton ];
    
}

IBAction TYMarDLGPlugin::dialogCancel:()
{
    {
    [ NSApp stopModalWithCode:NSCancelButton ];
    
    
    
}

