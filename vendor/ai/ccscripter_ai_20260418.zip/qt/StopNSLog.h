#ifndef STOPNSLOG_H
#define STOPNSLOG_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

#endif // STOPNSLOG_H
