#ifndef TYRESPONDRECTMANAGER_H
#define TYRESPONDRECTMANAGER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYRespondRectManager : public QObject
{
    Q_OBJECT
public:
    QObject* initWithStageManager:();
    void addSelection:();
    void initialButtonImage();
    int selectedButtonID();
    int selectedIndex();
    int incToIndex();
    int decToIndex();
    NSData* rectMap();
    bool changeSelection:();
    void draw();
    void clear();
};

#endif // TYRESPONDRECTMANAGER_H
