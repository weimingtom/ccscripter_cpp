#ifndef TYMAINCONTROLLER_H
#define TYMAINCONTROLLER_H

#include <QObject>
#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QVariant>

class TYMainController : public QObject
{
    Q_OBJECT
public:
    void select_action();
    IBAction cancel_action:();
    void up_action();
    void down_action();
    void move_mouse:();
    void other_action:();
    IBAction changeTextSpeed:();
    IBAction skipToSelection:();
    IBAction skipWhileKidoku:();
    IBAction openAutoMode:();
    IBAction versionDisp:();
    IBAction openSaveDialog:();
    IBAction openLoadDialog:();
    IBAction openAudioPathWindow:();
    IBAction showDebugInfo:();
    IBAction windowMode:();
    IBAction fullScreenMode:();
    IBAction openBGMVolumeDialog:();
    IBAction eraseTextWindowMode:();
    IBAction preference:();
    IBAction resetGame:();
    IBAction forceResume:();
    IBAction openRightclickMenu:();
    IBAction enterLookback:();
    void enterSystemMode();
    void exitSystemModeResumeStatus:();
    void enterYesNoModeTitle:();
    bool isPossibleEnterSystemMode();
    void openSaveLoadDialog:();
    void enterSaveLoadMenu:();
    void closeBGMVolumeDialog:();
    void changeBGMVolume:();
    void setStatus:(void value);
    int status();
    void saveLocalData:();
    bool loadLocalData:();
    int autoclickTimer();
    void setTrap:(void value);
    void endButton();
    void setImage:(void value);
    void setImage:(void value);
    NSImage* image();
    void directDrawImage:();
    NSImage* makeImageFromMainView();
    void setNeedsDisplayMainView:(void value);
    void setAcceptsMouseMovedEvents:(void value);
    void disableContextMenu();
    void playSound:();
    void playWaveSound:();
    void playWaveChannel:();
    void playMovie:();
    void endCheckMovie();
    void endPlayMovie();
    void lockFocusMainView();
    void unlockFocusMainView();
    NSWindow* mainWindow();
    void changeFont:();
    void setAudioPath:(void value);
    int selectedSpeedTag();
    void didChangeKeyWindow:();
    void setEnableAutomode:(void value);
    void ty_playstop:();
    void ty_defvoicevol:();
    void ty_defsevol:();
    void ty_systemcall:();
    void ty_menusetwindow:();
    void ty_dwave:();
};

#endif // TYMAINCONTROLLER_H
