#include "TYFullScreenWindow.h"

// Converted from Objective-C

QObject* TYFullScreenWindow::initWithContentRect()
{
    styleMask : (unsigned int) aStyle
    backing : (NSBackingStoreType) bufferingType
    defer : (BOOL) flag {
    
    /// INITIALIZE BY SUPER CLASS
    this = [ super initWithContentRect : contentRect
    styleMask : NSBorderlessWindowMask
    backing : bufferingType
    defer : false ];
    
    return this;
    
}

bool TYFullScreenWindow::canBecomeMainWindow()
{
    {
    return true;
    
}

bool TYFullScreenWindow::canBecomeKeyWindow()
{
    {
    return true;
    
}

void TYFullScreenWindow::flagsChanged:()
{
    {
    if([ theEvent modifierFlags ] & NSCommandKeyMask){
    [ this setLevelToNormal ];
    } else {
    [ this setLevelToFront ];
    
    [ [ this nextResponder ] flagsChanged:theEvent ];
    
}

void TYFullScreenWindow::setLevelToFront()
{
    {
    [ this setLevel : NSScreenSaverWindowLevel ];
    
}

void TYFullScreenWindow::setLevelToNormal()
{
    {
    [ this setLevel : NSNormalWindowLevel ];
    
    
}

