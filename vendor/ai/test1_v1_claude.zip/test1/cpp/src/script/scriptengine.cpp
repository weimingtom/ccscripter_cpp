/*
 *  scriptengine.cpp - NScripter script execution engine
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "script/scriptengine.h"
#include "core/scriptervalues.h"
#include <QFile>
#include <QTextStream>
#include <QRegExp>
#include <QDebug>

ScriptEngine* tukuyomi::ScriptEngine::s_instance = nullptr;

using namespace tukuyomi;

ScriptEngine::ScriptEngine()
{
    s_instance = this;

    m_multiLineCommands << "select" << "selnum" << "selgosub" << "csel";
}

ScriptEngine& ScriptEngine::instance()
{
    static ScriptEngine inst;
    return inst;
}

bool ScriptEngine::loadScript(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }

    m_scriptLines.clear();
    m_labelDict.clear();

    QTextStream stream(&file);
    int lineNumber = 0;
    while (!stream.atEnd()) {
        QString line = stream.readLine();
        m_scriptLines.append(line);

        ScriptPoint labelPos = parseLabel(line);
        if (labelPos.line != 0 || labelPos.column != 0) {
            m_labelDict[line.trimmed()] = lineNumber;
        }
        lineNumber++;
    }

    return true;
}

ScriptPoint ScriptEngine::parseLabel(const QString& line)
{
    ScriptPoint point = {0, 0};
    QString trimmed = line.trimmed();

    if (trimmed.startsWith("*") && !trimmed.startsWith("*select") && !trimmed.startsWith("*selnum")) {
        int colonIdx = trimmed.indexOf(':');
        if (colonIdx > 0) {
            QString labelName = trimmed.mid(1, colonIdx - 1).trimmed();
            if (!labelName.isEmpty()) {
                point.line = m_runLine;
                point.column = 0;
            }
        }
    }

    return point;
}

void ScriptEngine::setController(QObject* controller, QObject* stageManager)
{
    m_controller = controller;
    m_stageManager = stageManager;
}

void ScriptEngine::runScript()
{
    if (m_scriptLines.isEmpty()) {
        return;
    }

    m_breakRun = false;
    m_runLine = 0;

    while (m_runLine < m_scriptLines.size() && !m_breakRun) {
        QString line = m_scriptLines[m_runLine];
        QList<QString> args;
        int argCount = splitArgNormal(line, args);

        if (argCount > 0 && !args[0].isEmpty()) {
            evaluate(QList<QVariant>::fromList(args));
        }

        m_runLine++;
    }
}

bool ScriptEngine::evaluate(const QList<QVariant>& arguments)
{
    if (arguments.isEmpty()) {
        return true;
    }

    QString cmd = arguments[0].toString().toLower();

    if (cmd == "mov") {
        cmdMov(arguments);
    } else if (cmd == "goto") {
        cmdGoto(arguments);
    } else if (cmd == "nsa") {
        cmdNsa(arguments);
    } else if (cmd == "trap") {
        cmdTrap(arguments);
    }

    return true;
}

int ScriptEngine::splitArgNormal(const QString& line, QList<QString>& cmdArray)
{
    cmdArray.clear();

    QString current;
    bool inQuote = false;
    for (int i = 0; i < line.size(); ++i) {
        QChar c = line[i];
        if (c == '"') {
            inQuote = !inQuote;
            current += c;
        } else if (c.isSpace() && !inQuote) {
            if (!current.isEmpty()) {
                cmdArray.append(current);
                current.clear();
            }
        } else {
            current += c;
        }
    }

    if (!current.isEmpty()) {
        cmdArray.append(current);
    }

    return cmdArray.size();
}

void ScriptEngine::lineEnd()
{
    emit lineEnded();
}

void ScriptEngine::jump(unsigned target)
{
    if (target < static_cast<unsigned>(m_scriptLines.size())) {
        m_runLine = static_cast<int>(target);
    }
}

void ScriptEngine::labelJump(const QString& label)
{
    auto it = m_labelDict.find(label);
    if (it != m_labelDict.end()) {
        m_runLine = it.value();
    }
}

void ScriptEngine::jumpToLoopEnd()
{
    if (!m_loopStack.isEmpty()) {
        ScriptPoint target = m_loopStack.pop().returnPoint;
        m_runLine = static_cast<int>(target.line);
    }
}

void ScriptEngine::moveRunLine(int delta)
{
    m_runLine += delta;
}

void ScriptEngine::incRunColumn()
{
    m_runColumn++;
}

void ScriptEngine::resetRunColumn()
{
    m_runColumn = 0;
}

bool ScriptEngine::isMultiLineCommand(const QString& command) const
{
    return m_multiLineCommands.contains(command);
}

QString ScriptEngine::nextLine()
{
    if (m_runLine < m_scriptLines.size()) {
        return m_scriptLines[m_runLine];
    }
    return QString();
}

QVariant ScriptEngine::getValueOfArgument(const QString& arg)
{
    bool ok;
    int intVal = arg.toInt(&ok);
    if (ok) {
        return intVal;
    }

    if (arg.startsWith("%")) {
        int varId = arg.mid(1).toInt(&ok);
        if (ok) {
            return ScripterValues::instance().getIntValue(varId);
        }
    }

    return arg;
}

QString ScriptEngine::getStringOfArgument(const QString& arg)
{
    if (arg.startsWith("$")) {
        int varId = arg.mid(1).toInt();
        return ScripterValues::instance().getStringValue(varId);
    }
    return arg;
}

int ScriptEngine::getEffectNoOfArguments(const QList<QVariant>& args)
{
    if (args.size() > 1) {
        return args[1].toInt();
    }
    return 0;
}

bool ScriptEngine::judgeCondition(const QString& condition, bool isString)
{
    QRegExp cmpRxp("(.+?)([=!<>]+)(.+)");

    if (cmpRxp.indexIn(condition) != -1) {
        QString left = cmpRxp.cap(1).trimmed();
        QString op = cmpRxp.cap(2);
        QString right = cmpRxp.cap(3).trimmed();

        if (isString) {
            QString leftStr = getStringOfArgument(left);
            QString rightStr = getStringOfArgument(right);
            if (op == "=" || op == "==") {
                return leftStr == rightStr;
            }
        } else {
            int leftVal = getValueOfArgument(left).toInt();
            int rightVal = getValueOfArgument(right).toInt();
            if (op == "=" || op == "==") {
                return leftVal == rightVal;
            } else if (op == "!=") {
                return leftVal != rightVal;
            } else if (op == ">") {
                return leftVal > rightVal;
            } else if (op == ">=") {
                return leftVal >= rightVal;
            } else if (op == "<") {
                return leftVal < rightVal;
            } else if (op == "<=") {
                return leftVal <= rightVal;
            }
        }
    }

    return false;
}

bool ScriptEngine::judgeFchk(const QString& file)
{
    return ResourceServer::instance().fchk(file);
}

bool ScriptEngine::judgeLchk(const QString& label)
{
    return m_labelDict.contains(label);
}

void ScriptEngine::resetGame()
{
    ScripterValues::instance().resetGame();
    m_returnStack.clear();
    m_loopStack.clear();
    m_runLine = 0;
    m_breakRun = false;
}

void ScriptEngine::enableKidoku()
{
    m_isWatchKidoku = true;
}

void ScriptEngine::setWatchKidoku(bool enable)
{
    m_isWatchKidoku = enable;
}

bool ScriptEngine::isModeSVGA() const
{
    return false;
}

int ScriptEngine::scanGlobalValue()
{
    return ScripterValues::instance().getIntValue(0);
}

void ScriptEngine::startPrint(const QString& str)
{
    qDebug() << "Print:" << str;
}

void ScriptEngine::cmdMov(const QList<QVariant>& args)
{
    if (args.size() < 3) return;

    QString dest = args[1].toString();
    QVariant value = args[2];

    if (dest.startsWith("%")) {
        int varId = dest.mid(1).toInt();
        ScripterValues::instance().setIntValue(varId, value.toInt());
    } else if (dest.startsWith("$")) {
        int varId = dest.mid(1).toInt();
        ScripterValues::instance().setStringValue(varId, value.toString());
    }
}

void ScriptEngine::cmdGoto(const QList<QVariant>& args)
{
    if (args.size() < 2) return;
    labelJump(args[1].toString());
}

void ScriptEngine::cmdNsa(const QList<QVariant>& args)
{
    if (args.size() < 2) return;
    QString nsaPath = args[1].toString();
    ResourceServer::instance().addArchiver(nsaPath);
}

void ScriptEngine::cmdTrap(const QList<QVariant>& args)
{
    if (args.size() < 2) return;
    QString trapLabel = args[1].toString();
    if (!trapLabel.isEmpty()) {
        labelJump(trapLabel);
    }
}
