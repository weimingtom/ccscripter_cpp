/*
 *  sararchiver.cpp - SAR archive reader
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "archive/sararchiver.h"
#include <unistd.h>
#include <cstring>

SarArchiver::SarArchiver(const QString& path)
    : Archiver()
    , m_arcPath(path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return;
    }

    // Read file count (big-endian 16-bit)
    QByteArray header = file.read(2);
    if (header.size() < 2) {
        return;
    }
    uint16_t filenum = (static_cast<unsigned char>(header[0]) << 8) |
                        static_cast<unsigned char>(header[1]);

    // Read base offset (big-endian 32-bit)
    QByteArray offsetData = file.read(4);
    if (offsetData.size() < 4) {
        return;
    }
    m_baseOffset = (static_cast<unsigned char>(offsetData[0]) << 24) |
                   (static_cast<unsigned char>(offsetData[1]) << 16) |
                   (static_cast<unsigned char>(offsetData[2]) << 8) |
                   static_cast<unsigned char>(offsetData[3]);

    // Read file index
    for (uint16_t i = 0; i < filenum; ++i) {
        char address[256] = {0};
        int j = 0;

        // Read filename (null-terminated)
        while (true) {
            char c;
            if (file.read(&c, 1) != 1) {
                break;
            }
            if (c == '\\') {
                c = '/';  // Convert backslash to forward slash
            }
            if (c == '\0') {
                address[j] = '\0';
                break;
            }
            address[j++] = c;
        }

        // Read file offset (big-endian 32-bit)
        QByteArray offData = file.read(4);
        if (offData.size() < 4) {
            break;
        }
        uint32_t fileOffset = (static_cast<unsigned char>(offData[0]) << 24) |
                              (static_cast<unsigned char>(offData[1]) << 16) |
                              (static_cast<unsigned char>(offData[2]) << 8) |
                              static_cast<unsigned char>(offData[3]);

        // Read file length (big-endian 32-bit)
        QByteArray lenData = file.read(4);
        if (lenData.size() < 4) {
            break;
        }
        uint32_t fileLength = (static_cast<unsigned char>(lenData[0]) << 24) |
                              (static_cast<unsigned char>(lenData[1]) << 16) |
                              (static_cast<unsigned char>(lenData[2]) << 8) |
                              static_cast<unsigned char>(lenData[3]);

        QString key = QString::fromLatin1(address).toLower();
        m_filesDict[key] = SarArchivedFile(fileOffset, fileLength);
    }
}

QByteArray SarArchiver::unarchiveFile(const QString& address)
{
    QString key = address.toLower();
    auto it = m_filesDict.find(key);
    if (it == m_filesDict.end()) {
        return QByteArray();
    }

    uint32_t fileOffset, fileLength;
    it.value().getFileDataOffset(&fileOffset, &fileLength);

    return readDataOffset(fileOffset, fileLength);
}

bool SarArchiver::fileHandleWithPath(const QString& aPath, int* length, QFile*& outFile)
{
    QString key = aPath.toLower();
    auto it = m_filesDict.find(key);
    if (it == m_filesDict.end()) {
        return false;
    }

    uint32_t fileOffset, fileLength;
    it.value().getFileDataOffset(&fileOffset, &fileLength);

    outFile = new QFile(m_arcPath);
    if (!outFile->open(QIODevice::ReadOnly)) {
        delete outFile;
        outFile = nullptr;
        return false;
    }

    *length = static_cast<int>(fileLength);
    return true;
}

QByteArray SarArchiver::readDataOffset(uint32_t offset, uint32_t length)
{
    QFile file(m_arcPath);
    if (!file.open(QIODevice::ReadOnly)) {
        return QByteArray();
    }

    if (!file.seek(static_cast<qint64>(offset + m_baseOffset))) {
        return QByteArray();
    }

    return file.read(static_cast<qint64>(length));
}
