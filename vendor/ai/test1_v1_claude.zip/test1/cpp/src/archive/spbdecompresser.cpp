/*
 *  spbdecompresser.cpp - SPB image decompression
 *
 *  Copyright (c) 2002 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "archive/spbdecompresser.h"
#include <QByteArray>
#include <cstring>

#define BPP 3

#define BIT_GETN(d, n)                                                       \
    if (remain_bit < n) {                                                     \
        if (src >= data + encode_size) {                                     \
            break;                                                            \
        }                                                                    \
        bits = (bits << 8) | *src++;                                         \
        remain_bit += 8;                                                      \
    }                                                                         \
    remain_bit -= n;                                                          \
    d = (bits >> remain_bit) & ((1 << n) - 1);

#define BIT_GET8(d)                                                           \
    if (remain_bit < 8) {                                                     \
        if (src >= data + encode_size) {                                     \
            break;                                                            \
        }                                                                    \
        bits = (bits << 8) | *src++;                                         \
        remain_bit += 8;                                                      \
    }                                                                         \
    d = (bits >> remain_bit);

#define BIT_SET()                                                             \
    *dest++ = ch;

using namespace tukuyomi;

QImage SpbDecompresser::decompress(const QByteArray& compressedData, size_t /*decodeSize*/)
{
    const unsigned char* data = reinterpret_cast<const unsigned char*>(compressedData.constData());
    const size_t encode_size = compressedData.size();

    unsigned char* src;
    unsigned char* dest;
    unsigned char* tmp_data;
    unsigned char* p;
    unsigned char* q;
    size_t tmp_data_size;
    unsigned int bits;
    int nbit;
    int mask;
    int remain_bit;
    int t;
    unsigned char ch;

    // Read width/height from big-endian bytes
    uint16_t width = (data[0] << 8) | data[1];
    uint16_t height = (data[2] << 8) | data[3];

    if (width <= 0 || height <= 0) {
        return QImage();
    }

    size_t data_size = width * height * BPP;
    QByteArray bmpData(static_cast<int>(data_size), 0);
    unsigned char* data_bmp = reinterpret_cast<unsigned char*>(bmpData.data());

    tmp_data_size = width * height;
    QByteArray tmpData(static_cast<int>(tmp_data_size + 4), 0);
    tmp_data = reinterpret_cast<unsigned char*>(tmpData.data());

    src = const_cast<unsigned char*>(&data[4]);
    dest = tmp_data;
    bits = 0;
    remain_bit = 0;

    for (int rgb = 2; rgb >= 0; rgb--, dest = tmp_data) {
        BIT_GET8(ch);
        BIT_SET();

        while (dest < tmp_data + tmp_data_size) {
            BIT_GETN(nbit, 3);
            if (nbit == 0) {
                BIT_SET();
                BIT_SET();
                BIT_SET();
                BIT_SET();
                continue;
            }

            if (nbit == 7) {
                BIT_GETN(mask, 1);
                mask++;
            } else {
                mask = nbit + 2;
            }

            for (int i = 0; i < 4; i++) {
                if (mask == 8) {
                    BIT_GET8(ch);
                } else {
                    BIT_GETN(t, mask);
                    if (t & 1) {
                        ch += (t >> 1) + 1;
                    } else {
                        ch -= (t >> 1);
                    }
                }
                BIT_SET();
            }
        }

        p = tmp_data;
        q = data_bmp + rgb;
        for (int j = 0; j < height / 2; j++) {
            for (int i = 0; i < width; i++) {
                *q = *p++;
                q += 3;
            }
            q += width * 3;
            for (int i = 0; i < width; i++) {
                q -= 3;
                *q = *p++;
            }
            q += width * 3;
        }
        if (height & 1) {
            for (int i = 0; i < width; i++) {
                *q = *p++;
                q += 3;
            }
        }
    }

    // Create QImage from RGB data (bottom-up format)
    QImage image(width, height, QImage::Format_RGB888);
    for (int y = 0; y < height; y++) {
        const unsigned char* srcRow = data_bmp + (height - 1 - y) * width * BPP;
        unsigned char* destRow = image.scanLine(y);
        std::memcpy(destRow, srcRow, width * BPP);
    }

    return image;
}
