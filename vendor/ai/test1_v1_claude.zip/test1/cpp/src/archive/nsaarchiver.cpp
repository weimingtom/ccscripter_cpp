/*
 *  nsaarchiver.cpp - NSA archive reader
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "archive/nsaarchiver.h"
#include <unistd.h>

NsaFileMode tukuyomi::NsaArchiver::s_mode = NsaFileMode::Normal;

using namespace tukuyomi;

void NsaArchiver::setMode(NsaFileMode mode)
{
    s_mode = mode;
}

NsaArchiver::NsaArchiver(const QString& path)
    : Archiver()
    , m_arcPath(path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return;
    }

    // Skip mode-dependent header bytes
    switch (s_mode) {
    case NsaFileMode::Type2:
        file.read(1);
        break;
    case NsaFileMode::Type3:
        file.read(2);
        break;
    case NsaFileMode::Normal:
    default:
        break;
    }

    // Read file count (big-endian 16-bit)
    QByteArray header = file.read(2);
    if (header.size() < 2) {
        return;
    }
    uint16_t filenum = (static_cast<unsigned char>(header[0]) << 8) |
                        static_cast<unsigned char>(header[1]);

    // Read base offset (big-endian 32-bit)
    QByteArray offsetData = file.read(4);
    if (offsetData.size() < 4) {
        return;
    }
    m_baseOffset = (static_cast<unsigned char>(offsetData[0]) << 24) |
                   (static_cast<unsigned char>(offsetData[1]) << 16) |
                   (static_cast<unsigned char>(offsetData[2]) << 8) |
                   static_cast<unsigned char>(offsetData[3]);

    switch (s_mode) {
    case NsaFileMode::Type2:
        m_baseOffset += 1;
        break;
    case NsaFileMode::Type3:
        m_baseOffset += 2;
        break;
    case NsaFileMode::Normal:
    default:
        break;
    }

    // Read file index
    for (uint16_t i = 0; i < filenum; ++i) {
        char address[256] = {0};
        int j = 0;

        // Read filename (null-terminated)
        while (true) {
            char c;
            if (file.read(&c, 1) != 1) {
                break;
            }
            if (c == '\\') {
                c = '/';  // Convert backslash to forward slash
            }
            if (c == '\0') {
                address[j] = '\0';
                break;
            }
            address[j++] = c;
        }

        // Read compression type
        QByteArray compData = file.read(1);
        if (compData.size() < 1) {
            break;
        }
        uint32_t fileCompress = static_cast<unsigned char>(compData[0]);

        // Read file offset (big-endian 32-bit)
        QByteArray offData = file.read(4);
        if (offData.size() < 4) {
            break;
        }
        uint32_t fileOffset = (static_cast<unsigned char>(offData[0]) << 24) |
                              (static_cast<unsigned char>(offData[1]) << 16) |
                              (static_cast<unsigned char>(offData[2]) << 8) |
                              static_cast<unsigned char>(offData[3]);

        // Read file length (big-endian 32-bit)
        QByteArray lenData = file.read(4);
        if (lenData.size() < 4) {
            break;
        }
        uint32_t fileLength = (static_cast<unsigned char>(lenData[0]) << 24) |
                              (static_cast<unsigned char>(lenData[1]) << 16) |
                              (static_cast<unsigned char>(lenData[2]) << 8) |
                              static_cast<unsigned char>(lenData[3]);

        // Read expanded length (big-endian 32-bit)
        QByteArray exLenData = file.read(4);
        if (exLenData.size() < 4) {
            break;
        }
        uint32_t fileExLength = (static_cast<unsigned char>(exLenData[0]) << 24) |
                                (static_cast<unsigned char>(exLenData[1]) << 16) |
                                (static_cast<unsigned char>(exLenData[2]) << 8) |
                                static_cast<unsigned char>(exLenData[3]);

        QString key = QString::fromLatin1(address).toLower();
        m_filesDict[key] = NsaArchivedFile(fileOffset, fileLength, fileCompress, fileExLength);
    }
}

QByteArray NsaArchiver::unarchiveFile(const QString& address)
{
    QString key = address.toLower();
    auto it = m_filesDict.find(key);
    if (it == m_filesDict.end()) {
        return QByteArray();
    }

    uint32_t fileOffset, fileLength;
    it.value().getFileDataOffset(&fileOffset, &fileLength);

    NsaCompressionType compType = static_cast<NsaCompressionType>(it.value().compressType());

    switch (compType) {
    case NsaCompressionType::None:
        return readDataOffset(fileOffset, fileLength);

    case NsaCompressionType::Spb: {
        QByteArray compressed = readDataOffset(fileOffset, fileLength);
        if (compressed.isEmpty()) {
            return QByteArray();
        }
        // SPB decompression returns QImage - for now return as-is
        // In actual use, caller should handle QImage conversion
        return compressed;
    }

    case NsaCompressionType::Lzss: {
        QFile file(m_arcPath);
        if (!file.open(QIODevice::ReadOnly)) {
            return QByteArray();
        }
        if (!file.seek(static_cast<qint64>(fileOffset + m_baseOffset))) {
            return QByteArray();
        }
        return LZSSDecoder::decompress(file, fileLength, it.value().expandedLength());
    }

    default:
        return QByteArray();
    }
}

bool NsaArchiver::fileHandleWithPath(const QString& aPath, int* length, QFile*& outFile)
{
    Q_UNUSED(aPath);
    Q_UNUSED(length);
    Q_UNUSED(outFile);
    // NSA doesn't support direct file handles due to compression
    return false;
}

QByteArray NsaArchiver::readDataOffset(uint32_t offset, uint32_t length)
{
    QFile file(m_arcPath);
    if (!file.open(QIODevice::ReadOnly)) {
        return QByteArray();
    }

    if (!file.seek(static_cast<qint64>(offset + m_baseOffset))) {
        return QByteArray();
    }

    return file.read(static_cast<qint64>(length));
}
