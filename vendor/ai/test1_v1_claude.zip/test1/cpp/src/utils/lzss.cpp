/*
 *  lzss.cpp - LZSS compression/decompression
 *
 *  Copyright (c) 2002 toveta All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "utils/lzss.h"
#include <QBuffer>

using namespace tukuyomi;

void LZSSDecoder::init(QFile& file, size_t encodeSize)
{
    m_streamSize = static_cast<int>(encodeSize);
    QByteArray data = file.read(encodeSize);
    m_fp = reinterpret_cast<const unsigned char*>(data.constData());
    m_bitMask = 0;
}

int LZSSDecoder::getBit(int n)
{
    int x = 0;
    for (int i = 0; i < n; i++) {
        if (m_bitMask == 0) {
            if (m_streamSize-- <= 0) return EOF;
            m_fp++;
            m_bitMask = 128;
        }
        x <<= 1;
        if (*m_fp & m_bitMask) x |= 1;
        m_bitMask >>= 1;
    }
    return x;
}

QByteArray LZSSDecoder::decompress(QFile& file, size_t encodeSize, size_t originalSize)
{
    init(file, encodeSize);

    QByteArray result(static_cast<int>(originalSize), 0);
    unsigned char* p = reinterpret_cast<unsigned char*>(result.data());

    for (int i = 0; i < N - F; i++) {
        m_buffer[i] = ' ';
    }
    int r = N - F;

    int c;
    while ((c = getBit(1)) != EOF) {
        if (c) {
            if ((c = getBit(8)) == EOF) break;
            *p++ = c;
            m_buffer[r++] = c;
            r &= (N - 1);
        } else {
            int i = getBit(EI);
            if (i == EOF) break;
            int j = getBit(EJ);
            if (j == EOF) break;
            for (int k = 0; k <= j + 1; k++) {
                c = m_buffer[(i + k) & (N - 1)];
                *p++ = c;
                m_buffer[r++] = c;
                r &= (N - 1);
            }
        }
    }

    return result;
}
