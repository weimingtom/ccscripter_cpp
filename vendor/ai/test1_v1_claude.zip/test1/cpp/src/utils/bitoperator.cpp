/*
 *  bitoperator.cpp - Bit-level reading from files
 *
 *  Copyright (c) 2002 toveta All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "utils/bitoperator.h"
#include <unistd.h>

using namespace tukuyomi;

BitOperator::BitOperator(QFile& file, size_t size)
    : m_file(file)
    , m_size(size)
{
    QByteArray byte = m_file.read(1);
    if (!byte.isEmpty()) {
        m_tmp = static_cast<unsigned char>(byte[0]);
    }
    m_mask = 0x100;
}

int BitOperator::get()
{
    m_mask >>= 1;
    if (m_mask == 0x00) {
        m_size--;
        QByteArray byte = m_file.read(1);
        if (!byte.isEmpty()) {
            m_tmp = static_cast<unsigned char>(byte[0]);
        }
        m_mask = 0x80;
    }
    return (m_tmp & m_mask) ? 1 : 0;
}

uint32_t BitOperator::getBits(int n)
{
    uint32_t v = 0;
    for (int i = 0; i < n; i++) {
        v <<= 1;
        if (get()) {
            v |= 1;
        }
    }
    return v;
}

// Core C-style API implementation
CoreBitOperator* tukuyomi::createCoreBitOperator(QFile& file, size_t size)
{
    Q_UNUSED(size);
    CoreBitOperator* op = new CoreBitOperator;
    op->fd = file.handle();

    QByteArray byte = file.read(1);
    if (byte.isEmpty()) {
        delete op;
        return nullptr;
    }
    op->tmp = static_cast<unsigned char>(byte[0]);
    op->mask = 0x100;

    return op;
}

int tukuyomi::getCoreBitOperator(CoreBitOperator* op)
{
    op->mask >>= 1;
    if (op->mask == 0x00) {
        read(op->fd, &op->tmp, 1);
        op->mask = 0x80;
    }
    return (op->tmp & op->mask) ? 1 : 0;
}

uint32_t tukuyomi::getBitsCoreBitOperator(CoreBitOperator* op, int n)
{
    uint32_t v = 0;
    for (int i = 0; i < n; i++) {
        v <<= 1;
        op->mask >>= 1;
        if (op->mask == 0x00) {
            read(op->fd, &op->tmp, 1);
            op->mask = 0x80;
        }
        if (op->tmp & op->mask) {
            v |= 1;
        }
    }
    return v;
}

void tukuyomi::releaseCoreBitOperator(CoreBitOperator* op)
{
    delete op;
}
