/*
 *  musicplayer.cpp - BGM/Music playback using QMediaPlayer
 *
 *  Copyright (c) 2002 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "audio/musicplayer.h"
#include <QFile>
#include <QTemporaryFile>

using namespace tukuyomi;

MusicPlayer::MusicPlayer(QObject* parent)
    : QObject(parent)
{
    m_player = new QMediaPlayer(this);
    connect(m_player, &QMediaPlayer::mediaStatusChanged, this, &MusicPlayer::onMediaStatusChanged);
}

void MusicPlayer::setMedia(const QMediaContent& content)
{
    m_player->setMedia(content);
}

void MusicPlayer::setVolume(int volume)
{
    m_volume = qreal(volume) / 100.0;
    m_player->setVolume(static_cast<int>(m_volume * 100));
}

int MusicPlayer::volume() const
{
    return static_cast<int>(m_player->volume());
}

void MusicPlayer::play()
{
    if (m_loopMode == LoopMode::Looping) {
        m_player->setLoops(QMediaPlayer::Infinite);
    } else {
        m_player->setLoops(1);
    }
    m_player->play();
}

void MusicPlayer::stop()
{
    m_player->stop();
}

bool MusicPlayer::isPlaying() const
{
    return m_player->state() == QMediaPlayer::PlayingState;
}

void MusicPlayer::gotoBeginning()
{
    m_player->setPosition(0);
}

void MusicPlayer::setLoopMode(LoopMode mode)
{
    m_loopMode = mode;
    if (m_player->state() == QMediaPlayer::PlayingState) {
        if (mode == LoopMode::Looping) {
            m_player->setLoops(QMediaPlayer::Infinite);
        }
    }
}

LoopMode MusicPlayer::loopMode() const
{
    return m_loopMode;
}

void MusicPlayer::onMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        if (m_loopMode == LoopMode::Looping) {
            gotoBeginning();
            play();
        } else {
            emit playbackFinished();
        }
    }
}
