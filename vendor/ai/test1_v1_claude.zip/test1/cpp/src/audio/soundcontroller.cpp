/*
 *  soundcontroller.cpp - Sound effect playback
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "audio/soundcontroller.h"
#include "core/resourceserver.h"
#include <QFile>
#include <QTemporaryFile>

using namespace tukuyomi;

SoundController::SoundController(const QString& path, bool loop, int volume)
    : m_soundPath(path)
    , m_isLoop(loop)
{
    QByteArray data = ResourceServer::instance().getData(path);
    if (data.isEmpty()) {
        return;
    }

    // Create temporary file for sound data
    QTemporaryFile* tempFile = new QTemporaryFile;
    if (tempFile->open()) {
        tempFile->write(data);
        tempFile->flush();

        m_effect = new QSoundEffect(this);
        m_effect->setSource(QUrl::fromLocalFile(tempFile->fileName()));
        m_effect->setLoopCount(loop ? QSoundEffect::Infinite : 1);

        // Set volume (0.0 to 1.0)
        qreal vol = qreal(volume) / qreal(TY_SOUND_VOLUME_MAX);
        m_effect->setVolume(vol);

        connect(m_effect, &QSoundEffect::playingChanged, this, &SoundController::onSoundPlayingChanged);
    }
}

SoundController::~SoundController()
{
    stop();
}

void SoundController::play()
{
    if (m_effect) {
        if (m_postingNotification && !m_isLoop) {
            emit soundStarted();
        }
        m_effect->play();
    }
}

void SoundController::stop()
{
    if (m_effect) {
        if (m_postingNotification && !m_isLoop) {
            emit soundFinished();
        }
        m_effect->stop();
    }
}

void SoundController::setPostingNotification(bool enable)
{
    m_postingNotification = enable;
}

bool SoundController::isPlaying() const
{
    return m_effect && m_effect->isPlaying();
}

QString SoundController::soundPathIfNeedPlayingAtLoad() const
{
    if (m_effect && m_effect->isPlaying() && m_isLoop) {
        return m_soundPath;
    }
    return QString();
}

void SoundController::onSoundPlayingChanged()
{
    if (!m_effect->isPlaying() && !m_isLoop && m_postingNotification) {
        emit soundFinished();
    }
}
