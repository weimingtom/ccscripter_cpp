/*
 *  mainwindow.cpp - Main application window
 *
 *  Tukuyomi Visual Novel Engine
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ui/mainwindow.h"
#include "graphics/visualnovelview.h"
#include "script/scriptengine.h"
#include "core/environment.h"
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QMessageBox>
#include <QFileDialog>

using namespace tukuyomi;

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
{
    setWindowTitle("Tukuyomi - Visual Novel Engine");
    setMinimumSize(640, 480);

    m_view = new VisualNovelView(this);
    setCentralWidget(m_view);

    m_scriptEngine = &ScriptEngine::instance();

    setupMenuBar();
    setupConnections();
}

void MainWindow::setupMenuBar()
{
    QMenu* fileMenu = menuBar()->addMenu(tr("&File"));

    m_loadAction = fileMenu->addAction(tr("&Load..."), this, &MainWindow::showLoadDialog);
    m_loadAction->setShortcut(QKeySequence::Open);

    m_saveAction = fileMenu->addAction(tr("&Save..."), this, &MainWindow::showSaveDialog);
    m_saveAction->setShortcut(QKeySequence::Save);

    fileMenu->addSeparator();

    QAction* quitAction = fileMenu->addAction(tr("&Quit"), this, &QWidget::close);
    quitAction->setShortcut(QKeySequence::Quit);

    QMenu* viewMenu = menuBar()->addMenu(tr("&View"));

    m_fullscreenAction = viewMenu->addAction(tr("&Fullscreen"), this, &MainWindow::toggleFullscreen);
    m_fullscreenAction->setShortcut(Qt::Key_F11);

    QMenu* helpMenu = menuBar()->addMenu(tr("&Help"));

    helpMenu->addAction(tr("&About"), this, &MainWindow::about);
}

void MainWindow::setupConnections()
{
    connect(m_scriptEngine, &ScriptEngine::lineEnded, this, &MainWindow::onScriptLineExecuted);
}

void MainWindow::initialize()
{
    Environment::instance();
    ResourceServer::instance();

    m_scriptEngine->resetGame();
}

void MainWindow::loadScript(const QString& path)
{
    if (m_scriptEngine->loadScript(path)) {
        m_scriptEngine->runScript();
    }
}

void MainWindow::setFullscreen(bool enable)
{
    m_fullscreen = enable;
    if (enable) {
        showFullScreen();
    } else {
        showNormal();
    }
}

void MainWindow::toggleFullscreen()
{
    setFullscreen(!m_fullscreen);
}

void MainWindow::showLoadDialog()
{
    QString file = QFileDialog::getOpenFileName(this, tr("Load Game"),
                                                QString(), tr("NScripter Scripts (*.nsa *.sar)"));
    if (!file.isEmpty()) {
        loadScript(file);
    }
}

void MainWindow::showSaveDialog()
{
    QString file = QFileDialog::getSaveFileName(this, tr("Save Game"),
                                                QString(), tr("Save Files (*.sav)"));
    if (!file.isEmpty()) {
        // TODO: Implement save
    }
}

void MainWindow::showPreferences()
{
    // TODO: Implement preferences dialog
}

void MainWindow::about()
{
    QMessageBox::about(this, tr("About Tukuyomi"),
                       tr("Tukuyomi Visual Novel Engine\n\n"
                          "An NScripter-compatible visual novel engine for Qt."));
}

void MainWindow::onScriptLineExecuted()
{
    m_status = ControllerStatus::ScriptRunning;
}

void MainWindow::onButtonClicked(int id)
{
    Q_UNUSED(id);
    m_status = ControllerStatus::ScriptRunning;
}

void MainWindow::onSelectionChanged(int index)
{
    Q_UNUSED(index);
}

void MainWindow::keyPressEvent(QKeyEvent* event)
{
    switch (event->key()) {
    case Qt::Key_Space:
    case Qt::Key_Return:
        m_scriptEngine->setBreakRun(false);
        break;
    case Qt::Key_Escape:
        toggleFullscreen();
        break;
    default:
        QMainWindow::keyPressEvent(event);
    }
}

void MainWindow::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        m_scriptEngine->setBreakRun(false);
    }
    QMainWindow::mousePressEvent(event);
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    Environment::instance().save();
    event->accept();
}
