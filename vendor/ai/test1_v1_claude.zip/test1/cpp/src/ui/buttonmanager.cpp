/*
 *  buttonmanager.cpp - Button management for clickable UI elements
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ui/buttonmanager.h"
#include <QPainter>
#include <cstring>

using namespace tukuyomi;

Button::Button(int id, const QImage& unselected, const QImage& selected, const QRect& rect)
    : m_id(id)
    , m_unselectedImage(unselected)
    , m_selectedImage(selected)
    , m_rect(rect)
{
}

ButtonManager::ButtonManager(const QImage& sourceImage, QObject* parent)
    : QObject(parent)
    , m_sourceImage(sourceImage)
{
    m_rectMap.resize(VSCREEN_WIDTH * VSCREEN_HEIGHT);
    m_rectMap.fill(0);
}

void ButtonManager::addButton(int no, int x, int y, int width, int height,
                             int selX, int selY)
{
    // Create unselected image
    QImage unselImage(width, height, QImage::Format_ARGB32);
    QRect srcRect(selX, VSCREEN_HEIGHT - y - height, width, height);
    QImage selectedRegion = m_sourceImage.copy(srcRect);
    QPainter painter(&unselImage);
    painter.drawImage(0, 0, selectedRegion);
    painter.end();

    // Create selected image (same as source for now - could be different)
    QImage selImage(width, height, QImage::Format_ARGB32);
    QPainter selPainter(&selImage);
    selPainter.drawImage(0, 0, selectedRegion);
    selPainter.end();

    // Convert y coordinate (bottom-left origin to top-left)
    QRect rect(x, VSCREEN_HEIGHT - y - height, width, height);

    Button button(no, unselImage, selImage, rect);
    m_buttons.append(button);

    // Update rect map
    int index = m_buttons.size();
    unsigned char* map = reinterpret_cast<unsigned char*>(m_rectMap.data());

    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            int mapIndex = (VSCREEN_HEIGHT - y - height + i) * VSCREEN_WIDTH + x + j;
            if (mapIndex >= 0 && mapIndex < m_rectMap.size()) {
                map[mapIndex] = index;
            }
        }
    }
}

QImage ButtonManager::rectMap() const
{
    QImage mapImage(VSCREEN_WIDTH, VSCREEN_HEIGHT, QImage::Format_Grayscale8);
    const unsigned char* src = reinterpret_cast<const unsigned char*>(m_rectMap.constData());
    for (int y = 0; y < VSCREEN_HEIGHT; ++y) {
        for (int x = 0; x < VSCREEN_WIDTH; ++x) {
            mapImage.setPixel(x, y, src[y * VSCREEN_WIDTH + x]);
        }
    }
    return mapImage;
}

int ButtonManager::selectedButtonId() const
{
    if (m_beforeSelection > 0 && m_beforeSelection <= m_buttons.size()) {
        return m_buttons[m_beforeSelection - 1].id();
    }
    return 0;
}

int ButtonManager::incToIndex()
{
    int count = m_buttons.size();
    if (count == 0) return 0;

    int nowSelection = m_beforeSelection + 1;
    if (nowSelection > count) {
        return 1;
    }
    return nowSelection;
}

int ButtonManager::decToIndex()
{
    int count = m_buttons.size();
    if (count == 0) return 0;

    int nowSelection = m_beforeSelection - 1;
    if (nowSelection <= 0) {
        return count;
    }
    return nowSelection;
}

void ButtonManager::initialButtonImage()
{
    if (m_beforeSelection == static_cast<int>(ButtonState::Uninitialized)) {
        m_beforeSelection = static_cast<int>(ButtonState::NoSelected);
    }
}

void ButtonManager::drawWithSelection(int status)
{
    m_beforeSelection = status;
    emit buttonSelected(selectedButtonId());
}
