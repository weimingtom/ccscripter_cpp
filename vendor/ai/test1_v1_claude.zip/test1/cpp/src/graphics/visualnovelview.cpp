/*
 *  visualnovelview.cpp - Main visual novel view using QGraphicsView
 *
 *  Tukuyomi Visual Novel Engine
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "graphics/visualnovelview.h"
#include "core/resourceserver.h"
#include <QPainter>

using namespace tukuyomi;

VisualNovelView::VisualNovelView(QWidget* parent)
    : QGraphicsView(parent)
    , m_nativeSize(640, 480)
{
    m_scene = new QGraphicsScene(this);
    setScene(m_scene);

    m_backgroundItem = new QGraphicsPixmapItem();
    m_scene->addItem(m_backgroundItem);

    m_textItem = m_scene->addText(QString());
    m_textItem->setPos(20, 400);

    setSceneRect(0, 0, m_nativeSize.width(), m_nativeSize.height());
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
}

void VisualNovelView::setBackgroundImage(const QString& path)
{
    QImage image = ResourceServer::instance().getImage(path);
    if (!image.isNull()) {
        m_backgroundItem->setPixmap(QPixmap::fromImage(image));
    }
}

void VisualNovelView::setText(const QString& text)
{
    m_textItem->setPlainText(text);
}

void VisualNovelView::clearText()
{
    m_textItem->setPlainText(QString());
}

void VisualNovelView::showSprite(int id, const QString& path, int x, int y)
{
    if (m_sprites.contains(id)) {
        hideSprite(id);
    }

    QImage image = ResourceServer::instance().getImage(path);
    if (!image.isNull()) {
        QGraphicsPixmapItem* item = m_scene->addPixmap(QPixmap::fromImage(image));
        item->setPos(x, y);
        m_sprites[id] = item;
    }
}

void VisualNovelView::hideSprite(int id)
{
    if (m_sprites.contains(id)) {
        m_scene->removeItem(m_sprites[id]);
        delete m_sprites[id];
        m_sprites.remove(id);
    }
}

void VisualNovelView::showCharacter(int position, const QString& path)
{
    if (m_characters.contains(position)) {
        hideCharacter(position);
    }

    QImage image = ResourceServer::instance().getImage(path);
    if (!image.isNull()) {
        QGraphicsPixmapItem* item = m_scene->addPixmap(QPixmap::fromImage(image));
        int x = 0;
        switch (position) {
        case 0: x = 50; break;
        case 1: x = 220; break;
        case 2: x = 390; break;
        }
        item->setPos(x, 150);
        m_characters[position] = item;
    }
}

void VisualNovelView::hideCharacter(int position)
{
    if (m_characters.contains(position)) {
        m_scene->removeItem(m_characters[position]);
        delete m_characters[position];
        m_characters.remove(position);
    }
}

void VisualNovelView::fullscreenMode(bool enable)
{
    if (enable) {
        showFullScreen();
    } else {
        showNormal();
    }
}

void VisualNovelView::resizeEvent(QResizeEvent* event)
{
    QGraphicsView::resizeEvent(event);
    updateSceneRect();
}

void VisualNovelView::updateSceneRect()
{
    if (m_nativeSize.isEmpty()) {
        return;
    }

    QSize viewSize = viewport()->size();
    Qt::AspectRatioMode mode = Qt::KeepAspectRatio;

    QSize scaledSize = m_nativeSize.scaled(viewSize, mode);
    int x = (viewSize.width() - scaledSize.width()) / 2;
    int y = (viewSize.height() - scaledSize.height()) / 2;

    setSceneRect(x, y, scaledSize.width(), scaledSize.height());
}
