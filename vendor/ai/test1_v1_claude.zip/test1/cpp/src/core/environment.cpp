/*
 *  environment.cpp - Application settings/preferences
 *
 *  Copyright (c) 2001-2002 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "core/environment.h"
#include <QCoreApplication>

using namespace tukuyomi;

Environment::Environment()
    : m_settings(QSettings::IniFormat, QSettings::UserScope,
                 QCoreApplication::organizationName(),
                 QCoreApplication::applicationName())
{
}

Environment& Environment::instance()
{
    static Environment inst;
    return inst;
}

QVariant Environment::objectForKey(const QString& key)
{
    return m_settings.value(key);
}

QVariant Environment::defaultObjectForKey(const QString& key)
{
    return m_settings.value(key);
}

void Environment::setObject(const QVariant& obj, const QString& key)
{
    m_settings.setValue(key, obj);
}

void Environment::save()
{
    m_settings.sync();
}

float Environment::floatForKey(const QString& key)
{
    return m_settings.value(key).toFloat();
}

bool Environment::boolForKey(const QString& key)
{
    return m_settings.value(key).toBool();
}

void Environment::reload()
{
    m_settings.sync();
}
