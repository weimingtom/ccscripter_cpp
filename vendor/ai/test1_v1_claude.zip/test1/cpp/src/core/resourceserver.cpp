/*
 *  resourceserver.cpp - Central resource management
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "core/resourceserver.h"
#include "archive/sararchiver.h"
#include "archive/nsaarchiver.h"
#include <QFile>
#include <QDir>
#include <QImage>
#include <QPainter>

using namespace tukuyomi;

ResourceServer::ResourceServer()
    : m_defaultTransMode("alpha")
{
    m_imageCache.setMaxCost(50);
}

ResourceServer& ResourceServer::instance()
{
    static ResourceServer inst;
    return inst;
}

void ResourceServer::addArchiver(const QString& path)
{
    Archiver* archiver = Archiver::create(path);
    if (archiver) {
        m_archivers.append(archiver);
    }
}

QString ResourceServer::convertPath(const QString& path)
{
    QString result = path;
    result.replace('\\', '/');
    return result.toLower();
}

QString ResourceServer::getFilePath(const QString& path)
{
    QString convertedPath = convertPath(path);

    for (Archiver* archiver : m_archivers) {
        QFile* file = nullptr;
        int length = 0;
        if (archiver->fileHandleWithPath(convertedPath, &length, file)) {
            if (file) {
                delete file;
            }
            return convertedPath;
        }
    }

    QFileInfo info(path);
    if (info.exists()) {
        return path;
    }

    return QString();
}

QByteArray ResourceServer::getData(const QString& path)
{
    QString convertedPath = convertPath(path);

    for (Archiver* archiver : m_archivers) {
        QByteArray data = archiver->unarchiveFile(convertedPath);
        if (!data.isEmpty()) {
            return data;
        }
    }

    return QByteArray();
}

QImage ResourceServer::loadImageFromData(const QByteArray& data)
{
    QImage image;
    image.loadFromData(data);
    return image;
}

QImage ResourceServer::getImage(const QString& path, bool transMode, bool animate)
{
    Q_UNUSED(animate);

    QString cacheKey = path;
    if (m_imageCache.contains(cacheKey)) {
        return *m_imageCache[cacheKey];
    }

    QByteArray data = getData(path);
    if (data.isEmpty()) {
        return QImage();
    }

    QImage image = loadImageFromData(data);
    if (image.isNull()) {
        return QImage();
    }

    if (transMode) {
        image = translateImage(image, m_defaultTransMode);
    }

    m_imageCache.insert(cacheKey, new QImage(image));
    return image;
}

QImage ResourceServer::getImageWithTransMode(const QString& path, const QString& transMode)
{
    QByteArray data = getData(path);
    if (data.isEmpty()) {
        return QImage();
    }

    QImage image = loadImageFromData(data);
    if (image.isNull()) {
        return QImage();
    }

    return translateImage(image, transMode);
}

QImage ResourceServer::translateImage(const QImage& bitmap, const QString& transMode)
{
    if (transMode == "alpha" || transMode.isEmpty()) {
        return bitmap;
    }

    QImage result = bitmap.convertToFormat(QImage::Format_ARGB32);

    if (transMode == "monocro") {
        for (int y = 0; y < result.height(); ++y) {
            for (int x = 0; x < result.width(); ++x) {
                QRgb pixel = result.pixel(x, y);
                int gray = qGray(pixel);
                result.setPixel(x, y, qRgba(gray, gray, gray, qAlpha(pixel)));
            }
        }
    } else if (transMode == "nega") {
        for (int y = 0; y < result.height(); ++y) {
            for (int x = 0; x < result.width(); ++x) {
                QRgb pixel = result.pixel(x, y);
                result.setPixel(x, y, qRgba(255 - qRed(pixel),
                                              255 - qGreen(pixel),
                                              255 - qBlue(pixel),
                                              qAlpha(pixel)));
            }
        }
    }

    return result;
}

QByteArray ResourceServer::getSoundData(const QString& path)
{
    return getData(path);
}

void ResourceServer::setDefaultTransMode(const QString& transMode)
{
    m_defaultTransMode = transMode;
}

void ResourceServer::setFileLog(bool enable)
{
    m_fileLogEnabled = enable;
}

bool ResourceServer::fileLog(const QString& path)
{
    if (!m_fileLogEnabled) {
        return false;
    }

    QString convertedPath = convertPath(path);
    if (m_fileLogDict.contains(convertedPath)) {
        return true;
    }

    QFile file(path);
    if (file.exists()) {
        m_fileLogDict[convertedPath] = path;
        return true;
    }

    return false;
}

void ResourceServer::addLog(const QString& filename)
{
    m_fileLogDict[convertPath(filename)] = filename;
}

bool ResourceServer::fchk(const QString& filename)
{
    QString convertedPath = convertPath(filename);
    if (m_fileLogDict.contains(convertedPath)) {
        return true;
    }

    return !getFilePath(filename).isEmpty();
}

bool ResourceServer::saveLog(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }

    for (auto it = m_fileLogDict.constBegin(); it != m_fileLogDict.constEnd(); ++it) {
        QString line = it.key() + "\n";
        file.write(line.toLatin1());
    }

    return true;
}
