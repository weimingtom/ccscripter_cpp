/*
 *  scriptervalues.cpp - NScripter user variable storage
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "core/scriptervalues.h"
#include <QFile>
#include <QDataStream>
#include <cstring>

int tukuyomi::ScripterValues::MIN_GLOBAL_IDNO = 200;

using namespace tukuyomi;

ScripterValues::ScripterValues()
{
    QString blankStr;
    for (int i = 0; i < NUM_OF_VALUES; ++i) {
        m_strValues[i] = blankStr;
    }
}

ScripterValues& ScripterValues::instance()
{
    static ScripterValues inst;
    return inst;
}

void ScripterValues::setMinGlobalNo(int aInt)
{
    MIN_GLOBAL_IDNO = aInt;
}

void ScripterValues::setStringValue(int id, const QString& value)
{
    Q_ASSERT(id >= 0 && id < NUM_OF_VALUES);
    m_strValues[id] = value;
}

void ScripterValues::setIntValue(int id, int value)
{
    Q_ASSERT(id >= 0 && id < NUM_OF_VALUES);
    m_values[id] = value;
    enforceLimit(id);
    emit valueChanged(id);
}

QString ScripterValues::getStringValue(int id) const
{
    Q_ASSERT(id >= 0 && id < NUM_OF_VALUES);
    return m_strValues[id];
}

int ScripterValues::getIntValue(int id) const
{
    Q_ASSERT(id >= 0 && id < NUM_OF_VALUES);
    return m_values[id];
}

void ScripterValues::setArrayLine(int id, const QVector<int>& values, const QList<int>& address)
{
    auto it = m_arrayValues.find(id);
    if (it != m_arrayValues.end()) {
        it.value().setNumbers(values, address);
    }
}

void ScripterValues::defineArrayValue(int id, const QList<int>& limits)
{
    m_arrayValues[id] = ArrayValue(id, limits);
}

void ScripterValues::setIntLimit(int id, int low, int high)
{
    m_limitDict[id] = qMakePair(low, high);
    enforceLimit(id);
}

void ScripterValues::enforceLimit(int id)
{
    auto it = m_limitDict.find(id);
    if (it != m_limitDict.end()) {
        if (m_values[id] < it.value().first) {
            m_values[id] = it.value().first;
        } else if (m_values[id] > it.value().second) {
            m_values[id] = it.value().second;
        }
    }
}

bool ScripterValues::loadGlobalValues(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }

    for (int i = MIN_GLOBAL_IDNO; i < 4096; ++i) {
        unsigned char buf[4];
        if (file.read(reinterpret_cast<char*>(buf), 4) != 4) {
            break;
        }
        m_values[i] = buf[0] | (buf[1] << 8) | (buf[2] << 16) | (buf[3] << 24);

        QByteArray strBuf;
        char c;
        while (file.getChar(&c)) {
            if (c == '\0') {
                break;
            }
            strBuf.append(c);
        }
        if (!strBuf.isEmpty()) {
            m_strValues[i] = QString::fromLatin1(strBuf.constData());
        }
    }

    return true;
}

bool ScripterValues::saveGlobalValues(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }

    for (int i = MIN_GLOBAL_IDNO; i < 4096; ++i) {
        unsigned char buf[4];
        buf[0] = m_values[i] & 0xFF;
        buf[1] = (m_values[i] >> 8) & 0xFF;
        buf[2] = (m_values[i] >> 16) & 0xFF;
        buf[3] = (m_values[i] >> 24) & 0xFF;
        file.write(reinterpret_cast<char*>(buf), 4);

        QByteArray strData = m_strValues[i].toLatin1();
        strData.append('\0');
        file.write(strData);
    }

    return true;
}

void ScripterValues::mergeGlobalValues(ScripterValues* mergeValues)
{
    for (int i = MIN_GLOBAL_IDNO; i < 4096; ++i) {
        if (m_values[i] == 0) {
            m_values[i] = mergeValues->m_values[i];
        }
        if (m_strValues[i].isEmpty()) {
            m_strValues[i] = mergeValues->m_strValues[i];
        }
    }
}

void ScripterValues::resetGame()
{
    for (int i = 0; i < MIN_GLOBAL_IDNO; ++i) {
        m_values[i] = 0;
        m_strValues[i].clear();
    }
}

QByteArray ScripterValues::encode() const
{
    QByteArray data;
    QDataStream stream(&data, QIODevice::WriteOnly);

    for (int i = 0; i < MIN_GLOBAL_IDNO; ++i) {
        stream << m_values[i];
        stream << m_strValues[i];
    }

    return data;
}

void ScripterValues::decode(const QByteArray& data)
{
    QDataStream stream(data);
    for (int i = 0; i < MIN_GLOBAL_IDNO; ++i) {
        stream >> m_values[i];
        stream >> m_strValues[i];
    }
}
