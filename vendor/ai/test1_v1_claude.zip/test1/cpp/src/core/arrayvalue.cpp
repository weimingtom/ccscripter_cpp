/*
 *  arrayvalue.cpp - Array variable storage
 *
 *  Copyright (c) 2003 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "core/arrayvalue.h"

using namespace tukuyomi;

ArrayValue::ArrayValue(int id, const QList<int>& limits)
    : m_id(id)
    , m_limitArray(limits)
    , m_lastLimit(limits.last())
{
    int size = 1;
    for (int limit : limits) {
        size *= limit;
    }
    m_data.resize(size);
}

int ArrayValue::getAddressRecursive(int offset,
                                    const QList<int>::const_iterator& itI,
                                    const QList<int>::const_iterator& itA) const
{
    if (itA == m_limitArray.end()) {
        return 0;
    }

    int tmp1 = *itI;
    int tmp2 = *itA;

    if (offset == 0) {
        return tmp2 + getAddressRecursive(tmp1, std::next(itI), std::next(itA));
    } else {
        return tmp2 * offset + getAddressRecursive(offset * tmp1, std::next(itI), std::next(itA));
    }
}

int ArrayValue::calculateAddress(const QList<int>& address) const
{
    if (address.isEmpty()) {
        return 0;
    }

    auto itI = m_limitArray.rbegin();
    auto itA = address.rbegin();

    return getAddressRecursive(0, itI, itA);
}

void ArrayValue::setNum(int value, const QList<int>& address)
{
    Q_ASSERT(m_limitArray.size() == address.size());
    int addr = calculateAddress(address);
    m_data[addr] = value;
}

void ArrayValue::setNumbers(const QVector<int>& values, const QList<int>& address)
{
    Q_ASSERT(m_limitArray.size() == address.size() + 1);
    Q_ASSERT(m_lastLimit == values.size());

    auto itI = m_limitArray.rbegin();
    auto itA = address.rbegin();
    int addr = getAddressRecursive(*itI, std::next(itI), itA);

    for (int i = 0; i < values.size(); ++i) {
        m_data[addr + i] = values[i];
    }
}

int ArrayValue::getNumOfAddress(const QList<int>& address) const
{
    Q_ASSERT(m_limitArray.size() == address.size());
    int addr = calculateAddress(address);
    return m_data[addr];
}
