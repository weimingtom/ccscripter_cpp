/*
 *  mainwindow.h - Main application window
 *
 *  Tukuyomi Visual Novel Engine
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_MAINWINDOW_H
#define TUKUYOMI_MAINWINDOW_H

#include <QMainWindow>
#include <QMenuBar>
#include <QAction>
#include <QMenu>
#include <QTimer>

namespace tukuyomi {

class VisualNovelView;
class ScriptEngine;

enum class ControllerStatus {
    ScriptRunning = 1,
    ClickWait = 2,
    TimeWait = 3,
    Select = 4,
    ButtonWait = 5,
    Printing = 6
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override = default;

    void initialize();
    void loadScript(const QString& path);
    void setFullscreen(bool enable);

public slots:
    void onScriptLineExecuted();
    void onButtonClicked(int id);
    void onSelectionChanged(int index);

protected:
    void keyPressEvent(QKeyEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void closeEvent(QCloseEvent* event) override;

private slots:
    void toggleFullscreen();
    void showLoadDialog();
    void showSaveDialog();
    void showPreferences();
    void about();

private:
    void setupMenuBar();
    void setupConnections();

    VisualNovelView* m_view = nullptr;
    ScriptEngine* m_scriptEngine = nullptr;
    ControllerStatus m_status = ControllerStatus::ScriptRunning;
    bool m_fullscreen = false;

    QAction* m_fullscreenAction = nullptr;
    QAction* m_loadAction = nullptr;
    QAction* m_saveAction = nullptr;
};

} // namespace tukuyomi

#endif // TUKUYOMI_MAINWINDOW_H
