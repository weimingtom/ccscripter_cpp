/*
 *  buttonmanager.h - Button management for clickable UI elements
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_BUTTONMANAGER_H
#define TUKUYOMI_BUTTONMANAGER_H

#include <QObject>
#include <QImage>
#include <QRect>
#include <QMap>
#include <QList>

namespace tukuyomi {

constexpr int VSCREEN_WIDTH = 800;
constexpr int VSCREEN_HEIGHT = 600;

enum class ButtonState {
    Uninitialized = -1,
    NoSelected = 0
};

class Button {
public:
    Button(int id, const QImage& unselected, const QImage& selected, const QRect& rect);

    int id() const { return m_id; }
    QRect rect() const { return m_rect; }
    const QImage& unselectedImage() const { return m_unselectedImage; }
    const QImage& selectedImage() const { return m_selectedImage; }

private:
    int m_id;
    QImage m_unselectedImage;
    QImage m_selectedImage;
    QRect m_rect;
};

class ButtonManager : public QObject {
    Q_OBJECT
public:
    explicit ButtonManager(const QImage& sourceImage, QObject* parent = nullptr);
    ~ButtonManager() override = default;

    void addButton(int no, int x, int y, int width, int height,
                   int selX, int selY);

    QImage rectMap() const;
    int selectedButtonId() const;

    int incToIndex();
    int decToIndex();

    void initialButtonImage();
    void drawWithSelection(int status);

    const QList<Button>& buttons() const { return m_buttons; }

signals:
    void buttonSelected(int id);

private:
    QImage m_sourceImage;
    QList<Button> m_buttons;
    int m_beforeSelection = static_cast<int>(ButtonState::Uninitialized);
    QByteArray m_rectMap;
};

} // namespace tukuyomi

#endif // TUKUYOMI_BUTTONMANAGER_H
