/*
 *  bitoperator.h - Bit-level reading from files
 *
 *  Copyright (c) 2002 toveta All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_BITOPERATOR_H
#define TUKUYOMI_BITOPERATOR_H

#include <QFile>
#include <cstdint>

namespace tukuyomi {

class BitOperator {
public:
    BitOperator(QFile& file, size_t size);

    int get();
    uint32_t getBits(int n);

private:
    QFile& m_file;
    size_t m_size;
    uint32_t m_mask = 0x100;
    unsigned char m_tmp = 0;
};

struct CoreBitOperator {
    int fd = -1;
    uint32_t mask = 0x100;
    unsigned char tmp = 0;
};

CoreBitOperator* createCoreBitOperator(QFile& file, size_t size);
int getCoreBitOperator(CoreBitOperator* op);
uint32_t getBitsCoreBitOperator(CoreBitOperator* op, int n);
void releaseCoreBitOperator(CoreBitOperator* op);

} // namespace tukuyomi

#endif // TUKUYOMI_BITOPERATOR_H
