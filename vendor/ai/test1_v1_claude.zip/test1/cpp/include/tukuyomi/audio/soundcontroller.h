/*
 *  soundcontroller.h - Sound effect playback
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_SOUNDCONTROLLER_H
#define TUKUYOMI_SOUNDCONTROLLER_H

#include <QObject>
#include <QString>
#include <QSoundEffect>
#include <QVariantMap>

namespace tukuyomi {

constexpr int TY_SOUND_VOLUME_MAX = 256;

class SoundController : public QObject {
    Q_OBJECT
public:
    static SoundController& instance();

    explicit SoundController(const QString& path, bool loop, int volume = TY_SOUND_VOLUME_MAX);
    ~SoundController() override;

    void play();
    void stop();
    void setPostingNotification(bool enable);
    bool isPlaying() const;

    QString soundPathIfNeedPlayingAtLoad() const;

signals:
    void soundStarted();
    void soundFinished();

private slots:
    void onSoundPlayingChanged();

private:
    QSoundEffect* m_effect = nullptr;
    QString m_soundPath;
    bool m_isLoop = false;
    bool m_postingNotification = false;
    bool m_ownSoundEffect = true;
};

} // namespace tukuyomi

#endif // TUKUYOMI_SOUNDCONTROLLER_H
