/*
 *  nsaarchiver.h - NSA archive reader
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_NSAARCHIVER_H
#define TUKUYOMI_NSAARCHIVER_H

#include "sararchiver.h"
#include "nsaarchivedfile.h"
#include "lzss.h"
#include "spbdecompresser.h"
#include <QMap>
#include <QString>
#include <QFile>

namespace tukuyomi {

enum class NsaFileMode {
    Normal,
    Type2,
    Type3
};

class NsaArchiver : public Archiver {
    Q_OBJECT
public:
    static void setMode(NsaFileMode mode);

    explicit NsaArchiver(const QString& path);
    ~NsaArchiver() override = default;

    QByteArray unarchiveFile(const QString& address) override;
    bool fileHandleWithPath(const QString& aPath, int* length, QFile*& outFile) override;

private:
    QByteArray readDataOffset(uint32_t offset, uint32_t length);

    QString m_arcPath;
    QMap<QString, NsaArchivedFile> m_filesDict;
    uint32_t m_baseOffset = 0;

    static NsaFileMode s_mode;
};

} // namespace tukuyomi

#endif // TUKUYOMI_NSAARCHIVER_H
