/*
 *  nsaarchivedfile.h - NSA archive file entry
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_NSAARCHIVEFILE_H
#define TUKUYOMI_NSAARCHIVEFILE_H

#include "sararchivedfile.h"

namespace tukuyomi {

enum class NsaCompressionType {
    None = 0,
    Spb = 1,
    Lzss = 2
};

class NsaArchivedFile : public SarArchivedFile {
public:
    NsaArchivedFile(uint32_t offset, uint32_t length,
                     uint32_t compressType, uint32_t expandedLength);

    uint32_t compressType() const { return m_compressType; }
    uint32_t expandedLength() const { return m_expandedLength; }

private:
    uint32_t m_compressType;
    uint32_t m_expandedLength;
};

} // namespace tukuyomi

#endif // TUKUYOMI_NSAARCHIVEFILE_H
