/*
 *  archiver.h - Base class for SAR/NSA archive handling
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_ARCHIVER_H
#define TUKUYOMI_ARCHIVER_H

#include <QObject>
#include <QString>
#include <QFile>
#include <QByteArray>

namespace tukuyomi {

class Archiver : public QObject {
    Q_OBJECT
public:
    static Archiver* create(const QString& path);

    virtual ~Archiver() = default;

    virtual QByteArray unarchiveFile(const QString& address) = 0;
    virtual bool fileHandleWithPath(const QString& aPath, int* length, QFile*& outFile) = 0;

protected:
    Archiver(QObject* parent = nullptr) : QObject(parent) {}
};

} // namespace tukuyomi

#endif // TUKUYOMI_ARCHIVER_H
