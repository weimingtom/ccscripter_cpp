/*
 *  visualnovelview.h - Main visual novel view using QGraphicsView
 *
 *  Tukuyomi Visual Novel Engine
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_VISUALNOVELVIEW_H
#define TUKUYOMI_VISUALNOVELVIEW_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QGraphicsTextItem>
#include <QTimer>

namespace tukuyomi {

class VisualNovelView : public QGraphicsView {
    Q_OBJECT
public:
    explicit VisualNovelView(QWidget* parent = nullptr);
    ~VisualNovelView() override = default;

    void setBackgroundImage(const QString& path);
    void setText(const QString& text);
    void clearText();

    void showSprite(int id, const QString& path, int x, int y);
    void hideSprite(int id);

    void showCharacter(int position, const QString& path);
    void hideCharacter(int position);

public slots:
    void fullscreenMode(bool enable);

protected:
    void resizeEvent(QResizeEvent* event) override;

private:
    void updateSceneRect();

    QGraphicsScene* m_scene = nullptr;
    QGraphicsPixmapItem* m_backgroundItem = nullptr;
    QGraphicsTextItem* m_textItem = nullptr;
    QMap<int, QGraphicsPixmapItem*> m_sprites;
    QMap<int, QGraphicsPixmapItem*> m_characters;

    QSize m_nativeSize;
};

} // namespace tukuyomi

#endif // TUKUYOMI_VISUALNOVELVIEW_H
