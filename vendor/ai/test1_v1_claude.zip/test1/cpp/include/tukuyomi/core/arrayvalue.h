/*
 *  arrayvalue.h - Array variable storage
 *
 *  Copyright (c) 2003 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_ARRAYVALUE_H
#define TUKUYOMI_ARRAYVALUE_H

#include <QVector>
#include <QList>
#include <QVariant>

namespace tukuyomi {

class ArrayValue {
public:
    ArrayValue(int id, const QList<int>& limits);

    void setNum(int value, const QList<int>& address);
    void setNumbers(const QVector<int>& values, const QList<int>& address);
    int getNumOfAddress(const QList<int>& address) const;

    int id() const { return m_id; }

private:
    int calculateAddress(const QList<int>& address) const;
    int getAddressRecursive(int offset, const QList<int>::const_iterator& itI,
                           const QList<int>::const_iterator& itA) const;

    int m_id;
    QList<int> m_limitArray;
    QVector<int> m_data;
    int m_lastLimit;
};

} // namespace tukuyomi

#endif // TUKUYOMI_ARRAYVALUE_H
