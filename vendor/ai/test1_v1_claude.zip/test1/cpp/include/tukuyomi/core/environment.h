/*
 *  environment.h - Application settings/preferences
 *
 *  Copyright (c) 2001-2002 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_ENVIRONMENT_H
#define TUKUYOMI_ENVIRONMENT_H

#include <QObject>
#include <QVariant>
#include <QSettings>

namespace tukuyomi {

class Environment : public QObject {
    Q_OBJECT
public:
    static Environment& instance();

    QVariant objectForKey(const QString& key);
    QVariant defaultObjectForKey(const QString& key);
    void setObject(const QVariant& obj, const QString& key);
    void save();

    float floatForKey(const QString& key);
    bool boolForKey(const QString& key);

    void reload();

private:
    Environment();
    ~Environment() override = default;

    QSettings m_settings;
};

// Environment keys
constexpr char TYFontNameEnviroment[] = "FontName";
constexpr char TYAudioFilePathEnviroment[] = "AudioFilePath";
constexpr char TYWindowPointXEnviroment[] = "WindowPointX";
constexpr char TYWindowPointYEnviroment[] = "WindowPointY";
constexpr char TYBGMVolumeEnviroment[] = "BGMVolume";
constexpr char TYVoiceVolumeEnviroment[] = "VoiceVolume";
constexpr char TYSEVolumeEnviroment[] = "SEVolume";
constexpr char TYScaleInFullScreenModeEnviroment[] = "ScaleInFullScreenMode";
constexpr char TYEnableBoldFontEnviroment[] = "EnableBoldFont";
constexpr char TYFullScreenModeEnviroment[] = "FullScreenMode";
constexpr char TYWaveExtraNameEnviroment[] = "WaveExtraName";
constexpr char TYDisableSelectScriptEnviroment[] = "DisableSelectScript";
constexpr char TYLookbackBufferPageEnviroment[] = "LookbackBufferPage";
constexpr char TYLookbackVoiceReplayEnviroment[] = "LookbackVoiceReplay";
constexpr char TYDisplayResizeAtFullScreenEnviroment[] = "DisplayResizeAtFullScreen";
constexpr char TYAutomodeWaitTypeEnviroment[] = "AutomodeWaitType";
constexpr char TYAutomodeWaitTimeEnviroment[] = "AutomodeWaitTime";
constexpr char TYKidokumodeEnviroment[] = "Kidokumode";
constexpr char TYEnablePlayMovieEnviroment[] = "EnablePlayMovie";
constexpr char TYHideOtherFullScreenEnviroment[] = "HideOtherFullScreen";
constexpr char TYLastSelectedFolderPref[] = "LastSelectedFolder";

} // namespace tukuyomi

#endif // TUKUYOMI_ENVIRONMENT_H
