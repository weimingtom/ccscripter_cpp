/*
 *  resourceserver.h - Central resource management
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_RESOURCESERVER_H
#define TUKUYOMI_RESOURCESERVER_H

#include "archive/archiver.h"
#include <QObject>
#include <QString>
#include <QImage>
#include <QByteArray>
#include <QMap>
#include <QList>
#include <QCache>

namespace tukuyomi {

class ResourceServer : public QObject {
    Q_OBJECT
public:
    static ResourceServer& instance();

    void addArchiver(const QString& path);

    QString getFilePath(const QString& path);
    QByteArray getData(const QString& path);
    QImage getImage(const QString& path, bool transMode = true, bool animate = false);
    QImage getImageWithTransMode(const QString& path, const QString& transMode);
    QByteArray getSoundData(const QString& path);

    void setDefaultTransMode(const QString& transMode);
    void setFileLog(bool enable);
    bool fileLog(const QString& path);
    void addLog(const QString& filename);
    bool fchk(const QString& filename);
    bool saveLog(const QString& path);

    static constexpr const char* FILELOG_FILENAME = "NScrflog.dat";
    static constexpr const char* WIN_PATH_DELIMITER = "\\";

signals:
    void imageLoaded(const QString& path);
    void dataLoaded(const QString& path);

private:
    ResourceServer();
    ~ResourceServer() override;

    QString convertPath(const QString& path);
    QImage translateImage(const QImage& bitmap, const QString& transMode);
    QImage loadImageFromData(const QByteArray& data);

    QList<Archiver*> m_archivers;
    QString m_defaultTransMode;
    bool m_fileLogEnabled = false;
    QMap<QString, QString> m_fileLogDict;
    QCache<QString, QImage> m_imageCache;
};

} // namespace tukuyomi

#endif // TUKUYOMI_RESOURCESERVER_H
