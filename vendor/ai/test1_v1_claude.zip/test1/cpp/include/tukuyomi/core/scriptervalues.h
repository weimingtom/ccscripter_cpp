/*
 *  scriptervalues.h - NScripter user variable storage
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_SCRIPTERVALUES_H
#define TUKUYOMI_SCRIPTERVALUES_H

#include "arrayvalue.h"
#include <QMap>
#include <QString>
#include <QObject>
#include <QByteArray>

namespace tukuyomi {

constexpr int NUM_OF_VALUES = 10000;

class ScripterValues : public QObject {
    Q_OBJECT
public:
    static ScripterValues& instance();

    void setMinGlobalNo(int aInt);

    void setStringValue(int id, const QString& value);
    void setIntValue(int id, int value);
    QString getStringValue(int id) const;
    int getIntValue(int id) const;

    void setArrayLine(int id, const QVector<int>& values, const QList<int>& address);
    void defineArrayValue(int id, const QList<int>& limits);

    void setIntLimit(int id, int low, int high);

    bool loadGlobalValues(const QString& path);
    bool saveGlobalValues(const QString& path);
    void mergeGlobalValues(ScripterValues* mergeValues);
    void resetGame();

    QByteArray encode() const;
    void decode(const QByteArray& data);

signals:
    void valueChanged(int id);

private:
    ScripterValues();
    ~ScripterValues() override;

    static int MIN_GLOBAL_IDNO;

    int m_values[NUM_OF_VALUES];
    QString m_strValues[NUM_OF_VALUES];
    QMap<int, ArrayValue> m_arrayValues;
    QMap<int, QPair<int, int>> m_limitDict;

    void enforceLimit(int id);
};

} // namespace tukuyomi

#endif // TUKUYOMI_SCRIPTERVALUES_H
