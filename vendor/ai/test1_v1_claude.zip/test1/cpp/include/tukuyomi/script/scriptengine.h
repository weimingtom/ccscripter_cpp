/*
 *  scriptengine.h - NScripter script execution engine
 *
 *  Copyright (c) 2001 toveta. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef TUKUYOMI_SCRIPTENGINE_H
#define TUKUYOMI_SCRIPTENGINE_H

#include "scriptervalues.h"
#include <QObject>
#include <QString>
#include <QMap>
#include <QStack>
#include <QList>
#include <QVariant>

class QTextCodec;

namespace tukuyomi {

struct ScriptPoint {
    unsigned line;
    unsigned column;
};

struct LoopStackItem {
    int variableId;
    int currentValue;
    int limitValue;
    int stepValue;
    ScriptPoint returnPoint;
};

class ScriptEngine : public QObject {
    Q_OBJECT
public:
    static ScriptEngine& instance();

    bool loadScript(const QString& path);
    void setController(QObject* controller, QObject* stageManager);

    void runScript();
    bool evaluate(const QList<QVariant>& arguments);
    bool isBreakRun() const { return m_breakRun; }
    void setBreakRun(bool flag) { m_breakRun = flag; }

    void lineEnd();
    void jump(unsigned target);
    void labelJump(const QString& label);
    void jumpToLoopEnd();

    int runLine() const { return m_runLine; }
    void moveRunLine(int delta);
    void incRunColumn();
    void resetRunColumn();

    bool isMultiLineCommand(const QString& command) const;
    QString nextLine();

    QVariant getValueOfArgument(const QString& arg);
    QString getStringOfArgument(const QString& arg);
    int getEffectNoOfArguments(const QList<QVariant>& args);

    bool judgeCondition(const QString& condition, bool isString);
    bool judgeFchk(const QString& file);
    bool judgeLchk(const QString& label);

    void resetGame();
    void enableKidoku();
    void setWatchKidoku(bool enable);

    bool isModeSVGA() const;
    int scanGlobalValue();

    void startPrint(const QString& str);

signals:
    void lineEnded();
    void scriptError(const QString& error);
    void labelFound(const QString& label, int line);

public slots:
    // NScripter command handlers
    void cmdMov(const QList<QVariant>& args);
    void cmdGoto(const QList<QVariant>& args);
    void cmdNsa(const QList<QVariant>& args);
    void cmdTrap(const QList<QVariant>& args);

private:
    ScriptEngine();
    ~ScriptEngine() override;

    int splitArgNormal(const QString& line, QList<QString>& cmdArray);
    ScriptPoint parseLabel(const QString& line);

    static ScriptEngine* s_instance;

    QObject* m_controller = nullptr;
    QObject* m_stageManager = nullptr;

    bool m_breakRun = false;
    QList<QString> m_scriptLines;
    QByteArray m_currentLineBuffer;
    int m_runLine = 0;
    unsigned m_runColumn = 0;

    ScriptPoint m_savePoint;
    QStack<ScriptPoint> m_returnStack;
    QStack<LoopStackItem> m_loopStack;

    QMap<QString, QString> m_numAliases;
    QMap<QString, QString> m_strAliases;
    bool m_globalOn = false;
    QString m_nsaDir;

    QMap<QString, int> m_labelDict;
    QByteArray m_kidokuData;
    bool m_isWatchKidoku = false;

    ScriptPoint m_textgosubPoint;
    int m_textgosubPointIndex = 0;

    QSet<QString> m_multiLineCommands;
    QTextCodec* m_codec = nullptr;
};

} // namespace tukuyomi

#endif // TUKUYOMI_SCRIPTENGINE_H
