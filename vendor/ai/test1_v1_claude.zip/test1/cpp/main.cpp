/*
 *  main.cpp - Tukuyomi Visual Novel Engine
 *
 *  Copyright (c) 2001-2024 Tukuyomi Project
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <QApplication>
#include <QCommandLineParser>
#include <QDebug>
#include <QDir>

#include "ui/mainwindow.h"
#include "core/environment.h"
#include "core/resourceserver.h"
#include "script/scriptengine.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QApplication::setApplicationName("Tukuyomi");
    QApplication::setApplicationVersion("1.0.0");
    QApplication::setOrganizationName("Tukuyomi Project");

    QCommandLineParser parser;
    parser.setApplicationDescription("Tukuyomi Visual Novel Engine");
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption scriptOption("s", "Script file to load", "script");
    parser.addOption(scriptOption);

    QCommandLineOption fullscreenOption("f", "Start in fullscreen mode");
    parser.addOption(fullscreenOption);

    parser.process(app);

    tukuyomi::MainWindow mainWindow;
    mainWindow.initialize();

    if (parser.isSet(fullscreenOption)) {
        mainWindow.setFullscreen(true);
    }

    if (parser.isSet(scriptOption)) {
        QString scriptPath = parser.value(scriptOption);
        mainWindow.loadScript(scriptPath);
    }

    mainWindow.show();

    return app.exec();
}
