//
//  TYScriptEngine.m
//  Tukuyomi
//
//  Created by toveta on Thu Jun 07 2001.
//  Copyright (c) 2001 toveta. All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY toveta ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL toveta OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#import "TYMainController.h"
#import "TYScriptEngine.h"
#import "TYResourceServer.h"
#import "TY-NSStringAddition.h"
#import "TYStageManager.h"
#import "TYMiscUtil.h"
#import "TYFileLog.h"
#import "TYEnviroment.h"
#import "TYInputStrController.h"
#import "TYArgment.h"
#import "TYStringVarArgment.h"
#import "TYIntVarArgment.h"
#import "TYConstStringArgment.h"
#import "TYNsaArchiver.h"
#import "TYScripterValues.h"

#import "StopNSLog.h"

@implementation TYScriptEngine

// gnscripter����R�s�y(��
#define myisdigit(c) ((c) >= '0' && (c) <= '9')
#define myishexdigit(c) (myisdigit(c) || (c) >= 'a' && (c) <= 'f' || (c) >= 'A' && (c) <= 'F')
#define myisalpha(c) ((c) >= 'a' && (c) <= 'z' || (c) >= 'A' && (c) <= 'Z' || (c) == '_')
#define myisalnum(c) (myisdigit(c) || myisalpha(c))
#define myvarchar(c) (myisalnum(c) || (c) == '%' || (c) == '$' || (c) == '[' || (c) == ']' || (c) == '?')

#define getbit(b,i) (*((b)+((i)>>3)) & (1 << ((i) & 0x7)))

#define MAX_LINE_LENGTH 1024

NSString* const TYNScriptRunTimeErrorException=@"TYNScriptRunTimeErrorException";
NSString* const TYNScriptSyntaxErrorException=@"TYNScriptSyntaxErrorException";

static id sharedEngine;

const static char *newLineCodeUnix="\n";
const static char *newLineCodeWin="\r\n";
const static char *newLineCodeMac="\r";

static int slideColumn(char**,unsigned); // ��X�L�b�v����

static int slideColumn(char **ptr,unsigned toColumn)
{
    unsigned column=0;
    BOOL escape=NO;
    
    while(column<toColumn){
        if(**ptr=='\0'){
            return 1; // line up
        }
        if(**ptr=='"'){
            escape = (escape) ? NO : YES;
        }
        if((!escape)&&(**ptr==':')){
            column++;
        }
        (*ptr)++;
    }
    return 0;
}

static int get_item(char**,char*);
static int get_vararg(char**,char*);
static void space_skip(char**);

// �������擾���A���̃R���e�L�X�g��Ԃ��B
typedef enum { TYNoArgContext=-1,TYUndefinedArgContext,TYOperandArgContext,TYStringArgContext,TYIntergerArgContext,TYSeparaterArgContext,TYChainArgContext } TYArgContext;

static int get_item(char** ptr,char* buffer)
{
    int context=TYUndefinedArgContext;

    if( (**ptr=='%') || (**ptr=='?') ){
        context = TYIntergerArgContext;
        get_vararg(ptr,buffer);
        return context;
    } else if( **ptr=='$') {
        context = TYStringArgContext;
        get_vararg(ptr,buffer);
        return context;
    } else if( **ptr=='"' ) {
        context = TYStringArgContext;
        *buffer=**ptr; buffer++; (*ptr)++;
        while(**ptr && **ptr != '"'){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer=**ptr; buffer++; (*ptr)++;
        *buffer='\0';
        return context;
    } else if(**ptr=='(') {
        char strbuffer[MAX_LINE_LENGTH+1];
        // MEMO (string) string string �\���ɑΉ�
        context = TYStringArgContext;

        *buffer = **ptr;
        (*ptr)++; buffer++;
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        get_item(ptr,strbuffer);
        *buffer = '\0';
        strcat(buffer,strbuffer);
        buffer += strlen(strbuffer);
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }        
        *buffer = **ptr;
        (*ptr)++; buffer++;
        // second
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        get_item(ptr,strbuffer);
        *(buffer) = '\0';
        strcat(strbuffer," "); // Obj-C�̃p�[�T�Ŋy���邽�߂ɕK���X�y�[�X��ǉ�
        strcat(buffer,strbuffer);
        buffer += strlen(strbuffer);
        // third
        while(**ptr && isspace(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        get_item(ptr,strbuffer);
        *(buffer) = '\0';
        strcat(buffer,strbuffer);

        return context;
    } else if(isdigit(**ptr)||(**ptr=='-')) {
        context = TYIntergerArgContext;
        *buffer = **ptr;
        (*ptr)++; buffer++;        
        while(**ptr && isdigit(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer= '\0';
        return context;
    } else if(isalpha(**ptr)) {
        context = TYUndefinedArgContext;
        while(**ptr && myisalnum(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    } else if(**ptr && strchr("!<>=",**ptr)){
        context = TYOperandArgContext;
        while(**ptr && strchr("!<>=",**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    } else if(**ptr==',') {
        context = TYSeparaterArgContext;
        *buffer = **ptr;
        (*ptr)++; buffer++;
        *buffer='\0';
        return context;
    } else if(**ptr=='&') {
        context = TYChainArgContext;
        while(**ptr && **ptr=='&'){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    } else if(**ptr=='*' || **ptr=='#') {
        context = TYStringArgContext;
        *buffer = **ptr;
        (*ptr)++; buffer++;
        while(**ptr && myisalnum(**ptr)){
            *buffer = **ptr;
            (*ptr)++; buffer++;
        }
        *buffer='\0';
        return context;
    }
        
    return TYNoArgContext;
}

static int get_vararg(char** ptr,char* buffer)
{
    while(**ptr){
        if(isalnum(**ptr)){
            while(**ptr && (myvarchar(**ptr))){
                *buffer = **ptr;
                buffer++; (*ptr)++;
            }
            *buffer='\0';
            return 0;
            /*
        } else if(isdigit(**ptr)){
            while(**ptr && (isdigit(**ptr)) ){
                *buffer = **ptr;
                buffer++; (*ptr)++;
            }
            if((**ptr == '[')||(**ptr == ']'))
                continue;
                
            *buffer='\0';
            return 0;
            */
        } else {
            *buffer = **ptr;
            buffer++; (*ptr)++;
        }
    }
    
    *buffer='\0';

    return 0;
}

static void space_skip(char** ptr)
{
    while(**ptr && isspace(**ptr))
        (*ptr)++;
}

static __inline__ TYScriptPoint TYMakeScriptPoint(unsigned line,unsigned column)
{
    TYScriptPoint scPoint;
    
    scPoint.line = line;
    scPoint.column = column;
    
    return scPoint;
}

extern void TYParserSetCString(const char *ptr);
extern int yyparse();

// �v���O�������ŋN������G���W���͏�Ɉ�B�����Ԃ��B
+(id)sharedEngine
{
    return sharedEngine;
}

// �w�肳�ꂽ�p�X����X�N���v�g�t�@�C����T���A�ǂݍ��݁A�f�R�[�h�A������(�s���ƂɃX�v���b�g����Array�Ɋi�[�j���s���B
-(id)initWithContentsOfFile:(NSString*)path
{
    NSFileManager *fileManager;
    NSMutableData *ScriptData;
    NSString *truePath;
    NSData *addData;
    NSArray *filesArray;
    unsigned char* encodedCharptr;
    unsigned scriptLength;
    const unsigned char *stringSourceptr;
    int	i;
    enum { mode_multi,mode_single } scriptMode=mode_single;
    id arp;
    
    self = [ super init ];
    
    // path�t�H���_�����������ăX�N���v�g�t�@�C�����������B
    // 0.txt~��T���A���ꂪ�Ȃ����nscript.dat��T���B
    fileManager = [ NSFileManager defaultManager ];
    filesArray = [ fileManager directoryContentsAtPath:path ];
    for(i = 0; i < [ filesArray count ]; i++ ){
        if( [ [ filesArray objectAtIndex:i ] isEqualToString:@"0.txt" ]){
            scriptMode=mode_multi; 
            break;
        }
    }
    
    if(scriptMode==mode_single){
        truePath = [ [ NSString stringWithString:path ] stringByAppendingPathComponent:@"nscript.dat" ];
    
        // �Í������ꂽ�X�N���v�g���o�C�i���̂܂ܓǂݍ���
        ScriptData = [ [ NSMutableData alloc ] initWithContentsOfFile:truePath ]; // �s�v�ɂȂ������_�ő����Ƀ����[�X����
        if( ScriptData == nil){
            NSLog(@"Script File is not Found");
            return nil;
        }

        encodedCharptr = [ ScriptData mutableBytes ];

        // �ϊ��p�o�b�t�@�[�̈�̊m��
        scriptLength = [ ScriptData length ];
    
        // �e�o�C�g��132�ɂ��XOR�ŕϊ�
        for( i=0; i < scriptLength; i++,encodedCharptr++){
                *encodedCharptr = (*encodedCharptr) ^ 132;
        }
        stringSourceptr = [ ScriptData bytes ];
        
    } else {
        // �Í�������Ă��Ȃ��e�L�X�g�t�@�C�� 0.txt~��ǂݍ��݁A�A�����Ă����B
        i=0;

        ScriptData = [ [ NSMutableData alloc ] initWithCapacity:1 ]; // �s�v�ɂȂ������_�ő����Ƀ����[�X����
        //arp = [ [ NSAutoreleasePool alloc ] init ];

        while(1){
            addData = [ [ NSData alloc ] initWithContentsOfFile:
                            [ path stringByAppendingPathComponent:
                                [ NSString stringWithFormat:@"%d.txt",i ] ] ];
            if(addData){
                [ ScriptData appendData:addData ];
                [ ScriptData appendData:[ NSData dataWithBytes:"\r\n" length:2 ] ];
            } else {
                break;
            }
            i++;
        }
        scriptLength = [ ScriptData length ];
        stringSourceptr = [ ScriptData bytes ];
        //[ arp release ];
    }
    
    // ���s�R�[�h�̔��ʂ��s���B
    // MEMO:�Í�������ĂȂ��ꍇ�łȂ����X�N���v�g�������t�@�C���ɕ�����Ă���ƁA���s�R�[�h��CR+LF����B
    for(i =0 ; i < scriptLength ; i++){
        if (stringSourceptr[i] == '\n'){
            strcpy(newLineCode,newLineCodeUnix);
            break;
        } else if (stringSourceptr[i] == '\r'){
            if(stringSourceptr[i+1] == '\n'){
                strcpy(newLineCode,newLineCodeWin);
                break;
            } else {
                strcpy(newLineCode,newLineCodeMac);
            }
        }
    }
    
    // �ϊ������o�C�g�f�[�^����NSString�̐����A����эs�P�ʂł̔z��ւ̊i�[���s���B
    // encoding��"Japanese(Win,DOS)"���w�肷��B
    // MEMO:���������_�Ń��x���}�b�v���쐬����K�v������B���d��`������΃G���[�ɂ��邱�ƁB
    {
        NSString *str;
        str = [ [ NSString alloc ] initWithData:ScriptData encoding:NSShiftJISStringEncoding ];
        //[ ScriptData release ];
        ScriptArray = [ str componentsSeparatedByString:[ NSString stringWithCSJISString:newLineCode ] ];
        //[ ScriptArray retain ];
        //[ str release ]; //release����Ɨ�����BArray�ɂ͎Q�Ƃ����i�[����Ă��Ȃ��Ƃ������ƁH
    }

    // ���x�������쐬
    {
        NSCharacterSet *cset=[ NSCharacterSet varNameCharacterSet ];
        NSEnumerator *enu=[ ScriptArray objectEnumerator ];
        int line=0;
        NSString *buff;
        id tmp;
        NSScanner *scanner;

        labelDict = [ [ NSMutableDictionary alloc ] initWithCapacity:[ ScriptArray count ] /512 ];
        
        while(tmp = [ enu nextObject ]){
            scanner = [ NSScanner scannerWithString:tmp ];

            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                 intoString:nil ];
            if([ scanner scanString:@"*" intoString:nil ]){ // �s�̑O��ɋ󔒂������Ă����v
                [ scanner scanCharactersFromSet:cset
                                        intoString:&buff ];
                [ labelDict setObject:[ NSNumber numberWithInt:line ]
                               forKey:[ @"*" stringByAppendingString:[ buff lowercaseString ] ] ];
            }

            line++;
        }
    }

    
    // ���̑��̃C���X�^���X�ϐ��̏�����
    numAliases = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    strAliases = [ [ NSMutableDictionary alloc ] initWithCapacity:1 ];
    scripterValues = [ TYScripterValues ScripterValues ];
    multiLineCmdStringSet = [ [ NSSet alloc ] initWithObjects:MULTILINE_CMD_STRINGS,nil ];
    returnStack = [ NSMutableArray arrayWithCapacity:1 ];
    timerStartDate = [ [ NSDate alloc ] init ];
    loopStack = [ NSMutableArray arrayWithCapacity:1 ];
    textgosubPointIndex = -1;
    undefinedComSet = [ NSMutableSet set ];

    // �O���[�o���ϐ��̃��[�h�O��value�錾�̃`�F�b�N
    {
        int value = [ self scanGlobalValue ];
        if (value > 0) {
            NSLog(@"change global ID bottom = %d",value);
            [ TYScripterValues setMinGlobalNo:value ];
        }
    }
    
    // �O���[�o���ϐ��͊J�n����ɂ��炩���߃��[�h�����B
    [ scripterValues loadGlobalValues:
        [ getNScrRootDirectory() stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];

    // �J�n�ʒu������
    [ self labeljump:@"*define" ];

    // �����̎��ݒ�
    {
        NSCalendarDate *cDate=[ NSCalendarDate calendarDate ];
        unsigned int seed= ([ cDate hourOfDay ] *60 +[ cDate minuteOfHour ]) *60 +[ cDate secondOfMinute ];
        srandom(seed);
    }
    // shared�Ɋi�[
    sharedEngine = self;
    
    return self;
}

-(BOOL)isModeSVGA
{
    NSScanner *scanner;

    scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:0 ] ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                         intoString:NULL ];
    return [ scanner scanString:@";mode800" intoString:NULL ];
    
}

-(int)scanGlobalValue
{
    NSScanner *scanner;
    NSString *strBuf;

    scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:0 ] ];
    [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                         intoString:NULL ];
    [scanner scanUpToString:@"value" intoString:NULL ];
    if ([ scanner isAtEnd ] == YES) {
        return 0;
    } else {
        [ scanner scanString:@"value" intoString:NULL ];
        if ([ scanner scanCharactersFromSet:[ NSCharacterSet decimalDigitCharacterSet ]
                                 intoString:&strBuf ] == YES) {
            return [ strBuf intValue ];
        }
        
        return 0;
    }    
}

-(id)encodeWithSaveData
{
    NSDictionary *aDict;
    NSData *valueData;
    NSValue *pointValue;
    //TYScriptPoint point;

    
    valueData = [ scripterValues encodeWithSaveData ];

    /*
    {
        aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,nil ];
    
        return aDict;
    }
     */


    //point = TYMakeScriptPoint(runLine,runColumn);
    // �I�����̃N���b�N�҂��̊ԂɌĂ΂ꂽ�̂ł���΁A�Y���s�i��j�̏����𕜋A���ɂ�蒼���K�v������̂ŁB
    if([ (TYMainController*)controller status ]==TYSelectStatus){
        if(savePoint.column == 0){
            savePoint.line--;
        }
    } else if([ (TYMainController*)controller status ]==TYScriptRunningStatus){
        // �X�N���v�g�������Ȃ�ĊJ���Ɏ��̃J�����ɐi��ł���K�v������B
        savePoint.column++;
    }
    pointValue = [ NSValue valueWithBytes:&savePoint objCType:@encode(TYScriptPoint) ];

    if(textgosubPointIndex == -1){
        aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,
            pointValue,TYScriptPointSaveData,
            returnStack,TYReturnStackSaveData,nil ];
    } else {
        aDict = [ NSDictionary dictionaryWithObjectsAndKeys:valueData,TYLocalValuesSaveData,
            pointValue,TYScriptPointSaveData,
            returnStack,TYReturnStackSaveData,
            [ NSNumber numberWithInt:textgosubPointIndex ] , TYTextgosubIndexSaveData ,nil ];
    }

    return aDict;

}

-(void)decodeWithSaveData:(id)aObject
{
    id tmp;
    TYScriptPoint point;
    
    [ scripterValues decodeWithSaveData:[ aObject objectForKey:TYLocalValuesSaveData ] ];

    tmp = [ aObject objectForKey:TYReturnStackSaveData ];
    if(tmp){
        //if(returnStack)
        //    [ returnStack release ];
        returnStack = tmp;
    }

    tmp = [ aObject objectForKey:TYScriptPointSaveData ];
    if(tmp){
        [ tmp getValue:&point ];

        runLine=point.line;
        runColumn=point.column;
    }
    
    
    tmp = [ aObject objectForKey:TYTextgosubIndexSaveData ];
    if(tmp){
        textgosubPointIndex = [ tmp intValue ];
    } else {
        textgosubPointIndex = -1;
    }
}

-(void)resetGame
{
    [ scripterValues resetGame ];

    //[ returnStack release ];
    returnStack = [ NSMutableArray arrayWithCapacity:1 ];
    
    textgosubPointIndex = -1;

    [ self labeljump:@"*start" ];
}

-(void)setController:(id)cont stageManager:(id)manager
{
    controller = cont;
    stageManager = manager;
}

// NScript�����s���܂��B�X�N���v�g�����߂��A�R�}���h�����烁�\�b�h�𐶐����ċN�����܂��B
-(void)runScript
{
    NSString *currentString;
    const char *startptr;
    char *currentchars;
    char command[MAX_LINE_LENGTH]; 
    NSMutableArray *cmdArray;
    int j;
    BOOL conditionResult;
    
    breakRun = NO;
    
    [ controller setStatus:TYScriptRunningStatus ];
    // �C�x���g��҂K�v������܂ŁA�����𑱂��܂��B
    while(1){
        // trap�̕ߑ��`�F�b�N
        if(labelWithTrap && fireOfTrap){
            //[ labelWithTrap autorelease ];
            [ self labeljump:labelWithTrap ];
            [ controller setTrap:NO ];
            fireOfTrap=NO;
            labelWithTrap=nil;
        }
        
        // ��̏������łȂ���΍s��i�߂�
        if( runColumn == 0){
            runLine++;
            //NSLog2(@"%d",runLine);
        }
        currentString = [ ScriptArray objectAtIndex:runLine ];
        //[ currentData release ];
        currentData = [ currentString getCSJISData ];
        //[ currentData retain ];
        currentchars = [ currentData mutableBytes ];
        // �o�b�t�@�I�[�o�[�t���[�΍�
        if([ currentData length ] > MAX_LINE_LENGTH){
            NSLog(@"too long line. omit data over %d",MAX_LINE_LENGTH);
            currentchars[MAX_LINE_LENGTH -1] = '\0';
        }
        startptr = currentchars;
        // ��̏������Ȃ�J�n�ʒu�܂ł��炷
        if(runColumn){
            if(slideColumn(&currentchars,runColumn)){
                // ���s�ɃV�t�g����
                runLine++; runColumn=0;
                currentString = [ ScriptArray objectAtIndex:runLine ];
                //[ currentData release ];
                currentData = [ currentString getCSJISData ];
                //[ currentData retain ];
                currentchars = [ currentData mutableBytes ];
                startptr = currentchars;                
            }
        }
        savePoint.line=runLine;
        savePoint.column=runColumn;

        TYParserSetCString(currentchars);
        yyparse();
        
        /*
        // �擪�X�y�[�X�̓ǂݔ�΂�
        while((*currentchars)&&(isspace(*currentchars))){
            currentchars++;
        }
        
        // ���x���Ȃ烉�x�����O��ǉ����A����
        if(currentchars[0]=='*'){
            if(labelLog)
                [ labelLog addLog:[ NSString stringWithCSJISString:currentchars ] ];
            runColumn=0;
            continue;
        }
        // �R�����g�A��s�Ȃ玟��
        if( (strchr(";*~",currentchars[0]))||(currentchars[0]=='\0') ){
            runColumn=0;
            continue;
        }

        if (isalpha(*currentchars)) {
        // ���ߕ�
            
            // �`�����N���ɔz��Ɋi�[����
            cmdArray = [ NSMutableArray array ];
        
            // �R�}���h�̎擾�B�R�}���h���I������܂œǂݍ��݁B
            for(j=0; myisalnum(*currentchars); currentchars++,j++){
                command[j] = *currentchars;
            }
            command[j] = '\0';
            [ cmdArray addObject:[ [ NSString stringWithCSJISString:command ] lowercaseString ] ];

            // �ʏ�̖��ߕ���if�n�ōu�����߂��Ⴄ�̂ŕ���
            if( strncmp(command,"for",3)==0 ){
                [ self registLoop:currentchars ];
                continue;
            } else if( (strncmp(command,"if",2)!=0)&&(strncmp(command,"notif",5)!=0) ){
                [ self splitArgNormal:currentchars Array:cmdArray ]; // �ʏ�̈���������
            } else {
                if(strncmp(command,"if",2)==0){
                    conditionResult = [ self splitArgCondition:&currentchars trueflg:YES ]; // if
                } else {
                    conditionResult = [ self splitArgCondition:&currentchars trueflg:NO ]; // notif
                }

                if(conditionResult==NO){
                    runColumn=0;
                    continue;
                } else {
                    // �擪�X�y�[�X�̓ǂݔ�΂�
                    while((*currentchars)&&(*currentchars==' ')){
                        currentchars++;
                    }
                    // �`�����N���ɔz��Ɋi�[����
                    cmdArray = [ NSMutableArray array ];
                
                    // �R�}���h�̎擾�B
                    for(j=0; (*currentchars)&&(myisalnum(*currentchars)); currentchars++,j++){
                        command[j] = *currentchars;
                    }
                    command[j] = '\0';
                    if( strncmp(command,"for",3)==0 ){
                        [ self registLoop:currentchars ];
                        continue;
                    }
                    [ cmdArray addObject:[ [ NSString stringWithCSJISString:command ] lowercaseString ] ];
                    [ self splitArgNormal:currentchars Array:cmdArray ];
                }
            }

            // �X�N���v�g�����s�B
            if(![ self eval:cmdArray ]){
                NSLog(@"Undefined script '%@' at LINE %d\n",[ cmdArray objectAtIndex:0 ],runLine+1);
            }
        } else if (*currentchars==':') {
            runColumn++;
        } else {
            // �\�����̎�
            NSString* printString;
            
            if(currentchars==startptr){
                printString = [ ScriptArray objectAtIndex:runLine ];
            } else {
                printString = [ NSString stringWithCSJISString:currentchars ];
            }
            while(*currentchars &&(*currentchars !=':'))
                currentchars++;
            if(!currentchars){
                runColumn=0;
            } else {
                runColumn++;
            }
            // ���ǃX�L�b�v�g�p���̃`�F�b�N
            if(kidokuptr){
                if(isWatchKidoku){
                    //NSLog(@"runLine=%d,kidokuchr=%d,bit = %d",runLine,*(kidokuptr+(runLine>>3)),getbit(kidokuptr,runLine));
                    if(!(*(kidokuptr+(runLine>>3)) & (1 << (runLine & 0x7)))){
                        [ stageManager setSkipStatus:TYNoSkip ];
                        isWatchKidoku=NO;
                        *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
                        //NSLog(@"runLine=%d,kidokuchr=%d,bit = %d",runLine,*(kidokuptr+(runLine>>3)),getbit(kidokuptr,runLine));
                    }
                } else {
                    *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
   //                 NSLog(@"bit = %d",getbit(kidokuptr,runLine));
                }
            }
            [ stageManager textPrint:printString ];
        }
         */
        
        if(breakRun) {
            break;
        }
    }
}

-(void)ty__print:(NSMutableArray*)argments
{
    NSString *aStr = [ argments objectAtIndex:1 ];
    
    // ���ǃX�L�b�v�g�p���̃`�F�b�N
    if(kidokuptr){
        if(isWatchKidoku){
            if(!(*(kidokuptr+(runLine>>3)) & (1 << (runLine & 0x7)))){
                [ stageManager setSkipStatus:TYNoSkip ];
                isWatchKidoku=NO;
                *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
            }
        } else {
            *(kidokuptr+(runLine >> 3)) |= 1 << (runLine & 0x7);
        }
    }
    
    [ stageManager textPrint:aStr ];
 }

-(BOOL)eval:(NSMutableArray*)argments
{
    SEL cmdSEL;
    
    // �R�}���h������Z���N�^�𐶐��i�v���t�B�b�N�X"ty_"��t�^����B���\�b�h���̏Փ˖h�~�j
    // NScript�ł͑召�����̋�ʂ����Ȃ��B
    cmdSEL = NSSelectorFromString([ [ NSString stringWithFormat:@"ty_%@:",[ argments objectAtIndex:0] ] lowercaseString ]);
    NSLog(@"[%5d]%@",runLine+1,NSStringFromSelector(cmdSEL));
    
    // �Z���N�^�����g���������Ă��邩�ǂ����`�F�b�N�B
    if( [ self respondsToSelector:cmdSEL ]){
        // �Z���N�^���R�[���B�ق�Ƃ͗�O�̃n���h�����O�������������̂��ˁ`
        [ self performSelector:cmdSEL withObject:argments ];
    } else if ([ stageManager respondsToSelector:cmdSEL ]){
        [ stageManager performSelector:cmdSEL withObject:argments ];
    } else if ([ controller respondsToSelector:cmdSEL ]){
        [ controller performSelector:cmdSEL withObject:argments ];
    } else {
        // vXXXX:�����dvXXXX:�ւ̑Ή�
        NSScanner *scanner=[ NSScanner scannerWithString:[ argments objectAtIndex:0 ] ];
        NSString *cmdStr,*numStr;
        
        if([ scanner scanString:@"dv" intoString:&cmdStr ] || 
           [ scanner scanString:@"v" intoString:&cmdStr ]){
            [ scanner scanCharactersFromSet:[ NSCharacterSet decimalDigitCharacterSet ]
                                 intoString:&numStr ];                                 
            [ controller performSelector:NSSelectorFromString([ [ NSString stringWithFormat:@"ty_%@:",cmdStr ] lowercaseString ])
                                withObject:[ NSMutableArray arrayWithObjects:cmdStr,numStr,nil ] ];
        } else {
            if ([ undefinedComSet containsObject:[ argments objectAtIndex:0 ] ] == NO) {
                NSLog(@"Undefined script '%@' at LINE %d\n",[ argments objectAtIndex:0 ],runLine+1);
                [ undefinedComSet addObject:[ argments objectAtIndex:0 ] ];
            }
            return NO;
        }
    }
    
    return YES;
}

-(BOOL)breakRun
{
    return breakRun;
}

-(void)setBreakRun:(BOOL)aFlag
{
    breakRun = aFlag;
}

-(void)lineEnd // �s�̏I����ʒm�B
{
    //runColumn++;
}

// ���������𕪊����āAarray�Ɋi�[����
-(int)splitArgNormal:(char *)currentchars Array:(NSMutableArray *)cmdArray;
{
    char * buffer=currentchars;
    char command[MAX_LINE_LENGTH];
    int context; // �_�~�[�̒l
    BOOL multiLinePossible=YES;

    // �����Ƃ�Ȃ��Ȃ�܂Ń��[�v
    space_skip(&buffer);
    context = get_item(&buffer,command);

    while(context!=TYNoArgContext){
        [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
        space_skip(&buffer);
        context = get_item(&buffer,command);
        if(context==TYSeparaterArgContext){
            space_skip(&buffer);
            context = get_item(&buffer,command);
        } else {
            multiLinePossible=NO;
            break;
        }
    }

    // ��̃C���N�������g�`�F�b�N�B�����łȂ���Ε����s�T�|�[�g�R�}���h���`�F�b�N
    if(*buffer==':'){
        runColumn++;
    } else {
        if(multiLinePossible && [ self isMultLineSupport:[ cmdArray objectAtIndex:0 ] ]){
            [ self splitArgNormal:[ self nextLine ] Array:cmdArray ];
        } else {
            runColumn=0;
        }
    }        

    return 0;

    /*
    int i=0,j=0;
    char command[256];
    enum { aas_SpaceSkip,aas_CommaSkip,aas_GetArg,aas_GetArgStr } argAnalyzerStat;
    BOOL chained=NO;

    argAnalyzerStat = aas_SpaceSkip;
    while(currentchars[i]){
        switch (argAnalyzerStat) {
        case aas_SpaceSkip:	// ���̈��������n�܂�܂ł̃X�y�[�X���΂��܂��B
            if(!isspace(currentchars[i])){
                if(currentchars[i] == ':'){ // ���ߕ��̘A���q
                    runColumn++;
                    chained=YES;
                    break;
                }
                
                j=0;
                command[j] = currentchars[i];
                j++;
                if(currentchars[i] == '"'){
                    argAnalyzerStat = aas_GetArgStr;
                } else {
                    argAnalyzerStat = aas_GetArg;
                }
            }
            i++;
            break;

        case aas_GetArgStr: // ������萔���擾���܂��B
            command[j] = currentchars[i];
            j++;
            if(currentchars[i] == '"'){
                argAnalyzerStat = aas_CommaSkip;
                //�@�������𐶐�
                command[j] = '\0';
                [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
            }
            i++;
            break;
                    
        case aas_GetArg: // ����ȊO�̈��������擾���܂��B
            if( (currentchars[i] != ',')&&(!isspace(currentchars[i]))&&(currentchars[i] != ':') ){
                command[j] = currentchars[i];
                j++;
                i++;
            } else {
                argAnalyzerStat = aas_CommaSkip;
                // �������𐶐�
                command[j] = '\0';
                [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
                if(currentchars[i] == ':' ){ // �A�����w��q
                    runColumn++;
                    chained=YES;
                    break;
                }
            }
            break;

        case aas_CommaSkip: // ��������؂�̃J���}�܂Ŕ�΂��܂��B
            if(currentchars[i] == ','){
                argAnalyzerStat = aas_SpaceSkip;
            } else if(currentchars[i] == ':' ) {
                runColumn++;
                chained=YES;
                break;
            } else if(!isspace(currentchars[i])) {
                // �J���}�̂Ȃ��s���ȍ\��
                //[ NSException raise:@"TYNScriptSyntaxError" format:@"lack comma" ];
                // ���̃R�}���h�ň���������Ȃ��ꍇ�̂݃G���[��f���̂ŁA�����ł̓G���[�Ƃ��Ȃ��B
            }
            i++;
            break;
        
        default:
            NSLog(@"Show Debbuger!\n");
            return -1;
        }
        
        // �A���q���������āA�A�������i�[����Ă�����
        if(chained){
            break;
        }
    }
    
    // �������̐����r���Ńu���C�N���Ă�����
    if(argAnalyzerStat == aas_GetArg){
        command[j] = '\0';
        [ cmdArray addObject:[ NSString stringWithCSJISString:command ] ];
    } else if(argAnalyzerStat == aas_SpaceSkip){
        // �Q�ڈȍ~�̈�����T���r���Ńu���C�N���Ă�����
        if([ self isMultLineSupport:[ cmdArray objectAtIndex:0 ] ]){
            [ self splitArgNormal:[ self nextLine ] Array:cmdArray ];
        }
    }

    if(!chained){
        runColumn=0;
    }
    
    return 0;
     */
}

// �R�}���h�������s�ɓn��L�q��������Ă��邩�ǂ�����Ԃ�
-(BOOL)isMultLineSupport:(NSString*)command
{
    return [ multiLineCmdStringSet containsObject:command ];
}

// ���̍s�֏�����i�߁A�X�N���v�g�����o���B
-(char*)nextLine
{
    runLine++;
    //[ currentData release ];
    currentData = [ [ ScriptArray objectAtIndex:runLine ] getCSJISData ];
    //[ currentData retain ];
    return (unsigned char*)[ currentData mutableBytes ];
}

// for���[�v�̓o�^
/*
-(void)registLoop:(char *)currentchars
{
    char buffer[256];
    int context;
    id targetNo;
    int initValue;
    int limit;
    int step;
    NSString *var;
    TYLoopStruct loop;
    
    // �o�C���h����ϐ��ԍ����擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYIntergerArgContext&& buffer[0] == '%'),
             TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    targetNo = [ self getIdNoOfArgment:var ];
    // ���Z�q=�̃`�F�b�N
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYOperandArgContext && strcmp(buffer,"=")==0),
             TYNScriptSyntaxErrorException);
    // ����������l���擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYIntergerArgContext || context==TYUndefinedArgContext),
             TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    initValue = [ [ self getValueOfArgment:var ] intValue ];
    // to��`�F�b�N
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYUndefinedArgContext),TYNScriptSyntaxErrorException);
    // �E�o�����̒l���擾
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    NSAssert((context==TYUndefinedArgContext || context==TYIntergerArgContext),
             TYNScriptSyntaxErrorException);
    var = [ NSString stringWithCSJISString:buffer ];
    limit = [ [ self getValueOfArgment:var ] intValue ];
    // step��̑��݃`�F�b�N
    space_skip(&currentchars);
    context = get_item(&currentchars,buffer);
    if(context==TYNoArgContext){
        step=1;
    } else {
        NSAssert((context==TYUndefinedArgContext && (strcmp(buffer,"step")==0)),
                 TYNScriptSyntaxErrorException);
        // step�l�̎擾
        space_skip(&currentchars);
        context = get_item(&currentchars,buffer);
        NSAssert((context==TYUndefinedArgContext || context==TYIntergerArgContext),
                    TYNScriptSyntaxErrorException);
        var = [ NSString stringWithCSJISString:buffer ];
        step = [ [ self getValueOfArgment:var ] intValue ];
    }

    // �ϐ��ɏ������l�Z�b�g
    [ scripterValues setIntValue:targetNo object:[ NSNumber numberWithInt:initValue ] ];
    
    // �������l�����Ƀ��[�v�̒E�o�����𖞂����Ă���ꍇ
    if(step > 0){
        if(initValue > limit){
            [ self jumpToLoopEnd ];// next�ɃW�����v?
            return;
        }
    } else if(step < 0){
        if(initValue < limit){
            [ self jumpToLoopEnd ];// next�ɃW�����v?
            return;
        }
    }

    // loop�I�u�W�F�N�g�쐬�B�X�^�b�N�ɐςށB
    loop = TYMakeLoopStruct(TYMakeScriptPoint(runLine,runColumn),targetNo,limit,step);
    [ loopStack addObject:[ [ [ TYLoopValue alloc ] initWithStruct:loop ] autorelease ] ];
    
    runColumn++;
}
*/

-(void)registLoopTargetID:(id)varID initValue:(id)initVal limitValue:(id)limitVal step:(id)stepVal
{
    TYLoopStruct loop;    

    NSLog(@"push for stack at %d",runLine);
    // �ϐ��ɏ������l�Z�b�g
    [ scripterValues setIntValue:varID object:[ initVal intNumber ] ];
    
    // MEMO:�������l�����Ƀ��[�v�̒E�o�����𖞂����Ă���ꍇ�̑Ώ����K�v?

    // loop�I�u�W�F�N�g�쐬�B�X�^�b�N�ɐςށB
    loop = TYMakeLoopStruct(TYMakeScriptPoint(runLine,runColumn),varID,[ limitVal intValue ],[ stepVal intValue ]);
    [ loopStack addObject:[ [ TYLoopValue alloc ] initWithStruct:loop ] ];
}


static int chkNext(char**,int);

static int chkNext(char** ptr,int stColumn)
{
    int column;
    int result=-1;
    
    for(column=stColumn; !slideColumn(ptr,column); column++){
        space_skip(ptr);
        if(strncmp("next",*ptr,4)==0){
            result = column;
            break;
        }
    }
    
    return result;
}

// �����next���܂ŃW�����v���܂��B
-(void)jumpToLoopEnd
{
    char *ptr;
    int column=runColumn +1;
    // �o�C�i���B�E�|�b�g�̘A��������next�ɂ��Ή��B
    while(1) {
        ptr = (char*)[ [ ScriptArray objectAtIndex:runLine ] cSJISString ];
        column=chkNext(&ptr,column);
        if(column >= 0){
            runColumn = column +1;
            break;
        } else {
            runLine++;
            column=0;
        }
    }
}

// if �n�\���̉��߂Ə�������B
-(int)splitArgCondition:(char**)currentcharsptr trueflg:(BOOL)trueflg
{
    int k,count;
    NSMutableArray *conditions;
    char buffer[MAX_LINE_LENGTH];
    char sentence[MAX_LINE_LENGTH];
    int context=TYChainArgContext;
    BOOL judgeResult;

    conditions = [ NSMutableArray array ];

    while(context==TYChainArgContext){
        space_skip(currentcharsptr);
        context = get_item(currentcharsptr,buffer);
        strcpy(sentence,buffer);
        if(context==TYIntergerArgContext){
            // ���ӊm��B�����ĉ��Z�q�ƉE�ӂ��擾
            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if(context != TYOperandArgContext){
                NSLog(@"invalid argment [%s]. it needs operand here",buffer);
                return NO;
            }
            strcat(sentence,buffer);

            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if((context != TYIntergerArgContext )&&(context != TYUndefinedArgContext)){
                NSLog(@"invalid argment [%s]. it needs interger here",buffer);
                return NO;
            }
            strcat(sentence,buffer);
            [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];

        } else if(context==TYStringArgContext) {
            // ���ӊm��B�����ĉ��Z�q�ƉE�ӂ��擾
            [ conditions addObject:@"string" ];
            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if(context != TYOperandArgContext){
                NSLog(@"invalid argment [%s]. it needs operand here",buffer);
                return NO;
            }
            strcat(sentence,buffer);

            space_skip(currentcharsptr);
            context = get_item(currentcharsptr,buffer);
            if((context != TYStringArgContext )&&(context != TYUndefinedArgContext)){
                NSLog(@"invalid argment [%s]. it needs string here",buffer);
                return NO;
            }
            strcat(sentence,buffer);
            [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];
        } else if(context==TYUndefinedArgContext){
            if((strcmp(buffer,"fchk")==0)||(strcmp(buffer,"lchk")==0)){
                [ conditions addObject:[ NSString stringWithCSJISString:buffer ] ];
                space_skip(currentcharsptr);
                context = get_item(currentcharsptr,buffer);
                if((context==TYStringArgContext)||(context==TYUndefinedArgContext)){
                    [ conditions addObject:[ NSString stringWithCSJISString:buffer ] ];
                } else {
                    NSLog(@"invalid argment [%s]. it needs string here",buffer);
                    return NO;
                }
            } else {
                // �Ƃ肠�������ӂƂ݂Ȃ��B�����ĉ��Z�q�ƉE�ӂ��擾�B���ăX�g�����O�Ƃ����Ă���G���[�Ȃ�ł����ǂˁB
                space_skip(currentcharsptr);
                context = get_item(currentcharsptr,buffer);
                if(context != TYOperandArgContext){
                    NSLog(@"invalid argment [%s]. it needs operand here",buffer);
                    return NO;
                }
                strcat(sentence,buffer);

                space_skip(currentcharsptr);
                context = get_item(currentcharsptr,buffer);
                if(context != TYOperandArgContext){
                    NSLog(@"invalid argment [%s]. it needs interger here",buffer);
                    return NO;
                }
                strcat(sentence,buffer);
                [ conditions addObject:[ NSString stringWithCSJISString:sentence ] ];

            }
        } else {
            NSLog(@"invalid argment [%s].it needs interger or \"fchk\" or \"lchk\" here",buffer);
            return NO;
        }

        space_skip(currentcharsptr);
        if(**currentcharsptr=='&'){
            context = get_item(currentcharsptr,buffer);
        } else {
            break;
        }
    }
    
    // �������̐^�U�𔻒�Btrueflg=YES�̂Ƃ��S�Đ^�Ȃ���s�Atrueflg=NO�̂Ƃ��A�S�ċU�Ȃ���s
    for(k = 0,count=[ conditions count ]; k < count ; k++){
        if([ [ conditions objectAtIndex:k ] isEqualToString:@"fchk" ]){
            k++;
            judgeResult = [ self judgefchk:[ conditions objectAtIndex:k ] ];
        } else if([ [ conditions objectAtIndex:k ] isEqualToString:@"lchk" ]){
            k++;
            judgeResult = [ labelLog isRead:[ self getStringOfArgment:[ conditions objectAtIndex:k ] ] ];
        } else if([ [ conditions objectAtIndex:k ] isEqualToString:@"string" ]){
            k++;
            judgeResult = [ self judgeCondition:[ conditions objectAtIndex:k ] string:YES ];
        } else {
            judgeResult = [ self judgeCondition:[ conditions objectAtIndex:k ] string:NO ];
        }
        
        if(judgeResult != trueflg){
            return NO; // ���s����Ȃ����Ƃ����������甲����B
        }
    }
    
    return YES;
}

// ���̉摜�i�^�O���܂ށj���ǂݍ��܂ꂽ���ǂ�����Ԃ��B
-(BOOL)judgefchk:(NSString*)file
{
    return [ [ TYResourceServer sharedServer ] fchk:[ self getStringOfArgment:file ] ];
}

-(BOOL)judgelchk:(NSString*)label
{
    return [ labelLog isRead:[ self getStringOfArgment:label ] ];
}

-(void)addLabelLog:(NSString*)string
{
    if(labelLog)
        [ labelLog addLog:string ];
}

-(BOOL)judgeCondition:(NSString*)condition string:(BOOL)aBool
{
    char valueString1[MAX_LINE_LENGTH];
    char valueString2[MAX_LINE_LENGTH];
    char cond[3];
    const char *conditionchars;
    int value1,value2;
    const char *operandchars = "!<>=";
    int i,j;
    
    conditionchars = [ condition cSJISString ];
    
    // ���ӂ̎擾
    for(i=0,j=0; (conditionchars[i])&&(strchr(operandchars,conditionchars[i]) == NULL) ; i++,j++ ){
        valueString1[j] = conditionchars[i];
    }
    valueString1[j] = '\0';
    
    // ���Z�q�̎擾
    for( j=0; (conditionchars[i])&&(strchr(operandchars,conditionchars[i]) != NULL) ; i++,j++ ){
        cond[j] = conditionchars[i];
    }
    cond[j] = '\0';
    
    // �E�ӂ̎擾
    for(j=0; (conditionchars[i]) ; i++,j++ ){
        valueString2[j] = conditionchars[i];
    }
    valueString2[j] = '\0';

    if(aBool){
        NSString *string1,*string2;
        // ������̏ꍇ�̏���
        string1 = [ self getStringOfArgment:[ NSString stringWithCSJISString:valueString1 ] ];
        string2 = [ self getStringOfArgment:[ NSString stringWithCSJISString:valueString2 ] ];

        // ����
        if( (strcmp(cond,"==")==0)||(strcmp(cond,"=")==0) ){ // ������
            return [ string1 isEqualToString:string2 ];
        } else if ( (strcmp(cond,"!=")==0)||(strcmp(cond,"<>")==0) ) { // ����������
            return ![ string1 isEqualToString:string2 ];
        } else if (strcmp(cond,">")==0) { // ���Ӂ��E��
            return ([ string1 compare:string2 ] == NSOrderedDescending);
        } else if (strcmp(cond,"<")==0) { // ���Ӂ��E��
            return ([ string1 compare:string2 ] == NSOrderedAscending);
        } else if (strcmp(cond,">=")==0) { // ���Ӂ����E��
            return  ([ string1 compare:string2 ] >= NSOrderedSame);
        } else if (strcmp(cond,"<=")==0) { // ���Ӂ����E��
            return ([ string1 compare:string2 ] <= NSOrderedSame);
        } else {
            NSLog(@"It's illegal operand![%s]",conditionchars);
            return -1;
        }
    } else {
        // ���l�̏ꍇ�̏���
        value1 = [ [ self getValueOfArgment:[ NSString stringWithCSJISString:valueString1 ] ] intValue];
        value2 = [ [ self getValueOfArgment:[ NSString stringWithCSJISString:valueString2 ] ] intValue];

        // ����
        if( (strcmp(cond,"==")==0)||(strcmp(cond,"=")==0) ){ // ������
            return (value1 == value2);
        } else if ( (strcmp(cond,"!=")==0)||(strcmp(cond,"<>")==0) ) { // ����������
            return (value1 != value2);
        } else if (strcmp(cond,">")==0) { // ���Ӂ��E��
            return (value1 > value2);
        } else if (strcmp(cond,"<")==0) { // ���Ӂ��E��
            return (value1 < value2);
        } else if (strcmp(cond,">=")==0) { // ���Ӂ����E��
            return (value1 >= value2);
        } else if (strcmp(cond,"<=")==0) { // ���Ӂ����E��
            return (value1 <= value2);
        } else {
            NSLog(@"It's illegal operand![%s]",conditionchars);
            return -1;
        }
    }
}

-(void)jump:(unsigned)target
{
    runLine = target;
    runColumn = 0;
}

// �w�肳�ꂽ���x����T�������Ɉړ�
-(void)labeljump:(NSString*)label
{
    id tmp;

    if(tmp = [ labelDict objectForKey:[ label lowercaseString ] ]){
        // ���x�����O�ɒǉ�
        [ labelLog addLog:label ];
        runLine = [ tmp intValue ];
        runColumn =0;
        return;
    } else {
        NSLog(@"Not Found Label:%@",label);
        [ NSException raise:@"TYNScriptRuntimeError" format:@"Not Found Label:%@",label ];
    }

    /*
    [ self labeljump:label fromLine:0 reverse:NO ];
    return;
     */
    /*
    NSString *search_label;
    unsigned line;
    unsigned length;
    
    search_label = [ NSString stringWithFormat:@"%@",label ];
    length = [ ScriptArray count ];
    for(line=0; line < length; line++){
        if(![ ScriptArray objectAtIndex:line]){
            continue;
        }
        if([ search_label isEqualToString:[ ScriptArray objectAtIndex:line] ]){ // �s�̑O��ɋ󔒂��������肷��Ƃ܂�����
            runLine = line;
            runColumn = 0;
            return;
        }
    }
    
    NSLog(@"Not Found Label:%@",label);
    [ NSException raise:@"TYNScriptRuntimeError" format:@"Not Found Label:%@",label ];

    return;
    */
}

-(void)labeljump:(NSString*)label fromLine:(int)line reverse:(BOOL)aBool
{
    unsigned l;
    unsigned length;
    NSScanner *scanner;
    NSString *str;

    if(labelLog)
        [ labelLog addLog:label ];

    if(aBool==NO){
        length = [ ScriptArray count ];

        for(l=line; l < length; l++){
            str = [ ScriptArray objectAtIndex:l];
            if(![ str length ]){
                continue;
            }
            scanner = [ NSScanner scannerWithString:str ];
            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                 intoString:nil ];

            if([ scanner scanString:label intoString:nil ]){ // �s�̑O��ɋ󔒂������Ă����v
                if([ scanner isAtEnd ] ||
                   [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                        intoString:nil ]){

                    runLine = l;
                    runColumn = 0;
                    return;
                }
            }
        }
    } else {
        for(l=line; l >= 0; l--){
            if(![ ScriptArray objectAtIndex:l]){
                continue;
            }
            scanner = [ NSScanner scannerWithString:[ ScriptArray objectAtIndex:l] ];
            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                 intoString:nil ];
            if([ scanner scanString:label intoString:nil ]){ // �s�̑O��ɋ󔒂������Ă����v
                if([ scanner isAtEnd ] ||
                   [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceAndNewlineCharacterSet ]
                                     intoString:nil ]){                    

                    runLine = l;

                    runColumn = 0;

                    return;
                }
            }
        }
    }

    NSLog(@"Not Found Label:%@",label);
    [ NSException raise:@"TYNScriptRuntimeError" format:@"Not Found Label:%@",label ];

    return;
}

// ���������琔�l�I�u�W�F�N�g�����o���BMEMO:�����ϐ��ɂ��ċA�I�ȎQ�Ƃ��\�ɂ��Ȃ���΂Ȃ�Ȃ�
-(id)getValueOfArgment:(id/*NSString * */)argment
{
    /*
    NSString *firstCharStr;
    int scanValue;
    NSNumber *resultForAlias;
     */

    return [ argment intNumber ];
    /*
    firstCharStr = [ argment substringWithRange:NSMakeRange(0,1) ];
    // 1�����ڂ������ɂ���ĕ���
    if([ firstCharStr isEqualToString:@"%" ]) {
        // �ϐ��̏ꍇ�AIndex�̎w����ċA�ŕ]������
        return [ scripterValues getIntValue:[ self getValueOfArgment:[ argment substringFromIndex:1 ] ] ];
    } else if([ firstCharStr isEqualToString:@"?" ]){
        // �z��ϐ��������ꍇ
        return [ scripterValues getIntValue:[ self getArrayIdOfArgment:argment ] ];
    }

    if([ [ NSScanner scannerWithString:argment ] scanInt:&scanValue ]){
        // �萔�̏ꍇ
        return [ NSNumber numberWithInt:scanValue ];
    } else {
        // �G�C���A�X�H
        resultForAlias = [ numAliases objectForKey:[ argment lowercaseString ] ];
        if(resultForAlias){
            return resultForAlias;
        } else {
            // ��O����
            goto ANALYZE_ERROR;
            //[ NSException raise:@"TYNScriptRuntimeError" format:@"Illegal Value Index:%@",argment ];
            //return [ NSNumber numberWithInt:0 ];
        }
    }
    
ANALYZE_ERROR:
    NSLog(@"Not Get Interger Value from [%@]\n",argment);
    return [ NSNumber numberWithInt:0 ];
    */
}

// ���������當����I�u�W�F�N�g�����o���B
-(id)getStringOfArgment:(id/*NSString * */)argment
{
    /*
    NSString *firstCharStr;
    NSString *scanStr;
    NSString *resultForAlias;
     */
     return [ argment stringObj ];
     /*
    // 1�����ڂ������ɂ���ĕ���
    firstCharStr = [ argment substringWithRange:NSMakeRange(0,1) ];
    if( [ firstCharStr isEqualToString:@"\"" ]){
    // �����萔�̏ꍇ
        // �擪�Ɩ�����'"'���폜��������������̂܂ܕԂ��B
        if([ [ NSScanner scannerWithString:[ argment substringFromIndex:1 ] ] scanUpToString:
                @"\"" intoString:&scanStr ]){
            return scanStr;
        } else {
            return @"";
        }
        //NSLog(@"get constant String %@ from %@",scanStr,argment );
        //return (scanStr) ? scanStr : @"";
    } else if( [ firstCharStr isEqualToString:@"$" ]) {
        // �ϐ��̃C���f�b�N�X���ċA�I�Ɏ擾
        return [ scripterValues getStringValue:[ self getValueOfArgment:
                    [ argment substringFromIndex:1 ] ] ];
    } else if( [ firstCharStr isEqualToString:@"(" ]) {
        NSScanner *scanner=[ NSScanner scannerWithString:argment ];
        NSString *fileName,*trueStr,*falseStr;

        NSLog(@"%@",argment);
        [ scanner setScanLocation:1 ];
        [ scanner scanUpToString:@")" intoString:&fileName ];
        [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
        [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                             intoString:nil ];
        if([ [ argment substringWithRange:NSMakeRange([ scanner scanLocation ],1) ] isEqualToString:@"\"" ]) {
            [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
            [ scanner scanUpToString:@"\"" intoString:&trueStr ];
            [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
        } else {
            [ scanner scanUpToCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                                     intoString:&trueStr ];
        }

        if([ [ TYResourceServer sharedServer ] fchk:[ self getStringOfArgment:fileName ] ]){
            NSLog(@"fileName=%@[%@],TRUE\n,result=%@[%@]",fileName,[ self getStringOfArgment:fileName ],
                   trueStr,[ self getStringOfArgment:trueStr ]);
            return [ self getStringOfArgment:trueStr ];
        } else {
            [ scanner scanCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                                 intoString:nil ];
            
            if([ [ argment substringWithRange:NSMakeRange([ scanner scanLocation ],1) ] isEqualToString:@"\"" ]) {
                [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
                [ scanner scanUpToString:@"\"" intoString:&falseStr ];
            } else {
                [ scanner scanUpToCharactersFromSet:[ NSCharacterSet whitespaceCharacterSet ]
                                         intoString:&falseStr ];
            }
            NSLog(@"fileName=%@[%@],FALSE\n,result=%@[%@]",fileName,[ self getStringOfArgment:fileName ],
                   falseStr,[ self getStringOfArgment:falseStr ]);

            return [ self getStringOfArgment:falseStr ];
        }

        

    } else {
    // �G�C���A�X�̏ꍇ
        resultForAlias = [ strAliases objectForKey:[ argment lowercaseString ] ];
        if(resultForAlias){
            return resultForAlias;
        } else {
            return argment; // �G�C���A�X�ɓo�^����Ă��Ȃ���Ε���������̂܂ܕԂ��A�����񃉃x���W�J�΍�
            //goto ANALYZE_ERROR;
        }
    }
    */

/*    
ANALYZE_ERROR:
    NSLog(@"Not Get String Value from [%@]\n",argment);
    return nil;
 */

}

-(id)getIdNoOfArgment:(TYArgment*)argment
{
    return [ argment varID ];
    /*
    if([ argment length ] &&
       ([ [ argment substringWithRange:NSMakeRange(0,1) ] isEqualToString:@"?" ])){
       // �z��^
        return [ self getArrayIdOfArgment:argment ];
    } else {
        return [ self getValueOfArgment:[ argment substringFromIndex:1 ] ];
    } 
     */
}

-(id)getArrayIdOfArgment:(id/*NSString * */)argment
{
    return [ argment varID ];
    /*
    // �z��ϐ��̎w����擾�B
    NSMutableArray *aArray = [ NSMutableArray array ];
    NSScanner *scanner;
    NSString *bufStr;
    NSString *stopString = @"[";
    
    scanner = [ NSScanner scannerWithString:[ argment substringFromIndex:1 ] ];
    
    while([ scanner scanUpToString:stopString intoString:&bufStr ]){
        // �ϐ���W�J���Ċi�[
        [ aArray addObject:[ self getValueOfArgment:bufStr ] ];
        
        [ scanner setScanLocation:[ scanner scanLocation ]+1 ];
        [ scanner scanString:@"[" intoString:nil ];
        stopString = @"]";
    }
    
    return aArray;
    */
}

// �G�t�F�N�g�ԍ���Ԃ��B�����́ATYEffecter��-1�Ԃɓo�^���A-1��Ԃ��B
-(id)getEffectNoOfArgments:(NSMutableArray*)argments
{
    int count;
    
    count = [ argments count ];
    
    if(count == 1){
        return [ self getValueOfArgment:[ argments objectAtIndex:0 ] ];
    } else {
        [ argments insertObject:[ NSNull null ] atIndex:0 ];
        [ argments insertObject:[ NSNumber numberWithInt:-1 ] atIndex:1 ];
        [ stageManager performSelector:@selector(ty_effect:) withObject:argments ];
        return [ NSNumber numberWithInt:-1 ];
    }
}

-(id)intNumberWithVarID:(id)varID
{
    return [ scripterValues getIntValue:varID ];
}

-(id)stringValueWithVarID:(id)varID
{
    return [ scripterValues getStringValue:varID ];
}

-(id)intNumberWithAlias:(NSString*)aStr
{
    return [ numAliases objectForKey:aStr ];
}

-(id)stringValueWithAlias:(NSString*)aStr
{
    return [ strAliases objectForKey:aStr ];
}

// �����񒆂̕ϐ���W�J�����������Ԃ��B
-(NSString*)stringOfReplaceVars:(NSString *)aString
{
    NSCharacterSet *varHeaderSet = [ NSCharacterSet characterSetWithCharactersInString:@"$%" ];
    NSString *replaceStr,*str=nil,*symbol;
    NSScanner *scanner;
    NSMutableArray *array;
    
    scanner = [ NSScanner scannerWithString:aString ];
    [ scanner scanUpToCharactersFromSet:varHeaderSet intoString:&str ];
    if([ scanner isAtEnd ]==NO){
        array = [ NSMutableArray arrayWithCapacity:1 ];
        while(1){
            if(str)
                [ array addObject:str ];
            symbol = [ [ scanner string ] substringWithRange:NSMakeRange([ scanner scanLocation ],1) ];
            [ scanner setScanLocation:[ scanner scanLocation ] +1 ];
            [ scanner scanCharactersFromSet:[ NSCharacterSet varNameCharacterSet ] intoString:&str ];
            if([ symbol isEqualToString:@"$" ]){
                [ array addObject:[ self getStringOfArgment:
                    [ TYStringVarArgment argmentWithVarID:
                        [ NSNumber numberWithInt:[ str intValue ] ] ] ] ];
            } else if([ symbol isEqualToString:@"%" ]){
                NSNumber *number;
                number = [ self getValueOfArgment:
                            [ TYIntVarArgment argmentWithVarID:
                                [ NSNumber numberWithInt:[ str intValue ] ] ] ];
                [ array addObject:[ number stringValue ] ];
            }

            str = nil;
            [ scanner scanUpToCharactersFromSet:varHeaderSet intoString:&str ];
            if([ scanner isAtEnd ])
                break;
        }
        if(str)
            [ array addObject:str ];

        replaceStr = [ array componentsJoinedByString:@"" ];
    } else {
        replaceStr = aString;
    }
    
    return replaceStr;
}

-(void)saveExternalData
{
    if(globalOn){
        [ scripterValues saveGlobalValues:[ getNScrRootDirectory()
            stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    }

    if(labelLog)
        [ labelLog writeToFile:[ getNScrRootDirectory() stringByAppendingPathComponent:LABELLOG_FILENAME ] ];

    if(kidokuData)
        [ kidokuData writeToFile:[ getNScrRootDirectory() stringByAppendingPathComponent:KIDOKU_FILENAME ] atomically:YES ];
}

#if YYDEBUG == 1
extern int yydebug;
-(void)ty__yydebug:(NSMutableArray *)argments
{
    yydebug = [ [ argments objectAtIndex:1 ] intValue ];
}
#endif

-(void)ty__log:(NSMutableArray*)argments
{
    TYArgment *arg;
    
    arg = [ argments objectAtIndex:1 ];
    switch([ arg argType ]) {
    case TYDigitArgType:
    case TYIntVarArgType:
        NSLog(@"log it's number,[%d]",[ arg intValue ]);
        break;
    case TYConstStringArgType:
    case TYStringVarArgType:
    case TYFchkArgType:
        NSLog(@"log it's string,[%@]",[ arg stringObj ]);
        break;
    case TYAliasArgType:
        NSLog(@"log it's alias,name[%@],string[%@],number[%@]",[arg rawString],[arg stringObj],[arg intNumber ]);
    }
    
}

-(void)ty_globalon:(NSMutableArray *)argments
{
    // �O���[�o���ϐ������[�h���A�I�����ɕۑ�����悤�ɂ���B
    
    /*aData = [ NSMutableData dataWithContentsOfFile:
                [ getAppDirectory() stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    */
    
    
    // MEMO:�������݌����̃`�F�b�N�������
    {
        globalOn = YES;
    }

}

/*
-(void)saveGlobal // �A�v���I�����ɌĂԎ�
{
    if(globalOn){         
        [ scripterValues saveGlobalValues:[ getAppDirectory() 
            stringByAppendingPathComponent:GLOBAL_SAVEFILE_NAME ] ];
    }
}
*/


/*
-(void)saveLabelLog
{
    if(labelLog)
        [ labelLog writeToFile:[ getAppDirectory() stringByAppendingPathComponent:LABELLOG_FILENAME ] ];
}
*/

-(int)runLine
{
    return runLine;
}

-(void)moveRunLine:(int)aInt
{
    runLine += aInt;
}

-(void)incRunColumn
{
    runColumn++;
}

-(void)resetRunColumn
{
    runColumn=0;
}

-(void)ty_labellog:(NSMutableArray *)argments
{
    labelLog = [ [ TYFileLog alloc ] initWithContentsOfFile:[ getNScrRootDirectory()  	stringByAppendingPathComponent:LABELLOG_FILENAME ] ];
    
}

-(void)ty_getversion:(NSMutableArray *)argments
{
    NSNumber *verNum;
    id idno;
    verNum = [ TYEnviroment objectForKey:@"NScripterVersion" ];
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    [ scripterValues setIntValue:idno object:verNum ];
}

// �z��ϐ��̐錾
-(void)ty_dim:(NSMutableArray *)argments
{
    id idno;
    
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    
    [ scripterValues defineArrayValue:idno ];
}

-(void)ty_movl:(NSMutableArray *)argments
{
    id idno;
    NSEnumerator *enu;
    NSMutableArray *array = [ NSMutableArray array ];
    id tmp;
    
    enu = [ argments objectEnumerator ];
    [ enu nextObject ];
    
    idno = [ self getArrayIdOfArgment:[ enu nextObject ] ];
    
    while(tmp = [ enu nextObject ]){
        [ array addObject:[ self getValueOfArgment:tmp ] ];
    }
    
    [ scripterValues setArrayLine:idno values:array ];

}

//  �ϐ��ɑ��
-(void)ty_mov:(NSMutableArray *)argments
{
    TYVarType type;
    id arg;
    id idno;

    type = [ [ argments objectAtIndex:1 ] varType ];
    
    // �ϐ���ID���擾
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
        
    if(type == TYStringVarType){
        arg = [ self getStringOfArgment:[ argments objectAtIndex:2 ] ];
        [ scripterValues setStringValue:idno object:arg ];
    } else if(type & TYDigitVarTypeMask) {
        arg = [ self getValueOfArgment:[ argments objectAtIndex:2 ] ];
        [ scripterValues setIntValue:idno object:arg ];
    }
}

-(void)ty_mov3:(NSMutableArray*)argments
{
    [ self movRepeat:3 argments:(NSMutableArray*)argments ];
}

-(void)ty_mov4:(NSMutableArray*)argments
{
    [ self movRepeat:4 argments:(NSMutableArray*)argments ];
}

-(void)ty_mov5:(NSMutableArray*)argments
{
    [ self movRepeat:5 argments:(NSMutableArray*)argments ];
}

-(void)ty_mov6:(NSMutableArray*)argments
{
    [ self movRepeat:6 argments:(NSMutableArray*)argments ];
}

-(void)ty_mov7:(NSMutableArray*)argments
{
    [ self movRepeat:7 argments:(NSMutableArray*)argments ];
}

-(void)ty_mov8:(NSMutableArray*)argments
{
    [ self movRepeat:8 argments:(NSMutableArray*)argments ];
}

-(void)ty_mov9:(NSMutableArray*)argments
{
    [ self movRepeat:9 argments:(NSMutableArray*)argments ];
}

-(void)ty_mov10:(NSMutableArray*)argments
{
    [ self movRepeat:10 argments:(NSMutableArray*)argments ];
}

-(void)movRepeat:(int)repeat_times argments:(NSMutableArray*)argments
{
    TYVarType type;
    int i;
    int intId;
    NSEnumerator *enm;
    id temp;

    enm = [ argments objectEnumerator ];
    [ enm nextObject ];

    temp = [ enm nextObject ];
    type = [ temp varType ];
    intId = [ [ self getIdNoOfArgment:temp ] intValue ];

    if(type & TYDigitVarTypeMask){
        for(i=0; i < repeat_times; i++,intId++){
            [ scripterValues setIntValue:[ NSNumber numberWithInt:intId ] object:[ self getValueOfArgment:[ enm nextObject ] ] ];
        }
    } else if(type == TYStringVarType) {
        for(i=0; i < repeat_times; i++,intId++){
            [ scripterValues setStringValue:[ NSNumber numberWithInt:intId ] object:[ self getStringOfArgment:[ enm nextObject ] ] ];
        }
    } else {
        NSLog(@"movX,error of arg 1,invalid context");
    }
}

-(void)ty_intlimit:(NSMutableArray *)argments
{
    [ scripterValues setIntLimitID:[ self getValueOfArgment:[ argments objectAtIndex:1 ] ]
                               low:[ self getValueOfArgment:[ argments objectAtIndex:2 ] ] 				      high:[ self getValueOfArgment:[ argments objectAtIndex:3 ] ] ];
}

// �ϐ��̃C���N�������g
-(void)ty_inc:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;
    
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] +1 ];
    [ scripterValues setIntValue:idno object:number ];
    
}
// �ϐ��̃f�N�������g
-(void)ty_dec:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;
    
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] -1 ]; 
    [ scripterValues setIntValue:idno object:number ];
    
}

// �ϐ��̑����Z ������Ȃ�A������
-(void)ty_add:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;
    NSNumber *argnum;
    NSString *string;
    NSString *argstr;
    
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    if( [ [ argments objectAtIndex:1 ] varType ] == TYStringVarType ){
        argstr = [ self getStringOfArgment:[ argments objectAtIndex:2 ] ];
        string = [ scripterValues getStringValue:idno ];
        string = [ NSString stringWithFormat:@"%@%@",string,argstr ];
        [ scripterValues setStringValue:idno object:string ];
    } else {
        argnum = [ self getValueOfArgment:[argments objectAtIndex:2 ] ];
        number = [ scripterValues getIntValue:idno ];
        number = [ NSNumber numberWithInt:[ number intValue] +[ argnum intValue ] ];
        [ scripterValues setIntValue:idno object:number ];
    }
    
    return ;
}

// �ϐ��̈����Z
-(void)ty_sub:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;
    NSNumber *argnum;
    
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ self getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] -[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_mul:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;
    NSNumber *argnum;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ self getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] *[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_div:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;
    NSNumber *argnum;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ self getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] /[ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_mod:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;
    NSNumber *argnum;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    argnum = [ self getValueOfArgment:[ argments objectAtIndex:2 ] ];

    number = [ scripterValues getIntValue:idno ];
    number = [ NSNumber numberWithInt:[ number intValue] % [ argnum intValue ] ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_cmp:(NSMutableArray *)argments
{
    id idno;
    int result;
    
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    result = [ (NSString*)[ self getStringOfArgment:[ argments objectAtIndex:2 ] ] compare: 
                [ self getStringOfArgment:[ argments objectAtIndex:3 ] ] ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];            
    
}

-(void)ty_atoi:(NSMutableArray*)argments
{
    id idno;
    NSString *str;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    str = [ self getStringOfArgment:[ argments objectAtIndex:2 ] ];

    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:[ str intValue ] ] ];
}

-(void)ty_itoa:(NSMutableArray*)argments
{
    id idno;
    int value;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    value = [ [ self getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];

    [ scripterValues setStringValue:idno object:[ NSString stringWithFormat:@"%d",value ] ];
}

-(void)ty_len:(NSMutableArray*)argments
{
    id idno;
    unsigned length;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    length = [ [ self getStringOfArgment:[ argments objectAtIndex:2 ] ] cSJISStringLength ];

    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:length ] ];
}

-(void)ty_mid:(NSMutableArray *)argments
{
    id idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    NSString *inStr = [ self getStringOfArgment:[ argments objectAtIndex:2 ] ];
    int offset = [ [ self getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];
    int length = [ [ self getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ];
    
    [ scripterValues setStringValue:idno object:[ inStr substringSJISRange:NSMakeRange(offset,length) ] ];
}

-(void)ty_splitstring:(NSMutableArray *)argments
{
    NSString *scrStr;
    NSString *tmpStr;
    NSEnumerator *argEnu,*scrEnu;
    
    argEnu = [ argments objectEnumerator ];
    [ argEnu nextObject ];
    scrStr = [ [ argEnu nextObject ] stringObj ];
    scrEnu = [ [ scrStr componentsSeparatedByString:[ [ argEnu nextObject ] stringObj ] ] objectEnumerator ];
    while(tmpStr = [ scrEnu nextObject ]) {
        [ self ty_mov:[ NSMutableArray arrayWithObjects:@"mov",
                            [ argEnu nextObject ],
                            [ TYConstStringArgment argmentWithString:tmpStr ],nil ]  ];
    }
}

-(void)ty_rnd:(NSMutableArray *)argments
{
    id idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    int max = [ [ self getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    int result;
    
    result = TYRandom(0,max -1);
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];
}

-(void)ty_rnd2:(NSMutableArray *)argments
{
    int min,max,result;
    id idno;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    min = [ [ self getValueOfArgment:[ argments objectAtIndex:2 ] ] intValue ];
    max = [ [ self getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ];

    result = TYRandom(min,max);

    //NSLog(@"random,min=%d,max=%d,result=%d",min,max,result);
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:result ] ];
}

-(void)ty_date:(NSMutableArray *)argments
{
    NSCalendarDate *cDate;
    id idno;
    int d;

    cDate = [ NSCalendarDate calendarDate ];
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    d = [ cDate yearOfCommonEra ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    d = [ cDate monthOfYear ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:3 ] ];
    d = [ cDate dayOfMonth ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
}

-(void)ty_time:(NSMutableArray *)argments
{
    NSCalendarDate *cDate;
    id idno;
    int d;

    cDate = [ NSCalendarDate calendarDate ];
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    d = [ cDate hourOfDay ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    d = [ cDate minuteOfHour ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:3 ] ];
    d = [ cDate secondOfMinute ];
    [ scripterValues setIntValue:idno object:[ NSNumber numberWithInt:d ] ];
}

// ������G�C���A�X�̓o�^
-(void)ty_stralias:(NSMutableArray *)argments
{
    [ strAliases setObject: [ self getStringOfArgment:[ argments objectAtIndex:2 ] ] 
                forKey:[ [ argments objectAtIndex:1 ] lowercaseString ] ];
    return;
}

// �����G�C���A�X�̓o�^
-(void)ty_numalias:(NSMutableArray *)argments
{
    [ numAliases setObject:[ self getValueOfArgment:[ argments objectAtIndex:2 ] ]
                forKey:[ [ argments objectAtIndex:1 ] lowercaseString ] ];
    return;
}

// �A�[�J�C�o��o�^
-(void)ty_arc:(NSMutableArray *)argments
{
    [ [ TYResourceServer sharedServer ] addArchiver:[ self getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

// NSA�A�[�J�C�u��ǂ�
-(void)ty_nsa:(NSMutableArray *)argments
{
    int i;
    NSString *dir = ( nsaDir ) ? nsaDir : @"";

    [ [ TYResourceServer sharedServer ] addArchiver:
        [ dir stringByAppendingPathComponent:[ NSString stringWithFormat:DEFALUT_NSA_ARCHIVE,@"" ] ] ];

    for(i=1;i<=9;i++){
        [ [ TYResourceServer sharedServer ] addArchiver:
            [ dir stringByAppendingPathComponent:[ NSString stringWithFormat:DEFALUT_NSA_ARCHIVE,[ NSString stringWithFormat:@"%d",i ] ] ] ];
    }

}

-(void)ty_nsadir:(NSMutableArray *)argments
{
    nsaDir = [ self getStringOfArgment:[ argments objectAtIndex:1 ] ];
}

-(void)ty_ns2:(NSMutableArray *)argments
{
    [ TYNsaArchiver setMode:TY2TypeNsaFileMode ];
    [ self ty_nsa:nil ];
}

-(void)ty_ns3:(NSMutableArray *)argments
{
    [ TYNsaArchiver setMode:TY3TypeNsaFileMode ];
    [ self ty_nsa:nil ];
}

// �E�C���h�E�^�C�g���̕ύX
/*-(void)ty_caption:(NSMutableArray *)argments
{
    [ controller ty_caption:[ self getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
    return;
}*/


// �G�t�F�N�g��o�^
/*-(void)ty_effect:(NSMutableArray *)argments
{
    int count;
    NSNumber *effectNo=nil,*effectType=nil,*time=nil;
    NSString *path=nil;
    
    count = [ argments count ];
    
    switch(count){
    case 5:
        path = [ self getStringOfArgment:[ argments objectAtIndex:4 ] ];
    case 4:
        time = [ self getValueOfArgment:[ argments objectAtIndex:3 ] ];
    case 3:
        effectType = [ self getValueOfArgment:[ argments objectAtIndex:2 ] ];
        effectNo = [ self getValueOfArgment:[ argments objectAtIndex:1 ] ];
    }
    
    [ [ stageManager effecter ] setEffectNo:[ effectNo intValue ]
                                type:[ effectType intValue ]
                                time:[ time intValue ]
                                path:path ];
                                
}*/

/*-(void)ty_bg:(NSMutableArray *)argments
{
    NSNumber *effNo;
    
    effNo = [ self getEffectNoOfArgments:[ NSMutableArray arrayWithArray:
        [ argments subarrayWithRange:NSMakeRange(2,[ argments count]-2) ] ] ];

    [ stageManager ty_bg:[ self getStringOfArgment:[ argments objectAtIndex:1 ] ] effectNo:[ effNo intValue ] ];
}*/

/*-(void)ty_click:(NSMutableArray *)argments
{
    [ self setBreakRun:YES ];
    [ controller ty_click ];
}*/


/*-(void)ty_wait:(NSMutableArray *)argments
{
    [ self setBreakRun:YES ];
    [ controller setStatus:TYTimeWaitStatus ];
    [ self performSelector:@selector(runScript) withObject:nil afterDelay:
        [ [ self getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ] / 10 ];
}*/

-(void)ty_jumpf:(NSMutableArray *)argments
{
    [ self labeljump:@"~" fromLine:runLine reverse:NO ];
}

-(void)ty_jumpb:(NSMutableArray *)argments
{
    [ self labeljump:@"~" fromLine:runLine reverse:YES ];
}

-(void)ty_goto:(NSMutableArray *)argments
{
    [ self labeljump:[ self getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

-(void)ty_gosub:(NSMutableArray *)argments
{
    TYScriptPoint sPoint;
    sPoint = TYMakeScriptPoint(runLine,runColumn);
    [ returnStack addObject:[ NSValue valueWithBytes:&sPoint objCType:@encode(TYScriptPoint) ] ];
    [ self labeljump:[ self getStringOfArgment:[ argments objectAtIndex:1 ] ] ];
}

-(void)ty_return:(NSMutableArray *)argments
{
    TYScriptPoint sPoint;
    [ [ returnStack lastObject ] getValue:&sPoint ];
    [ self jump:sPoint.line ];
    runColumn = sPoint.column;
    [ returnStack removeLastObject ];
    
    // �V�X�e���J�X�^�}�C�Y���Atextgosub�ŌĂ΂ꂽ�Ƃ��납��Ԃ�Ȃ�
    if((textgosubPointIndex > -1) &&
       (textgosubPointIndex == [ returnStack count ])){
       [ self setBreakRun:YES ];
       [ stageManager resumePrinting ];
       textgosubPointIndex = -1;
    }
}

-(void)ty_tablegoto:(NSMutableArray *)argments
{
    int num=[ [ self getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    [ self ty_goto:[ NSMutableArray arrayWithObjects:@"goto",[ argments objectAtIndex:2+num ],nil ] ];
}

-(void)ty_skip:(NSMutableArray *)argments
{
    int step = [ [ self getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];
    if(step)
        runLine += step -1;
}

-(void)ty_next:(NSMutableArray *)argments
{
    TYLoopStruct loop;
    int now;

    NSAssert(([ loopStack count ] > 0),@"do next,but no loop stack");
    [ [ loopStack lastObject ] getValue:&loop ];

    now=[ [ scripterValues getIntValue:loop.varNo ] intValue ]+loop.step;
    [ scripterValues setIntValue:loop.varNo object:[ NSNumber numberWithInt:now ] ];

    if((loop.step>0 && now>loop.limit) || (loop.step<0 && now<loop.limit)){
        NSLog2(@"remove for stack");
        [ loopStack removeLastObject ];
    } else {
        runLine=loop.point.line;
        runColumn=loop.point.column;
        if(runColumn==0)
            runColumn++;
    }
}

-(void)ty_break:(NSMutableArray *)argments
{
    NSLog(@"remove for stack");
    [ loopStack removeLastObject ];
    if([ argments count ] >= 2) {
        [ self ty_goto:argments ];
    } else
        [ self jumpToLoopEnd ];
}

-(void)ty_game:(NSMutableArray *)argments
{
    [ self labeljump:@"*start" ];
}

-(void)ty_resettimer:(NSMutableArray *)argments
{
    //[ timerStartDate release ];
    timerStartDate = [ [ NSDate alloc ] init ];
}

-(void)ty_waittimer:(NSMutableArray *)argments
{
    int timerValue;
    NSTimeInterval interval=[ timerStartDate timeIntervalSinceNow ];
    NSTimeInterval delay;

    timerValue = [ [ self getValueOfArgment:[ argments objectAtIndex:1 ] ] intValue ];

    delay = timerValue / 1000.0 +interval;
    if(delay < 0)
        delay = 0;

    [ self setBreakRun:YES ];    

    [ self performSelector:@selector(runScript) withObject:nil afterDelay:
        timerValue / 1000.0 +[ timerStartDate timeIntervalSinceNow ] ];
}

-(void)ty_gettimer:(NSMutableArray *)argments
{
    id idno;
    NSNumber *number;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];

    number = [ NSNumber numberWithInt:-[ timerStartDate timeIntervalSinceNow ] *1000 ];
    [ scripterValues setIntValue:idno object:number ];
}

-(void)ty_loadgame:(NSMutableArray *)argments
{
    NSNumber *number;

    number = [ self getValueOfArgment:[ argments objectAtIndex:1 ] ];

    [ controller loadLocalData:number ];    
}

-(void)ty_savegame:(NSMutableArray *)argments
{
    NSNumber *number;

    number = [ self getValueOfArgment:[ argments objectAtIndex:1 ] ];

    [ controller saveLocalData:number ];
}

// �v���O�����̏I��
-(void)ty_end:(NSMutableArray *)argments
{
    // �����ݒ�̃Z�[�u
    // �O���[�o���ϐ��̃Z�[�u
    [ NSApp terminate:self ];
}

-(void)ty_inputstr:(NSMutableArray *)argments
{
    id idno;
    TYInputStrController *input;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    input = [ TYInputStrController dialog ];
    [ input runModalCaption:[ self getStringOfArgment:[ argments objectAtIndex:2 ] ]
                     length:[ [ self getValueOfArgment:[ argments objectAtIndex:3 ] ] intValue ]
                   notAscii:[ [ self getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ] ];

    [ scripterValues setStringValue:idno object:[ input string ] ];

}

-(void)ty_input:(NSMutableArray *)argments
{
    id idno;
    TYInputStrController *input;

    idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    input = [ TYInputStrController dialog ];
    [ input runModalCaption:[ self getStringOfArgment:[ argments objectAtIndex:2 ] ]
                 defaultStr:[ self getStringOfArgment:[ argments objectAtIndex:3 ] ]
                     length:[ [ self getValueOfArgment:[ argments objectAtIndex:4 ] ] intValue ]
                   notAscii:[ [ self getValueOfArgment:[ argments objectAtIndex:5 ] ] intValue ] ];

    [ scripterValues setStringValue:idno object:[ input string ] ];

}

-(void)ty_mesbox:(NSMutableArray *)argments
{
    NSRunInformationalAlertPanel([ self getStringOfArgment:[ argments objectAtIndex:2 ] ],[ self getStringOfArgment:[ argments objectAtIndex:1 ] ],@"OK",nil,nil);
    
}

-(void)ty_getreg:(NSMutableArray *)argments
{
    NSDictionary *aDict=[ NSDictionary dictionaryWithContentsOfFile:[ getNScrRootDirectory() stringByAppendingPathComponent:REGISTRY_NAME ] ];
    NSString *key;
    NSString *name;
    NSString *value;
    NSDictionary *keyDict;
    id idno;

    key = [ self getStringOfArgment:[ argments objectAtIndex:2 ] ];
    name = [ self getStringOfArgment:[ argments objectAtIndex:3 ] ];

    if((aDict)&&(keyDict = [ aDict objectForKey:key ])){
        value = [ keyDict objectForKey:name ];
        idno = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
        [ scripterValues setStringValue:idno object:value ];
    }
    
}

-(void)ty_getcursorpos:(NSMutableArray*)argments
{
    NSPoint point;
    id varX,varY;
    
    varX = [ self getIdNoOfArgment:[ argments objectAtIndex:1 ] ];
    varY = [ self getIdNoOfArgment:[ argments objectAtIndex:2 ] ];
    
    point = [ stageManager drawPoint ];
    [ scripterValues setIntValue:varX object:[ NSNumber numberWithInt:point.x ] ];
    [ scripterValues setIntValue:varY object:[ NSNumber numberWithInt:VSCREEN_HEIGHT -point.y ] ];
}

-(void)ty_lr_trap:(NSMutableArray*)argments 
{
    [ self ty_trap:argments ];
}

-(void)ty_trap:(NSMutableArray*)argments
{
    NSString *arg=[ argments objectAtIndex:1 ];
    NSString *carg = [ self getStringOfArgment:arg ];

    if([ arg compare:@"off" options:NSCaseInsensitiveSearch ]==NSOrderedSame){
        //if(labelWithTrap)
        //    [ labelWithTrap release ];
        labelWithTrap=nil;
        fireOfTrap = NO;
        [ controller setTrap:NO ];
    } else if([ arg compare:@"stop" options:NSCaseInsensitiveSearch ]==NSOrderedSame){
        fireOfTrap = NO;
        [ controller setTrap:NO ];        
    } else if([ arg compare:@"resume" options:NSCaseInsensitiveSearch ]==NSOrderedSame){
        fireOfTrap = NO;
        [ controller setTrap:YES ];    
    } else {
        labelWithTrap=carg;
        fireOfTrap = NO;
        [ controller setTrap:YES ];
    }
}

-(void)fireOfTrap
{
    if(labelWithTrap)
        fireOfTrap=YES;
}

-(void)fireOfTextgosub:(NSString*)aLabel
{
    TYScriptPoint point;
    point = TYMakeScriptPoint(runLine,runColumn);
    [ self ty_gosub:[ NSMutableArray arrayWithObjects:@"gosub",aLabel,nil ] ];
    textgosubPointIndex = [ returnStack count ] -1;
    [ self runScript ];
}

-(void)enableKidoku
{
    kidokuData=[ [ NSMutableData alloc ] initWithContentsOfFile:
        [ getNScrRootDirectory() stringByAppendingPathComponent:KIDOKU_FILENAME ] ];
    if(!kidokuData){
        kidokuData = [ [ NSMutableData alloc ] initWithLength:[ ScriptArray count ] / 8 +1 ];
    } else {
        if([ kidokuData length ] < [ ScriptArray count ] / 8 +1){
            [ kidokuData setLength:[ ScriptArray count ] / 8 +1 ];
        }
    }

    kidokuptr = (unsigned char*)[ kidokuData mutableBytes ];
}

-(void)setWatchKidoku:(BOOL)aBool
{
    isWatchKidoku = aBool;
}

@end
