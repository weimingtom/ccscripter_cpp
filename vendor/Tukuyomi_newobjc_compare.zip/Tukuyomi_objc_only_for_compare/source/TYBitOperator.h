//
//  TYBitOperator.h
//  Tukuyomi
//
//  Created by toveta on Mon Jun 17 2002.
//  Copyright (c) 2002 toveta All rights reserved.
//
/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND 
 * &ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#import <Foundation/Foundation.h>

// bit�P�ʂŃX�g���[������f�[�^�����o��
// NONAKA Kimihiro���̃\�[�X��Objective-C�ɈڐA�������̂ł��B

@interface TYBitOperator : NSObject {
    NSFileHandle *fh;
    size_t size;
    unsigned int mask;
    unsigned char tmp;
}
-(id)initWithFileHandle:(NSFileHandle*)f size:(unsigned int)s;
-(int)get;
-(unsigned int)getWithLength:(int)n;

@end

struct tyCoreBitOperater {
    int fd;
    //size_t size;
    unsigned int mask;
    unsigned char tmp;
};
typedef struct tyCoreBitOperater *TYCoreBitOperater;
TYCoreBitOperater TYCreateCoreBitOperater(NSFileHandle*,unsigned int);
__inline__ int TYGetCoreBitOperater(TYCoreBitOperater);
__inline__ unsigned int TYGetBitsCoreBitOperater(TYCoreBitOperater,int);
void TYReleaseCoreBitOperater(TYCoreBitOperater);
