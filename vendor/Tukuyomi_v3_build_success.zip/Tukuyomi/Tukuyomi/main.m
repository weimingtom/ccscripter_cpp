//
//  main.m
//  Tukuyomi
//
//  Created by Macmini on 2025/6/28.
//  Copyright © 2025 Macmini. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
