//
//  AppDelegate.h
//  Tukuyomi
//
//  Created by Macmini on 2025/6/28.
//  Copyright © 2025 Macmini. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

