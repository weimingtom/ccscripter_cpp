//
//  ViewController.m
//  Tukuyomi
//
//  Created by Macmini on 2025/6/28.
//  Copyright © 2025 Macmini. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
